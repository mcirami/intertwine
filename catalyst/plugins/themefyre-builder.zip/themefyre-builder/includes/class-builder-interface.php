<?php

// No direct access
defined( 'ABSPATH' ) or exit;

// Immediately invoke this class
new Builder_Interface();

/**
 * Themefyre Page Builder Interface Class
 *
 * Allows users to visually build their pages and generate shortcodes.
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
final class Builder_Interface {

   /**
    * Associative array of post types to apply the builder to.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    * @var array
    */
   public $screens;

   /**
    * Builder_Interface Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $this->screens = apply_filters( 'page_builder_screens', builder_get_screens() );

      // Load initial actions
      add_action( 'load-post.php',     array( $this, 'admin_init' ) );
      add_action( 'load-post-new.php', array( $this, 'admin_init' ) );

      // Array containing each AJAX action
      $actions = array(
         'get_image_preview',
         'get_gallery_preview',
         'get_builder_modules',
         'get_post_builder_value',
         'get_post_builder_css',
         'delete_post',
         'create_template',
         'get_premade_template',
      );

      // register each AJAX action
      foreach ( $actions as $action ) {
         add_action('wp_ajax_builder_ajax_' . $action, array( $this, $action . '_callback' ) );
         add_action('wp_ajax_nopriv_builder_ajax_' . $action, array( $this, $action . '_callback' ) );
      }
   }

   /**
    * Used to confirm page builder has been applied to the current screen.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access private
    *
    * @return bool
    */
   private function check_screen() {
      $screen = get_current_screen();
      return in_array( $screen->id, $this->screens );
   }


   /**
    * Called on admin post pages
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function admin_init() {
      if ( ! $this->check_screen() ) {
         return;
      }

      $this->add_actions();
      $this->add_help_tab();
      $this->apply_editor_wrap();
      add_action('admin_enqueue_scripts', array( $this, 'load_assets' ), 10 );
   }

   /**
    * Apply various required actions.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function add_actions() {
      add_action( 'save_post',        array( $this, 'update_meta_values' ) );
      add_action( 'media_buttons',    array( $this, 'insert_tmce_button' ) );
      add_action( 'admin_head',       array( $this, 'inline_styles' ) );
      add_action( 'admin_footer',     array( $this, 'inline_script' ) );
      add_action( 'admin_footer',     array( $this, 'template_manager_modal_template' ) );
      add_action( 'admin_footer',     array( $this, 'icon_picker_modal_template' ) );
      add_action( 'admin_footer',     array( $this, 'available_shortcodes_modal_templates' ) );
      add_action( 'admin_footer',     array( $this, 'available_row_shortcodes_modal_template' ) );
      add_action( 'admin_footer',     array( $this, 'edit_shortcode_modal_templates' ) );
      add_action( 'admin_footer',     array( $this, 'builder_module_templates' ) );
      add_action( 'admin_footer',     array( $this, 'builder_row_module_templates' ) );
      add_action( 'admin_footer',     array( $this, 'insert_shortcode_content_tmce_editor' ) );
      add_action( 'admin_footer',     array( $this, 'insert_instant_preview_notifications' ) );
      add_filter( 'admin_body_class', array( $this, 'add_body_class' ) );
   }

   /**
    * Adds several help tabs to the dashboard.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function add_help_tab() {
      $screen = get_current_screen();

      $screen->add_help_tab( array(
         'id'       => 'themefyre-builder',
         'title'    => __( 'Page Builder', 'themefyre_builder' ),
         'callback' => array( $this, 'help_tab_content' ),
      ) );
   }

   /**
    * Renders the content for the help tab.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function help_tab_content() {
      ?>
         <p><?php echo wp_kses( __( '<strong>Introduction</strong> - The page builder is a tool that allows you to build your pages/posts using a visual editor. Each module in the page builder represents a standard WordPress shortcode. While the page builder is active a custom page template will be used to display the page/post automatically.', 'themefyre_builder' ), array('strong'=>array()) ); ?></p>
         <p><?php echo wp_kses( __( '<strong>Getting Started</strong> - The page builder is organized into three distinct layers. Full width modules stretch to fill the width of the outer container. Row modules are placed directly within certain full width modules and are responsible for the horizontal layout of the page. Content modules live inside of the row modules, and as their name suggests are responsible for creating the actual content of your page.', 'themefyre_builder' ), array('strong'=>array()) ); ?></p>
         <p><?php echo wp_kses( __( '<strong>Importing Content</strong> - Pressing the "Import Post" icon immediately above the page builder will open a modal containing a list of other pages/posts which have the page builder enabled. From here you can select one of these pages/posts and its content will be appended to the content of the current page/post.', 'themefyre_builder' ), array('strong'=>array()) ); ?></p>
      <?php
   }

   /**
    * Loads required page builder assets.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function load_assets() {
      $builder = builder();

      // Load WP Color Picker
      wp_enqueue_style( 'wp-color-picker' );
      wp_enqueue_script( 'wp-color-picker' );

      // Load enabled Google fonts
      builder_enqueue_google_fonts();

      // Load enabled icon fonts
      builder_enqueue_icon_fonts();

      // Codemirror stylesheet
      wp_enqueue_style( 'builder-codemirror' );

      // Codemirror script
      wp_enqueue_script( 'builder-codemirror' );

      // // WP Editor Integration Script
      wp_enqueue_script( 'builder-wp-editor' );

      // General admin media script
      wp_enqueue_script( 'builder-media' );

      // Admin modal stylesheet
      wp_enqueue_style( 'builder-modal' );

      // Admin modal script
      wp_enqueue_script( 'builder-modal' );

      // Shortcode composer stylesheet
      wp_enqueue_style( 'builder-interface' );

      // Page Builder script
      wp_enqueue_script( 'builder-interface' );
   }

   /**
    * Outputs additional inline styles specific to the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function inline_styles() {
      // Use this hook to add custom inline styles to the page builder
      do_action('builder_inline_styles');
   }

   /**
    * Outputs additional inline JavaScript specific to the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function inline_script() {
      ?>
         <script>
            // Ensure availability of the global themefyreBuilder object
            window.themefyreBuilder = window.themefyreBuilder || {};

            // This object will contain the various JavaScript callbacks for
            // dynamically rendering certain module previews
            themefyreBuilder.modulePreviewCallbacks = {};

            // Disables a control, requires the original change event
            themefyreBuilder.disableControl = function( $control, event ) {
               if ( undefined === event.originalEvent ) {
                  $control.hide();
               }
               else {
                  $control.slideUp();
               }
               $control.addClass('is-disabled')
            };

            // Enables a control, requires the original change event
            themefyreBuilder.enableControl = function( $control, event ) {
               if ( event.originalEvent === undefined ) {
                  $control.show();
               }
               else {
                  $control.slideDown();
               }
               $control.removeClass('is-disabled')
            };
         </script>
      <?php

      // Use this hook to add custom inline JavaScript to the page builder
      do_action('builder_inline_script');
   }

   /**
    * Wraps the default editor appropriately.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function apply_editor_wrap() {
      add_action( 'edit_form_after_title',  array( $this, 'before_editor' ), 100000 );
      add_action( 'edit_form_after_editor', array( $this, 'after_editor' ),  1 );
   }

   /**
    * Modifies the `body` element class to reflect which editor is active.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function add_body_class() {
      return 'page-builder-'.builder_get_state();
   }

   /**
    * Inserts the button to add/edit a shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function insert_tmce_button() {
      ?>
         <button type="button" class="button" id="builder-insert-shortcode" title="<?php esc_attr_e( 'Add Page Builder Shortcode', 'themefyre_builder' ) ?>" style="display: none;">
            <?php esc_html_e( 'Add Page Builder Shortcode', 'themefyre_builder' ) ?>
         </button>
      <?php
   }

   /**
    * Outputs HTML to be placed before the default editor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function before_editor() {
      $inactive_text = __( 'Themefyre Page Builder', 'themefyre_builder' );
      $active_text   = __( 'Default Editor', 'themefyre_builder' );
      $button_text   = 'active' == builder_get_state() ? $active_text : $inactive_text;
      ?>
         <button type="button" class="button button-primary hide-if-no-js" id="builder-toggle" data-inactive-text="<?php echo esc_attr( $inactive_text ); ?>" data-active-text="<?php echo esc_attr( $active_text ); ?>">
            <?php echo esc_html( $button_text ); ?>
         </button>
         <?php $this->render_builder(); ?>
         <div id="builder-default-editor-wrap">
      <?php
   }

   /**
    * Outputs HTML to be placed after the default editor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function after_editor() {
      ?>
         </div><!-- #builder-default-editor-wrap -->
         <div id="builder-faux-content-wrap" style="display:none;"></div>
      <?php
   }

   /**
    * Apply various required actions.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param int $post_id The ID of the post being updated
    */
   public function update_meta_values( $post_ID ) {

      // Update the value of the current editor
      $builder_state = isset( $_POST['_themefyre_builder_state'] ) ? $_POST['_themefyre_builder_state'] : 'inactive';
      if ( ! in_array( $builder_state, array( 'active', 'inactive' ) ) ) $builder_state = 'inactive';
      update_post_meta( $post_ID, '_themefyre_builder_state', $builder_state );

      // Always update the `temporary` value which is only used when in preview mode
      $builder_value = isset( $_POST['_themefyre_builder_temporary_value'] ) ? $_POST['_themefyre_builder_temporary_value'] : '';
      update_post_meta( $post_ID, '_themefyre_builder_temporary_value', $builder_value );

      // Only if we`re not in preview mode do we update the actual value of the page builder
      if ( ! ( isset( $_POST['wp-preview'] ) && 'dopreview' === $_POST['wp-preview'] ) ) {
         update_post_meta( $post_ID, '_themefyre_builder_value', $builder_value );
      }

      // Always update the `temporary` value of the custom css which is only used when in preview mode
      $builder_css = isset( $_POST['_themefyre_builder_temporary_css'] ) ? $_POST['_themefyre_builder_temporary_css'] : '';
      update_post_meta( $post_ID, '_themefyre_builder_temporary_css', $builder_css );

      // Only if we`re not in preview mode do we update the actual value of the custom CSS
      if ( ! ( isset( $_POST['wp-preview'] ) && 'dopreview' === $_POST['wp-preview'] ) ) {
         update_post_meta( $post_ID, '_themefyre_builder_css', $builder_css );
      }
   }

   /**
    * Get the correct ID attribute for an attribute.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param string $tag Tag of shortcode
    * @param string $id ID of registered attribute
    * @return string
    */
   public function get_attribute_id( $tag, $id ) {
      return $tag . '-' .$id;
   }

   /**
    * Render control for a `bool` type attribute
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @uses builder_select()
    *
    * @param string $tag Tag of shortcode
    * @param string $id ID of registered attribute
    * @param array $config Configuration array for the attribute
    */
   public function callback_bool_control( $tag, $id, $config ) {
      $args = array(
         'type'  => 'checkbox',
         'name'  => $this->get_attribute_id($tag, $id),
         'id'    => $this->get_attribute_id($tag, $id),
         'value' => '1',
      );
      if ( isset( $config['default'] ) && 'true' == $config['default'] ) {
         $args['checked'] = 'checked';
      }
      echo '<label for="'.$this->get_attribute_id($tag, $id).'">';
      builder_input( $args );
      echo isset( $config['label'] ) ? esc_html( $config['label'] ) : esc_html( $config['title'] );
      echo '</label>';
   }

   /**
    * Render control for a `within` type attribute
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @uses builder_select()
    *
    * @param string $tag Tag of shortcode
    * @param string $id ID of registered attribute
    * @param array $config Configuration array for the attribute
    */
   public function callback_within_control( $tag, $id, $config ) {
      $args = array(
         'name'    => $this->get_attribute_id($tag, $id),
         'id'      => $this->get_attribute_id($tag, $id),
         'class'   => 'regular-text',
         'options' => is_callable( $config['options'] ) ? call_user_func( $config['options'] ) : $config['options'],
      );
      if ( isset( $config['default'] ) && $config['default'] ) {
         $args['value'] = $config['default'];
      }
      builder_select( $args );
   }

   /**
    * Render control for a `string` type attribute
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @uses builder_input()
    *
    * @param string $tag Tag of shortcode
    * @param string $id ID of registered attribute
    * @param array $config Configuration array for the attribute
    */
   public function callback_string_control( $tag, $id, $config ) {
      $args = array(
         'name'  => $this->get_attribute_id($tag, $id),
         'id'    => $this->get_attribute_id($tag, $id),
         'class' => 'regular-text',
      );
      if ( isset( $config['default'] ) && $config['default'] ) {
         $args['value'] = $config['default'];
      }
      if ( isset( $config['placeholder'] ) && $config['placeholder'] ) {
         $args['placeholder'] = $config['placeholder'];
      }
      builder_input( $args );
   }

   /**
    * Render control for a `html_string` type attribute
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @uses builder_textarea()
    *
    * @param string $tag Tag of shortcode
    * @param string $id ID of registered attribute
    * @param array $config Configuration array for the attribute
    */
   public function callback_html_string_control( $tag, $id, $config ) {
      $args = array(
         'name'  => $this->get_attribute_id($tag, $id),
         'id'    => $this->get_attribute_id($tag, $id),
      );
      if ( isset( $config['default'] ) && $config['default'] ) {
         $args['value'] = $config['default'];
      }
      if ( isset( $config['placeholder'] ) && $config['placeholder'] ) {
         $args['placeholder'] = $config['placeholder'];
      }
      builder_textarea( $args );
      ?>
         <p class="description allowed-tags">
            <?php printf( esc_html__( 'Allowed HTML tags: %s', 'themefyre_builder' ), '&lt;span&gt; &lt;a&gt; &lt;br /&gt; &lt;abbr&gt; &lt;acronym&gt; &lt;b&gt; &lt;strong&gt; &lt;i&gt; &lt;em&gt; &lt;del&gt; &lt;ins&gt; &lt;sub&gt; &lt;sup&gt; &lt;mark&gt;' ); ?>
         </p>
      <?php
   }

   /**
    * Render control for a `comma_list` type attribute
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @uses builder_input()
    *
    * @param string $tag Tag of shortcode
    * @param string $id ID of registered attribute
    * @param array $config Configuration array for the attribute
    */
   public function callback_comma_list_control( $tag, $id, $config ) {
      $args = array(
         'name'  => $this->get_attribute_id($tag, $id),
         'id'    => $this->get_attribute_id($tag, $id),
         'class' => 'regular-text',
      );
      if ( isset( $config['placeholder'] ) && $config['placeholder'] ) {
         $args['placeholder'] = $config['placeholder'];
      }
      builder_input( $args );
      echo '<ul class="list-items"></ul>';
   }

   /**
    * Render control for a `bar_list` type attribute
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @uses builder_input()
    *
    * @param string $tag Tag of shortcode
    * @param string $id ID of registered attribute
    * @param array $config Configuration array for the attribute
    */
   public function callback_bar_list_control( $tag, $id, $config ) {
      $this->callback_comma_list_control( $tag, $id, $config );
   }

   /**
    * Render control for a `bar_list` type attribute
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @uses builder_input()
    *
    * @param string $tag Tag of shortcode
    * @param string $id ID of registered attribute
    * @param array $config Configuration array for the attribute
    */
   public function callback_hex_code_control( $tag, $id, $config ) {
      $args = array(
         'name'  => $this->get_attribute_id($tag, $id),
         'id'    => $this->get_attribute_id($tag, $id),
         'class' => 'builder-color-picker',
      );
      builder_input( $args );
   }

   /**
    * Render control for a `icon` type attribute
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @uses builder_enabled_icon_fonts()
    *
    * @param string $tag Tag of shortcode
    * @param string $id ID of registered attribute
    * @param array $config Configuration array for the attribute
    */
   public function callback_icon_control( $tag, $id, $config ) {
      $enabled_icon_fonts = builder_enabled_icon_fonts();
      if ( empty( $enabled_icon_fonts ) ) {
         echo '<p class="description builder-no-options">'.wp_kses( __( 'No icon fonts have been enabled, go to <strong>Settings > Page Builder</strong> to manage your active icon fonts.', 'themefyre_builder' ), array('strong'=>array())).'</p>';
      }
      else {
         $remove_text = __('Remove Icon', 'themefyre_builder');
         $select_text = __('Select Icon', 'themefyre_builder');
         echo '<div class="builder-icon-preview"></div>';
         $args = array(
            'name'  => $this->get_attribute_id($tag, $id),
            'id'    => $this->get_attribute_id($tag, $id),
            'type'  => 'hidden',
         );
         builder_input( $args );
         echo '<p><a href="#" class="builder-select-icon" data-remove-text="'.esc_attr($remove_text).'" data-select-text="'.esc_attr($select_text).'">'.esc_html($select_text).'</a></p>';
      }
   }

   /**
    * Render control for a `font` type attribute
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @uses builder_get_option()
    *
    * @param string $tag Tag of shortcode
    * @param string $id ID of registered attribute
    * @param array $config Configuration array for the attribute
    */
   public function callback_font_control( $tag, $id, $config ) {
      $builder = builder();

      // Family options = selectable font families
      $family_options = array(
         'default' => __( '(default font)', 'themefyre_builder' ),
      );

      // Will be an associative array of enabled fonts
      $enabled_font_sources = array();

      // If the current theme provides a list of enabled
      if ( $theme_google_fonts = builder_get_theme_google_fonts() ) {

         // The label to identify this group of fonts
         $group_label = sprintf( __( '%s Theme Fonts', 'themefyre_builder' ), wp_get_theme() );
         $family_options[$group_label] = array();
         foreach ( $theme_google_fonts as $name => $weights ) {
            $family_options[$group_label]['theme,'.$name] = $name;
         }
         $enabled_font_sources['theme'] = $theme_google_fonts;
      }

      // If the current user has enabled 1 or more fonts from the settings panel
      if ( $user_fonts = get_option( 'builder_google_fonts' ) ) {

         // Reset the $user_fonts array so it only contains
         // font names & their associated variants/weights
         foreach ( $user_fonts as $name => $font ) {
            $user_fonts[$name] = $font['variants'];
         }

         // The label to identify this group of fonts
         $group_label = __( 'Saved Fonts', 'themefyre_builder' );
         $family_options[$group_label] = array();
         foreach ( $user_fonts as $name => $font ) {
            $family_options[$group_label]['custom,'.$name] = $name;
         }
         $enabled_font_sources['custom'] = $user_fonts;
      }

      // If only the default font is available, tell the user whats going on
      if ( 1 == count($family_options) ) {
         $args = array(
            'name'    => $this->get_attribute_id($tag, $id),
            'id'      => $this->get_attribute_id($tag, $id),
            'value'   => 'default',
            'type'    => 'hidden',
         );
         builder_input( $args );
         ?>
            <p class="description builder-no-options">
               <?php echo wp_kses( __( 'No Google fonts fonts have been enabled, go to <strong>Settings > Page Builder</strong> to manage your active Google fonts.', 'themefyre_builder' ) ); ?>
            </p>
         <?php
         return;
      }

      // The visual font preview
      ?>
         <p class="builder-font-selector-preview" contenteditable>
            <?php esc_html_e( 'Preview text, this text is editable.', 'themefyre_builder' ); ?>
         </p>
      <?php

      // Output the select box for selecting the family
      $args = array(
         'name'    => $this->get_attribute_id($tag, $id),
         'id'      => $this->get_attribute_id($tag, $id),
         'class'   => 'regular-text builder-font-selector',
         'options' => $family_options,
         'value'   => 'default',
         'title'   => __('Select font family', 'themefyre_builder'),
      );

      builder_select( $args );

      // Output all of the select boxes for selecting the weight of each font
      foreach ( $enabled_font_sources as $category => $fonts ) {
         foreach ( $fonts as $name => $weights ) {
            if ( ! $weights ) {
               $weights = '400';
            }
            $weight_options = array();
            foreach ( explode( ',', $weights ) as $weight ) {
               $weight_options[$weight] = $builder->google_font_variants[$weight];
            }
            $weight_default = array_key_exists( '400', $weight_options ) ? '400' : key( $weight_options );
            $args = array(
               'data-font' => $category.','.$name,
               'class'     => 'regular-text builder-weight-selector',
               'options'   => $weight_options,
               'value'     => $weight_default,
               'title'     => __('Select font weight', 'themefyre_builder'),
            );
            if ( 2 > count( $weight_options ) ) {
               $args['disabled'] = 'disabled';
            }
            builder_select( $args );
         }
      }
   }

   /**
    * Render control for a `image` type attribute
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @uses builder_input()
    *
    * @param string $tag Tag of shortcode
    * @param string $id ID of registered attribute
    * @param array $config Configuration array for the attribute
    */
   public function callback_image_control( $tag, $id, $config ) {
      $args = array(
         'type'     => 'hidden',
         'name'     => $this->get_attribute_id($tag, $id),
         'id'       => $this->get_attribute_id($tag, $id),
         'data-key' => $this->get_attribute_id($tag, $id),
         'class'    => 'builder-value-image',
      );

      builder_input( $args );

      echo '<p class="builder-preview-image" data-key="'.$this->get_attribute_id($tag, $id).'"></p>';

      $remove_text = isset( $config['remove_text'] ) && $config['remove_text'] ? $config['remove_text'] : __( 'Remove image', 'themefyre_builder' );
      $add_text    = isset( $config['add_text'] ) && $config['add_text'] ? $config['add_text'] : __( 'Select image', 'themefyre_builder' );
      echo '<p><a href="#" class="builder-select-image" data-key="'.$this->get_attribute_id($tag, $id).'" data-remove-text="'.esc_attr( $remove_text ).'" data-add-text="'.esc_attr( $add_text ).'">'.esc_html( $add_text ).'</a></p>';
   }

   /**
    * Render control for a `gallery` type attribute
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @uses builder_input()
    *
    * @param string $tag Tag of shortcode
    * @param string $id ID of registered attribute
    * @param array $config Configuration array for the attribute
    */
   public function callback_gallery_control( $tag, $id, $config ) {
      $args = array(
         'type'     => 'hidden',
         'name'     => $this->get_attribute_id($tag, $id),
         'id'       => $this->get_attribute_id($tag, $id),
         'data-key' => $this->get_attribute_id($tag, $id),
         'class'    => 'builder-value-gallery',
      );

      builder_input( $args );
      echo '<ul class="builder-preview-gallery" data-key="'.$this->get_attribute_id($tag, $id).'"></ul>';
      $remove_text = isset( $config['remove_text'] ) && $config['remove_text'] ? $config['remove_text'] : __( 'Remove gallery images', 'themefyre_builder' );
      $add_text    = isset( $config['add_text'] ) && $config['add_text'] ? $config['add_text'] : __( 'Add gallery images', 'themefyre_builder' );
      echo '<p><a href="#" class="builder-manage-gallery" data-key="'.$this->get_attribute_id($tag, $id).'" data-remove-text="'.esc_attr( $remove_text ).'" data-add-text="'.esc_attr( $add_text ).'">'.esc_html( $add_text ).'</a></p>';
   }

   /**
    * Render control for a `video` type attribute
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @uses builder_input()
    *
    * @param string $tag Tag of shortcode
    * @param string $id ID of registered attribute
    * @param array $config Configuration array for the attribute
    */
   public function callback_video_control( $tag, $id, $config ) {
      $args = array(
         'name'        => $this->get_attribute_id($tag, $id),
         'id'          => $this->get_attribute_id($tag, $id),
         'class'       => 'regular-text',
         'placeholder' => isset( $config['placeholder'] ) ? $config['placeholder'] : 'http://...',
         'data-key' => $this->get_attribute_id($tag, $id),
      );
      if ( isset( $config['default'] ) && $config['default'] ) {
         $args['value'] = $config['default'];
      }
      builder_input( $args );

      ?>
         <a class="button builder-select-video" data-key="<?php echo $this->get_attribute_id($tag, $id); ?>"><?php esc_html_e('Select File', 'themefyre_builder'); ?></a>
      <?php
   }

   /**
    * Render control for a `audio` type attribute
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @uses builder_input()
    *
    * @param string $tag Tag of shortcode
    * @param string $id ID of registered attribute
    * @param array $config Configuration array for the attribute
    */
   public function callback_audio_control( $tag, $id, $config ) {
      $args = array(
         'name'        => $this->get_attribute_id($tag, $id),
         'id'          => $this->get_attribute_id($tag, $id),
         'class'       => 'regular-text',
         'placeholder' => isset( $config['placeholder'] ) ? $config['placeholder'] : 'http://...',
         'data-key' => $this->get_attribute_id($tag, $id),
      );
      if ( isset( $config['default'] ) && $config['default'] ) {
         $args['value'] = $config['default'];
      }
      builder_input( $args );

      ?>
         <a class="button builder-select-audio" data-key="<?php echo $this->get_attribute_id($tag, $id); ?>"><?php esc_html_e('Select File', 'themefyre_builder'); ?></a>
      <?php
   }

   /**
    * Render control for a `audio` type attribute
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @uses builder_input()
    *
    * @param string $tag Tag of shortcode
    * @param string $id ID of registered attribute
    * @param array $config Configuration array for the attribute
    */
   public function callback_dev_control( $tag, $id, $config ) {
      $args = array(
         'type'  => 'hidden',
         'name'  => $this->get_attribute_id($tag, $id),
         'id'    => $this->get_attribute_id($tag, $id),
      );
      if ( isset( $config['default'] ) && $config['default'] ) {
         $args['value'] = $config['default'];
      }
      builder_input( $args );
   }

   /**
    * Creates the templates for each shortcode`s edit screen
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @uses builder_get_shortcodes()
    */
   public function shortcode_attribute_control( $tag, $id ) {
      $shortcodes = builder_get_shortcodes();
      $config = $shortcodes[$tag]->config['attributes'][$id];
      ?>
         <div class="attribute-setting" data-attribute="<?php echo $id; ?>" data-type="<?php echo $config['type']; ?>" id="attribute-<?php echo $tag; ?>-<?php echo $id; ?>">
            <?php if ( 'dev' !== $config['type'] ) : ?>
               <div class="builder-columns-1_3-2_3 spacing-2">
            <?php endif; ?>
               <?php if ( 'dev' !== $config['type'] ) : ?>
                  <div class="attribute-label">
                     <?php if ( in_array( $config['type'], array( 'bool', 'html_string', 'string', 'within', 'comma_list', 'bar_list', 'video', 'audio' ) ) ) : ?>
                        <label for="<?php echo $this->get_attribute_id( $tag, $id ); ?>">
                           <?php echo esc_html( $config['title'] ); ?>
                        </label>
                     <?php else: ?>
                        <strong>
                           <?php echo esc_html( $config['title'] ); ?>
                        </strong>
                     <?php endif; ?>
                     <?php if ( $shortcodes[$tag]->config['label_attribute'] == $id ) : ?>
                        <br />
                        <span class="module-label-attribute-marker" title="<?php esc_attr_e( 'This attribute will be used to identify this module within the page builder.', 'themefyre_builder' ); ?>">
                           <?php esc_html_e( 'Module Label Attribute', 'themefyre_builder' ); ?>
                        </span>
                     <?php endif; ?>
                  </div>
               <?php endif; ?>
               <div class="attribute-control">
                  <?php call_user_func( array( $this, "callback_{$config['type']}_control"), $tag, $id, $config ); ?>
                  <?php if ( isset( $config['desc'] ) && $config['desc'] ) : ?>
                     <p class="attribute-description description"><?php echo wp_kses_post( $config['desc'] ); ?></p>
                  <?php endif; ?>
               </div>
            <?php if ( 'dev' !== $config['type'] ) : ?>
               </div>
            <?php endif; ?>
         </div>
      <?php
   }

   /**
    * Creates the templates for the available shortcodes modals.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function template_manager_modal_template() {
      $builder = builder();
      ?>
         <script type="text/html" id="builder-tmpl-builder-template-manager">
            <nav class="builder-modal-tabs">
               <ul>
                  <li class="builder-modal-tab">
                     <button type="button" data-tab="premade"><?php esc_html_e('Premade Templates', 'themefyre_builder'); ?></button>
                  </li>
                  <li class="builder-modal-tab">
                     <button type="button" data-tab="manager"><?php esc_html_e('Custom Templates', 'themefyre_builder'); ?></button>
                  </li>
                  <li class="builder-modal-tab">
                     <button type="button" data-tab="import"><?php esc_html_e('Import Page/Post', 'themefyre_builder'); ?></button>
                  </li>
               </ul>
            </nav>
            <div class="builder-modal-panes">
               <div class="builder-modal-pane" data-pane="premade">
                  <div class="modal-padding">
                     <p class="description"><?php esc_html_e('This page builder includes several premade templates to help you get started building your website right away. Select a template below to import it to the current page/post. The imported content will be <strong>appended</strong> to the current page/post.', 'themefyre_builder'); ?></p>
                     <div id="builder-import-premade-template" class="builder-importer-available-items">
                        <?php
                           $sources = array();
                           foreach ( $builder->templates as $slug => $config ) {
                              $sources[$config['source']][] = $slug;
                           }

                           if ( ! empty( $sources ) ) {
                              foreach ( $sources as $source => $slug_list ) {
                                 if ( 'none' == $source ) {
                                    echo '<div style="height:25px;"></div>';
                                 }
                                 else {
                                    echo '<h3>'.$source.'<span>'.sprintf( esc_html__('These premade templates are only available while %s is active.', 'themefyre_builder'), '<strong>'.$source.'</strong>').'</span></h3>';
                                 }
                                 foreach ( $slug_list as $slug ) {
                                    $template_config = $builder->templates[$slug];
                                    $label = '<span class="item-name">'.esc_html( $template_config['name'] ).'</span>';
                                    if ( $template_config['desc'] ) {
                                       $label .= '<span class="item-description">'.esc_html( $template_config['desc'] ).'</span>';
                                    }
                                    echo '<button type="button" data-template-slug="'.$slug.'">'.$label.'</button>';
                                 }
                              }
                           }
                           else {
                              ?>
                                 <p class="builder-importer-no-items">
                                    <?php echo wp_kses( sprintf( __('No premade templates available. You can purchase a compatible theme from <a href="%s" target="_blank">Themefyre</a>.', 'themefyre_builder' ), 'http://www.themefyre.com'), array('a'=>array('href'=>array(),'target'=>array())) ); ?>
                                 </p>
                              <?php
                           }
                        ?>
                     </div>
                  </div>
               </div>
               <div class="builder-modal-pane" data-pane="manager">
                  <div class="modal-padding">
                     <p class="description"><?php echo wp_kses( __('This page builder allows you to save/import/export an unlimited number of custom templates. With this control panel you are able to save the current page as a new template, or import one of your saved templates. Select a template below to import it\'s content into the current page/post. The imported content will be <strong>appended</strong> to the current page/post.', 'themefyre_builder'), array('strong'=>array()) ); ?></p>
                     <div id="builder-create-new-template-form">
                        <label for="builder-create-new-template-name"><?php esc_html_e( 'Save Page as Template', 'themefyre_builder' ); ?></label>
                        <input type="text" id="builder-create-new-template-name" placeholder="<?php esc_attr_e( 'Template Name', 'themefyre_builder' ); ?>" />
                        <button type="button" id="builder-create-new-template-submit" class="button button-primary"><?php esc_html_e( 'Save Template', 'themefyre_builder' ); ?></button>
                     </div>
                     <?php
                     $args = array(
                        'post_type'      => 'builder_template',
                        'posts_per_page' => '-1',
                        'orderby'        => 'post_date',
                        'order'          => 'ASC',
                        'meta_query' => array(
                           array(
                              'key'     => '_themefyre_builder_value',
                              'value'   => '',
                              'compare' => '!=',
                           ),
                        ),
                     );
                     $saved_templates = get_posts( $args ); ?>
                     <div id="builder-import-template" class="builder-importer-available-items<?php if ( empty($saved_templates) ) echo ' no-items'; ?>">
                        <p class="builder-importer-no-items"><?php esc_html_e('You don\'t have any saved templates yet.', 'themefyre_builder'); ?></p>
                        <h3><?php esc_html_e( 'Saved Templates', 'themefyre_builder' ); ?></h3>
                        <?php foreach ( $saved_templates as $template ) : ?>
                           <button type="button" class="builder-saved-template" data-post-id="<?php echo $template->ID; ?>">
                              <span class="item-name"><?php echo esc_html( $template->post_title ); ?></span>
                              <span class="remove-item" title="<?php esc_attr_e( 'Delete Template', 'themefyre_builder' ); ?>"><span class="dashicons dashicons-no-alt"></span></span>
                           </button>
                        <?php endforeach; ?>
                     </div>
                  </div>
               </div>
               <div class="builder-modal-pane" data-pane="import">
                  <div class="modal-padding">
                     <p class="description"><?php echo wp_kses( __('Select a page/post below to import its content into the current page/post. The imported content will be <strong>appended</strong> to the current page/post. You are only allowed to choose from pages/posts which currently have the page builder enabled.', 'themefyre_builder'), array('strong'=>array()) ); ?></p>
                     <div id="builder-import-post" class="builder-importer-available-items">
                        <?php
                           $import_list = '';
                           foreach ( $this->screens as $post_type ) {
                              $post_type_obj = get_post_type_object( $post_type );
                              $title = isset($post_type_obj->labels->name) ? $post_type_obj->labels->name : $post_type;
                              $args = array(
                                 'post_type' => $post_type,
                                 'posts_per_page' => -1,
                                 'post__not_in' => array( get_the_ID() ),
                                 'orderby'=> 'title',
                                 'order' => 'ASC',
                                 'meta_query' => array(
                                    array(
                                       'key'   => '_themefyre_builder_state',
                                       'value' => 'active',
                                       'compare' => '=',
                                    ),
                                    array(
                                       'key'     => '_themefyre_builder_value',
                                       'value'   => '',
                                       'compare' => '!=',
                                    ),
                                 ),
                              );
                              $posts = get_posts( $args );

                              if ( $posts ) {
                                 $import_list .= '<h3>'.esc_html($title).'</h3>';
                                 $import_list .= '<div class="builder-grid-3 spacing-1">';
                                 foreach ( $posts as $post ) {
                                    $title = isset( $post->post_title ) ? $post->post_title : $post->ID;
                                    $import_list .= '<div><button type="button" data-post-id="'.$post->ID.'">'.esc_html($title).'</button></div>';
                                 }
                                 $import_list .= '</div>';
                              }
                           }
                           echo $import_list ? $import_list : '<p class="builder-importer-no-items">'.esc_html__('This is currently the only page/post with the page builder enabled and contains importable content.', 'themefyre_builder').'</p>';
                        ?>
                     </div>
                  </div>
               </div>
            </div>
         </script>
      <?php
   }

   /**
    * AJAX callback for getting the complete list of available icons.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function icon_picker_modal_template() {
      $builder = builder();
      $enabled_icon_fonts = builder_enabled_icon_fonts();
      if ( empty( $enabled_icon_fonts ) ) {
         return;
      }
      ?>
         <script type="text/html" id="builder-tmpl-icon-selector">
            <input type="text" class="builder-search-icons builder-modal-search" placeholder="<?php esc_attr_e('Search Icons...', 'themefyre_builder'); ?>" />
            <div class="builder-available-icons">
            <?php
               foreach ( $enabled_icon_fonts as $icon_font ) {

                  // Get the configuration for the icon font
                  ob_start();
                  include $builder->plugin_dir . 'icons/'.$icon_font.'/'.$icon_font.'.json';
                  $icon_font_config = json_decode( ob_get_clean(), true );

                  // Make sure there are icons to show
                  if ( empty( $icon_font_config ) ) {
                     continue;
                  }

                  // Display all available icons
                  echo '<div class="icon-font-group">';
                  echo '<h3>'.$icon_font_config['name'].'</h3>';
                  foreach ( $icon_font_config['glyphs'] as $glyph ) {
                     $glyph_value = $icon_font_config['css_prefix_text'].$glyph['css'];
                     echo '<a class="builder-available-icon" data-icon="'.$glyph_value.'" title="'.$glyph_value.'" data-name="'.$glyph['css'].'">'.builder_get_icon_html( $glyph_value ).'</a>';
                  }
                  echo '</div>';
               }
            ?>
            </div>
         </script>
      <?php
   }

   /**
    * Creates the templates for the available shortcodes modals.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @uses builder_get_shortcodes()
    */
   public function available_shortcodes_modal_templates() {
      $shortcodes = builder_get_shortcodes();

      // Sort shortcode list alphabetically BY TAG
      ksort( $shortcodes );

      foreach ( array( 'full-width', 'content', 'tmce' ) as $role ) :

         // Compile a list of sources
         $sources = array();
         foreach ( $shortcodes as $tag => $shortcode ) {
            if ( 'tmce' !== $role && $shortcode->config['builder_role'] !== $role ) continue;
            if ( 'tmce' == $role && ! $shortcode->config['tmce'] ) continue;
            $sources[$shortcode->config['builder_source']][] = $tag;
         }

         if ( in_array('builder_section', $sources['none']) ) {
            $sources['none'] = array_diff($sources['none'], array('builder_section'));
            array_unshift( $sources['none'], 'builder_section' );
         }

         // Make sure the native modules are always displayed first
         $native = array('none' => $sources['none']);
         unset($sources['none']);
         $sources = array_merge($native, $sources);
         ?>
            <script type="text/html" id="builder-tmpl-available-<?php echo $role; ?>-shortcodes">
               <?php if ( 'content' === $role ) : ?>
                  <input type="text" class="builder-search-modules builder-modal-search" placeholder="<?php esc_attr_e('Search...', 'themefyre_builder'); ?>" />
               <?php endif; ?>
               <div class="available-content-shortcodes">
                  <?php foreach ( $sources as $source => $tag_list ) : ?>
                     <div class="available-content-shortcodes-group">
                        <?php if ( 'none' !== $source ) : ?>
                           <h3>
                              <?php echo $source; ?>
                              <span>
                                 <?php printf( esc_html__( 'These shortcode modules are only available while %s is active.', 'themefyre_builder'), '<strong>'.$source.'</strong>' ); ?>
                              </span>
                           </h3>
                        <?php endif; ?>
                        <ul class="builder-grid-<?php echo 'full-width' == $role ? 4 : 5; ?> spacing-1">
                           <?php foreach ( $tag_list as $tag ) : ?>
                              <li<?php if ( 'builder_section' === $tag ) echo ' style="width:100%!important;"'; ?> data-name="<?php echo esc_attr( $shortcodes[$tag]->config['labels']['singular'] ); ?>">
                                 <button type="button" data-tag="<?php echo $tag; ?>" data-add-title="<?php printf( esc_attr__( 'Add New %s', 'themefyre_builder' ), $shortcodes[$tag]->config['labels']['singular'] ); ?>" <?php if ( $shortcodes[$tag]->config['labels']['info'] ) echo ' title="'.esc_attr(strip_tags($shortcodes[$tag]->config['labels']['info'])).'"'; ?>>
                                    <span class="dashicons dashicons-<?php echo $shortcodes[$tag]->config['icon']; ?>"></span>
                                    <strong class="title"><?php echo esc_html( $shortcodes[$tag]->config['labels']['singular'] ); ?></strong>
                                 </button>
                              </li>
                           <?php endforeach; ?>
                        </ul>
                     </div>
                  <?php endforeach; ?>
               </div>
            </script>
         <?php
      endforeach;
   }

   /**
    * Creates the templates for the available shortcodes modals.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function available_row_shortcodes_modal_template() {
      $builder = builder();
      ?>
         <script type="text/html" id="builder-tmpl-available-row-shortcodes">
            <div class="available-shortcodes available-rows">
               <h2><?php esc_html_e( 'Full Width', 'themefyre_builder' ); ?></h2>
               <button type="button" class="layout-option" data-tag="builder_row">
                  <div class="column">100%</div>
               </button>
               <?php

                  // Array of allowed special layouts
                  $column_combinations = array(
                     2,
                     array('1/3', '2/3'),
                     array('2/3', '1/3'),
                     array('2/5', '3/5'),
                     array('3/5', '2/5'),
                     array('1/4', '3/4'),
                     array('3/4', '1/4'),
                     3,
                     array('1/2', '1/4', '1/4'),
                     array('1/4', '1/2', '1/4'),
                     array('1/4', '1/4', '1/2'),
                     4,
                     5,
                     6,
                  );

                  $last_num_columns = 1;

                  foreach ( $column_combinations as $column_combination ) {
                     $num_columns = '';
                     $layout_key = '';
                     if ( is_array($column_combination) ) {
                        $num_columns = count( $column_combination );
                        $layout_key = str_replace('/', '_', implode('-', $column_combination) );
                     }
                     else {
                        $num_columns = $layout_key = $column_combination;
                     }

                     if ( $num_columns != $last_num_columns ) {
                        $last_num_columns = $num_columns;
                        ?>
                           <h2><?php printf( esc_html__( '%s Columns', 'themefyre_builder' ), $num_columns ); ?></h2>
                        <?php
                     }
                     ?>
                        <button type="button" class="layout-option" data-tag="builder_column_row-<?php echo $layout_key; ?>">
                           <div class="builder-columns-<?php echo $layout_key; ?> spacing-1">
                              <?php
                                 for ( $i=0; $i<$num_columns; $i++ ) {

                                    $description = '';
                                    if ( is_array($column_combination) ) {
                                       $description_parts = explode('/', $column_combination[$i]);
                                       $description = $description_parts[0] / $description_parts[1];
                                    }
                                    else {
                                       $description = 1/$num_columns;
                                    }
                                    $description = $description ? round( $description, 3 )*100 : '';
                                    ?>
                                       <div>
                                          <div class="column"><?php echo $description; ?>%</div>
                                       </div>
                                    <?php
                                 }
                              ?>
                           </div>
                        </button>
                     <?php
                  }
               ?>
            </div>
         </script>
      <?php
   }

   /**
    * Creates the templates for the available shortcodes modules.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @uses builder_get_shortcodes()
    */
   public function builder_module_templates() {
      $shortcodes = builder_get_shortcodes();
      foreach ( $shortcodes as $tag => $shortcode ) :
         if ( 'none' == $shortcode->config['builder_role'] ) {
            continue;
         }
         $callback = $this->get_module_callback( $tag );
         $default_attributes = $shortcode->get_attribute_defaults();
         foreach ($default_attributes as $attr => $val) {
            if ( ! $val ) {
               unset($default_attributes[$attr]);
            }
         }
         ?>
            <script type="text/html" id="builder-tmpl-builder-module-<?php echo esc_attr( $tag ); ?>">
               <?php echo call_user_func( array($this, $callback), $default_attributes, $shortcode->config['default_content'], $tag); ?>
            </script>
         <?php
      endforeach;
   }

   /**
    * Creates the templates for the available row shortcodes modules.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_row_module_templates() {

      ?>
         <script type="text/html" id="builder-tmpl-builder-module-builder_row">
            <?php echo $this->builder_row_module_callback( null, null, 'builder_row' ); ?>
         </script>
      <?php

      // Array of allowed special layouts
      $column_combinations = array(
         2,
         array('1/3', '2/3'),
         array('2/3', '1/3'),
         array('2/5', '3/5'),
         array('3/5', '2/5'),
         array('1/4', '3/4'),
         array('3/4', '1/4'),
         3,
         array('1/2', '1/4', '1/4'),
         array('1/4', '1/2', '1/4'),
         array('1/4', '1/4', '1/2'),
         4,
         5,
         6,
      );

      foreach ( $column_combinations as $column_combination ) {
         $content_string = '';
         $layout_key = '';
         if ( is_array($column_combination) ) {
            foreach ($column_combination as $span) {
               $content_string .= '[builder_column span="'.$span.'"][/builder_column]';
            }
            $layout_key = str_replace('/', '_', implode('-', $column_combination) );
         }
         else {
            for ($i=0;$i<$column_combination;$i++) {
               $content_string .= '[builder_column][/builder_column]';
            }
            $layout_key = $column_combination;
         }
         ?>
            <script type="text/html" id="builder-tmpl-builder-module-builder_column_row-<?php echo $layout_key; ?>">
               <?php echo $this->builder_column_row_module_callback( null, $content_string, 'builder_column_row' ); ?>
            </script>
         <?php
      }
   }

   /**
    * Inserts the single instance of wp_editor that the page builder uses
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function insert_shortcode_content_tmce_editor() {
      ?>
         <div id="builder-shortcode-content-tmce-editor">
            <?php wp_editor( '', 'shortcode_wp_editor_content', array(
               'editor_height' => 275,
               'tinymce'=> array(
                  'toolbar1' => 'bold,italic,underline,strikethrough,bullist,numlist,blockquote,hr,alignjustify,alignleft,aligncenter,alignright,link,unlink,wp_adv',
                  'toolbar2' => 'formatselect,forecolor,pastetext,removeformat,charmap,outdent,indent,undo,redo',
                  'toolbar3' => '',
               ),
            ) ); ?>
         </div>
      <?php
   }

   /**
    * Inserts the HTML for the notification used to indicate when the preview has been refreshed
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function insert_instant_preview_notifications() {
      ?>
         <div id="builder-preview-notification">
            <div id="builder-preview-queued-notification">
               <?php esc_html_e( 'Preview Queued', 'themefyre_builder' ); ?>
            </div>
            <div id="builder-preview-updated-notification">
               <?php esc_html_e( 'Preview Updating', 'themefyre_builder' ); ?>
            </div>
         </div>
      <?php
   }

   /**
    * Creates the templates for each shortcode`s edit screen
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @uses builder_get_shortcodes()
    */
   public function edit_shortcode_modal_templates() {
      $shortcodes = builder_get_shortcodes();

      foreach ( $shortcodes as $tag => $shortcode ) :

         // Determine the type of content this shortcode can handle, if any
         $content_type = $shortcode->config['content_type'];
         if ( ! in_array( $shortcode->config['content_type'], array( 'none', 'textarea', 'editor' ) ) ) {
            $content_type = 'child_element';
         }

         // Set up the title for the content tab, if one has not been specified
         if ( 'none' !== $content_type && ! $shortcode->config['labels']['content_tab_title'] ) {

            // Standard text editor
            if ( in_array( $content_type, array( 'textarea', 'editor' ) ) ) {
               $shortcode->config['labels']['content_tab_title'] = __( 'Content', 'themefyre_builder' );
            }

            // Content element, so use its plural label
            else {
               $shortcode->config['labels']['content_tab_title'] = $shortcodes[$shortcode->config['content_type']]->config['labels']['plural'];
            }
         }

         // Create the array of form tabs
         $form_tabs = array();
         $form_tab_count = 0;

         // if the content should be displayed first
         $content_first = isset( $shortcode->config['content_first'] ) && $shortcode->config['content_first'];

         // Add the appropriate content tab
         if ( 'none' !== $content_type && $content_first ) {
            $form_tabs['content'] = $shortcode->config['labels']['content_tab_title'];
            $form_tab_count++;
         }

         // Check if the shortcode has attributes
         if ( ! empty( $shortcode->config['attributes'] ) ) {

            $form_tab_count++;

            // Create default tab containing all attributes
            $form_tabs['attributes'] = array(
               'all' => array(
                  'title' => $shortcode->config['labels']['attributes_tab_title'],
                  'ids'   => array_keys( $shortcode->config['attributes'] ),
               ),
            );

            // Check for any custom defined tabs
            if ( is_array( $shortcode->config['attribute_tabs'] ) ) {
               $form_tabs['attributes'] = array_merge( $form_tabs['attributes'], $shortcode->config['attribute_tabs'] );

               // Remove attributes in custom tabs from default tab to prevent duplicates
               foreach ( $shortcode->config['attribute_tabs'] as $tab_id => $tab_config ) {
                  $form_tabs['attributes']['all']['ids'] = array_diff( $form_tabs['attributes']['all']['ids'], $tab_config['ids'] );
                  $form_tab_count++;
               }
            }
         }

         // Add the appropriate content tab
         if ( 'none' !== $content_type && ! $content_first ) {
            $form_tabs['content'] = $shortcode->config['labels']['content_tab_title'];
            $form_tab_count++;
         }

         // Add the automatically created advanced controls
         if ( ! $shortcode->config['disable_advanced'] ) {
            $form_tabs['advanced'] = $shortcode->config['labels']['advanced_tab_title'];

            // Remove advanced attributes from default attributes tab
            $form_tabs['attributes']['all']['ids'] = array_diff( $form_tabs['attributes']['all']['ids'], array( 'class', 'id', 'inline_attributes', 'device_visibility' ) );
            $form_tab_count++;
         }

         // If there are no longer any attributes in the default tab, remove it
         if ( isset( $form_tabs['attributes'] ) && empty( $form_tabs['attributes']['all']['ids'] ) ) {
            unset( $form_tabs['attributes']['all'] );
            $form_tab_count--;
         }

         // Add the explanation tab
         if ( $shortcode->config['labels']['info'] ) {
            $form_tabs['info'] = __('More Information', 'themefyre_builder');
         }

         ?>
            <script type="text/html" id="builder-tmpl-edit-shortcode-<?php echo $tag; ?>">
               <div class="edit-shortcode-form" data-tag="<?php echo $tag; ?>">
                  <nav class="builder-modal-tabs">
                     <ul>
                        <?php foreach ( $form_tabs as $tab => $tab_title ) : ?>
                           <?php if ( 'attributes' === $tab ) : ?>
                              <?php foreach ( $tab_title as $attribute_tab => $attribute_tab_config ) : ?>
                                 <li class="builder-modal-tab tab-attributes-<?php echo $attribute_tab; ?>">
                                    <button type="button" data-tab="attributes-<?php echo $attribute_tab; ?>">
                                       <?php echo esc_html( $attribute_tab_config['title'] ); ?>
                                    </button>
                                 </li>
                              <?php endforeach; ?>
                           <?php else: ?>
                              <li class="builder-modal-tab tab-<?php echo $tab; ?>">
                                 <button type="button" data-tab="<?php echo $tab; ?>">
                                    <?php echo esc_html( $tab_title ); ?>
                                 </button>
                              </li>
                           <?php endif; ?>
                        <?php endforeach; ?>
                     </ul>
                  </nav>
                  <div class="builder-modal-panes">
                     <?php foreach ( $form_tabs as $tab => $tab_title ) : ?>

                        <?php if ( 'attributes' == $tab ) : ?>
                           <?php foreach ( $form_tabs['attributes'] as $pane_id => $pane_config ) : ?>
                              <div class="builder-modal-pane" data-pane="attributes-<?php echo $pane_id; ?>">
                                 <?php foreach ( $pane_config['ids'] as $id ) : ?>
                                    <?php $this->shortcode_attribute_control( $tag, $id ); ?>
                                 <?php endforeach; ?>
                              </div>
                           <?php endforeach; ?>
                        <?php endif; ?>

                        <?php if ( 'content' == $tab ) : ?>
                           <div class="builder-modal-pane" data-pane="content">
                              <div class="shortcode-content-editor" data-type="<?php echo $content_type; ?>">
                                 <?php if ( 'textarea' == $content_type ) : ?>
                                    <div class="builder-codeMirror-wrap">
                                       <textarea id="shortcode_codeMirror_content"></textarea>
                                    </div>
                                 <?php elseif ( 'child_element' == $content_type ) : ?>
                                    <div class="builder-module-dropzone is-empty" data-dropzone="child" data-child-tag="<?php echo $shortcode->config['content_type']; ?>"></div>
                                    <button type="button" class="builder-add-module dropzone-button" data-role="child" data-tag="<?php echo $shortcode->config['content_type']; ?>">
                                       <?php printf( esc_html__( 'Add New %s', 'themefyre_builder' ), $shortcodes[$shortcode->config['content_type']]->config['labels']['singular'] ); ?>
                                    </button>
                                 <?php endif; ?>
                              </div>
                              <?php if ( 'editor' !== $content_type && $shortcode->config['labels']['content_tab_desc'] ) : ?>
                                 <p class="content-editor-description description">
                                    <?php echo wp_kses( $shortcode->config['labels']['content_tab_desc'], array('strong'=>array(),'a'=>array('href'=>array(),'target'=>array(),'title'=>array()))); ?>
                                 </p>
                              <?php endif; ?>
                           </div>
                        <?php endif; ?>

                        <?php if ( 'advanced' === $tab ) : ?>
                           <div class="builder-modal-pane" data-pane="advanced">
                              <?php foreach ( array('class', 'id', 'inline_attributes') as $id ) : ?>
                                 <?php $this->shortcode_attribute_control( $tag, $id ); ?>
                              <?php endforeach; ?>
                              <?php if ( 'child' !== $shortcode->config['builder_role'] ) : ?>
                                 <?php $this->shortcode_attribute_control( $tag, 'device_visibility' ); ?>
                              <?php endif; ?>
                           </div>
                        <?php endif; ?>

                        <?php if ( 'info' == $tab ) : ?>
                           <div class="builder-modal-pane" data-pane="info">
                              <div class="modal-padding">
                                 <h2><?php echo esc_html( $shortcode->config['labels']['singular'] ); ?></h3>
                                 <p class="description"><?php echo wp_kses( $shortcode->config['labels']['info'], array('strong'=>array(),'a'=>array('href'=>array(),'target'=>array(),'title'=>array()))); ?></p>
                              </p>
                           </div>
                        <?php endif; ?>

                     <?php endforeach; ?>
                  </div>
               </div>
            </script>
         <?php
      endforeach;
   }

   /**
    * Gets the name of the callback used to display the module for a specific shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param $tag Shortcode tag to get the callback name for
    * @return string
    */
   public function get_module_callback( $tag ) {
      return method_exists($this, $tag.'_module_callback') ? $tag.'_module_callback' : 'module_callback';
   }

   /**
    * Custom alternative to WordPress do_shortcode which only uses the builder module callback.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @return string
    */
   public function do_shortcode( $content ) {
      $pattern = get_shortcode_regex();
      return preg_replace_callback( "/$pattern/s", array( $this, 'do_shortcode_tag' ), $content );
   }

   /**
    * Custom alternative to WordPress do_shortcode which only uses the builder module callback.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @uses builder_get_shortcodes()
    *
    * @param array $m Regular expression match array
    * @return string
    */
   public function do_shortcode_tag( $m ) {
      $shortcodes = builder_get_shortcodes();
      $tag = $m[2];

      // Unrecognized shortcodes do not output anything
      if ( ! isset( $shortcodes[$tag] ) ) {
         return '';
      }

      $attr = shortcode_parse_atts( $m[3] );
      $content = isset( $m[5] ) ? $m[5] : null;
      $callback = $this->get_module_callback( $tag );

      return $m[1] . call_user_func( array( $this, $callback ), $attr, $content, $tag ) . $m[6];
   }

   /**
    * Callback for displaying module buttons
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $button Array of buttons to display
    */
   public function module_controls( $buttons, $tag = '' ) {
      $title = __('Module', 'themefyre_builder');
      $role = 'content';
      if ( $tag ) {
         $title = $tag;
         $shortcode = builder_get_shortcode( $tag );
         if ( $shortcode->config['labels']['singular'] ) {
            $title = $shortcode->config['labels']['singular'];
         }
         if ( $shortcode->config['builder_role'] ) {
            $role = $shortcode->config['builder_role'];
         }
      }

      foreach ( $buttons as $button ) {
         switch ( $button ) {

            case 'edit':
               ?>
                  <button type="button" class="module-edit" title="<?php printf( esc_attr__( 'Edit %s', 'themefyre_builder' ), $title ); ?>">
                     <span class="dashicons dashicons-menu"></span>
                  </button>
               <?php
               break;

            case 'duplicate':
               ?>
                  <button type="button" class="module-duplicate" title="<?php printf( esc_attr__( 'Duplicate %s', 'themefyre_builder' ), $title ); ?>">
                     <span class="dashicons dashicons-admin-page"></span>
                  </button>
               <?php
               break;

            case 'remove':
               ?>
                  <button type="button" class="module-remove" title="<?php printf( esc_attr__( 'Delete %s', 'themefyre_builder' ), $title ); ?>">
                     <span class="dashicons dashicons-no"></span>
                  </button>
               <?php
               break;

            case 'move-up':
               $button_title = 'full-width' === $role ? sprintf( esc_attr__( 'Move %s Up (Click and hold to move to the top of the page)', 'themefyre_builder' ), $title ) : sprintf( esc_attr__( 'Move %s Up', 'themefyre_builder' ), $title );
               ?>
                  <button type="button" class="module-move-up" title="<?php echo esc_attr( $button_title ); ?>">
                     <span class="dashicons dashicons-arrow-up-alt2"></span>
                  </button>
               <?php
               break;

            case 'move-down':
               $button_title = 'full-width' === $role ? sprintf( esc_html__( 'Move %s Down (Click and hold to move to the bottom of the page)', 'themefyre_builder' ), $title ) : sprintf( esc_html__( 'Move %s Up', 'themefyre_builder' ), $title );
               ?>
                  <button type="button" class="module-move-down" title="<?php echo esc_attr( $button_title ); ?>">
                     <span class="dashicons dashicons-arrow-down-alt2"></span>
                  </button>
               <?php
               break;
         }
      }
   }

   /**
    * Callback for displaying the module label for a specific module.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @uses builder_get_shortcodes()
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function module_has_custom_label( $atts, $content = null, $tag = null ) {
      $shortcode = builder_get_shortcode($tag);
      return 'none' !== $shortcode->config['label_attribute'] && isset( $atts[$shortcode->config['label_attribute']] );
   }

   /**
    * Callback for displaying the module label for a specific module.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @uses builder_get_shortcodes()
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function module_label( $atts, $content = null, $tag = null ) {
      $shortcode = builder_get_shortcode($tag);
      $has_custom_label = $this->module_has_custom_label( $atts, $content, $tag );
      ?>
         <p class="module-title">
            <span class="module-name"><?php echo esc_html( $shortcode->config['labels']['singular'] ); ?></span>
            <?php if ( $has_custom_label ) : ?>
               <span class="module-label">
                  <?php echo builder_decode_shortcode_attr( $atts[$shortcode->config['label_attribute']] ); ?>
               </span>
            <?php endif; ?>
         </p>
      <?php
   }

   /**
    * Returns the preview for the module based on the supplied attirbutes & content
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null).
    * @return string
    */
   public function module_preview( $atts, $content = null, $tag = null ) {
      $shortcode = builder_get_shortcode($tag);
      if ( 'content' !== $shortcode->config['builder_role'] && 'child' !== $shortcode->config['builder_role'] ) {
         return '';
      }
      return $shortcode->builder_preview_callback( $shortcode->get_sanitized_attributes( $atts ), $content, $tag );
   }

   /**
    * Outputs all relevant attributes for a module container.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @uses builder_get_shortcodes()
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function module_container_html_attributes( $atts, $content = null, $tag = null ) {
      $shortcode = builder_get_shortcode($tag);
      $atts_json = "";
      if ( is_array( $atts ) && ! empty( $atts ) ) {
         $atts_json = array();
         foreach ( $atts as $key => $value ) {
            $atts_json[$key] = builder_encode_shortcode_attr( $value );
         }
         $atts_json = json_encode( $atts_json );
      }

      $row_bottom_margin = 'row' == $shortcode->config['builder_role'] && isset( $atts['bottom_margin'] ) && $atts['bottom_margin'] ? ' data-bottom-margin="'.esc_attr($atts['bottom_margin']).'"' : '';

      // Create the class list
      $has_custom_label = $this->module_has_custom_label( $atts, $content, $tag ) ? 'has-custom-label' : '';
      $has_custom_source = 'none' !== $shortcode->config['builder_source'] ? 'has-custom-source' : '';
      $has_preview = $this->module_preview($atts, $content, $tag) ? 'has-preview' : '';
      $class = builder_compile_html_class('builder-module', $has_custom_label, $has_custom_source, $has_preview);

      // Echo the attributes string
      echo 'class="'.$class.'" data-singular-name="'.esc_attr($shortcode->config['labels']['singular']).'" data-role="'.$shortcode->config['builder_role'].'" data-content-type="'.$shortcode->config['content_type'].'" data-tag="'.$tag.'" data-label-attribute="'.$shortcode->config['label_attribute'].'" data-attributes=\''.$atts_json.'\''.$row_bottom_margin;
   }

   /**
    * Alternate callback for displaying the shortcode module sin the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @uses builder_get_shortcodes()
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function module_callback( $atts, $content = null, $tag = null ) {
      $shortcodes = builder_get_shortcodes();
      $shortcode = $shortcodes[$tag];
      $atts_string = "";
      if ( is_array( $atts ) && ! empty( $atts ) ) {
         foreach ( $atts as $key => $val ) {
            $atts_string .= ' '.$key.'="'.$val.'"';
         }
      }
      ob_start(); ?>
      <div <?php $this->module_container_html_attributes( $atts, $content, $tag ); ?>>

         <?php if ( 'content' === $shortcode->config['builder_role'] || 'child' === $shortcode->config['builder_role'] ) : ?>
            <div class="module-header">
         <?php endif; ?>
            <div class="module-controls">
               <div class="module-controls-inner">
                  <?php
                     $buttons = array('edit', 'duplicate', 'remove');
                     if ( 'full-width'== $shortcode->config['builder_role'] ) {
                        $buttons[] = 'move-up';
                        $buttons[] = 'move-down';
                     }
                     $this->module_controls( $buttons, $tag );
                  ?>
               </div>
            </div>
            <?php $this->module_label( $atts, $content, $tag ); ?>
         <?php if ( 'content' === $shortcode->config['builder_role'] || 'child' === $shortcode->config['builder_role'] ) : ?>
            </div>
         <?php endif; ?>

         <?php if ( 'none' == $shortcode->config['content_type'] ) : ?>
            <textarea class="builder-piece" data-piece="complete">[<?php echo $tag . $atts_string; ?>]</textarea>
         <?php else : ?>
            <textarea class="builder-piece" data-piece="open">[<?php echo $tag . $atts_string; ?>]</textarea>
            <textarea class="builder-piece" data-piece="content"><?php echo $content; ?></textarea>
            <textarea class="builder-piece" data-piece="close">[/<?php echo $tag; ?>]</textarea>
         <?php endif; ?>

         <?php if ( 'content' === $shortcode->config['builder_role'] || 'child' === $shortcode->config['builder_role'] ) : ?>
            <div class="module-preview <?php echo esc_attr($tag); ?>-module-preview"><?php echo $this->module_preview( $atts, $content, $tag ); ?></div>
         <?php endif; ?>

         <?php if ( 'none' !== $shortcode->config['builder_source'] ) : ?>
            <p class="builder-module-external-source-indicator" title="<?php printf( esc_attr__('This shortcode module is only available while %s is active', 'themefyre_builder'), $shortcode->config['builder_source'] ); ?>">*</p>
         <?php endif; ?>
      </div>
      <?php return ob_get_clean();
   }

   /**
    * Alternate callback for displaying the shortcode modules in the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @uses builder_get_shortcodes()
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_section_module_callback( $atts, $content = null, $tag = null ) {
      $atts_string = "";
      if ( is_array( $atts ) && ! empty( $atts ) ) {
         foreach ( $atts as $key => $val ) {
            $atts_string .= ' '.$key.'="'.$val.'"';
         }
      }
      ob_start(); ?>
      <div <?php $this->module_container_html_attributes( $atts, $content, $tag ); ?>>
         <div class="module-controls">
            <div class="module-controls-inner">
               <?php
                  $buttons = array('edit', 'duplicate', 'remove', 'move-up', 'move-down');
                  $this->module_controls( $buttons, 'builder_section' );
               ?>
            </div>
         </div>
         <textarea class="builder-piece" data-piece="open">[<?php echo $tag . $atts_string; ?>]</textarea>
         <div class="builder-module-dropzone" data-dropzone="row">
            <?php echo $this->do_shortcode( $content ); ?>
         </div>
         <button type="button" class="builder-add-module dropzone-button" data-role="row" title="<?php esc_attr_e( 'Add New Row Module', 'themefyre_builder' ); ?>">
            <?php esc_html_e( 'Add New Row Module', 'themefyre_builder' ); ?>
         </button>
         <textarea class="builder-piece" data-piece="close">[/<?php echo $tag; ?>]</textarea>
      </div>
      <?php return ob_get_clean();
   }

   /**
    * Alternate callback for displaying column rows in the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_row_module_callback( $atts, $content = null, $tag = null ) {

      // Prepare a string version of the provided attributes
      $atts_string = "";
      if ( is_array( $atts ) && ! empty( $atts ) ) {
         foreach ( $atts as $key => $val ) {
            $atts_string .= ' '.$key.'="'.$val.'"';
         }
      }
      ob_start(); ?>
         <div <?php $this->module_container_html_attributes( $atts, $content, $tag ); ?>>
            <div class="module-controls">
               <div class="module-controls-inner">
                  <?php
                     $buttons = array('edit', 'duplicate', 'remove', 'move-up', 'move-down');
                     $this->module_controls( $buttons, $tag );
                  ?>
               </div>
            </div>
            <textarea class="builder-piece" data-piece="open">[builder_row<?php echo $atts_string; ?>]</textarea>
            <div class="builder-module-dropzone" data-dropzone="content">
               <?php echo $this->do_shortcode($content); ?>
            </div>
            <button type="button" class="builder-add-module dropzone-button" data-role="content" title="<?php esc_attr_e( 'Add New Module', 'themefyre_builder' ); ?>">
               <?php _e( 'Add New Module', 'themefyre_builder' ); ?>
            </button>
            <textarea class="builder-piece" data-piece="close">[/builder_row]</textarea>
         </div>
      <?php return ob_get_clean();
   }

   /**
    * Alternate callback for displaying columns in the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_column_module_callback( $atts, $content = null, $tag = null ) {
      global $builder_columns;
      $atts['content'] = $content;
      $builder_columns[] = $atts;
   }

   /**
    * Alternate callback for displaying column rows in the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_column_row_module_callback( $atts, $content = null, $tag = null ) {

      // Prepare a string version of the provided attributes
      $atts_string = "";
      if ( is_array( $atts ) && ! empty( $atts ) ) {
         foreach ( $atts as $key => $val ) {
            $atts_string .= ' '.$key.'="'.$val.'"';
         }
      }

      // Array of allowed special layouts
      $allowed_custom_layouts = array(
         '1_3-2_3',
         '2_3-1_3',
         '2_5-3_5',
         '3_5-2_5',
         '3_4-1_4',
         '1_4-3_4',
         '1_2-1_4-1_4',
         '1_4-1_2-1_4',
         '1_4-1_4-1_2',
      );

      // Grab any defined columns
      // Store the processed content so it can be used later
      global $builder_columns;
      $builder_columns = array();
      $processed_content = $this->do_shortcode( $content );

      // Not enough columns, do not return anything
      if ( ! is_array( $builder_columns ) || 2 > count( $builder_columns ) ) {
         return '';
      }

      // Limit number of columns to 6
      $builder_columns = array_slice( $builder_columns, 0, 6 );
      $num_columns = count( $builder_columns );

      // Check to see if a valid custom layout has been supplied
      $custom_layout = array();
      foreach ($builder_columns as $column_config) {
         if ( empty($column_config['span']) ) {
            $custom_layout = array();
            break;
         }
         $custom_layout[] = str_replace('/', '_', $column_config['span']);
      }

      // Make sure the custom layout (if any) is valid
      if ( ! empty($custom_layout) && ! in_array(implode('-', $custom_layout), $allowed_custom_layouts) ) {
         $custom_layout = array();
      }

      // Create the CSS friendly layout class
      $layout_class = ! empty($custom_layout) ? implode('-', $custom_layout) : $num_columns;

      ob_start(); ?>
         <div <?php $this->module_container_html_attributes( $atts, $content, 'builder_column_row' ); ?>>
            <div class="module-controls">
               <div class="module-controls-inner">
                  <?php
                     $buttons = array('edit', 'duplicate', 'remove', 'move-up', 'move-down');
                     $this->module_controls( $buttons, 'builder_column_row' );
                  ?>
               </div>
            </div>
            <textarea class="builder-piece" data-piece="open">[builder_column_row<?php echo $atts_string; ?>]</textarea>
            <div class="builder-columns-<?php echo $layout_class; ?> spacing-1">
            <?php for ( $i=0;$i<$num_columns;$i++ ) :

               // Grab the content then remove it from the attributes array
               $column_content = $this->do_shortcode( $builder_columns[$i]['content'] );
               unset($builder_columns[$i]['content']);
               $column_atts = $builder_columns[$i];

               // Prepare a string version of the provided attributes
               $column_atts_string = "";
               if ( is_array( $column_atts ) && ! empty( $column_atts ) ) {
                  foreach ( $column_atts as $key => $val ) {
                     $column_atts_string .= ' '.$key.'="'.$val.'"';
                  }
               }

               ?>
                  <div>
                     <div <?php $this->module_container_html_attributes( $column_atts, null, 'builder_column' ); ?>>
                        <textarea class="builder-piece" data-piece="open">[builder_column<?php echo $column_atts_string; ?>]</textarea>
                        <div class="builder-module-dropzone" data-dropzone="content">
                           <?php echo $column_content; ?>
                        </div>
                        <button type="button" class="builder-add-module dropzone-button" data-role="content" title="<?php esc_attr_e( 'Add New Module', 'themefyre_builder' ); ?>" style="float: left;">
                           <?php esc_html_e( 'Add New Module', 'themefyre_builder' ); ?>
                        </button>
                        <div class="module-controls">
                           <?php $this->module_controls( array('edit'), 'builder_column' ); ?>
                        </div>
                        <textarea class="builder-piece" data-piece="close">[/builder_column]</textarea>
                     </div>
                  </div>
            <?php endfor; ?>
            </div>
            <textarea class="builder-piece" data-piece="close">[/builder_column_row]</textarea>
         </div>
      <?php return ob_get_clean();
   }

   /**
    * Creates the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function render_builder() {
      ?>
         <div id="page_builder_meta_box" class="postbox">
            <h3 class="hndle">
               <span class="builder-normal-title"><?php esc_html_e( 'Themefyre Page Builder', 'themefyre_builder' ); ?></span>
               <span class="builder-fullscreen-title">
                  <span class="builder-post-title"><?php the_title(); ?></span>
                  <button class="button" id="builder-preview-post"><?php esc_html_e( 'Preview Changes', 'themefyre_builder' ); ?></button>
                  <button class="button" id="builder-save-post"><?php esc_html_e( 'Save Changes', 'themefyre_builder' ); ?></button>
               </span>
               <span id="builder-menu" class="builder-menu hide-if-no-js">
                  <?php if ( builder_is_developer_mode() ) : ?>
                     <button type="button" id="builder-export" title="<?php esc_attr_e( 'Export as executable shortcodes', 'themefyre_builder' ); ?>">
                        <span class="dashicons dashicons-editor-code"></span>
                     </button>
                  <?php endif; ?>
                  <button type="button" id="builder-undo" class="is-disabled" title="<?php esc_attr_e( 'Undo', 'themefyre_builder' ); ?>">
                     <span class="dashicons dashicons-undo"></span>
                  </button>
                  <button type="button" id="builder-redo" class="is-disabled" title="<?php esc_attr_e( 'Redo', 'themefyre_builder' ); ?>">
                     <span class="dashicons dashicons-redo"></span>
                  </button>
                  <button type="button" id="builder-reset" class="is-disabled" title="<?php esc_attr_e( 'Delete All Modules and Remove Any Custom CSS', 'themefyre_builder' ); ?>">
                     <span class="dashicons dashicons-trash"></span>
                  </button>
                  <button type="button" id="builder-instant-preview" title="<?php esc_attr_e( 'Toggle instant preview, when enabled the page preview will automatically refresh whenever you make a change.', 'themefyre_builder' ); ?>">
                     <span class="dashicons dashicons-update"></span>
                  </button>
                  <button type="button" id="builder-templates" title="<?php esc_attr_e( 'Template Manager', 'themefyre_builder' ); ?>">
                     <span class="dashicons dashicons-download"></span>
                  </button>
                  <button type="button" id="builder-edit-css" title="<?php esc_attr_e( 'Edit CSS', 'themefyre_builder' ); ?>">
                     <span class="dashicons dashicons-admin-appearance"></span>
                  </button>
                  <button type="button" id="builder-toggle-fullscreen" title="<?php esc_attr_e( 'Toggle Fullscreen', 'themefyre_builder' ); ?>">
                     <span class="dashicons dashicons-editor-expand"></span>
                  </button>
               </span>
            </h3>
            <?php if ( ! current_theme_supports('themefyre-page-builder') ) : ?>
               <p class="builder-no-theme-support"><?php echo wp_kses( sprintf( __('The active theme does not support Themefyre Page Builder, some shortcode modules may not be displayed correctly.<br /> You can purchase a compatible theme from <a href="%s" target="_blank">Themefyre</a>.', 'themefyre_builder' ), 'http://www.themefyre.com'), array('href'=>array('a'=>array(),'target'=>array()))); ?></p>
            <?php endif; ?>
            <div id="builder" class="inside">
               <div class="hide-if-no-js">
                  <div id="builder-canvas" class="builder-module-dropzone" data-dropzone="full-width">
                     <?php echo $this->do_shortcode( get_post_meta( get_the_ID(), '_themefyre_builder_value', true ) ); ?>
                  </div>
                  <button class="builder-add-module dropzone-button" data-role="full-width" title="<?php esc_attr_e( 'Add New Full Width Module', 'themefyre_builder' ); ?>" type="button"></button>
                  <div id="builder-start">
                     <span class="builder-start-line-1"><?php esc_html_e( 'Welcome to Themefyre Page Builder', 'themefyre_builder' ); ?></span>
                     <span class="builder-start-line-2"><?php esc_html_e( 'Add Your First Module or Select a Template to Import Below', 'themefyre_builder' ); ?></span>
                     <div class="builder-start-buttons">
                        <button id="builder-start-select-module" type="button" class="button">
                           <?php esc_html_e( 'Select Module', 'themefyre_builder' ); ?>
                        </button>
                        <button id="builder-start-select-template" type="button" class="button button-primary">
                           <?php esc_html_e( 'Import Template', 'themefyre_builder' ); ?>
                        </button>
                     </div>
                  </div>
               </div>
               <div class="hide-if-js">
                  <p><?php esc_html_e( 'JavaScript must be enabled to use the Themefyre Page Builder.', 'themefyre_builder' ); ?></p>
               </div>
            </div>
            <div id="builder-fields">
               <input type="hidden" id="builder-post-id" value="<?php echo get_the_ID(); ?>">
               <input type="hidden" id="builder-state" name="_themefyre_builder_state" value="<?php echo builder_get_state(); ?>">
               <textarea id="builder-temporary-value" name="_themefyre_builder_temporary_value"></textarea>
               <textarea id="builder-css-value" name="_themefyre_builder_temporary_css"><?php echo builder_get_css(); ?></textarea>
            </div>
         </div>
      <?php
   }

   /**
    * AJAX callback for getting the preview for an `image` attribute.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function get_image_preview_callback() {
      if ( ! $value = isset( $_POST['value'] ) ? $_POST['value'] : null ) {
         die();
      }
      if ( $attachment_data = wp_get_attachment_image_src( $value, 'medium' ) ) {
         echo '<img src="'.$attachment_data[0].'" alt="" />';
      }
      die();
   }

   /**
    * AJAX callback for getting the preview for an `gallery` attribute.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function get_gallery_preview_callback() {
      if ( ! $value = isset( $_POST['value'] ) ? $_POST['value'] : null ) {
         die();
      }
      foreach ( explode( ',', $value ) as $attachment_id ) {
         if ( $attachment_data = wp_get_attachment_image_src( $attachment_id, 'thumbnail' ) ) {
            echo '<li style="background-image:url('.$attachment_data[0].');"></li>';
         }
      }
      die();
   }

   /**
    * AJAX callback for getting the rendered modules from a string containing shortcodes.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function get_builder_modules_callback() {
      if ( ! $value = isset( $_POST['value'] ) ? $_POST['value'] : null ) {
         die();
      }
      echo $this->do_shortcode( stripslashes( $value ) );
      die();
   }

   /**
    * AJAX callback for getting the page builder value from a specific post.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function get_post_builder_value_callback() {
      if ( ! $post_ID = isset( $_POST['post_id'] ) ? $_POST['post_id'] : null ) {
         die();
      }
      echo get_post_meta( $post_ID, '_themefyre_builder_value', true );
      die();
   }

   /**
    * AJAX callback for getting the page builder CSS value from a specific post.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function get_post_builder_css_callback() {
      if ( ! $post_ID = isset( $_POST['post_id'] ) ? $_POST['post_id'] : null ) {
         die();
      }
      echo get_post_meta( $post_ID, '_themefyre_builder_css', true );
      die();
   }

   /**
    * AJAX callback for deleting a post by ID.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function delete_post_callback() {
      if ( ! $post_ID = isset( $_POST['post_id'] ) ? $_POST['post_id'] : null ) {
         echo 'error';
         die();
      }
      echo wp_delete_post( $post_ID, true ) ? 'success' : 'error';
      die();
   }

   /**
    * AJAX callback for deleting a post by ID.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function create_template_callback() {
      if ( ! $post_title = isset( $_POST['post_title'] ) ? $_POST['post_title'] : null ) {
         echo 'error';
         die();
      }
      if ( ! $builder_value = isset( $_POST['builder_value'] ) ? $_POST['builder_value'] : null ) {
         echo 'error';
         die();
      }

      $css_value = isset( $_POST['css_value'] ) ? $_POST['css_value'] : '';

      // Create post object
      $args = array(
         'post_title'   => $post_title,
         'post_status'  => 'publish',
         'post_type'    => 'builder_template',
      );

      // Insert the post into the database
      $result = wp_insert_post( $args );

      if ( is_int( $result ) && $result ) {

         // Update the value of the page builder for our new template
         update_post_meta( $result, '_themefyre_builder_value', $builder_value );
         update_post_meta( $result, '_themefyre_builder_css', $css_value );

         ?>
            <button type="button" data-post-id="<?php echo $result; ?>">
               <?php echo esc_html( $post_title ); ?>
               <span class="remove-item" title="<?php esc_attr_e( 'Delete Template', 'themefyre_builder' ); ?>"><span class="dashicons dashicons-no-alt"></span></span>
            </button>
         <?php
      }
      else {
         echo 'error';
      }

      die();
   }

   /**
    * AJAX callback for getting the content of a premade template.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function get_premade_template_callback() {
      if ( ! $template_slug = isset( $_POST['template_slug'] ) ? $_POST['template_slug'] : null ) {
         die();
      }
      $builder = builder();
      include $builder->templates[$template_slug]['path'];
      die();
   }

}