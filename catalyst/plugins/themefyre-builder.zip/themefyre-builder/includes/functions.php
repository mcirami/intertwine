<?php

/**
 * Themefyre Page Builder Functions.
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Add custom links to the plugin action links in WP admin.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @return array
 */
function builder_action_links( $links ) {
   $links[] = '<a href="'.get_admin_url(null, 'options-general.php?page=builder-settings').'">'.esc_attr__('Settings', 'themefyre_builder').'</a>';
   return $links;
}

/**
 * Registers the `Themefyre Page Builder Template` post type with WordPress
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @return array
 */
function builder_template_post_type() {
   $args = array(
      'labels' => array(
         'name'          => __( 'Page Builder Templates', 'themefyre_builder' ),
         'singular_name' => __( 'Page Builder Template', 'themefyre_builder' ),
      ),
      'supports' => array( 'title', 'editor', ),
   );
   register_post_type( 'builder_template', $args );
}

/**
 * used to check if the page builder is in developer mode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @return bool
 */
function builder_is_developer_mode() {
   return defined('BUILDER_DEVELOPER_MODE') && BUILDER_DEVELOPER_MODE;
}

/**
 * Returns an array of enabled icon fonts.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @return array
 */
function builder_enabled_icon_fonts() {
   $default_icon_fonts = array(
      'entypo' => true,
   );

   $icon_fonts_setting = get_option( 'builder_icon_fonts', $default_icon_fonts );

   $icon_fonts = array();
   foreach ( $icon_fonts_setting as $icon_font => $enabled ) {
      if ( $enabled ) {
         $icon_fonts[] = $icon_font;
      }
   }
   return $icon_fonts;
}

/**
 * Returns an array of post types that the page builder has been applied to.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @return array
 */
function builder_get_screens() {
   $default_screens = array(
      'page' => true,
      'post' => true,
   );

   $screens_setting = get_option( 'builder_screens', $default_screens );

   $screens = array();
   foreach ( $screens_setting as $post_type => $enabled ) {
      if ( $enabled ) {
         $screens[] = $post_type;
      }
   }
   return $screens;
}

/**
 * Returns the state of the page builder.
 *
 * Can be used within the loop or with a custom Post ID.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param int $post_id Post ID (default: null)
 * @return array
 */
function builder_get_state( $post_id = null ) {
   if ( is_null( $post_id ) ) $post_id = get_the_ID();
   $state = get_post_meta( $post_id, '_themefyre_builder_state', true );
   return $state ? $state : 'inactive';
}

/**
 * Returns the saved custom CSS for the page builder.
 *
 * Can be used within the loop or with a custom Post ID.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param int $post_id Post ID (default: null)
 * @return array
 */
function builder_get_css( $post_id = null ) {
   if ( is_null( $post_id ) ) $post_id = get_the_ID();
   return get_post_meta( $post_id, '_themefyre_builder_css', true );
}

/**
 * Determines if the page builder is enabled for a specific post.
 *
 * Can be used within the loop or with a custom Post ID.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_get_screens()
 * @uses builder_get_state()
 *
 * @param int $post_id Valid post ID
 * @return bool
 */
function builder_is_enabled( $post_id = null ) {
   if ( is_null( $post_id ) ) $post_id = get_the_ID();
   return in_array( get_post_type( $post_id ), builder_get_screens() ) && 'active' == builder_get_state( $post_id );
}

/**
 * Determines if the page builder is active for a specific post.
 *
 * Can be used within the loop or with a custom Post ID.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_get_screens()
 * @uses builder_get_state()
 *
 * @param int $post_id Valid post ID
 * @return bool
 */
function builder_is_active( $post_id = null ) {
   return is_singular( $post_id ) && builder_is_enabled( $post_id );
}

/**
 * Filter the content of posts upon saving.
 *
 * This page builder encodes the content into a single string, this is to prevent
 * WordPress from formatting the content, and will preserve all user formatting.
 * Unfortunately this masks the content of the post, preventing it from being
 * shown in search results. This function counters this.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_get_searchable_content()
 * @uses builder_remove_shortcode()
 *
 * @param string $content Content of post being saved
 * @return string
 */
function builder_content_save_pre( $content ) {

   // Can not determine if page builder is active, or which post is being saved. Do nothing.
   if ( ! isset( $_POST['_themefyre_builder_state'] ) || ! isset( $_POST['post_ID'] ) ) {
      return $content;
   }

   // Page builder is active, sanitize content & prepare for saving
   if ( 'active' === $_POST['_themefyre_builder_state'] ) {

      // Retrieve the searchable content string for the content
      $searchable_content = builder_get_searchable_content( stripslashes( $content ) );

      // Return a single shortcode which contains all of the searchable content
      return '[builder_content post_id="'.$_POST['post_ID'].'"]'.$searchable_content.'[/builder_content]';
   }

   // Page builder is not active, remove any unnecessary shortcodes
   else if ( 'inactive' === $_POST['_themefyre_builder_state'] ) {
      $content = builder_remove_shortcode( $content, 'builder_content' );
   }

   return $content;
}

/* ================================================ *
 * HELPERS
 * ================================================ */

/**
 * Returns a boolean value based on the unput.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param mixed $input Input value to be converted to boolean
 * @return bool
 */
function builder_get_bool( $input ) {
   return is_bool( $input ) ? $input : 'true' == $input;
}

/**
 * Returns a string value based on the unput.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param mixed $input Input value to be converted to boolean
 * @return string
 */
function builder_get_bool_string( $input ) {
   return is_bool( $input ) && $input ? 'true' : 'false';
}

/**
 * Completely flatten a multi dimensional array.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param array $array Multidimensional array to be flattened
 * @return string
 */
function builder_flatten_array( $array ) {
   $flat = array();
   foreach ( $array as $key => $value ) {
      if ( is_array( $value ) ) {
         $flat = array_merge( $flat, builder_flatten_array( $value ) );
         continue;
      }
      $flat[$key] = $value;
   }
   return $flat;
}

/**
 * Recursively sanitize each element in an array.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param array $array Array whose elements should be sanitized
 * @param callable $sanitization Function to be used to sanitize each element
 * @return string
 */
function builder_sanitize_array( $array, $sanitization ) {
   $sanitized = array();
   foreach ( $array as $key => $value ) {
      if ( is_array( $value ) ) {
         $sanitized[$key] = builder_sanitize_array( $value, $sanitization );
         continue;
      }
      $sanitized[$key] = call_user_func( $sanitization, $value );
   }
   return $sanitized;
}

/**
 * Helper function to convert a hex value to an rgba value
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param string $hex 3 or 6 character hex code
 * @param string $alpha Alpha for generated RGBA
 * @return string
 */
function builder_hex_to_rgba( $hex, $alpha = 1 ) {
   $hex = str_replace('#', '', $hex);

   // Convert hex to 6 character, if needed
   if ( strlen($hex) == 3 ) {
      $hex_1 = str_repeat( substr($hex, 0, 1), 2 );
      $hex_2 = str_repeat( substr($hex, 1, 1), 2 );
      $hex_3 = str_repeat( substr($hex, 2, 1), 2 );
      $hex = $hex_1 . $hex_2 . $hex_3;
   }

   if ( 6 !== strlen($hex) ) return $hex;

   // Get RGB values
   $r = hexdec( substr($hex, 0, 2) );
   $g = hexdec( substr($hex, 2, 2) );
   $b = hexdec( substr($hex, 4, 2) );

   return 'rgba(' . $r . ',' . $g . ',' . $b . ',' . $alpha . ')';
}

/* ================================================ *
 * FORMATTING
 * ================================================ */

/**
 * Creates a valid sanitized list of classes based on any number of variables.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param mixed $arg Either array or string HTML class.
 * @return string
 */
function builder_compile_html_class( $arg ) {
   for ( $i=0; $i<func_num_args(); $i++ ) {
      $classes = func_get_arg($i);
      if ( ! is_array( $classes ) ) {
         $classes = explode(' ', trim( $classes ) );
      }
      foreach ( $classes as $class ) {
         if ( is_string( $class ) && $class = sanitize_html_class( $class ) ) {
            $class_list[] = $class;
         }
      }
   }
   if ( empty( $class_list ) ) {
      return '';
   }
   return implode(' ', array_unique( $class_list ) );
}

/**
 * Sanitizes a space delimited list of CSS classes.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param string $input The input CSS classes
 * @return string
 */
function builder_sanitize_html_class_list( $input ) {
   $out = '';
   foreach ( explode( ' ', trim( $input ) ) as $class ) {
      if ( $class = sanitize_html_class( $class ) ) {
         $out .= $class.' ';
      }
   }
   return apply_filters( 'builder_sanitize_html_class_list', trim($out) );
}

/**
 * Sanitizes a 3 or 6 character hex code
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param string $color The input hex code
 * @return string
 */
function builder_sanitize_hex_color( $color ) {
   if ( '' === $color ) {
      return '';
   }

   // 3 or 6 hex digits, or the empty string.
   if ( preg_match('|^#([A-Fa-f0-9]{3}){1,2}$|', $color ) ) {
      return $color;
   }

   return null;
}

/**
 * Makes sure returned value is an integer
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param string $input The input value
 * @return string
 */
function builder_sanitize_int( $input ) {
   if ( ! $input = preg_replace( '/[^0-9]/', '', $input ) ) {
      return '';
   }
   return intval( $input );
}

/**
 * Function to convert a string to a usable slug.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param bool $input The string to be converted to a string
 * @return string
 */
function builder_slug( $input ) {

   // replace non letter or digits by -
   $input = preg_replace('~[^\\pL\d]+~u', '-', $input);

   // trim
   $input = trim( $input, '-' );

   // transliterate
   $input = iconv( 'utf-8', 'us-ascii//TRANSLIT', $input );

   // lowercase
   $input = strtolower( $input );

   // remove unwanted characters
   $input = preg_replace( '~[^-\w]+~', '', $input );

   if ( empty( $input ) ) {
      return 'n-a';
   }

   return $input;
}

/**
 * Function to convert a string to a safe value for shortcode attributes.
 *
 * Simply replaces all square brackets and quotes with their HTML entinty alternatives.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param bool $input The string to be encoded
 * @return string
 */
function builder_encode_shortcode_attr( $input ) {
   $replace = array( 'BUILDER_LEFT_BRACKET', 'BUILDER_RIGHT_BRACKET', 'BUILDER_DOUBLE_QUOTE', 'BUILDER_SINGLE_QUOTE' );

   $search  = array( '[', ']', '"', "'" );
   $input = str_replace( $search, $replace, $input );

   $search  = array( '&#91;', '&#93;', '&#34;', '&#39;' );
   $input = str_replace( $search, $replace, $input );

   return str_replace( $search, $replace, $input );
}

/**
 * Function to convert a string to a display friendly value.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param bool $input The string to be encoded
 * @return string
 */
function builder_decode_shortcode_attr( $input ) {
   $search  = array( 'BUILDER_LEFT_BRACKET', 'BUILDER_RIGHT_BRACKET', 'BUILDER_DOUBLE_QUOTE', 'BUILDER_SINGLE_QUOTE' );
   $replace = array( '[', ']', '"', "'" );
   return str_replace( $search, $replace, $input );
}

/* ================================================ *
 * PLUGIN INTEGRATION
 * ================================================ */

/**
 * Checks to see if a single plugin is active based on its path.
 *
 * This function will first check to see if the standard WordPress method
 * for determining if a plugin is active is available, if it is that function
 * will be used.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @see http://codex.wordpress.org/Function_Reference/is_plugin_active
 * @see http://codex.wordpress.org/Function_Reference/is_plugin_active_for_network
 *
 * @param $plugin The name of the plugin sub-directory/file.
 * @return bool
 */
function builder_is_plugin_active( $plugin ) {
   if ( function_exists('is_plugin_active') ) {
      return is_plugin_active( $plugin );
   }

   // See if plugin is active for multisite
   if ( is_multisite() ) {
      $multisite_plugins = get_site_option( 'active_sitewide_plugins' );
      if ( isset( $multisite_plugins[$plugin] ) ) {
         return true;
      }
   }

   // See if plugin is active for single site
   return in_array( $plugin, (array) get_option( 'active_plugins', array() ) );
}

/* ================================================ *
 * THEME INTEGRATION
 * ================================================ */

/**
 * Returns the supplied value of the content max width.
 *
 * If no value has been supplied the max width is assumed to be 1000px
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param int $default The value to be returned if no value was supplied (default: 1000).
 * @return mixed
 */
function builder_get_theme_content_max_width( $default = 1000 ) {
   if ( ! $theme_support = get_theme_support('themefyre-page-builder') ) {
      return $default;
   }
   if ( ! isset( $theme_support[0]['content_max_width'] ) ) {
      return $default;
   }
   return $theme_support[0]['content_max_width'];
}

/**
 * Returns the supplied value of the smooth scroll offset.
 *
 * If no value has been supplied the offset is assumed to be 0px
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param int $default The value to be returned if no value was supplied (default: 0).
 * @return mixed
 */
function builder_get_theme_scroll_top_offset( $default = 0 ) {
   if ( ! $theme_support = get_theme_support('themefyre-page-builder') ) {
      return $default;
   }
   if ( ! isset( $theme_support[0]['scroll_top_offset'] ) ) {
      return $default;
   }
   return $theme_support[0]['scroll_top_offset'];
}

/**
 * Returns the supplied value of the content spacer size.
 *
 * If no value has been supplied the spacer size is assumed to be 22px
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param int $default The value to be returned if no value was supplied (default: 22).
 * @return mixed
 */
function builder_get_theme_content_spacer_size( $default = 22 ) {
   if ( ! $theme_support = get_theme_support('themefyre-page-builder') ) {
      return $default.'px';
   }
   if ( ! isset( $theme_support[0]['content_spacer_size'] ) ) {
      return $default.'px';
   }
   return $theme_support[0]['content_spacer_size'].'px';
}

/**
 * Returns an array of Google fonts included in the active theme.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @return mixed
 */
function builder_get_theme_google_fonts() {
   if ( ! $theme_support = get_theme_support('themefyre-page-builder') ) {
      return;
   }
   if ( ! isset( $theme_support[0]['theme_google_fonts'] ) ) {
      return;
   }
   return $theme_support[0]['theme_google_fonts'];
}

/**
 * Returns an array of button styles included in the active theme.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @return mixed
 */
function builder_get_theme_button_styles() {
   if ( ! $theme_support = get_theme_support('themefyre-page-builder') ) {
      return;
   }
   if ( ! isset( $theme_support[0]['theme_button_styles'] ) ) {
      return;
   }
   return $theme_support[0]['theme_button_styles'];
}

/**
 * Returns an array of text styles included in the active theme.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @return mixed
 */
function builder_get_theme_text_styles() {
   if ( ! $theme_support = get_theme_support('themefyre-page-builder') ) {
      return;
   }
   if ( ! isset( $theme_support[0]['theme_text_styles'] ) ) {
      return;
   }
   $out = null;
   foreach ( $theme_support[0]['theme_text_styles'] as $value => $name ) {
      $out['builder-text-style-'.$value] = $name;
   }
   return $out;
}

/* ================================================ *
 * FRONT-END
 * ================================================ */

/**
 * Adds the `no-js` class to the body so it can be removed later.
 *
 * @since Themefyre Page Builder 0.0.0
 */
function builder_body_class( $classes ) {
   if ( ! in_array('no-js', $classes) ) {
      $classes[] = 'no-js';
   }
   $builder_state = is_singular() ? builder_get_state() : 'inactive';
   $classes[] = 'builder-'.$builder_state;
   return $classes;
}

/**
 * Enqueus front-end styles/scripts for the page builder.
 *
 * @since Themefyre Page Builder 0.0.0
 */
function builder_enqueue_assets() {
   wp_enqueue_style( 'builder-front-end' );

   if ( is_rtl() ) {
      wp_enqueue_style( 'builder-rtl' );
   }

   wp_enqueue_script( 'builder-front-end' );
}

/**
 * Insert custom JavaScript variables on the front-end
 *
 * @uses builder_get_theme_content_max_width()
 *
 * @since Themefyre Page Builder 0.0.0
 */
function builder_insert_js_vars() {
   ?>
      <script>
         // Ensure availability of the global themefyreBuilder object
         window.themefyreBuilder = window.themefyreBuilder || {};

         // Content maximum width
         themefyreBuilder.contentMaxWidth = <?php echo builder_get_theme_content_max_width(); ?>;

         // Scroll top offset
         themefyreBuilder.scrollTopOffset = <?php echo builder_get_theme_scroll_top_offset(); ?>;
      </script>
   <?php
}

/**
 * Outputs any user defined global CSS
 *
 * @since Themefyre Page Builder 0.0.0
 */
function builder_enqueue_global_css() {
   if ( $global_css = get_option('builder_global_css') ) {
      echo '<style id="builder-global-css">'.$global_css.'</style>';
   }
}

/**
 * Enqueues all enabled icon fonts.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_enabled_icon_fonts()
 */
function builder_enqueue_icon_fonts() {
   $builder = builder();
   foreach ( builder_enabled_icon_fonts() as $icon_font ) {
      wp_enqueue_style( 'builder-icons-'.$icon_font, $builder->plugin_url.'icons/'.$icon_font.'/'.$icon_font.'.css', false, $builder->version );
   }
}

/**
 * Enqueues all enabled Google fonts.
 *
 * @since Themefyre Page Builder 0.0.0
 */
function builder_enqueue_google_fonts() {
   $builder = builder();
   $fonts = get_option( 'builder_google_fonts' );
   $subsets_list = array();
   if ( empty( $fonts ) ) {
      return;
   }
   foreach ( $fonts as $name => $font ) {
      $variants = isset( $font['variants'] ) && $font['variants'] ? $font['variants'] : null;
      $subsets = isset( $font['subsets'] ) && $font['subsets'] ? $font['subsets'] : null;

      // Begin with just the name
      $request = str_replace(' ', '+', $name);

      // If there are certain variants to be requested, list them
      if ( $variants ) {
         $request .= ':'.$variants;
      }

      // If there are certain subsets to load, add them
      if ( $subsets ) {
         foreach ( explode(',', $subsets) as $subset ) {
            if ( in_array($subset, $subsets_list) ) {
               continue;
            }
            $subsets_list[] = $subset;
         }
      }

      // Add the request to our list of fonts to load
      $load_fonts[] = $request;
   }
   if ( ! empty( $load_fonts ) ) {

      // Start our URL
      $http = is_ssl() ? 'https' : 'http';
      $url = $http.'://fonts.googleapis.com/css?family='.implode('|', $load_fonts);

      // Append the subsets list when applicable
      if ( ! empty( $subsets_list ) ) {
         $url .= '&subset='.implode(',', $subsets_list);
      }

      wp_enqueue_style( 'builder-google-fonts', $url, false, $builder->version );
   }
}

/* ================================================ *
 * ATTACHMENTS
 * ================================================ */

/**
 * Returns the url for an attachment using its ID.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param int $attachment_id The ID of the image to use
 * @param string $size Additional class(es) to add to the icon. (default: 'full')
 * @return string
 */
function builder_get_attachment_src( $attachment_id, $size = 'full' ) {
   if ( $img_data = wp_get_attachment_image_src( $attachment_id, $size ) ) {
      return  $img_data[0];
   }
   return '';
}

/**
 * Returns the caption for an attachment using its ID.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param int $attachment_id The ID of the image to use
 * @return string
 */
function builder_get_attachment_caption( $attachment_id ) {
   $attachment = get_post( $attachment_id );
   return $attachment->post_excerpt;
}

/**
 * Returns the alt text for an attachment using its ID.
 *
 * This function will first look for a custom entered alt text
 * entered by the user, if none is found the title will be used,
 * if the title is not found then the ID will be used as is, this
 * way the image will always have some kind of alt text.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param int $attachment_id The ID of the image to use
 * @return string
 */
function builder_get_attachment_alt( $attachment_id ) {
   if ( $alt = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) ) {
      return $alt;
   }
   if ( $caption = builder_get_attachment_caption( $attachment_id ) ) {
      return $caption;
   }
   if ( $title = get_the_title( $attachment_id ) ) {
      return $title;
   }
   return $attachment_id;
}

/**
 * Returns an array of all intermediate image sizes.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @return array
 */
function builder_get_attachment_sizes() {
   global $_wp_additional_image_sizes;

   $sizes = array();

   foreach( get_intermediate_image_sizes() as $_size ) {
      if ( in_array( $_size, array( 'thumbnail', 'medium', 'large' ) ) ) {
         $sizes[$_size] = array(
            'width'  => get_option( $_size . '_size_w' ),
            'height' => get_option( $_size . '_size_h' ),
            'crop'   => (bool) get_option( $_size . '_crop' ),
         );
      }
      else if ( isset( $_wp_additional_image_sizes[ $_size ] ) ) {
         $sizes[$_size] = array(
            'width'  => $_wp_additional_image_sizes[ $_size ]['width'],
            'height' => $_wp_additional_image_sizes[ $_size ]['height'],
            'crop'   => $_wp_additional_image_sizes[ $_size ]['crop'],
         );
      }
   }

   return $sizes;
}

/**
 * Returns an array of available image sizes.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_get_attachment_sizes()
 *
 * @return array
 */
function builder_get_available_attachment_sizes() {
   $image_sizes = array(
      'full' => __( 'Full Size', 'themefyre_builder' ),
   );
   foreach ( builder_get_attachment_sizes() as $name => $sizes ) {
      $image_sizes[$name] = ucwords( str_replace( array('-','_'), ' ', $name ) ).' ('.$sizes['width'].' x '.$sizes['height'].')';
   }
   return $image_sizes;
}

/**
 * Returns an array of available button styles.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @return array
 */
function builder_get_available_button_styles() {
   $styles = array(
      'default' => __( '(default button style)', 'themefyre_builder' ),
   );

   $styles[__( 'Basic Styles', 'themefyre_builder' )] = array(
      'muted'   => __( 'Muted', 'themefyre_builder' ),
      'inverse' => __( 'Inverse', 'themefyre_builder' ),
   );

   $styles[__( 'Colors', 'themefyre_builder' )] = array(
      'blue'  => __( 'Blue', 'themefyre_builder' ),
      'green' => __( 'Green', 'themefyre_builder' ),
      'red'   => __( 'Red', 'themefyre_builder' ),
   );

   if ( $theme_style_options = builder_get_theme_button_styles() ) {
      $styles[sprintf( __( '%s Theme Styles', 'themefyre_builder' ), wp_get_theme() )] = $theme_style_options;
   }

   return $styles;
}

/**
 * Returns an array of available text styles.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @return array
 */
function builder_get_available_text_styles() {
   $styles = array(
      'none' => __( '(no applied style)', 'themefyre_builder' ),
   );

   $styles[__( 'Basic Styles', 'themefyre_builder' )] = array(
      'builder-text-style-page-title'      => __( 'Page Title', 'themefyre_builder' ),
      'builder-text-style-page-tagline'    => __( 'Page Tagline', 'themefyre_builder' ),
      'builder-text-style-section-title'   => __( 'Section Title', 'themefyre_builder' ),
      'builder-text-style-section-tagline' => __( 'Section Tagline', 'themefyre_builder' ),
   );

   $styles[__( 'Hero Styles', 'themefyre_builder' )] = array(
      'builder-text-style-hero-title'       => __( 'Hero Title', 'themefyre_builder' ),
      'builder-text-style-hero-tagline'     => __( 'Hero Tagline', 'themefyre_builder' ),
   );

   if ( $theme_style_options = builder_get_theme_text_styles() ) {
      $styles[sprintf( __( '%s Theme Styles', 'themefyre_builder' ), wp_get_theme() )] = $theme_style_options;
   }

   return $styles;
}

/* ================================================ *
 * TEMPLATING
 * ================================================ */

/**
 * Returns the slug of a random enabled icon
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @return string
 */
function builder_get_random_icon_slug() {
   $builder = builder();

   // Will contain our list of enabled icons
   static $enabled_icons = array();

   // If the list of enabled icons has not been created we need to
   // populate, if it turns out the list is empty we will set the value
   // to null so we know that no icons have been enabled
   if ( is_array( $enabled_icons ) && empty( $enabled_icons ) ) {
      foreach ( builder_enabled_icon_fonts() as $icon_font ) {

         // Get the configuration for the icon font
         ob_start();
         include $builder->plugin_dir . 'icons/'.$icon_font.'/'.$icon_font.'.json';
         $icon_font_config = json_decode( ob_get_clean(), true );

         // Make sure there are icons to show
         if ( empty( $icon_font_config ) ) {
            continue;
         }

         foreach ( $icon_font_config['glyphs'] as $glyph ) {
            $enabled_icons[] = $icon_font_config['css_prefix_text'].$glyph['css'];
         }
      }

      // Set the value to null so we know that no icons have been enabled
      if ( empty( $enabled_icons ) ) {
         $enabled_icons = null;
      }
   }

   // If at least one icon font has been enabled, select one at random
   if ( ! empty( $enabled_icons ) ) {
      return $enabled_icons[array_rand($enabled_icons)];
   }

   // No icons have been enabed, return an empty string
   return '';
}

/**
 * Prints the slug of a random enabled icon
 *
 * @since Themefyre Page Builder 0.0.0
 */
function builder_random_icon_slug() {
   echo builder_get_random_icon_slug();
}

/**
 * Used to register a template with the page builder.
 *
 * You must create a separate file for each template you wish to add.
 * Each separate file should consist of exlusively 1 template,
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param string $slug Unique slug to be used to identify the template.
 * @param string $args Array or arguments for the template.
 * @return bool
 */
function builder_add_template( $slug, $args ) {
   $default_args = array(
      'name'   => '',     // Displayed name of the template
      'desc'   => '',     // Short description of the template
      'path'   => '',     // Path to the file containing the template
      'source' => 'none', // Optional, if the template was provided by a theme or separate plugin, add its name here.
   );

   $args = wp_parse_args( $args, $default_args );

   // Make sure our template has a readable path
   if ( ! is_readable( $args['path'] ) ) {
      return false;
   }

   // Grab the global $builder object
   $builder = builder();

   // Add template config to global $builder object
   $builder->templates[$slug] = $args;

   // Return true upon success
   return true;
}

/**
 * Retrieves all templates added to the page builder.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @return array
 */
function builder_get_templates() {
   $builder = builder();
   return $builder->templates;
}

/* ================================================ *
 * SHORTCODE HELPERS
 * ================================================ */

/**
 * Used to set up a shortcode with the page builder.
 *
 * This also handles registering the shortcode with WordPress,
 * so you do not need to also call `add_shortcode`. Should be called
 * during or after `init` action.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param string $class Name of class used to configure the shortcode.
 * @param string $tag Optional, when provided the shortcode can be dsabled using a filter. (default: null)
 * @return bool
 */
function builder_add_shortcode( $class, $tag = null ) {
   if ( $tag && apply_filters('builder_disable_shortcode_'.$tag, false) ) {

      // Shortcode has been disabled, return false
      return false;
   }

   // Grab the global $builder object
   $builder = builder();

   // Create shortcode object
   $shortcode = new $class();
   $tag = $shortcode->config['tag'];

   // Add shortcode object to global $builder object
   $builder->shortcodes[$tag] = $shortcode;

   // Register the shortcode with WordPress
   add_shortcode( $tag, array( $shortcode, 'shortcode_callback' ) );

   // Return true upon success
   return true;
}

/**
 * Retrieves all shortcodes created via the TF_Shortcode abstract.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @return array
 */
function builder_get_shortcodes() {
   $builder = builder();
   return $builder->shortcodes;
}

/**
 * Retrieves a single shortcode created via the TF_Shortcode abstract.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_get_shortcodes()
 *
 * @return array
 */
function builder_get_shortcode($tag) {
   $shortcodes = builder_get_shortcodes();
   return isset( $shortcodes[$tag] ) ? $shortcodes[$tag] : false;
}

/**
 * Shortcut for calling a shortcodes callback function
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param string $tag Shortcode tag whose callback to use.
 * @param array $atts Array of provided attributes. (default: array())
 * @param string $content Any content provided for shortcode. (default: null)
 * @return string
 */
function builder_shortcode_callback( $tag, $atts = array(), $content = null ) {
   $shortcodes = builder_get_shortcodes();
   if ( ! isset( $shortcodes[$tag] ) ) {
      return '';
   }
   return $shortcodes[$tag]->shortcode_callback( $atts, $content, $tag );
}

/**
 * Returns an html ready icon.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param string $icon The icon to be displayed
 * @param array $args Additional settings for this icon. (default: array)
 * @return string
 */
function builder_get_icon_html( $icon, $args = array() ) {
   $args = wp_parse_args( $args, array(
      'tag'         => 'span',
      'class'       => '',
      'inline_html' => '',
   ) );
   if ( ! $icon ) {
      return '';
   }
   $class = builder_compile_html_class($args['class'], 'builder-icon', $icon);
   return '<'.$args['tag'].' class="'.$class.'"'.$args['inline_html'].'></'.$args['tag'].'>';
}

/**
 * Returns inline HTML based on user input.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param array $atts Array of provided attributes.
 * @return string
 */
function builder_get_link_inline_html( $atts ) {
   $atts = wp_parse_args( $atts, array(
      'link_type'       => '',
      'link_url'        => '',
      'link_page'       => '',
      'link_post'       => '',
      'link_new_window' => '',
      'link_image'      => '',
      'link_video'      => '',
   ) );

   if ( ! $atts['link_type'] || 'none' === $atts['link_type'] ) {
      return '';
   }
   $out = '';

   switch( $atts['link_type'] ) {
      case 'custom':
         if ( ! $atts['link_url'] ) {
            return '';
         }
         $out = ' href="'.esc_url($atts['link_url']).'"';
         if ( builder_get_bool( $atts['link_new_window'] ) ) {
            $out .= ' target="_blank"';
         }
         break;
      case 'page':
      case 'post':
      case 'project':
         $post_id = $atts['link_'.$atts['link_type']] ? $atts['link_'.$atts['link_type']] : 'none';
         if ( 'none' == $post_id || ! $post_url = get_permalink( $post_id ) ) {
            return '';
         }
         $out = ' href="'.esc_url($post_url).'"';
         if ( builder_get_bool( $atts['link_new_window'] ) ) {
            $out .= ' target="_blank"';
         }
         return $out;
         break;
      case 'image':
         if ( ! $atts['link_image'] || ! $img_src = builder_get_attachment_src( $atts['link_image'] ) ) {
            return '';
         }
         $out = ' href="'.esc_url($img_src).'" data-builder-lightbox-role="image"';
         if ( $caption = builder_get_attachment_caption( $atts['link_image'] ) ) {
            $out .= ' data-builder-lightbox-caption="'.esc_attr($caption).'"';
         }
         break;
      case 'video':
         if ( ! $atts['link_video'] ) {
            return '';
         }
         $out = ' href="'.esc_url($atts['link_video']).'" data-builder-lightbox-role="iframe"';
         break;
   }

   return $out;
}

/**
 * Returns inline HTML based on user input.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param array $atts Array of provided attributes.
 * @return array
 */
function builder_get_background_html( $atts ) {
   $atts = wp_parse_args( $atts, array(
      'bg_source'                       => '',
      'bg_color'                        => '',
      'bg_gradient_orientation'         => '',
      'bg_gradient_color_one'           => '',
      'bg_gradient_color_two'           => '',
      'bg_image'                        => '',
      'bg_image_style'                  => '',
      'bg_image_attachment'             => '',
      'bg_video_fallback'               => '',
      'bg_video_webm'                   => '',
      'bg_video_ogg'                    => '',
      'bg_video_mp4'                    => '',
      'bg_video_audio'                  => '',
      'bg_video_loop'                   => '',
      'bg_video_parallax'               => '',
      'bg_overlay_style'                => '',
      'bg_color_overlay_opacity'        => '',
      'bg_color_overlay_color'          => '',
      'bg_gradient_overlay_orientation' => '',
      'bg_gradient_overlay_color_one'   => '',
      'bg_gradient_overlay_opacity_one' => '',
      'bg_gradient_overlay_color_two'   => '',
      'bg_gradient_overlay_opacity_two' => '',
   ) );

   $out = array(
      'inline_css'  => '',
      'inline_html' => '',
      'extra_class' => '',
   );

   if ( ! $atts['bg_source'] || 'none' === $atts['bg_source'] ) {
      return $out;
   }

   switch ( $atts['bg_source'] ) {
      case 'color':
         if ( ! $atts['bg_color'] ) {
            break;
         }

         $out['inline_css'] .= 'background-color:'.$atts['bg_color'].';';

         // Background type identification class
         $out['extra_class'] .= ' has-custom-bg has-color-bg';
         break;

      case 'gradient':
         if ( ! $atts['bg_gradient_color_one'] || ! $atts['bg_gradient_color_two'] ) {
            break;
         }

         // Compile our two colors for easier access later
         $inline_css_colors = ','.$atts['bg_gradient_color_one'].','.$atts['bg_gradient_color_two'];

         // Prepare the orientation for CSS usage
         switch ( $atts['bg_gradient_orientation'] ) {
            case 'horizontal': $inline_css_orientation = 'linear-gradient(to left'; break;
            case 'circular-centered': $inline_css_orientation = 'radial-gradient(center'; break;
            case 'circular-top-left': $inline_css_orientation = 'radial-gradient(top left'; break;
            case 'circular-top-right': $inline_css_orientation = 'radial-gradient(top right'; break;
            case 'circular-bottom-left': $inline_css_orientation = 'radial-gradient(bottom left'; break;
            case 'circular-bottom-right': $inline_css_orientation = 'radial-gradient(bottom right'; break;
            default: $inline_css_orientation = 'linear-gradient(to bottom';
         }

         // Compile the usable inline CSS for our gradient
         $out['inline_css'] .= 'background:'.$atts['bg_gradient_color_one'].';';
         $out['inline_css'] .= 'background: -webkit-'.$inline_css_orientation.$inline_css_colors.');';
         $out['inline_css'] .= 'background: '.$inline_css_orientation.$inline_css_colors.');';

         // Background type identification class
         $out['extra_class'] .= ' has-custom-bg has-color-bg has-gradient-bg';
         break;

      case 'image':
         if ( ! $bg_image_url = builder_get_attachment_src( $atts['bg_image'] ) ) {
            break;
         }

         // Custom background identification class
         $out['extra_class'] .= ' has-custom-bg';

         // Will contain all of the inline CSS for our image background
         $inline_css = '';
         if ( $atts['bg_color'] ) {
            $inline_css .= 'background-color:'.$atts['bg_color'].';';

            // Background type identification class
            $out['extra_class'] .= ' has-color-bg';
         }

         // Add the background image
         $inline_css .= 'background-image:url('.$bg_image_url.');';

         // Add the style & attachment properties
         $extra_class = ' builder-bg-'.$atts['bg_image_style'];
         if ( 'parallax' !== $atts['bg_image_attachment'] ) {
            $extra_class .= ' builder-bg-'.$atts['bg_image_attachment'];
         }

         // Background type identification class
         $out['extra_class'] .= ' has-image-bg';

         if ( 'parallax' === $atts['bg_image_attachment'] ) {
            $out['extra_class'] .= ' builder-parallax-viewport';
            $out['inline_html'] .= '<div class="builder-parallax-bg'.$extra_class.'" style="'.$inline_css.';" data-parallax="translate"></div>';

            // Background type identification class
            $out['extra_class'] .= ' has-parallax-bg has-parallax-image-bg';
         }
         else {
            $out['extra_class'] .= $extra_class;
            $out['inline_css'] .= $inline_css;
         }
         break;

      case 'video':

         // No video files were provided, do not continue
         if ( ! $atts['bg_video_webm'] && ! $atts['bg_video_ogg'] && ! $atts['bg_video_mp4'] ) {
            break;
         }

         // Custom background identification class
         $out['extra_class'] .= ' has-custom-bg';

         if ( $atts['bg_color'] ) {
            $out['inline_css'] .= 'background-color:'.$atts['bg_color'].';';

            // Background type identification class
            $out['extra_class'] .= ' has-color-bg';
         }

         $out['extra_class'] .= ' builder-has-html5-video-bg has-video-bg';

         // Add the parallax container class when applicable
         if ( builder_get_bool( $atts['bg_video_parallax'] ) ) {
            $out['extra_class'] .= ' builder-parallax-viewport';

            // Background type identification class
            $out['extra_class'] .= ' builder-parallax-viewport has-parallax-bg has-parallax-video-bg';
         }

         // Will contain each of our `source` elements
         $sources_html = '';

         // Create the fallback background image
         if ( $bg_video_fallback_url = builder_get_attachment_src( $atts['bg_video_fallback'] ) ) {
            $out['inline_html'] .= '<div class="builder-html5-video-bg-fallback builder-bg-scale builder-bg-scroll" style="background-image:url('.$bg_video_fallback_url.');"></div>';
         }

         // Create our HTML sources list
         foreach ( array( 'webm', 'ogg', 'mp4') as $source_type ) {
            if ( $atts['bg_video_'.$source_type] ) {
               $sources_html .= '<source src="'.$atts['bg_video_'.$source_type].'" type="video/'.$source_type.'" />';
            }
         }

         $loop = builder_get_bool( $atts['bg_video_loop'] ) ? ' loop' : '';
         $mute = ! builder_get_bool( $atts['bg_video_audio'] ) ? ' muted' : '';
         $parallax = builder_get_bool( $atts['bg_video_parallax'] ) ? ' data-parallax="translate"' : '';
         $out['inline_html'] .= '<video class="builder-html5-video-bg" preload="auto"'.$parallax.$loop.$mute.'>'.$sources_html.'</video>';
         break;
   }

   // Apply the background overlay color, if one has been set
   if ( in_array( $atts['bg_source'], array( 'image', 'video' ) ) ) {
      switch ( $atts['bg_overlay_style'] ) {
         case 'color':
            if ( '' !== $atts['bg_color_overlay_color'] ) {
               $out['extra_class'] .= ' has-bg-overlay bg-overlay-style-color';
               $out['inline_html'] .= '<div class="builder-bg-overlay" style="opacity:'.$atts['bg_color_overlay_opacity'].';background-color:'.$atts['bg_color_overlay_color'].';"></div>';
            }
            break;
         case 'gradient':
            if ( ( '' !== $atts['bg_gradient_overlay_color_one'] && '0' !== $atts['bg_gradient_overlay_opacity_one'] ) || ( '' !== $atts['bg_gradient_overlay_color_two'] && '0' !== $atts['bg_gradient_overlay_opacity_two'] ) ) {
               $fallback_color = '' !== $atts['bg_gradient_overlay_color_one'] ? builder_hex_to_rgba( $atts['bg_gradient_overlay_color_one'], $atts['bg_gradient_overlay_opacity_one'] ) : builder_hex_to_rgba( $atts['bg_gradient_overlay_color_two'], $atts['bg_gradient_overlay_opacity_two'] );
               $color_one = '' !== $atts['bg_gradient_overlay_color_one'] && '0' !== $atts['bg_gradient_overlay_opacity_one'] ? builder_hex_to_rgba( $atts['bg_gradient_overlay_color_one'], $atts['bg_gradient_overlay_opacity_one'] ) : 'transparent';
               $color_two = '' !== $atts['bg_gradient_overlay_color_two'] && '0' !== $atts['bg_gradient_overlay_opacity_two'] ? builder_hex_to_rgba( $atts['bg_gradient_overlay_color_two'], $atts['bg_gradient_overlay_opacity_two'] ) : 'transparent';

               // Compile our two colors for easier access later
               $overlay_inline_css_colors = ','.$color_one.','.$color_two;

               // Prepare the orientation for CSS usage
               switch ( $atts['bg_gradient_overlay_orientation'] ) {
                  case 'horizontal': $overlay_inline_css_orientation = 'linear-gradient(to left'; break;
                  case 'circular-centered': $overlay_inline_css_orientation = 'radial-gradient(center'; break;
                  case 'circular-top-left': $overlay_inline_css_orientation = 'radial-gradient(top left'; break;
                  case 'circular-top-right': $overlay_inline_css_orientation = 'radial-gradient(top right'; break;
                  case 'circular-bottom-left': $overlay_inline_css_orientation = 'radial-gradient(bottom left'; break;
                  case 'circular-bottom-right': $overlay_inline_css_orientation = 'radial-gradient(bottom right'; break;
                  default: $overlay_inline_css_orientation = 'linear-gradient(to bottom';
               }

               $out['extra_class'] .= ' has-bg-overlay bg-overlay-style-gradient';
               $out['inline_html'] .= '<div class="builder-bg-overlay" style="background:'.$fallback_color.';background:-webkit-'.$overlay_inline_css_orientation.$overlay_inline_css_colors.');background:'.$overlay_inline_css_orientation.$overlay_inline_css_colors.');"></div>';
            }
            break;
      }
   }

   return $out;
}

/**
 * Retrieve the shortcode regular expression for searching.
 *
 * The regular expression combines the shortcode tags in the regular expression
 * in a regex class.
 *
 * The regular expression contains 6 different sub matches to help with parsing.
 *
 * 1 - An extra [ to allow for escaping shortcodes with double [[]]
 * 2 - The shortcode name
 * 3 - The shortcode argument list
 * 4 - The self closing /
 * 5 - The content of a shortcode when it wraps some content.
 * 6 - An extra ] to allow for escaping shortcodes with double [[]]
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @see get_shortcode_regex()
 *
 * @param array $tags List of shortcode tag names to remove (default:null)
 * @return string The shortcode search regular expression
 */
function builder_get_shortcode_regex( $tags = null ) {
   if ( ! $tags ) {
      return get_shortcode_regex();
   }

   // Ensure that our list of tags is an array without typecasting
   if ( ! is_array( $tags ) ) {
      $tags = array( $tags );
   }

   $tagregexp = join( '|', array_map( 'preg_quote', $tags ) );

   // WARNING! Do not change this regex without changing do_shortcode_tag() and strip_shortcode_tag()
   // Also, see shortcode_unautop() and shortcode.js.
   return
        '\\['                              // Opening bracket
      . '(\\[?)'                           // 1: Optional second opening bracket for escaping shortcodes: [[tag]]
      . "($tagregexp)"                     // 2: Shortcode name
      . '(?![\\w-])'                       // Not followed by word character or hyphen
      . '('                                // 3: Unroll the loop: Inside the opening shortcode tag
      .     '[^\\]\\/]*'                   // Not a closing bracket or forward slash
      .     '(?:'
      .         '\\/(?!\\])'               // A forward slash not followed by a closing bracket
      .         '[^\\]\\/]*'               // Not a closing bracket or forward slash
      .     ')*?'
      . ')'
      . '(?:'
      .     '(\\/)'                        // 4: Self closing tag ...
      .     '\\]'                          // ... and closing bracket
      . '|'
      .     '\\]'                          // Closing bracket
      .     '(?:'
      .         '('                        // 5: Unroll the loop: Optionally, anything between the opening and closing shortcode tags
      .             '[^\\[]*+'             // Not an opening bracket
      .             '(?:'
      .                 '\\[(?!\\/\\2\\])' // An opening bracket not followed by the closing shortcode tag
      .                 '[^\\[]*+'         // Not an opening bracket
      .             ')*+'
      .         ')'
      .         '\\[\\/\\2\\]'             // Closing shortcode tag
      .     ')?'
      . ')'
      . '(\\]?)';                          // 6: Optional second closing brocket for escaping shortcodes: [[tag]]
}

/**
 * Remove indicated shortcodes from the provided content
 *
 * Can be used within the loop or with a custom Post ID.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param string $content The content to search through
 * @param array $tags List of shortcode tag names to be rmeoved
 * @return string
 */
function builder_remove_shortcode( $content, $tags ) {

   // Make sure our content has shortcodes to search through
   if ( false === strpos( $content, '[' ) ) {
      return $content;
   }

   // Grab our pattern for removing the indicated shortcodes
   $pattern = builder_get_shortcode_regex( $tags );

   return preg_replace_callback( "/$pattern/s", 'strip_shortcode_tag', $content );
}

/**
 * Remove all shortcode tags from the given content.
 *
 * This function is based on the original strip_shortcode_tags function
 * from the WordPress core. However this preserves all shortcode content.
 * It also runs recursively, to be applied to all nested shortcodes as well.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses $shortcode_tags
 *
 * @param string $content Content to remove shortcode tags.
 * @return string
 */
function builder_get_searchable_content( $content ) {
   global $shortcode_tags;

   if ( false === strpos( $content, '[' ) || empty( $shortcode_tags ) || ! is_array( $shortcode_tags ) ) {
      return $content;
   }

   $pattern = get_shortcode_regex();

   return trim( preg_replace_callback( "/$pattern/s", 'builder_get_shortcode_searchable_content', $content ) );
}

function builder_get_shortcode_searchable_content( $m ) {
   $out = '';

   // Grab the shortcode object (if there is one )
   $shortcode = builder_get_shortcode( $m[2] );

   // Add any attributes values
   //
   // We iterate through each provided attirbute and confirm
   // that it is an expected attribute, if so, and if it has
   // been set to be included in the searchable content, then
   // we include it.
   if ( $shortcode && $m[3] ) {
      foreach ( shortcode_parse_atts( $m[3] ) as $key => $value ) {
         if ( ! $attr_obj = isset( $shortcode->config['attributes'][$key] ) ? $shortcode->config['attributes'][$key] : '' ) {
            continue;
         }

         // If the attribute has been marked as searchable, include it`s value
         if ( trim( $value ) && isset( $attr_obj['searchable'] ) && $attr_obj['searchable'] ) {
            $out .= trim( strip_tags( builder_decode_shortcode_attr( $value ) ) ) . ' ';
         }
      }
   }

   // Add any content placed before the shortcode
   $out .= builder_get_searchable_content( $m[1] ).' ';

   // Add any content placed within the shortcode
   $out .= builder_get_searchable_content( $m[5] ).' ';

   // Add any content placed after the shortcode
   $out .= builder_get_searchable_content( $m[6] ).' ';

   return $out;
}

/* ================================================ *
 * FORMS
 * ================================================ */

/**
 * Returns a text box control.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param array $args Associative array of HTML attributes for the input.
 * @return string
 */
function builder_get_input( $args ) {
   $args = wp_parse_args( $args, array(
      'type' => 'text',
   ) );

   $out = '<input';
   foreach ( $args as $attr => $val ) {
      if ( false === $val ) {
         continue;
      }
      $out .= ' '.sanitize_html_class($attr);
      if ( ! is_bool( $val ) && $val ) {
         $out .= '="'.esc_attr(trim($val)).'"';
      }
   }
   $out .= ' />';

   return $out;
}

/**
 * Echos a text box control.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_get_input()
 *
 * @param array $args Associative array of HTML attributes for the input.
 */
function builder_input( $args ) {
   echo builder_get_input( $args );
}

/**
 * Returns a textarea control.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param array $args Associative array of HTML attributes for the textarea.
 * @return string
 */
function builder_get_textarea( $args ) {
   $args = wp_parse_args( $args, array(
      'value' => '',
   ) );

   $value = $args['value'];
   unset( $args['value'] );

   $out = '<textarea';
   foreach ( $args as $attr => $val ) {
      if ( false === $val ) {
         continue;
      }
      $out .= ' '.sanitize_html_class($attr);
      if ( ( is_string($val) || is_int($val) ) && trim($val) ) {
         $out .= '="'.esc_attr(trim($val)).'"';
      }
   }
   $out .= '>' . $value . '</textarea>';

   return $out;
}

/**
 * Echos a textarea control.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_get_textarea()
 *
 * @param array $args Associative array of HTML attributes for the textarea.
 */
function builder_textarea( $args ) {
   echo builder_get_textarea( $args );
}

/**
 * Renders a select control.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param array $args Associative array of HTML attributes for the select box.
 * @return string
 */
function builder_get_select( $args ) {
   $args = wp_parse_args( $args, array(
      'value' => '',
      'options' => array(),
   ) );

   if ( empty( $args['options'] ) ) {
      return null;
   }

   extract( $args );
   unset( $args['value'], $args['options'] );

   $out = '<select';
   foreach ( $args as $attr => $val ) {
      if ( false === $val ) {
         continue;
      }
      $out .= ' '.sanitize_html_class($attr);
      if ( ( is_string($val) || is_int($val) ) && trim($val) ) {
         $out .= '="'.esc_attr(trim($val)).'"';
      }
   }
   $out .= '>';
   $out .= builder_get_select_options( $options, $value );
   $out .= '</select>';

   return $out;
}

/**
 * Echos a select control.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_get_select()
 *
 * @param array $args Associative array of HTML attributes for the select field.
 */
function builder_select( $args ) {
   echo builder_get_select( $args );
}

/**
 * Recursively turns associative array into select box options.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param array $options Array of options to render
 * @param string $value The input value
 * @return string
 */
function builder_get_select_options( $options, $value ) {
   $out = '';
   foreach ( $options as $slug => $data ) {
      if ( is_array( $data ) ) {
         $out .= '<optgroup label="'.$slug.'">';
         $out .= builder_get_select_options( $data, $value );
         $out .= '</optgroup>';
         continue;
      }
      $out .= '<option value="'.esc_attr($slug).'" '.selected( $value, $slug, false ).'>'.esc_html($data).'</option>';
   }
   return $out;
}

/**
 * Recursively turns associative array into select box options.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_get_select_options()
 *
 * @param array $options Array of options to render
 * @param string $value The input value
 * @return string
 */
function builder_select_options( $options, $value ) {
   echo builder_get_select_options( $options, $value );
}

/**
 * Returns a radio control.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param array $args Associative array of HTML attributes for the radio options.
 * @return string
 */
function builder_get_radio( $args ) {
   $args = wp_parse_args( $args, array(
      'id'      => '',
      'name'    => '',
      'value'   => '',
      'options' => array(),
   ) );

   if ( empty( $args['options'] ) ) {
      return null;
   }

   extract( $args );
   unset( $args['value'], $args['options'] );
   $out = '';

   foreach ( $options as $slug => $label ) {
      $out .= '<label for="'.$id.'-'.$slug.'">';
      $out .= '<input type="radio" name="'.esc_attr($name).'" id="'.esc_attr($id).'-'.esc_attr($slug).'" value="'.esc_attr($slug).'" '.checked( $value, $slug, false ).' />';
      $out .= esc_html($label);
      $out .= '</label>';
      $out .= '<br />';
   }

   return $out;
}

/**
 * Echos a radio control.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_get_radio()
 *
 * @param array $args Associative array of HTML attributes for the radio options.
 */
function builder_radio( $args ) {
   echo builder_get_radio( $args );
}

/**
 * Returns a multicheck control.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param array $args Associative array of HTML attributes for the radio options.
 * @return string
 */
function builder_get_multicheck( $args ) {
   $args = wp_parse_args( $args, array(
      'id'      => '',
      'name'    => '',
      'value'   => '',
      'options' => array(),
   ) );

   if ( empty( $args['options'] ) ) {
      return null;
   }

   extract( $args );
   unset( $args['value'], $args['options'] );
   $out = '';

   foreach ( $options as $slug => $label ) {
      $option_value = isset( $value[$slug] ) ? $value[$slug] : false;
      $out .= '<label for="'.$id.'-'.$slug.'">';
      $out .= '<input type="checkbox" name="'.esc_attr($name).'['.esc_attr($slug).']" id="'.esc_attr($id).'-'.esc_attr($slug).'" value="1" '.checked($option_value,true,false).' />';
      $out .= esc_html($label);
      $out .= '</label>';
      $out .= '<br />';
   }

   return $out;
}

/**
 * Echos a multicheck control.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_get_multicheck()
 *
 * @param array $args Associative array of HTML attributes for the multicheck options.
 */
function builder_multicheck( $args ) {
   echo builder_get_multicheck( $args );
}