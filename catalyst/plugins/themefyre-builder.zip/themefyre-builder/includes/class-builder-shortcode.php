<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Themefyre Page Builder Shortcode Abstract
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
abstract class Builder_Shortcode {

   /**
    * Associative array of shortcode arguments.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    * @var array
    */
   public $config;

   /**
    * Builder_Shortcode Constructor.
    *
    * $args[labels]                       Associative array of labels
    * $args[labels][singular]             Singular title
    * $args[labels][plural]               Plural title
    * $args[labels][info]                 Additional information describing the shortcode and its functionality
    * $args[labels][content_tab_title]    Custom title for content tab
    * $args[labels][content_tab_desc]     Description for the content tab
    * $args[labels][attributes_tab_title] Custom title for attributes tab
    * $args[labels][link_tab_title]       Custom title for link tab
    * $args[labels][advanced_tab_title]   Custom title for advanced tab
    * $args[tag]                          Tag for shortcode identification.
    * $args[attributes]                   Associative array of accepted shortcode attributes.
    * $args[tmce]                         Whether or not this shortcode can be added directly to the TinyMCE editor.
    * $args[builder_role]                 This shortcodes roll in the page builder: none/child/content/full-width
    * $args[builder_source]               If shortcode supports the page builder optionally specify a category for it
    * $args[content_type]                 none, textarea, editor, single shortcode tag
    * $args[default_content]              Only applicable if shortcode is page builder and/or tmce enabled and accepts some kind of content
    * $args[content_first]                Content tab will be displayed before attirbutes tabs (true by default when content type is a child element)
    * $args[disable_advanced]             If shortcode supports custom class/id attributes
    * $args[support_link]                 If shortcode supports a link - This will add several attributes automatically
    * $args[support_background]           If shortcode supports a background - This will add several attributes automatically
    * $args[attribute_tabs]               Custom associative array used to map how the attribute tabs should be displayed
    * $args[label_attribute]              Which attribute (if any) should be used as the module title in the page builder
    * $args[prevent_processing]           Attributes of shortcodes that extend this class will be modified before being passed to the callback, this prevents that
    *
    * Each element in the attributes argument should be an associative array with the key
    * representing the name of the attribute, and the value being the configuration. The
    * arguments for each attribute are outlined below:
    *
    * $args[attributes][][title]      (required) Always displayed within the <th /> of the option row
    * $args[attributes][][desc]       Adds a description below the option control
    * $args[attributes][][label]      Only applicable for `bool` type options, defaults to the title
    * $args[attributes][][default]    Custom default value, will be used as is if saved value is not found, required for certain option types
    * $args[attributes][][options]    Only applicable to `within` type options. Can be an associative array or callable
    * $args[attributes][][searchable] Whether or not the value of the attribute should be used as searchable content for the page/post
    * $args[attributes][][type]       Specifies the type of value this attribute handles, see below:
    *    'bool'          true / false
    *    'within'        Must be one of several values
    *    'string'        Any valid string
    *    'html_string'   Valid string with a predefined list of allowed HTML tags
    *    'comma_list'    Comma delimited list of values
    *    'bar_list'      Vertical bar delimited list of values
    *    'hex_code'      Valid HEX code (with leading hash)
    *    'icon'          Valid icon class
    *    'font'          Custom Google font/weight
    *    'image'         Valid image id
    *    'gallery'       Comma delimited list of image id`s
    *    'video'         Valid video URL (self hosted or 3rd party)
    *    'audio'         Valid audio URL (self hosted or 3rd party)
    *    'dev'           An attribute that is not bisible in the page builder and whose value is not filtered
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $args (See above)
    */
   public function __construct( $args ) {

      // Parse labels separately
      $args['labels'] = wp_parse_args( $args['labels'], $this->get_default_labels() );

      // If the `content_first` option was not explicitly set and the content type is a child
      // module then we need to set `content_first` to true before applying the default args
      if ( ! isset( $args['content_first'] ) && isset( $args['content_type'] ) && ! in_array( $args['content_type'], array( 'none', 'textarea', 'editor' ) ) ) {
         $args['content_first'] = true;
      }

      // Parse args object
      $this->config = wp_parse_args( $args, $this->get_default_args() );

      // Set up the label attribute if one has been specified
      if ( 'none' !== $this->config['label_attribute'] && ! isset( $this->config['attributes'][$this->config['label_attribute']] ) ) {
         $this->apply_standard_label_attribute();
      }

      // Add the advanced options if applicable
      if ( ! $this->config['disable_advanced'] ) {
         $this->apply_advanced_attributes();
      }

      // Add the link options if applicable
      if ( $this->config['support_link'] ) {
         $this->apply_link_attributes();
         add_action('builder_inline_script', array( $this, 'builder_inline_link_script' ) );
      }

      // Add the background options if applicable
      if ( $this->config['support_background'] ) {
         $this->apply_background_attributes();
         add_action('builder_inline_script', array( $this, 'builder_inline_background_script' ) );
      }

      // Adds any inline styles required for the page builder
      add_action('builder_inline_styles', array( $this, 'builder_inline_styles' ) );

      // Adds any inline JavaScript required for the page builder
      add_action('builder_inline_script', array( $this, 'builder_inline_script' ) );
   }

   /**
    * Return an array of default labels.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access private
    *
    * @return array Default labels.
    */
   private function get_default_labels() {
      return apply_filters( 'builder_shortcode_default_labels', array(
         'singular'             => '',
         'plural'               => '',
         'info'                 => '',
         'content_tab_title'    => '',
         'content_tab_desc'     => '',
         'attributes_tab_title' => __( 'Attributes', 'themefyre_builder' ),
         'link_tab_title'       => __( 'Link', 'themefyre_builder' ),
         'advanced_tab_title'   => __( 'Advanced', 'themefyre_builder' ),
      ) );
   }

   /**
    * Return an array of default arguments.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access private
    *
    * @return array Default arguments.
    */
   private function get_default_args() {
      return apply_filters( 'builder_shortcode_default_args', array(
         'tag'                => '',
         'icon'               => 'editor-code',
         'attributes'         => array(),
         'tmce'               => false,
         'labels'             => '',
         'builder_role'       => 'none',
         'builder_source'     => 'none',
         'content_type'       => 'none',
         'default_content'    => null,
         'content_first'      => false,
         'disable_advanced'   => false,
         'support_link'       => false,
         'support_background' => false,
         'attribute_tabs'     => array(),
         'label_attribute'    => 'builder_module_label',
         'prevent_processing' => false,
      ) );
   }

   /**
    * Automatically adds a set of attributes to the shortcode allowing it to have a custom HTML ID/Class
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function apply_standard_label_attribute() {

      // Make sure the module label attribute is added to the beginning of the attributes list
      $this->config['attributes'] = array_merge( array(
         'builder_module_label' => array(
            'type'  => 'string',
            'title' => __( 'Module Label', 'themefyre_builder' ),
            'desc'  => __( 'Label to identify this module, this attribute is only used within the page builder.', 'themefyre_builder' ),
         ),
      ), $this->config['attributes']);
   }

   /**
    * Automatically adds a set of attributes to the shortcode allowing it to have a custom HTML ID/Class
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function apply_advanced_attributes() {
      $builder = builder();
      $this->config['attributes']['class'] = array(
         'type'  => 'string',
         'title' => __( 'Class', 'themefyre_builder' ),
         'desc'  => __( 'You can enter multiple classes delimited by spaces.', 'themefyre_builder' ),
      );
      $this->config['attributes']['id'] = array(
         'type'  => 'string',
         'title' => __( 'ID', 'themefyre_builder' ),
         'desc'  => __( '<strong>Be careful</strong>, for your website to be valid the ID must be unique.', 'themefyre_builder' ),
      );
      $this->config['attributes']['inline_attributes'] = array(
         'type'         => 'string',
         'title'        => __( 'Inline HTML Attributes', 'themefyre_builder' ),
         'desc'         => __( 'Custom HTML attributes to be added to this element. You can enter multiple attributes delimited by spaces.', 'themefyre_builder' ),
         'placeholder'  => 'attribute="value"',
      );
      if ( 'child' !== $this->config['builder_role'] ) {
         $this->config['attributes']['device_visibility'] = array(
            'type'         => 'within',
            'title'        => __( 'Device Visibility', 'themefyre_builder' ),
            'desc'         => __( 'Which devices this module should be visible on.', 'themefyre_builder' ),
            'options'      => $builder->device_visibility_options,
         );
      }
   }

   /**
    * Automatically adds a set of attributes to the shortcode allowing it to handle a link.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function apply_link_attributes() {
      $select_page_options = array(
         'none' => __('Select page...', 'themefyre_builder'),
      );
      foreach (get_posts(array('post_type' => 'page', 'posts_per_page'=>-1)) as $post_obj) {
         $select_page_options[$post_obj->ID] = $post_obj->post_title;
      }
      $select_post_options = array(
         'none' => __('Select post...', 'themefyre_builder'),
      );
      foreach (get_posts(array('post_type' => 'post', 'posts_per_page'=>-1)) as $post_obj) {
         $select_post_options[$post_obj->ID] = $post_obj->post_title;
      }

      $this->config['attribute_tabs']['link'] = array(
         'title' => $this->config['labels']['link_tab_title'],
         'ids'   => array( 'link_type', 'link_url', 'link_page', 'link_post', 'link_new_window', 'link_image', 'link_video' ),
      );
      $this->config['attributes']['link_type'] = array(
         'type'    => 'within',
         'title'   => __( 'Link Type', 'themefyre_builder' ),
         'desc'    => __( 'How this element should be linked (if at all).', 'themefyre_builder' ),
         'default' => 'none',
         'options' => array(
            'none'   => __( 'None', 'themefyre_builder' ),
            'custom' => __( 'Custom URL', 'themefyre_builder' ),
            __( 'Existing content', 'themefyre_builder' ) => array(
               'page'    => __( 'Page', 'themefyre_builder' ),
               'post'    => __( 'Post', 'themefyre_builder' ),
            ),
            __( 'Using a lightbox', 'themefyre_builder' ) => array(
               'image'    => __( 'Image', 'themefyre_builder' ),
               'video'    => __( 'Video', 'themefyre_builder' ),
            ),
         ),
      );
      $this->config['attributes']['link_url'] = array(
         'type'  => 'string',
         'title' => __( 'Custom URL', 'themefyre_builder' ),
         'desc'  => __( 'Custom URL, or HTML ID. When entering an HTML ID prepend the ID with a pound sign: <strong>#my-html-id</strong>.', 'themefyre_builder' ),
         'placeholder' => 'http://...',
      );
      $this->config['attributes']['link_page'] = array(
         'type'    => 'within',
         'title'   => __( 'Page', 'themefyre_builder' ),
         'desc'    => __( 'Select a page to link to.', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $select_page_options,
      );
      $this->config['attributes']['link_post'] = array(
         'type'    => 'within',
         'title'   => __( 'Post', 'themefyre_builder' ),
         'desc'    => __( 'Select a post to link to.', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $select_post_options,
      );
      $this->config['attributes']['link_new_window'] = array(
         'type'  => 'bool',
         'title' => __( 'New Window', 'themefyre_builder' ),
         'label' => __( 'Open this link in a new window/tab.', 'themefyre_builder' ),
      );
      $this->config['attributes']['link_image'] = array(
         'type'  => 'image',
         'title' => __( 'Image', 'themefyre_builder' ),
         'desc'  => __( 'Select an image to be opened in a lightbox.', 'themefyre_builder' ),
      );
      $this->config['attributes']['link_video'] = array(
         'type'  => 'string',
         'title' => __( 'Video', 'themefyre_builder' ),
         'desc'  => __( 'paste a full <strong>YouTube</strong> or <strong>Vimeo</strong> URL here.', 'themefyre_builder' ),
         'placeholder' => 'http://...',
      );
   }

   /**
    * Automatically adds a set of attributes to the shortcode allowing it to handle a background.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function apply_background_attributes() {
      $opacity_options = array(
         '0'    => __( '0% (not visible)', 'themefyre_builder' ),
         '0.1'  => '10%',
         '0.2'  => '20%',
         '0.3'  => '30%',
         '0.4'  => '40%',
         '0.5'  => '50%',
         '0.6'  => '60%',
         '0.7'  => '70%',
         '0.8'  => '80%',
         '0.9'  => '90%',
         '1.0'  => '100%',
      );
      $this->config['attribute_tabs']['background'] = array(
         'title' => __( 'Background', 'themefyre_builder' ),
         'ids'   => array( 'bg_source', 'bg_color', 'bg_gradient_orientation', 'bg_gradient_color_one', 'bg_gradient_color_two', 'bg_image', 'bg_image_style', 'bg_image_attachment', 'bg_video_fallback', 'bg_video_webm', 'bg_video_ogg', 'bg_video_mp4', 'bg_video_audio', 'bg_video_loop', 'bg_video_parallax', 'bg_overlay_style', 'bg_color_overlay_opacity', 'bg_color_overlay_color', 'bg_gradient_overlay_orientation', 'bg_gradient_overlay_color_one', 'bg_gradient_overlay_opacity_one', 'bg_gradient_overlay_color_two', 'bg_gradient_overlay_opacity_two' ),
      );
      $this->config['attributes']['bg_source'] = array(
         'type'    => 'within',
         'title'   => __( 'Background Style', 'themefyre_builder' ),
         'default' => 'none',
         'options' => array(
            'none'     => __( '(default background)', 'themefyre_builder' ),
            'color'    => __( 'Solid color', 'themefyre_builder' ),
            'gradient' => __( 'Gradient', 'themefyre_builder' ),
            'image'    => __( 'Image', 'themefyre_builder' ),
            'video'    => __( 'HTML5 video', 'themefyre_builder' ),
         ),
      );
      $this->config['attributes']['bg_color'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Background Color', 'themefyre_builder' ),
         'desc'  => __( 'Custom background color to be used for this module, leave this blank to use the default background color.', 'themefyre_builder' ),
      );
      $this->config['attributes']['bg_gradient_orientation'] = array(
         'type'    => 'within',
         'title'   => __( 'Gradient Orientation', 'themefyre_builder' ),
         'default' => 'vertical',
         'options' => array(
            __( 'Linear Variations', 'themefyre_builder' ) => array(
               'vertical'   => __( 'Vertical (color one on top)', 'themefyre_builder' ),
               'horizontal' => __( 'Horizontal (color one on left)', 'themefyre_builder' ),
            ),
            __( 'Radial Variations', 'themefyre_builder' ) => array(
               'circular-centered' => __( 'Radial centered (color one in center)', 'themefyre_builder' ),
               'circular-top-left' => __( 'Radial top left (color one in top left)', 'themefyre_builder' ),
               'circular-top-right' => __( 'Radial top right (color one in top right)', 'themefyre_builder' ),
               'circular-bottom-left' => __( 'Radial bottom left (color one in bottom left)', 'themefyre_builder' ),
               'circular-bottom-right' => __( 'Radial bottom right (color one in bottom right)', 'themefyre_builder' ),
            ),
         ),
      );
      $this->config['attributes']['bg_gradient_color_one'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Gradient Color One', 'themefyre_builder' ),
      );
      $this->config['attributes']['bg_gradient_color_two'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Gradient Color Two', 'themefyre_builder' ),
      );
      $this->config['attributes']['bg_image'] = array(
         'type'  => 'image',
         'title' => __( 'Background Image', 'themefyre_builder' ),
         'desc'  => __( 'This will be displayed on top of the background color.', 'themefyre_builder' ),
      );
      $this->config['attributes']['bg_image_style'] = array(
         'type'    => 'within',
         'title'   => __( 'Background Image Style', 'themefyre_builder' ),
         'desc'    => __( 'Tiled will display the image at its actual size but it will repeat to fill the background. Scaled will (potentially) increase or decrease either the width or the height of the image to ensure that it will cover the background, the image will be scaled proportionately.', 'themefyre_builder' ),
         'default' => 'scale',
         'options' => array(
            'scale' => __( 'Scaled', 'themefyre_builder' ),
            'tile'  => __( 'Tiled', 'themefyre_builder' ),
         ),
      );
      $this->config['attributes']['bg_image_attachment'] = array(
         'type'    => 'within',
         'title'   => __( 'Background Image Attachment / Enable Parallax', 'themefyre_builder' ),
         'desc'    => __( 'This will dictate how the image should behave as the page is scrolled. Scroll will allow the background image to scroll normally with the rest of the page, while fixed will leave the image fixed in place as the page scrolls. <strong>The majority of mobile devices do not support fixed backgrounds, because of this fixed backgrounds will be disabled for these devices.</strong> Parallax will enable parallax scrolling for the background image.', 'themefyre_builder' ),
         'default' => 'scroll',
         'options' => array(
            'scroll'   => __( 'Scroll', 'themefyre_builder' ),
            'fixed'    => __( 'Fixed', 'themefyre_builder' ),
            'parallax' => __( 'Parallax', 'themefyre_builder' ),
         ),
      );
      $this->config['attributes']['bg_video_fallback'] = array(
         'type'  => 'image',
         'title' => __( 'Fallback Image', 'themefyre_builder' ),
         'desc'  => __( 'Image to be used as the background on devices that don\'t fully support HTML5 video elements. This inlcudes nearly all mobile devices and tablets. The background image will be stretched proportionately to completely cover the background.', 'themefyre_builder' ),
      );
      $this->config['attributes']['bg_video_webm'] = array(
         'type'  => 'video',
         'title' => __( 'WebM URL', 'themefyre_builder' ),
         'desc'  => __( '<strong>WebM</strong> file to use for the video background.', 'themefyre_builder' ),
      );
      $this->config['attributes']['bg_video_ogg'] = array(
         'type'  => 'video',
         'title' => __( 'Ogg URL', 'themefyre_builder' ),
         'desc'  => __( '<strong>Ogg</strong> file to use for the video background.', 'themefyre_builder' ),
      );
      $this->config['attributes']['bg_video_mp4'] = array(
         'type'  => 'video',
         'title' => __( 'MP4 URL', 'themefyre_builder' ),
         'desc'  => __( '<strong>MP4</strong> file to use for the video background.', 'themefyre_builder' ),
      );
      $this->config['attributes']['bg_video_audio'] = array(
         'type'      => 'bool',
         'title'     => __( 'Enable Audio', 'themefyre_builder' ),
         'label'     => __( 'Enable audio for the HTML5 video background.', 'themefyre_builder' ),
      );
      $this->config['attributes']['bg_video_loop'] = array(
         'type'      => 'bool',
         'default'   => 'true',
         'title'     => __( 'Enable Loop', 'themefyre_builder' ),
         'label'     => __( 'The background video will continually loop.', 'themefyre_builder' ),
      );
      $this->config['attributes']['bg_video_parallax'] = array(
         'type'      => 'bool',
         'title'     => __( 'Enable Parallax', 'themefyre_builder' ),
         'label'     => __( 'Enable parallax for this element\'s HTML5 video background.', 'themefyre_builder' ),
      );
      $this->config['attributes']['bg_overlay_style'] = array(
         'type'    => 'within',
         'title'   => __( 'Background Overlay Style', 'themefyre_builder' ),
         'default' => 'none',
         'options' => array(
            'none'     => __( '(no background overlay)', 'themefyre_builder' ),
            'color'    => __( 'Solid Color', 'themefyre_builder' ),
            'gradient' => __( 'Gradient', 'themefyre_builder' ),
         ),
      );
      $this->config['attributes']['bg_color_overlay_opacity'] = array(
         'type'    => 'within',
         'title'   => __( 'Background Overlay Opacity', 'themefyre_builder' ),
         'default' => '0.3',
         'options' => $opacity_options,
      );
      $this->config['attributes']['bg_color_overlay_color'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Background Overlay Color', 'themefyre_builder' ),
      );
      $this->config['attributes']['bg_gradient_overlay_orientation'] = array(
         'type'    => 'within',
         'title'   => __( 'Background Overlay Gradient Orientation', 'themefyre_builder' ),
         'default' => 'vertical',
         'options' => array(
            __( 'Linear Variations', 'themefyre_builder' ) => array(
               'vertical'   => __( 'Vertical (color one on top)', 'themefyre_builder' ),
               'horizontal' => __( 'Horizontal (color one on left)', 'themefyre_builder' ),
            ),
            __( 'Radial Variations', 'themefyre_builder' ) => array(
               'circular-centered' => __( 'Radial centered (color one in center)', 'themefyre_builder' ),
               'circular-top-left' => __( 'Radial top left (color one in top left)', 'themefyre_builder' ),
               'circular-top-right' => __( 'Radial top right (color one in top right)', 'themefyre_builder' ),
               'circular-bottom-left' => __( 'Radial bottom left (color one in bottom left)', 'themefyre_builder' ),
               'circular-bottom-right' => __( 'Radial bottom right (color one in bottom right)', 'themefyre_builder' ),
            ),
         ),
      );
      $this->config['attributes']['bg_gradient_overlay_color_one'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Background Overlay Gradient Color One', 'themefyre_builder' ),
      );
      $this->config['attributes']['bg_gradient_overlay_opacity_one'] = array(
         'type'    => 'within',
         'title'   => __( 'Background Overlay Gradient Color One Opacity', 'themefyre_builder' ),
         'default' => '0.4',
         'options' => $opacity_options,
      );
      $this->config['attributes']['bg_gradient_overlay_color_two'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Background Overlay Gradient Color Two', 'themefyre_builder' ),
      );
      $this->config['attributes']['bg_gradient_overlay_opacity_two'] = array(
         'type'    => 'within',
         'title'   => __( 'Background Overlay Gradient Color Two Opacity', 'themefyre_builder' ),
         'default' => '0.4',
         'options' => $opacity_options,
      );
   }

   /**
    * Displays a dropdown for selecting a page.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param string $tag Tag of shortcode
    * @param string $id ID of registered attribute
    */
   public function builder_select_page_callback( $tag, $id ) {
      $args = array(
         'name' => $tag.'-'.$id,
      );

      wp_dropdown_pages( $args );
   }

   /**
    * Overwrite this method to load inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {}

   /**
    * Overwrite this method to load inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {}

   /**
    * Custom inline javascript used to make the link customizer interactive
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_link_script() {
      ?>
         <script>
            (function($) {
               $(document).on('change', "#<?php echo $this->config['tag']; ?>-link_type", function(event) {
                  var type = $(this).val();

                  var linkControls = {
                     custom:  "#attribute-<?php echo $this->config['tag']; ?>-link_url",
                     page:    "#attribute-<?php echo $this->config['tag']; ?>-link_page",
                     post:    "#attribute-<?php echo $this->config['tag']; ?>-link_post",
                     image:   "#attribute-<?php echo $this->config['tag']; ?>-link_image",
                     video:   "#attribute-<?php echo $this->config['tag']; ?>-link_video",
                  };

                  var $newWindow = $("#attribute-<?php echo $this->config['tag']; ?>-link_new_window");

                  if ( 'none' == type ) {
                     $.each( linkControls, function( key, selector ) {
                        themefyreBuilder.disableControl( $(selector), event );
                     });
                     themefyreBuilder.disableControl( $newWindow, event );
                  }

                  else {
                     $.each( linkControls, function( key, selector ) {
                        if ( key === type ) {
                           themefyreBuilder.enableControl( $(selector), event );
                        }
                        else {
                           themefyreBuilder.disableControl( $(selector), event );
                        }
                     });
                     if ( -1 !== ['custom','page','post'].indexOf(type) ) {
                        themefyreBuilder.enableControl( $newWindow, event );
                     }
                     else {
                        themefyreBuilder.disableControl( $newWindow, event );
                     }
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Custom inline javascript used to make the background customizer customizable
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_background_script() {
      ?>
         <script>
            (function($) {
               $(document).on('change', "#<?php echo $this->config['tag']; ?>-bg_source", function(event) {
                  var backgroundSource = $(this).val(),
                      $basicControls = $("#attribute-<?php echo $this->config['tag']; ?>-bg_color,"
                                     + "#attribute-<?php echo $this->config['tag']; ?>-bg_gradient_orientation,"
                                     + "#attribute-<?php echo $this->config['tag']; ?>-bg_gradient_color_one,"
                                     + "#attribute-<?php echo $this->config['tag']; ?>-bg_gradient_color_two,"
                                     + "#attribute-<?php echo $this->config['tag']; ?>-bg_image,"
                                     + "#attribute-<?php echo $this->config['tag']; ?>-bg_image_style,"
                                     + "#attribute-<?php echo $this->config['tag']; ?>-bg_image_attachment,"
                                     + "#attribute-<?php echo $this->config['tag']; ?>-bg_video_fallback,"
                                     + "#attribute-<?php echo $this->config['tag']; ?>-bg_video_webm,"
                                     + "#attribute-<?php echo $this->config['tag']; ?>-bg_video_ogg,"
                                     + "#attribute-<?php echo $this->config['tag']; ?>-bg_video_mp4,"
                                     + "#attribute-<?php echo $this->config['tag']; ?>-bg_video_audio,"
                                     + "#attribute-<?php echo $this->config['tag']; ?>-bg_video_loop,"
                                     + "#attribute-<?php echo $this->config['tag']; ?>-bg_video_parallax");

                  // No source was selected so we simply disable all controls and return
                  if ( 'none' === backgroundSource ) {
                     themefyreBuilder.disableControl( $basicControls, event );
                     themefyreBuilder.disableControl( $("#attribute-<?php echo $this->config['tag']; ?>-bg_overlay_style, #attribute-<?php echo $this->config['tag']; ?>-bg_overlay_opacity, #attribute-<?php echo $this->config['tag']; ?>-bg_overlay_color, #attribute-<?php echo $this->config['tag']; ?>-bg_overlay_color_top,  #attribute-<?php echo $this->config['tag']; ?>-bg_overlay_color_bottom"), event );
                     return;
                  }

                  var sourceControls = {
                     color: "#attribute-<?php echo $this->config['tag']; ?>-bg_color",
                     gradient: "#attribute-<?php echo $this->config['tag']; ?>-bg_gradient_orientation," + "#attribute-<?php echo $this->config['tag']; ?>-bg_gradient_color_one," + "#attribute-<?php echo $this->config['tag']; ?>-bg_gradient_color_two",
                     image: "#attribute-<?php echo $this->config['tag']; ?>-bg_color," + "#attribute-<?php echo $this->config['tag']; ?>-bg_image," + "#attribute-<?php echo $this->config['tag']; ?>-bg_image_style," + "#attribute-<?php echo $this->config['tag']; ?>-bg_image_attachment",
                     video: "#attribute-<?php echo $this->config['tag']; ?>-bg_color," + "#attribute-<?php echo $this->config['tag']; ?>-bg_video_fallback," + "#attribute-<?php echo $this->config['tag']; ?>-bg_video_webm," + "#attribute-<?php echo $this->config['tag']; ?>-bg_video_ogg," + "#attribute-<?php echo $this->config['tag']; ?>-bg_video_mp4," + "#attribute-<?php echo $this->config['tag']; ?>-bg_video_audio," + "#attribute-<?php echo $this->config['tag']; ?>-bg_video_loop," + "#attribute-<?php echo $this->config['tag']; ?>-bg_video_parallax",
                  }

                  // Toggle all basic (non dynamic) controls
                  themefyreBuilder.disableControl( $basicControls.not(sourceControls[backgroundSource]), event );
                  themefyreBuilder.enableControl( $(sourceControls[backgroundSource]), event );

                  // Toggle the overlay opacity control
                  if ( -1 !== ['image','video'].indexOf(backgroundSource) ) {
                     themefyreBuilder.enableControl( $("#attribute-<?php echo $this->config['tag']; ?>-bg_overlay_style"), event );
                     $('#<?php echo $this->config['tag']; ?>-bg_overlay_style').trigger('change');
                  }
                  else {
                     themefyreBuilder.disableControl( $("#attribute-<?php echo $this->config['tag']; ?>-bg_overlay_style,#attribute-<?php echo $this->config['tag']; ?>-bg_overlay_opacity,  #attribute-<?php echo $this->config['tag']; ?>-bg_overlay_color, #attribute-<?php echo $this->config['tag']; ?>-bg_overlay_color_top,  #attribute-<?php echo $this->config['tag']; ?>-bg_overlay_color_bottom"), event );
                  }
               });
               $(document).on('change', "#<?php echo $this->config['tag']; ?>-bg_overlay_style", function(event) {
                  switch ( $(this).val() ) {
                     case 'color':
                        themefyreBuilder.disableControl( $("#attribute-<?php echo $this->config['tag']; ?>-bg_gradient_overlay_orientation, #attribute-<?php echo $this->config['tag']; ?>-bg_gradient_overlay_color_one, #attribute-<?php echo $this->config['tag']; ?>-bg_gradient_overlay_opacity_one, #attribute-<?php echo $this->config['tag']; ?>-bg_gradient_overlay_color_two, #attribute-<?php echo $this->config['tag']; ?>-bg_gradient_overlay_opacity_two"), event );
                        themefyreBuilder.enableControl( $("#attribute-<?php echo $this->config['tag']; ?>-bg_color_overlay_opacity, #attribute-<?php echo $this->config['tag']; ?>-bg_color_overlay_color"), event );
                        break;
                     case 'gradient':
                        themefyreBuilder.disableControl( $("#attribute-<?php echo $this->config['tag']; ?>-bg_color_overlay_opacity, #attribute-<?php echo $this->config['tag']; ?>-bg_color_overlay_color"), event );
                        themefyreBuilder.enableControl( $("#attribute-<?php echo $this->config['tag']; ?>-bg_gradient_overlay_orientation, #attribute-<?php echo $this->config['tag']; ?>-bg_gradient_overlay_color_one, #attribute-<?php echo $this->config['tag']; ?>-bg_gradient_overlay_opacity_one, #attribute-<?php echo $this->config['tag']; ?>-bg_gradient_overlay_color_two, #attribute-<?php echo $this->config['tag']; ?>-bg_gradient_overlay_opacity_two"), event );
                        break;
                     default:
                        themefyreBuilder.disableControl( $("#attribute-<?php echo $this->config['tag']; ?>-bg_color_overlay_opacity, #attribute-<?php echo $this->config['tag']; ?>-bg_color_overlay_color, #attribute-<?php echo $this->config['tag']; ?>-bg_gradient_overlay_orientation, #attribute-<?php echo $this->config['tag']; ?>-bg_gradient_overlay_color_one, #attribute-<?php echo $this->config['tag']; ?>-bg_gradient_overlay_opacity_one, #attribute-<?php echo $this->config['tag']; ?>-bg_gradient_overlay_color_two, #attribute-<?php echo $this->config['tag']; ?>-bg_gradient_overlay_opacity_two"), event );
                        return;
                        break;
                  }

                  // Scroll the background overlay color selector into view
                  if ( undefined !== event.originalEvent ) {
                     var $scrollBox = $("#attribute-<?php echo $this->config['tag']; ?>-bg_overlay_style").closest('.builder-modal-content');
                     setTimeout( function() {
                        $scrollBox.animate( {
                           scrollTop: $scrollBox.prop('scrollHeight'),
                        }, 250 );
                     }, 255 );
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Optional callback that can be used to output a preview within the page builder
    *
    * If this callback is utilized you must also create a mirror version of this function
    * via JavaScript that can also be used to update the preview without AJAX
    *
    * Note that this callback is only applicable to content & child level modules
    *
    * All provided attributes will have already been run through the sanitization process
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {}

   /**
    * Wrapper for the front end display callback of shortcode.
    *
    * Using a wrapper for the callback allows for the callback
    * to be overwritten in a theme.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode_callback( $atts, $content = null, $tag = '' ) {
      static $_instances;
      global $_themefyre_builder_full_width_instances;

      // Only sanitize the attributes when applicable
      if ( ! $this->config['prevent_processing'] ) {

         // Full width modules get special treatment
         if ( 'full-width' === $this->config['builder_role'] ) {
            $_themefyre_builder_full_width_instances++;

            // Certain classes are applied automatically, whenever possible
            if ( ! $this->config['disable_advanced'] ) {
               if ( empty( $atts['class'] ) ) {
                  $atts['class'] = '';
               }
               $atts['class'] = 'builder-full-width-element builder-full-width-element-'.$_themefyre_builder_full_width_instances.' '.$atts['class'];
            }
         }

         // Sanitize all attributes
         $atts = $this->get_sanitized_attributes( $atts );

         // Keep track of how many of each shortcode is being used
         if ( ! isset( $_instances[$tag] ) ) {
            $_instances[$tag] = 0;
         }
         $_instances[$tag]++;

         // If the shortcode supports `advanced` attributes
         if ( ! $this->config['disable_advanced'] ) {

            // If an ID has not been supplied by the user we generte one automatically
            $atts['id'] = isset($atts['id']) && '' !== trim($atts['id']) ? sanitize_html_class($atts['id']) : str_replace('_', '-', $tag).'-'.$_instances[$tag];

            // Non child modules support device a device visibility setting for responsive customization
            if ( 'child' !== $this->config['builder_role'] && isset($atts['device_visibility']) && 'none' !== $atts['device_visibility'] ) {
               if ( empty($atts['inline_attributes']) ) {
                  $atts['inline_attributes'] = '';
               }
               $atts['inline_attributes'] .= ' data-device-visibility="'.$atts['device_visibility'].'"';
            }

            // If advanced is enabled and inline HTML attributes have been supplied
            // then we need to sanitize and prepare them
            if ( ! empty($atts['inline_attributes']) ) {
               if ( 0 !== strpos( $atts['inline_attributes'], ' ' ) ) {
                  $atts['inline_attributes'] = ' '.$atts['inline_attributes'];
               }
            }
         }
      }

      // Determine which callback to use to render the shortcode
      //
      // This filter can be used to use a different callback function for a specific function
      // you can even use different callbacks depending on the variables that have been set
      $callback = apply_filters( 'builder_shortcode_callback_'.$tag, array( $this, 'shortcode' ), $atts, $content );

      // Call the actual shortcode handler
      return apply_filters( 'builder_shortcode_output_'.$tag, call_user_func( $callback, $atts, $content, $tag ), array( $this, 'shortcode' ), $atts, $content );
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * This method needs to be overwritten for each shortcode individually.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public abstract function shortcode( $atts, $content = null, $tag = '' );

   /**
    * Provides the default value for a single attribute by ID.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param string $id ID of accepted attribute.
    * @return mixed Different for each attribute/attribute type
    */
   public function get_attribute_default( $id ) {
      $attribute = $this->config['attributes'][$id];

      // Check for manually set default
      if ( isset( $attribute['default'] ) ) {
         return $attribute['default'];
      }

      // Return automatic default
      switch ( $attribute['type'] ) {
         case 'within':
            if ( is_array( $attribute['options'] ) ) {
               return key( builder_flatten_array( $attribute['options'] ) );
            }
            break;
         case 'bool':
            return 'false';
            break;
      }

      return '';
   }

   /**
    * Provides a complete array of default settings.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @return array
    */
   public function get_attribute_defaults() {
      if ( ! $this->config['attributes'] ) {
         return array();
      }
      $defaults = array();
      foreach ( $this->config['attributes'] as $id => $config ) {
         $defaults[$id] = $this->get_attribute_default( $id );
      }
      return $defaults;
   }

   /**
    * Helper function to sanitize user input.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $input Array of user defined attributes
    * @return array
    */
   public function get_sanitized_attributes( $input ) {
      if ( ! $this->config['attributes'] ) {
         return array();
      }

      if ( ! $input ) $input = array();

      // Sanitize user input
      foreach ( $input as $id => $value ) {
         if ( ! isset( $this->config['attributes'][$id] ) ) {
            continue;
         }
         $type = $this->config['attributes'][$id]['type'];
         $function = array( $this, "sanitize_{$type}_attribute" );
         $input[$id] = call_user_func( $function, $value, $id );
      }

      // Run return value through `shortcode_atts`
      return shortcode_atts( $this->get_attribute_defaults(), $input, $this->config['tag'] );
   }

   /**
    * Sanitize a shortcode `string` attribute.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param string $value The submitted value
    * @return string
    */
   public function sanitize_string_attribute( $value ) {
      return builder_decode_shortcode_attr( sanitize_text_field( $value ) );
   }

   /**
    * Sanitize a shortcode `html_string` attribute.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param string $value The submitted value
    * @return string
    */
   public function sanitize_html_string_attribute( $value ) {
      return builder_decode_shortcode_attr( strip_tags( $value, '<span><a><br><br/><abbr><acronym><b><strong><i><em><del><ins><sub><sup><mark>' ) );
   }

   /**
    * Sanitize a shortcode `bool` attribute.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param string $value The submitted value
    * @return string
    */
   public function sanitize_bool_attribute( $value, $id ) {
      return in_array( $value, array( 'true', 'false' ) ) ? $value : $this->get_attribute_default( $id );
   }

   /**
    * Sanitize a shortcode `within` attribute.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param string $value The submitted value
    * @param array $config Configuration array for the option
    * @return string
    */
   public function sanitize_within_attribute( $value, $id ) {
      $options = $this->config['attributes'][$id]['options'];
      $options = is_callable( $options ) ? call_user_func( $options ) : $options;
      $allowed = array_keys( builder_flatten_array( $options ) );
      return in_array( $value, $allowed ) ? $value : $this->get_attribute_default( $id );
   }

   /**
    * Sanitize a shortcode `comma_list` attribute.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param string $value The submitted value
    * @return string
    */
   public function sanitize_comma_list_attribute( $value ) {
      $sanitized = '';
      foreach ( explode( ',', $value ) as $item ) {
         $sanitized .= $this->sanitize_string_attribute( $item ) . ',';
      }
      return trim( $sanitized, ',' );
   }

   /**
    * Sanitize a shortcode `bar_list` attribute.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param string $value The submitted value
    * @return string
    */
   public function sanitize_bar_list_attribute( $value ) {
      $sanitized = '';
      foreach ( explode( '|', $value ) as $item ) {
         $sanitized .= $this->sanitize_string_attribute( $item ) . '|';
      }
      return trim( $sanitized, '|' );
   }

   /**
    * Sanitize a shortcode `hex_code` attribute.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param string $value The submitted value
    * @return string
    */
   public function sanitize_hex_code_attribute( $value ) {
      return builder_sanitize_hex_color( $value );
   }

   /**
    * Sanitize a shortcode `icon` attribute.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param string $value The submitted value
    * @return string
    */
   public function sanitize_icon_attribute( $value ) {
      return sanitize_html_class( $value );
   }

   /**
    * Sanitize a shortcode `font` attribute.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param string $value The submitted value
    * @return string
    */
   public function sanitize_font_attribute( $value ) {
      if ( 'default' == $value || 3 !== count(explode(',', $value)) ) {
         return '';
      }
      $value = explode(',', $value);

      // Sanitize font source
      if ( ! in_array($value[0], array('theme','custom') ) ) {
         return '';
      }

      // Sanitize font name
      $value[1] = preg_replace("/[^a-zA-Z0-9\s]/", "", $value[1]);
      if ( 3 > strlen( $value[1] ) ) {
         return '';
      }

      // Sanitize font weight
      $builder = builder();
      $allowed_weights = array_keys( $builder->google_font_variants );
      if ( ! in_array($value[2], $allowed_weights ) ) {
         return '';
      }

      // Determine if font weight is meant to be italic
      $italic_style = strpos($value[2], 'italic') ? 'font-style:italic;' : '';
      $value[2] = str_replace('italic', '', $value[2]);

      $single_quote = preg_match('/\s/', $value[1]) ? "'" : '';
      return 'font-family:'.$single_quote.$value[1].$single_quote.';font-weight:'.$value[2].';'.$italic_style;
   }

   /**
    * Sanitize a shortcode `image` attribute.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param string $value The submitted value
    * @return string
    */
   public function sanitize_image_attribute( $value ) {
      if ( wp_get_attachment_image_src( $value ) ) {
         return $value;
      }
      return '';
   }

   /**
    * Sanitize a shortcode `gallery` attribute.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param string $value The submitted value
    * @return string
    */
   public function sanitize_gallery_attribute( $value ) {
      $sanitized = '';
      foreach ( explode( ',', $value ) as $attachment_id ) {
         if ( wp_get_attachment_image_src( $attachment_id ) ) {
            $sanitized .= $attachment_id . ',';
         }
      }
      return trim( $value, ',' );
   }

   /**
    * Sanitize a shortcode `video` attribute.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param string $value The submitted value
    * @return string
    */
   public function sanitize_video_attribute( $value ) {
      return esc_url( $value );
   }

   /**
    * Sanitize a shortcode `audio` attribute.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param string $value The submitted value
    * @return string
    */
   public function sanitize_audio_attribute( $value ) {
      return esc_url( $value );
   }

   /**
    * Sanitize a shortcode `dev` attribute.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param string $value The submitted value
    * @return string
    */
   public function sanitize_dev_attribute( $value ) {
      return $value;
   }

}