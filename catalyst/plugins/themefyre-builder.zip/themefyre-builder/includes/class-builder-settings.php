<?php

// No direct access
defined( 'ABSPATH' ) or exit;

// Immediately invoke this class
if ( is_admin() ) {
  new Builder_Settings();
}

/**
 * Themefyre Page Builder Settings Class.
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
final class Builder_Settings {

   /**
    * Builder_Settings class constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      add_option( 'builder_screens', array(
         'page' => true,
         'post' => true,
      ) );

      add_option( 'builder_icon_fonts', array(
         'entypo' => true,
      ) );

      add_option( 'builder_global_css' );
      add_option( 'builder_google_fonts' );

      add_action( 'admin_menu', array( $this, 'add_options_page' ) );
      add_action( 'admin_init', array( $this, 'add_settings_sections' ) );
      add_action( 'admin_init', array( $this, 'add_settings_fields' ) );
      add_action( 'admin_init', array( $this, 'register_settings' ) );
   }

   /**
    * Adds the options page to the WordPress settings menu.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function add_options_page() {
      $builder_settings = add_options_page(
         sprintf( __( '%s Settings', 'themefyre_builder' ), 'Themefyre Page Builder' ),
         __('Page Builder', 'themefyre_builder'),
         'manage_options',
         'builder-settings',
         array( $this, 'page_callback' )
      );

      // Load the init action
      add_action( 'load-'.$builder_settings, array( $this, 'init' ) );
   }

   /**
    * Called only when on the settings page.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function init() {
      add_action( 'admin_enqueue_scripts', array( $this, 'load_assets' ), 10 );
      add_action('admin_footer', array( $this, 'inline_html_templates' ) );
   }


   /**
    * Loads assets required for the page builder settings page.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function load_assets() {
      $builder = builder();

      // Load enabled Google fonts
      builder_enqueue_google_fonts();

      // Load WordPress media functionality
      wp_enqueue_media();

      // Chosen plugin stylesheet
      wp_enqueue_style( 'builder-chosen', $builder->plugin_url . 'css/chosen.css', false, $builder->version );

      // Chosen plugin script
      wp_enqueue_script( 'builder-chosen', $builder->plugin_url . 'js/chosen.min.js', null, $builder->version, true );

      // Admin modal stylesheet
      wp_enqueue_style( 'builder-modal' );

      // Admin modal script
      wp_enqueue_script( 'builder-modal' );

      // Codemirror stylesheet
      wp_enqueue_style( 'builder-codemirror' );

      // Codemirror script
      wp_enqueue_script( 'builder-codemirror' );

      // Builder settings stylesheet
      wp_enqueue_style( 'builder-settings', $builder->plugin_url . 'css/settings.css', false, $builder->version );

      // Builder settings script
      wp_enqueue_script( 'builder-settings', $builder->plugin_url . 'js/settings.js', array('jquery', 'builder-chosen', 'builder-codemirror', 'builder-modal'), $builder->version, true );

      // Localiz builder settings script
      wp_localize_script( 'builder-settings', 'builderSettingsLocalize', array(
         'add_font_title'          => __( 'Add Google Font - %s', 'themefyre_builder' ),
         'font_list_error'         => __( 'There was en error retrieving the list of available Google fonts, please ty again later.', 'themefyre_builder' ),
         'no_variants'             => __( 'You must select at least one font weight.', 'themefyre_builder' ),
         'confirm_remove_font_all' => __( 'Are you sure you want to delete all enabled fonts? This can not be undone.', 'themefyre_builder' ),
      ) );
   }

   /**
    * Add the appropriate settings sections
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function add_settings_sections() {
      add_settings_section(
         'general',
         '', // No title for first section
         '', // No callback for displaying the description
         'builder-settings'
      );

      add_settings_section(
         'google_fonts_manager',
         __('Google Fonts Manager', 'themefyre_builder'),
         array($this, 'google_fonts_manager_section_callback'),
         'builder-settings'
      );
   }

   /**
    * Callback for the google_fonts_manager options section.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function google_fonts_manager_section_callback() {
      ?>
         <p><?php echo wp_kses( __('Use the below controls to manage your custom Google fonts. The complete list of available fonts can be found <a href="http://www.google.com/fonts">here</a>. Once you have chosen a font to add, select it from the dropdown below. Some fonts require additional setup to use because they have multiple styles and/or multiple character sets. <strong>Be careful, loading multiple Google font families can compromise overall website performance.</strong>', 'themefyre_builder'), array('a'=>array('href'=>array(),'strong'=>array())) ); ?></p>
      <?php
   }

   /**
    * Registers the page builder fields with WordPress.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function add_settings_fields() {
      add_settings_field(
         'screens',
         __('Post Types', 'themefyre_builder'),
         array($this, 'screens_callback'),
         'builder-settings',
         'general'
      );

      add_settings_field(
         'icon_fonts',
         __('Icon Fonts', 'themefyre_builder'),
         array($this, 'icon_fonts_callback'),
         'builder-settings',
         'general'
      );

      add_settings_field(
         'global_css',
         __('Global CSS', 'themefyre_builder'),
         array($this, 'global_css_callback'),
         'builder-settings',
         'general'
      );

      add_settings_field(
         'google_fonts',
         __('Google Fonts', 'themefyre_builder'),
         array($this, 'google_fonts_callback'),
         'builder-settings',
         'google_fonts_manager'
      );
   }

   /**
    * Registers the page builder settings with WordPress.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function register_settings() {
      register_setting( 'builder-settings', 'builder_screens', array($this, 'update_screens') );
      register_setting( 'builder-settings', 'builder_icon_fonts', array($this, 'update_icon_fonts') );
      register_setting( 'builder-settings', 'builder_global_css', array($this, 'update_global_css') );
      register_setting( 'builder-settings', 'builder_google_fonts', array($this, 'update_google_fonts') );
   }

   /**
    * Callback for displaying the screens setting
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $input Array of submited values
    * @return array
    */
   public function screens_callback() {
      $args = array(
         'id' => 'builder-screens',
         'name' => 'builder_screens',
         'value' => get_option('builder_screens'),
         'options' => $this->get_possible_post_types(),
      );

      builder_multicheck( $args );

      ?>
         <p class="description">
            <?php esc_html_e( 'Which post types the page builder should be applied to.', 'themefyre_builder' ); ?>
         </p>
      <?php
   }

   /**
    * Callback for displaying the icon fonts setting
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $input Array of submited values
    * @return array
    */
   public function icon_fonts_callback() {
      $builder = builder();

      foreach ( $builder->included_icon_fonts as $icon_font ) {
         $options[$icon_font] = ucwords( str_replace('-', ' ', $icon_font) );
      }

      $args = array(
         'id' => 'builder-icon-fonts',
         'name' => 'builder_icon_fonts',
         'value' => get_option('builder_icon_fonts'),
         'options' => $options,
      );

      builder_multicheck( $args );

      ?>
         <p class="description">
            <?php echo wp_kses( __( 'Which icon fonts should be loaded in your theme. <strong>Be careful, loading multiple icon fonts can compromise overall website performance.</strong>', 'themefyre_builder' ), array('strong'=>array()) ); ?>
         </p>
         <p>
            <?php esc_html_e( 'Learn more about each icon font:', 'themefyre_builder' ); ?> <a href="http://www.entypo.com">Entypo</a>, <a href="https://fortawesome.github.io/Font-Awesome/">Font Awesome</a>, <a href="http://www.typicons.com">Typicons</a>, <a href="https://www.mapbox.com/maki/">Maki</a>, <a href="http://designmodo.com/linecons-free/">Linecons</a>, <a href="http://www.alessioatzeni.com/meteocons/">Meteocons</a>
         </p>
      <?php
   }

   /**
    * Callback for displaying the Global CSS setting
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $input Array of submited values
    * @return array
    */
   public function global_css_callback() {
      $args = array(
         'id' => 'builder-global-css',
         'name' => 'builder_global_css',
         'value' => get_option('builder_global_css'),
      );

      ?>
         <div class="builder-codeMirror-wrap">
            <?php builder_textarea( $args ); ?>
         </div>
         <p class="description">
            <?php echo wp_kses( __( 'Custom CSS to be applied to <strong>every page</strong>.', 'themefyre_builder' ), array('strong'=>array()) ); ?>
         </p>
      <?php
   }

   /**
    * Callback for displaying the Google fonts setting
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $input Array of submited values
    * @return array
    */
   public function google_fonts_callback() {
      $value = get_option('builder_google_fonts');
      $builder = builder();

      $google_fonts_options = null;
      $raw_google_fonts = json_decode( file_get_contents('https://s3.amazonaws.com/themefyre-json-files/google-fonts-list.json') );

      if ( ! empty( $raw_google_fonts->items ) ) {
         foreach ( $raw_google_fonts->items as $item ) {
            $variants = array();
            foreach ( $item->variants as $variant ) {
               if ( 'regular' === $variant ) {
                  $variant = '400';
               }
               else if ( 'italic' === $variant ) {
                  $variant = '400italic';
               }
               $variants[] = $variant;
            }
            $google_fonts_options[] = array(
               'family' => $item->family,
               'variants' => implode(',', $variants),
               'subsets' => implode(',', $item->subsets),
            );
         }
      }
      ?>
         <?php if ( $google_fonts_options ) : ?>
            <select data-placeholder="<?php esc_attr_e('Select Google Font', 'themefyre_builder'); ?>" id="font-list">
               <?php foreach ( $google_fonts_options as $option ) : ?>
                  <option value="<?php echo $option['family']; ?>" data-variants="<?php echo $option['variants']; ?>" data-subsets="<?php echo $option['subsets']; ?>"><?php echo $option['family']; ?></option>
               <?php endforeach; ?>
            </select>
         <?php endif; ?>
         <p class="description hide-if-js"><?php esc_html_e( 'JavaScript must be enabled to add new Google Fonts', 'themefyre_builder'); ?></p>
         <div style="height:10px;"></div>
         <input type="hidden" name="builder_google_fonts" value="" />
         <table id="saved-fonts" class="wp-list-table widefat fixed<?php if ( ! is_array( $value ) || empty( $value) ) echo ' is-empty' ?>">
            <thead class="saved-fonts-legend">
               <tr>
                  <th scope="col" class="font-name-column"><span><?php esc_html_e( 'Name', 'themefyre_builder'); ?></span></th>
                  <th scope="col" class="font-variants-column"><span><?php esc_html_e( 'Styles', 'themefyre_builder'); ?></span></th>
                  <th scope="col" class="font-subsets-column"><span><?php esc_html_e( 'Character Sets', 'themefyre_builder'); ?></span></th>
                  <th scope="col" class="font-actions-column hide-if-no-js">
                     <a href="#" id="remove-all-fonts" title="<?php esc_attr_e( 'Delete All Fonts', 'themefyre_builder' ); ?>"><span class="dashicons dashicons-no-alt"></span></a>
                  </th>
               </tr>
            </thead>
            <tbody>
               <?php if ( is_array( $value ) && ! empty( $value) ) : ?>
                  <?php foreach ( $value as $name => $font ) : ?>
                     <tr class="saved-font">
                        <td scope="row" class="font-name-container font-name-column">
                           <div class="font-name" style="font-family:'<?php echo $name; ?>';"><?php echo $name; ?></div>
                        </td>
                        <td class="font-variants-container font-variants-column">
                           <div class="font-variants" style="font-family:'<?php echo $name; ?>';">
                              <?php foreach ( explode(',', $font['variants']) as $variant ) : ?>
                                 <span class="variant-<?php echo $variant; ?>">
                                    <?php echo $builder->google_font_variants[$variant]; ?>
                                 </span>
                              <?php endforeach; ?>
                           </div>
                        </td>
                        <td class="font-subsets-container font-subsets-column">
                           <span class="font-subsets">
                              <?php echo str_replace(',', ', ', $font['subsets'] ); ?>
                           </span>
                        </td>
                        <td class="font-actions font-actions-column hide-if-no-js">
                           <a href="#" class="remove-font" title="<?php _e( 'Delete Font', 'themefyre_builder' ); ?>"><span class="dashicons dashicons-no-alt"></span></a>
                           <input type="hidden" name="builder_google_fonts[<?php echo $name; ?>][variants]" value="<?php echo $font['variants']; ?>" />
                           <input type="hidden" name="builder_google_fonts[<?php echo $name; ?>][subsets]" value="<?php echo $font['subsets']; ?>" />
                        </td>
                     </tr>
                  <?php endforeach; ?>
               <?php endif; ?>
            </tbody>
         </table>
         <p><?php esc_html_e('You don\'t have any enabled Google Fonts yet, select one to add above.', 'themefyre_builder'); ?></p>
      <?php
   }

   /**
    * Updates the screens setting.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param mixed $submitted Any data submitted through the form
    * @return string
    */
   public function update_screens( $submitted ) {
      if ( ! is_array( $submitted ) || empty( $submitted ) ) {
         return array();
      }
      $clean = array();
      $allowed = array_keys( $this->get_possible_post_types() );
      foreach ( $submitted as $key => $value ) {
         if ( in_array($key, $allowed) && $value ) {
            $clean[$key] = true;
         }
      }
      return $clean;
   }

   /**
    * Updates the icon fonts setting.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param mixed $submitted Any data submitted through the form
    * @return string
    */
   public function update_icon_fonts( $submitted ) {
      if ( ! is_array( $submitted ) || empty( $submitted ) ) {
         return array();
      }
      $clean = array();
      $builder = builder();
      foreach ( $submitted as $key => $value ) {
         if ( in_array($key, $builder->included_icon_fonts) && $value ) {
            $clean[$key] = true;
         }
      }
      return $clean;
   }

   /**
    * Updates the global CSS setting.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param mixed $submitted Any data submitted through the form
    * @return string
    */
   public function update_global_css( $submitted ) {
      return $submitted;
   }

   /**
    * Updates the Google fonts setting.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param mixed $submitted Any data submitted through the form
    * @return string
    */
   public function update_google_fonts( $submitted ) {
      if ( ! is_array( $submitted ) || empty( $submitted ) ) {
         return '';
      }
      $builder = builder();
      $allowed_variants = array_keys( $builder->google_font_variants );
      $clean = array();

      foreach ( $submitted as $name => $font ) {
         $name = preg_replace("/[^a-zA-Z0-9\s]/", "", $name);

         // Make sure the name is at least 3 characters
         if ( 3 > strlen( $name ) ) {
            continue;
         }

         // Add the font name to the list
         $clean[$name] = array();

         // Add the list of variants
         if ( isset( $font['variants'] ) && $font['variants'] ) {
            $variants = explode(',', $font['variants']);
            $clean_variants = array();
            foreach ( $allowed_variants as $allowed_variant ) {
               if ( in_array( $allowed_variant, $variants ) ) {
                  $clean_variants[] = $allowed_variant;
               }
            }
            $clean[$name]['variants'] = implode( ',', $clean_variants );
         }

         // Add the list of subsets
         if ( isset( $font['subsets'] ) && $font['subsets'] ) {
            $clean[$name]['subsets'] = $font['subsets'];
         }

      }

      return $clean;
   }

   /**
    * Callback for displaying the options page.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function page_callback() {
      ?>
         <div class="wrap">
            <h2><?php esc_html_e( 'Themefyre Page Builder Settings', 'themefyre_builder' ); ?></h2>
            <form method="post" action="options.php">
               <?php settings_fields( 'builder-settings' ); ?>
               <?php do_settings_sections( 'builder-settings' ); ?>
               <?php submit_button(); ?>
            </form>
         </div>
      <?php
   }

   /**
    * Returns an array of possibly applicable post types for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @return array
    */
   public function get_possible_post_types() {
      $post_types = array(
         'page' => __( 'Pages', 'themefyre_builder' ),
         'post' => __( 'Posts', 'themefyre_builder' ),
      );

      $args = array(
         'public'   => true,
         '_builtin' => false
      );

      foreach ( get_post_types( $args, 'objects' ) as $post_type ) {
         $post_types[$post_type->name] = isset( $post_type->labels->name ) ? $post_type->labels->name : $post_type;
      }

      return $post_types;
   }

   /**
    * The HTML template for adding new Google Fonts.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function inline_html_templates() {
      $builder = builder();
      ?>
         <script type="text/html" id="tmpl-builder-configure-font">
            <div id="configure-font">
               <div class="builder-columns-2 spacing-2">
                  <div id="font-variants">
                     <h2><?php esc_html_e( 'Select Font Styles', 'themefyre_builder' ); ?></h2>
                     <?php foreach ( $builder->google_font_variants as $variant => $description) : ?>
                        <input type="checkbox" id="variant-<?php echo $variant; ?>" value="<?php echo $variant; ?>" />
                        <label for="variant-<?php echo $variant; ?>"><?php echo $description; ?></label>
                     <?php endforeach; ?>
                  </div>
                  <div id="font-subsets">
                     <h2><?php esc_html_e( 'Select Character Sets', 'themefyre_builder' ); ?></h2>
                  </div>
               </div>
            </div>
         </script>
         <script type="text/html" id="tmpl-builder-fonts-option">
            <tr class="saved-font">
               <td class="font-name-container font-name-column">
                  <div class="font-name"></div>
               </td>
               <td class="font-variants-container font-variants-column">
                  <div class="font-variants"></div>
               </td>
               <td class="font-subsets-container font-subsets-column">
                  <span class="font-subsets"></span>
               </td>
               <td class="font-actions font-actions-column hide-if-no-js">
                  <a href="#" class="remove-font" title="<?php esc_html_e( 'Delete Font', 'themefyre_builder' ); ?>"><span class="dashicons dashicons-no-alt"></span></a>
               </td>
            </tr>
         </script>
      <?php
   }

}