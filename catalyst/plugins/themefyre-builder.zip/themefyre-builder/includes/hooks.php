<?php

/**
 * Themefyre Page Builder Actions & Filters.
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */

// No direct access
defined( 'ABSPATH' ) or exit;

// Global configuration
$builder = builder();

/**
 * Add custom links to the plugin action links in WP admin.
 */
add_filter( 'plugin_action_links_' . $builder->basename, 'builder_action_links' );

/**
 * Filter the content of posts upon saving.
 */
add_filter( 'content_save_pre', 'builder_content_save_pre', 10, 1 );

/**
 * Registers the `Themefyre Page Builder Template` post type with WordPress
 */
add_action( 'init', 'builder_template_post_type' );

/**
 * Front end assets
 */
add_action( 'wp_enqueue_scripts', 'builder_enqueue_assets',       10 );
add_action( 'wp_enqueue_scripts', 'builder_enqueue_icon_fonts',   10 );
add_action( 'wp_enqueue_scripts', 'builder_enqueue_google_fonts', 10 );

/**
 * Add builder related classes to the `body` element
 */
add_filter( 'body_class', 'builder_body_class' );

/**
 * Outputs any user defined global CSS
 */
add_action( 'wp_head', 'builder_enqueue_global_css', 100 );

/**
 * Insert custom JavaScript variables on the front-end
 */
add_action( 'wp_footer', 'builder_insert_js_vars', 100 );