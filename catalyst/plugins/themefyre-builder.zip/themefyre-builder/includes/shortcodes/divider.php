<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_divider` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_divider_shortcode() {
  builder_add_shortcode('Builder_Divider_Shortcode', 'builder_divider');
}
add_action('init', 'builder_add_divider_shortcode');

/**
 * Divider Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Divider_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Divider_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular' => __( 'Divider', 'themefyre_builder' ),
         'plural'   => __( 'Dividers', 'themefyre_builder' ),
      );

      $args = array(
         'labels'       => $labels,
         'tag'          => 'builder_divider',
         'icon'         => 'editor-insertmore',
         'builder_role' => 'content',
      );

      $args['attributes']['color'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Color', 'themefyre_builder' ),
         'desc'  => __( 'Leave this blank to use the default color.', 'themefyre_builder' ),
      );

      $args['attributes']['margin_top'] = array(
         'type'        => 'string',
         'title'       => __( 'Top Margin', 'themefyre_builder' ),
         'desc'        => __( 'The value must include a unit (px,em,etc...).<br /><strong>You can enter "0" to have no top margin.</strong>', 'themefyre_builder' ),
         'placeholder' => __( '(default top margin)', 'themefyre_builder' ),
      );

      $args['attributes']['margin_bottom'] = array(
         'type'        => 'string',
         'title'       => __( 'Bottom Margin', 'themefyre_builder' ),
         'desc'        => __( 'The value must include a unit (px,em,etc...).<br /><strong>You can enter "0" to have no bottom margin.</strong>', 'themefyre_builder' ),
         'placeholder' => __( '(default bottom margin)', 'themefyre_builder' ),
      );

      $args['attributes']['width'] = array(
         'type'    => 'within',
         'title'   => __( 'Width', 'themefyre_builder' ),
         'default' => '100',
         'options' => array(
            '25'  => '25%',
            '50'  => '50%',
            '75'  => '75%',
            '100' => '100%',
         ),
      );

      $args['attributes']['align'] = array(
         'type'    => 'within',
         'title'   => __( 'Horizontal Alignment', 'themefyre_builder' ),
         'desc'    => __( 'Because the divider is not set to 100% width, you can now choose how it should be horizontally aligned.', 'themefyre_builder' ),
         'default' => 'center',
         'options' => array(
            'left'   => 'Left',
            'center' => 'Center',
            'right'  => 'Right',
         ),
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               $(document).on('change', '#builder_divider-width', function(event) {
                  if ( '100' == $(this).val() ) {
                     themefyreBuilder.disableControl( $('#attribute-builder_divider-align'), event );
                  }
                  else {
                     themefyreBuilder.enableControl( $('#attribute-builder_divider-align'), event );
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      extract( $atts );

      $inline_css = '';

      if ( '' !== $margin_top ) {
         $inline_css .= 'margin-top:'.$margin_top.';';
      }

      if ( '' !== $margin_bottom ) {
         $inline_css .= 'margin-bottom:'.$margin_bottom.';';
      }

      if ( '' !== $color ) {
         $inline_css .= 'color:'.$color.' !important;';
      }

      // Wrap our inlice CSS in the `style` attribute
      if ( $inline_css ) {
         $inline_css = ' style="'.$inline_css.'"';
      }

      $classes = builder_compile_html_class('builder-divider has-clearfix', 'divider-width-'.$width, '100' !== $width ? 'divider-align-'.$align : '', $class);
      return '<div class="'.$classes.'" id="'.$id.'"'.$inline_css.$inline_attributes.'></div>';
   }

}