<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_html_block` and `builder_full_width_html_block` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_html_block_shortcodes() {
  builder_add_shortcode('Builder_HTML_Block_Shortcode', 'builder_html_block');
  builder_add_shortcode('Builder_Full_Width_HTML_Block_Shortcode', 'builder_full_width_html_block');
}
add_action('init', 'builder_add_html_block_shortcodes');

/**
 * HTML Block Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_HTML_Block_Shortcode extends Builder_Shortcode {

   /**
    * Builder_HTML_Block_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      $entrance_delay_options = array('none' => __('(no animated entrance delay)', 'themefyre_builder') );
      for ($i=250;$i<=5000;$i+=250) {
         $entrance_delay_options[$i] = $i.'ms';
      }

      $labels = array(
         'singular'         => __( 'HTML Block', 'themefyre_builder' ),
         'plural'           => __( 'HTML Blocks', 'themefyre_builder' ),
         'content_tab_desc' => sprintf( __( 'Do not use any %1$s or %2$s tags. Make sure all tags are properly opened and closed.', 'themefyre_builder' ), '&lt;style /&gt;', '&lt;script /&gt;' ),
      );

      $args = array(
         'labels'        => $labels,
         'tag'           => 'builder_html_block',
         'icon'          => 'media-code',
         'builder_role'  => 'content',
         'content_type'  => 'textarea',
         'content_first' => true,
      );

      $args['attributes']['entrance'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->animated_entrance_options,
      );

      $args['attributes']['entrance_delay'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance Delay', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $entrance_delay_options,
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               $(document).on('change', '#builder_html_block-icon_location', function(event) {
                  var $iconControl = $('#attribute-builder_html_block-icon');
                  if ( 'none' === $(this).val() ) {
                     themefyreBuilder.disableControl( $iconControl, event );
                  }
                  else {
                     themefyreBuilder.enableControl( $iconControl, event );
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      extract( $atts );

      // Compile class list
      $classes = builder_compile_html_class('builder-html-block', $class);

      // Animated entrance inline data
      $entrance_data = 'none' !== $entrance ? ' data-entrance="'.$entrance.'"' : '';
      if ( $entrance_data && 'none' !== $entrance_delay ) {
         $entrance_data .= ' data-entrance-delay="'.$entrance_delay.'"';
      }

      $out  = '<div class="'.$classes.'" id="'.$id.'"'.$entrance_data.$inline_attributes.'>';
      $out .= '<div class="builder-html-content">'.do_shortcode($content).'</div>';
      $out .= '</div>';
      return $out;
   }

}

/**
 * Full Width HTML Block Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Full_Width_HTML_Block_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Full_Width_HTML_Block_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular'         => __( 'Full Width HTML Block', 'themefyre_builder' ),
         'plural'           => __( 'Full Width HTML Blocks', 'themefyre_builder' ),
         'content_tab_desc' => sprintf( __( '<strong>Do not use any %1$s or %2$s tags</strong>. <strong>Make sure all tags are properly opened and closed</strong>.', 'themefyre_builder' ), '&lt;style /&gt;', '&lt;script /&gt;' ),
      );

      $args = array(
         'labels'        => $labels,
         'tag'           => 'builder_full_width_html_block',
         'icon'          => 'media-code',
         'builder_role'  => 'full-width',
         'content_type'  => 'textarea',
         'content_first' => true,
      );

      parent::__construct( $args );
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      $classes = builder_compile_html_class('builder-html-block builder-full-width-html-block', $class);
      $out  = '<div class="'.$classes.'" id="'.$id.'"'.$inline_attributes.'>';
      $out .= '<div class="builder-html-content">'.do_shortcode($content).'</div>';
      $out .= '</div>';
      return $out;
   }

}