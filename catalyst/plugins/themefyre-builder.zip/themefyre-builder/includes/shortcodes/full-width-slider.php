<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_full_width_slider`, `builder_full_width_slider_slide`, and `builder_full_width_slider_element` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_full_width_slider_shortcodes() {
  builder_add_shortcode('Builder_Full_Width_Slider_Shortcode', 'builder_full_width_slider');
  builder_add_shortcode('Builder_Full_Width_Slider_Slide_Shortcode', 'builder_full_width_slider_slide');
  builder_add_shortcode('Builder_Full_Width_Slider_Element_Shortcode', 'builder_full_width_slider_element');
}
add_action('init', 'builder_add_full_width_slider_shortcodes');

/**
 * Full-width Slider Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Full_Width_Slider_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Full_Width_Slider_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular' => __( 'Full Width Slider', 'themefyre_builder' ),
         'plural'   => __( 'Full Width Sliders', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_full_width_slider',
         'icon'            => 'video-alt3',
         'builder_role'    => 'full-width',
         'content_type'    => 'builder_full_width_slider_slide',
         'default_content' => '[builder_full_width_slider_slide builder_module_label="'.__('Sample Slide One', 'themefyre_builder').'" bg_source="color" bg_color="#dd9933"]'
                            . '[builder_full_width_slider_element source="header" header_style="builder-text-style-hero-title" header_text="'.__('Slide One Headline', 'themefyre_builder').'" header_tag="h2" header_color="#ffffff"]'
                            . '[builder_full_width_slider_element source="header" header_style="builder-text-style-hero-tagline" header_text="'.__('Slide One Tagline', 'themefyre_builder').'" header_tag="h3" header_color="#ffffff"]'
                            . '[/builder_full_width_slider_slide]'
                            . '[builder_full_width_slider_slide builder_module_label="'.__('Sample Slide Two', 'themefyre_builder').'" bg_source="color" bg_color="#1e73be"]'
                            . '[builder_full_width_slider_element source="header" header_style="builder-text-style-hero-title" header_text="'.__('Slide Two Headline', 'themefyre_builder').'" header_tag="h2" header_color="#ffffff"]'
                            . '[builder_full_width_slider_element source="header" header_style="builder-text-style-hero-tagline" header_text="'.__('Slide Two Tagline', 'themefyre_builder').'" header_tag="h3" header_color="#ffffff"]'
                            . '[/builder_full_width_slider_slide]',
      );

      $args['attributes']['height'] = array(
         'type'        => 'string',
         'title'       => __( 'Height', 'themefyre_builder' ),
         'desc'        => __( 'The value must include a unit (px,em,etc...). The default value is 50% of the total screen height. <strong>To set the height as a percentage of total screen height, use the "vh" unit, for example 100vh = 100% total screen height.</strong>', 'themefyre_builder' ),
         'placeholder' => __( '50vh, or 50% of total screen height', 'themefyre_builder' ),
      );

      $args['attributes']['controls'] = array(
         'type'    => 'within',
         'title'   => __( 'Enabled Controls', 'themefyre_builder' ),
         'default' => 'both',
         'options' => array(
            'both'      => __( 'Pager & direction nav', 'themefyre_builder' ),
            'pager'     => __( 'Pager only', 'themefyre_builder' ),
            'direction' => __( 'Direction nav only', 'themefyre_builder' ),
            'none'      => __( 'None, no manual controls', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['auto'] = array(
         'type'  => 'bool',
         'title' => __( 'Automatically Change Slides', 'themefyre_builder' ),
         'label' => __( 'Automatically change slides at an interval you set.', 'themefyre_builder' ),
      );

      $args['attributes']['hover_pause'] = array(
         'type'    => 'bool',
         'title'   => __( 'Pause On Hover', 'themefyre_builder' ),
         'label'   => __( 'Pause the slider while it is moused over.', 'themefyre_builder' ),
         'default' => 'true',
      );

      $args['attributes']['interval'] = array(
         'type'        => 'string',
         'title'       => __( 'Slide Change Interval', 'themefyre_builder' ),
         'desc'        => __( 'The amount of time between each automatic slide change. Enter a <strong>numeric</strong> value only in <strong>milliseconds</strong>. 1000 milliseconds = 1 second.', 'themefyre_builder' ),
         'placeholder' => '4000',
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               $(document).on('change', '#builder_full_width_slider-auto', function(event) {
                  if ( $(this).prop('checked') ) {
                     themefyreBuilder.enableControl( $('#attribute-builder_full_width_slider-interval, #attribute-builder_full_width_slider-hover_pause'), event );
                  }
                  else {
                     themefyreBuilder.disableControl( $('#attribute-builder_full_width_slider-interval, #attribute-builder_full_width_slider-hover_pause'), event );
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_slides;
      $builder_slides = array();
      do_shortcode( $content );
      if ( empty( $builder_slides ) ) {
         return '';
      }
      extract( $atts );

      // Check if there is only one slide
      $single_slide = 2 > count( $builder_slides );

      // When there is only a single slide we modify some of the settings
      if ( $single_slide ) {
         $controls    = 'none';  // Disable all controls
         $auto        = 'false'; // Turn auto off
      }

      // Compile the class list
      $classes = builder_compile_html_class('builder-full-width-slider', $class);

      // Set up the min height style
      if ( ! $height ) {
         $height = '50vh';
      }

      // Enable auto slide rotation
      $interval_data = '';
      if ( builder_get_bool( $auto ) ) {
         $interval = $interval ? intval( $interval ) : 4000;
         $interval_data = ' data-interval="'.$interval.'" data-hoverpause="'.$hover_pause.'"';
      }

      // Begin the output
      $out  = '<div class="'.$classes.'" id="'.$id.'" data-controls="'.$controls.'"'.$interval_data.$inline_attributes.'>';
      $out .= '<ul class="builder-slider-slides" style="height:'.$height.';">';

      foreach ( $builder_slides as $slide ) {

         // Grab the args for the slide background settings
         $slide_bg_html = builder_get_background_html( $slide );

         // Parallax enabled content
         $parallax_content_attr = $parallax_content_class = '';
         if ( 'none' !== $slide['parallax_content'] && ! empty( $slide['content'] ) ) {
            $parallax_content_attr = ' data-parallax="'.$slide['parallax_content'].'"';
            $parallax_content_class = 'builder-parallax-viewport';
         }

         // Compile the class list for our slide
         $slide_classes = builder_compile_html_class('builder-full-width-slider-slide builder-slider-slide', $parallax_content_class, $slide_bg_html['extra_class'], $slide['class']);

         // Compile the inline style attribute
         $halign_css = 'none' !== $slide['halign'] ? 'text-align:'.$slide['halign'].';' : '';
         $text_shadow_css = $slide['text_shadow'] ? 'text-shadow:'.builder_hex_to_rgba($slide['text_shadow'],0.5).' 0px 1px 2px;' : '';
         $slide_inline_css = $text_shadow_css.$halign_css.$slide_bg_html['inline_css'] ? ' style="'.$text_shadow_css.$halign_css.$slide_bg_html['inline_css'].'"' : '';

         $out.= '<li class="'.$slide_classes.'" id="'.$slide['id'].'"'.$slide_inline_css.$slide['inline_attributes'].'>';
         $out .= $slide_bg_html['inline_html'];

         if ( ! empty( $slide['content'] ) ) {
            $out .= '<div class="builder-slide-caption builder-valign-middle"'.$parallax_content_attr.'>';
            $out .= '<div class="builder-slide-caption-inner builder-valign-target">';
            $out .= '<div class="builder-content-wrap">';

            $button_group_args = array(
               'halign' => $slide['halign'],
            );
            $button_row = array();
            foreach ( $slide['content'] as $element_args ) {
               $global_args = wp_parse_args( $element_args, array(
                  'class'             => '',
                  'id'                => '',
                  'inline_attributes' => '',
                  'link_type'         => '',
                  'link_url'          => '',
                  'link_page'         => '',
                  'link_post'         => '',
                  'link_new_window'   => '',
                  'link_image'        => '',
                  'link_video'        => '',
               ) );
               if ( 'button' === $element_args['source'] ) {
                  $button_args = array_merge( array(
                     'text'          => isset( $element_args['button_text'] ) ? $element_args['button_text'] : '',
                     'icon_location' => isset( $element_args['button_icon_location'] ) ? $element_args['button_icon_location'] : '',
                     'icon'          => isset( $element_args['button_icon'] ) ? $element_args['button_icon'] : '',
                     'style'         => isset( $element_args['button_style'] ) ? $element_args['button_style'] : '',
                     'font'          => isset( $element_args['button_font'] ) ? $element_args['button_font'] : '',
                  ), $global_args );
                  $button_row[] = $button_args;
               }
               else {
                  if ( ! empty( $button_row ) ) {
                     $out .= builder_shortcode_callback( 'builder_button_group', $button_group_args, $button_row );
                     $button_row = array();
                  }
                  switch ( $element_args['source'] ) {
                     case 'html':
                        $out .= builder_shortcode_callback( 'builder_html_block', $element_args, $element_args['content'] );
                        break;
                     case 'header':
                        $header_args = array_merge( array(
                           'text'          => isset( $element_args['header_text'] ) ? $element_args['header_text'] : '',
                           'style'         => isset( $element_args['header_style'] ) ? $element_args['header_style'] : '',
                           'font'          => isset( $element_args['header_font'] ) ? $element_args['header_font'] : '',
                           'font_size'     => isset( $element_args['header_font_size'] ) ? $element_args['header_font_size'] : '',
                           'tag'           => isset( $element_args['header_tag'] ) ? $element_args['header_tag'] : '',
                           'halign'        => isset( $slide['halign'] ) ? $slide['halign'] : '',
                           'color'         => isset( $element_args['header_color'] ) ? $element_args['header_color'] : '',
                           'opacity'       => isset( $element_args['header_opacity'] ) ? $element_args['header_opacity'] : '',
                           'line_height'   => isset( $element_args['header_line_height'] ) ? $element_args['header_line_height'] : '',
                           'margin_top'    => isset( $element_args['header_margin_top'] ) ? $element_args['header_margin_top'] : '',
                           'margin_bottom' => isset( $element_args['header_margin_bottom'] ) ? $element_args['header_margin_bottom'] : '',
                        ), $global_args );
                        $out .= builder_shortcode_callback( 'builder_header', $header_args );
                        break;
                     case 'image':
                        $image_args = array_merge( array(
                           'attachment_id' => isset( $element_args['image_attachment_id'] ) ? $element_args['image_attachment_id'] : '',
                           'size'          => isset( $element_args['image_size'] ) ? $element_args['image_size'] : '',
                           'max_width'     => isset( $element_args['image_max_width'] ) ? $element_args['image_max_width'] : '',
                           'halign'        => isset( $slide['halign'] ) ? $slide['halign'] : '',
                        ), $global_args );
                        $out .= builder_shortcode_callback( 'builder_image', $image_args );
                        break;
                  }
               }
            }

            // Ensure that the last button group gets rendered
            if ( ! empty( $button_row ) ) {
               $out .= builder_shortcode_callback( 'builder_button_group', $button_group_args, $button_row );
            }

            $out .= '</div></div></div>';
         }

         $out .= '</li>';
      }
      $out .= '</ul>';
      $out .= '</div>';

      return $out;
   }

}

/**
 * Full-width Slide Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Full_Width_Slider_Slide_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Full_Width_Slider_Slide_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      $labels = array(
         'singular'          => __( 'Slide', 'themefyre_builder' ),
         'plural'            => __( 'Slides', 'themefyre_builder' ),
         'content_tab_title' => __( 'Slide Content', 'themefyre_builder' ),
      );

      $args = array(
         'labels'             => $labels,
         'tag'                => 'builder_full_width_slider_slide',
         'builder_role'       => 'child',
         'content_type'       => 'builder_full_width_slider_element',
         'default_content'    => '[builder_full_width_slider_element source="header" header_style="builder-text-style-hero-title" header_text="'.__('Slide Headline', 'themefyre_builder').'" header_tag="h2"]'
                               . '[builder_full_width_slider_element source="header" header_style="builder-text-style-hero-tagline" header_text="'.__('Slide Tagline', 'themefyre_builder').'" header_tag="h3"]',
         'support_background' => true,
      );

      $args['attributes']['halign'] = array(
         'type'    => 'within',
         'title'   => __( 'Horizontal Alignment', 'themefyre_builder' ),
         'default' => 'center',
         'options' => $builder->halign_options,
      );

      $args['attributes']['parallax_content'] = array(
         'type'    => 'within',
         'title'   => __( 'Parallax Content', 'themefyre_builder' ),
         'default' => 'none',
         'options' => array(
            'none'                 => __( '(no parallax content)', 'themefyre_builder' ),
            'translate'            => __( 'Translate only', 'themefyre_builder' ),
            'fade'                 => __( 'Fade only', 'themefyre_builder' ),
            'scale'                => __( 'Scale only', 'themefyre_builder' ),
            'translate-fade'       => __( 'Translate and fade', 'themefyre_builder' ),
            'fade-scale'           => __( 'Fade and scale', 'themefyre_builder' ),
            'translate-scale'      => __( 'Translate and scale', 'themefyre_builder' ),
            'translate-fade-scale' => __( 'Translate, fade, and scale', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['text_shadow'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Content Text Shadow', 'themefyre_builder' ),
         'desc'  => __( 'Leave this blank to have no text shadow.', 'themefyre_builder' ),
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {
      ?>
         <style>
            .builder_full_width_slider_slide-module-preview {
               text-align: center;
            }
            .builder_full_width_slider_slide-module-preview .slide-button,
            .builder_full_width_slider_slide-module-preview .slide-element-description span {
               display: inline-block;
               padding: 0 10px;
               height: 40px;
               line-height: 40px;
               border-radius: 4px;
               margin: 4px;
            }
            .builder_full_width_slider_slide-module-preview .slide-button {
               background: #f0f0f0;
            }
            .builder_full_width_slider_slide-module-preview .slide-element-description span {
               border: 1px dashed #ddd;
               display: block;
               margin: 0 auto;
               width: 175px;

            }
            .builder-module[data-role="child"] .builder_full_width_slider_slide-module-preview h1 { font-size: 50px !important; }
            .builder-module[data-role="child"] .builder_full_width_slider_slide-module-preview h2 { font-size: 40px !important; }
            .builder-module[data-role="child"] .builder_full_width_slider_slide-module-preview h3 { font-size: 30px !important; }
            .builder-module[data-role="child"] .builder_full_width_slider_slide-module-preview h4 { font-size: 20px !important; }
            .builder-module[data-role="child"] .builder_full_width_slider_slide-module-preview h5 { font-size: 10px !important; }
            .builder-module[data-role="child"] .builder_full_width_slider_slide-module-preview h6 { font-size: 10px !important; }
         </style>
      <?php
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_full_width_slider_slide = function( args, content, $modal, $module ) {
                  var out = '', elementArgs, headerTag, buttonIcon, beforeButtonText, afterButtonText, buttonText;
                  if ( content && 'object' === typeof content && content.length ) {
                     _.each( content, function( shortcode ) {
                        elementArgs = shortcode.attrs.named;
                        if ( 'undefined' === typeof elementArgs.source || ! elementArgs.source ) {
                           return;
                        }
                        switch ( elementArgs.source ) {
                           case 'html':
                              out += '<p class="slide-element-description"><span><?php _e("Raw HTML", "themefyre_builder"); ?></span></p>';
                              break;
                           case 'header':
                              if ( 'undefined' !== typeof elementArgs.header_text && elementArgs.header_text ) {
                                 headerTag = 'undefined' !== typeof elementArgs.header_tag && elementArgs.header_tag ? elementArgs.header_tag : 'h3';
                                 out += '<'+headerTag+'>'+elementArgs.header_text+'</'+headerTag+'>';
                              }
                              break;
                           case 'image':
                              out += '<p class="slide-element-description"><span><?php _e("Image", "themefyre_builder"); ?></span></p>';
                              break;
                           case 'button':
                              buttonIcon = 'undefined' !== typeof elementArgs.button_icon_location && 'undefined' !== typeof elementArgs.button_icon && 'none' !== elementArgs.button_icon_location && elementArgs.button_icon ? '<span class="'+elementArgs.button_icon+'"></span>' : '';
                              beforeButtonText = buttonIcon && 'before' === elementArgs.button_icon_location ? buttonIcon+' ' : '';
                              afterButtonText = buttonIcon && 'after' === elementArgs.button_icon_location ? ' '+buttonIcon : '';
                              buttonText = 'undefined' !== typeof elementArgs.button_text ? elementArgs.button_text : '';
                              if ( beforeButtonText || buttonText || afterButtonText ) {
                                 out += '<span class="slide-button">'+beforeButtonText+buttonText+afterButtonText+'</span>';
                              }
                              break;
                        }
                     });
                  }
                  return out;
               };
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      global $builder_slide_elements;
      $builder_slide_elements = array();
      do_shortcode( $content );
      $out = '';
      $child_shortcode = builder_get_shortcode('builder_full_width_slider_element');
      foreach ( $builder_slide_elements as $element_args ) {
         $element_args = $child_shortcode->get_sanitized_attributes( $element_args );
         switch ( $element_args['source'] ) {
            case 'html':
               $out .= '<p class="slide-element-description"><span>'.__('Raw HTML', 'themefyre_builder').'</span></p>';
               break;
            case 'header':
               $out .= '<'.$element_args['header_tag'].'>'.$element_args['header_text'].'</'.$element_args['header_tag'].'>';
               break;
            case 'image':
               $out .= '<p class="slide-element-description"><span>'.__('Image', 'themefyre_builder').'</span></p>';
               break;
            case 'button':
               $icon = 'none' !== $element_args['button_icon_location'] && $element_args['button_icon'] ? '<span class="'.$element_args['button_icon'].'"></span>' : '';
               $before_text = $icon && 'before' == $element_args['button_icon_location'] ? $icon.' ' : '';
               $after_text = $icon && 'after' == $element_args['button_icon_location'] ? ' '.$icon : '';
               if ( $before_text || $element_args['button_text'] || $after_text ) {
                  $out .= '<span class="slide-button">'.$before_text.$element_args['button_text'].$after_text.'</span>';
               }
               break;
         }
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_slides, $builder_slide_elements;
      $builder_slide_elements = array();
      do_shortcode( $content );
      $atts['content'] = $builder_slide_elements;
      $builder_slides[] = $atts;
   }

}

/**
 * Full-width Slider Element Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Full_Width_Slider_Element_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Full_Width_Slider_Element_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      for ( $i=1; $i<7; $i++ ) {
         $tag_options['h'.$i] = 'h'.$i;
      }
      $size_options['default'] = __('(default font size)', 'themefyre_builder');
      for ( $i=10; $i<151; $i++ ) {
         $size_options[$i.'px'] = $i.'px';
      }

      $labels = array(
         'singular'          => __( 'Slide Element', 'themefyre_builder' ),
         'plural'            => __( 'Slide Elements', 'themefyre_builder' ),
         'content_tab_title' => __( 'Raw HTML Content', 'themefyre_builder' ),
         'content_tab_desc'  => __( 'This content will only be used when the <strong>Element Type</strong> setting has been set to <strong>Raw HTML</strong>.', 'themefyre_builder' ),
         'link_tab_title'    => __( 'Header/Image/Button Link', 'themefyre_builder' ),
      );

      $args = array(
         'labels'             => $labels,
         'tag'                => 'builder_full_width_slider_element',
         'builder_role'       => 'child',
         'support_link'       => true,
         'content_type'       => 'textarea',
         'prevent_processing' => true,
         'label_attribute'    => 'source',
      );

      $args['attributes']['source'] = array(
         'type'    => 'within',
         'title'   => __( 'Element Type', 'themefyre_builder' ),
         'desc'    => __( 'What type of content this element should contain.', 'themefyre_builder' ),
         'default' => 'html',
         'options' => array(
            'html'   => __( 'Raw HTML', 'themefyre_builder' ),
            'header' => __( 'Header', 'themefyre_builder' ),
            'image'  => __( 'Image', 'themefyre_builder' ),
            'button' => __( 'Button', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['header_text'] = array(
         'type'       => 'html_string',
         'title'      => __( 'Title', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['header_style'] = array(
         'type'    => 'within',
         'title'   => __( 'Predefined Styles', 'themefyre_builder' ),
         'default' => 'none',
         'options' => builder_get_available_text_styles(),
         'desc'    => __( 'Optionally select a predefined style set, you can still override the styles using the controls below.', 'themefyre_builder' ),
      );

      $args['attributes']['header_font'] = array(
         'type'  => 'font',
         'title' => __( 'Font Family', 'themefyre_builder' ),
      );

      $args['attributes']['header_font_size'] = array(
         'type'    => 'within',
         'title'   => __( 'Font Size', 'themefyre_builder' ),
         'default' => 'default',
         'options' => $size_options,
      );

      $args['attributes']['header_tag'] = array(
         'type'    => 'within',
         'title'   => __( 'Tag', 'themefyre_builder' ),
         'default' => 'h1',
         'options' => $tag_options,
      );

      $args['attributes']['header_color'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Color', 'themefyre_builder' ),
         'desc'  => __( 'Leave this blank to use the default color.', 'themefyre_builder' ),
      );

      $args['attributes']['header_opacity'] = array(
         'type'    => 'within',
         'title'   => __( 'Opacity', 'themefyre_builder' ),
         'default' => '1',
         'options' => array(
            '1'   => __( '100% - Fully visible', 'themefyre_builder' ),
            '0.9' => '90%',
            '0.8' => '80%',
            '0.7' => '70%',
            '0.6' => '60%',
            '0.5' => '50%',
            '0.4' => '40%',
            '0.3' => '30%',
            '0.2' => '20%',
            '0.1' => '10%',
            '0'   => __( '0% - Not visible', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['header_line_height'] = array(
         'type'        => 'string',
         'title'       => __( 'Line Height', 'themefyre_builder' ),
         'placeholder' => __( '(default line height)', 'themefyre_builder' ),
      );

      $args['attributes']['header_margin_top'] = array(
         'type'        => 'string',
         'title'       => __( 'Top Margin', 'themefyre_builder' ),
         'desc'        => __( 'The value must include a unit (px,em,etc...).<br /><strong>You can enter "0" to have no margin.</strong>', 'themefyre_builder' ),
         'placeholder' => __( '(default top margin)', 'themefyre_builder' ),
      );

      $args['attributes']['header_margin_bottom'] = array(
         'type'        => 'string',
         'title'       => __( 'Bottom Margin', 'themefyre_builder' ),
         'desc'        => __( 'The value must include a unit (px,em,etc...).<br /><strong>You can enter "0" to have no margin.</strong>', 'themefyre_builder' ),
         'placeholder' => __( '(default bottom margin)', 'themefyre_builder' ),
      );

      $args['attributes']['image_attachment_id'] = array(
         'type'  => 'image',
         'title' => __( 'Image', 'themefyre_builder' ),
      );

      $args['attributes']['image_size'] = array(
         'type'    => 'within',
         'title'   => __( 'Image Size', 'themefyre_builder' ),
         'desc'    => __( 'WordPress stores multiple sizes of each image, specify which size you would like to display.', 'themefyre_builder' ),
         'default' => 'full',
         'options' => builder_get_available_attachment_sizes(),
      );

      $args['attributes']['image_max_width'] = array(
         'type'        => 'string',
         'title'       => __( 'Maximum Width', 'themefyre_builder' ),
         'desc'        => __( 'In addition to specifying which image file to use, you can also control the maximum width the image is displayed as, the value must include a unit (px,em,etc...)', 'themefyre_builder' ),
         'placeholder' => __( '(size of container)', 'themefyre_builder' ),
      );

      $args['attributes']['button_text'] = array(
         'type'       => 'string',
         'title'      => __( 'Button Text', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['button_icon_location'] = array(
         'type'    => 'within',
         'title'   => __( 'Icon Location', 'themefyre_builder' ),
         'desc'    => __( 'Where the icon should be displayed, if at all.', 'themefyre_builder' ),
         'default' => 'none',
         'options' => array(
            'none'   => __( '(no button icon)', 'themefyre_builder' ),
            'before' => __( 'Before the button text', 'themefyre_builder' ),
            'after'  => __( 'After the button text', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['button_icon'] = array(
         'type'  => 'icon',
         'title' => __( 'Icon', 'themefyre_builder' ),
      );

      $args['attributes']['button_style'] = array(
         'type'    => 'within',
         'title'   => __( 'Style', 'themefyre_builder' ),
         'default' => 'default',
         'options' => builder_get_available_button_styles(),
      );

      $args['attributes']['button_font'] = array(
         'type'  => 'font',
         'title' => __( 'Font', 'themefyre_builder' ),
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {
      ?>
         <style>
            .builder_full_width_slider_element-module-preview {
               text-align: center;
            }
            .builder_full_width_slider_element-module-preview .slide-button,
            .builder_full_width_slider_element-module-preview .slide-element-description span {
               display: inline-block;
               padding: 0 10px;
               height: 40px;
               line-height: 40px;
               border-radius: 4px;
               margin: 4px;
            }
            .builder_full_width_slider_element-module-preview .slide-button {
               background: #f0f0f0;

            }
            .builder_full_width_slider_element-module-preview .slide-element-description span {
               border: 1px dashed #ddd;
               display: block;
               margin: 0 auto;
               width: 175px;

            }
            .builder-module[data-role="child"] .builder_full_width_slider_element-module-preview h1 { font-size: 50px !important; }
            .builder-module[data-role="child"] .builder_full_width_slider_element-module-preview h2 { font-size: 40px !important; }
            .builder-module[data-role="child"] .builder_full_width_slider_element-module-preview h3 { font-size: 30px !important; }
            .builder-module[data-role="child"] .builder_full_width_slider_element-module-preview h4 { font-size: 20px !important; }
            .builder-module[data-role="child"] .builder_full_width_slider_element-module-preview h5 { font-size: 10px !important; }
            .builder-module[data-role="child"] .builder_full_width_slider_element-module-preview h6 { font-size: 10px !important; }
         </style>
      <?php
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_full_width_slider_element = function( args, content, $modal, $module ) {
                  var out = '';
                  if ( 'undefined' === typeof args.source || ! args.source ) {
                     return;
                  }
                  switch ( args.source ) {
                     case 'html':
                        out += '<p class="slide-element-description"><span><?php _e("Raw HTML", "themefyre_builder"); ?></span></p>';
                        break;
                     case 'header':
                        if ( 'undefined' !== typeof args.header_text && args.header_text ) {
                           var headerTag = 'undefined' !== typeof args.header_tag && args.header_tag ? args.header_tag : 'h3';
                           out += '<'+headerTag+'>'+args.header_text+'</'+headerTag+'>';
                        }
                        break;
                     case 'image':
                        out += '<p class="slide-element-description"><span><?php _e("Image", "themefyre_builder"); ?></span></p>';
                        break;
                     case 'button':
                        var buttonIcon = 'undefined' !== typeof args.button_icon_location && 'undefined' !== typeof args.button_icon && 'none' !== args.button_icon_location && args.button_icon ? '<span class="'+args.button_icon+'"></span>' : '';
                        var beforeButtonText = buttonIcon && 'before' === args.button_icon_location ? buttonIcon+' ' : '';
                        var afterButtonText = buttonIcon && 'after' === args.button_icon_location ? ' '+buttonIcon : '';
                        var buttonText = 'undefined' !== typeof args.button_text ? args.button_text : '';
                        if ( beforeButtonText || buttonText || afterButtonText ) {
                           out += '<span class="slide-button">'+beforeButtonText+buttonText+afterButtonText+'</span>';
                        }
                        break;
                  }
                  return out;
               };
               $(document).on('change', '#builder_full_width_slider_element-source', function(event) {
                  var source = $(this).val(),
                      $headerControls = $('#attribute-builder_full_width_slider_element-header_text, #attribute-builder_full_width_slider_element-header_style, #attribute-builder_full_width_slider_element-header_font, #attribute-builder_full_width_slider_element-header_font_size, #attribute-builder_full_width_slider_element-header_tag, #attribute-builder_full_width_slider_element-header_color, #attribute-builder_full_width_slider_element-header_opacity, #attribute-builder_full_width_slider_element-header_line_height, #attribute-builder_full_width_slider_element-header_margin_top, #attribute-builder_full_width_slider_element-header_margin_bottom'),
                      $imageControls =  $('#attribute-builder_full_width_slider_element-image_attachment_id, #attribute-builder_full_width_slider_element-image_size, #attribute-builder_full_width_slider_element-image_max_width'),
                      $buttonControls =  $('#attribute-builder_full_width_slider_element-button_text, #attribute-builder_full_width_slider_element-button_icon_location, #attribute-builder_full_width_slider_element-button_style, #attribute-builder_full_width_slider_element-button_font'),
                      $iconControl = $('#attribute-builder_full_width_slider_element-button_icon');

                  if ( 'html' === source ) {
                     themefyreBuilder.disableControl( $headerControls, event );
                     themefyreBuilder.disableControl( $imageControls, event );
                     themefyreBuilder.disableControl( $buttonControls, event );
                     themefyreBuilder.disableControl( $iconControl, event );
                  }
                  else if ( 'header' === source ) {
                     themefyreBuilder.disableControl( $imageControls, event );
                     themefyreBuilder.disableControl( $buttonControls, event );
                     themefyreBuilder.disableControl( $iconControl, event );
                     themefyreBuilder.enableControl( $headerControls, event );
                  }
                  else if ( 'image' === source ) {
                     themefyreBuilder.disableControl( $headerControls, event );
                     themefyreBuilder.disableControl( $buttonControls, event );
                     themefyreBuilder.disableControl( $iconControl, event );
                     themefyreBuilder.enableControl( $imageControls, event );
                  }
                  else if ( 'button' === source ) {
                     themefyreBuilder.disableControl( $headerControls, event );
                     themefyreBuilder.disableControl( $imageControls, event );
                     themefyreBuilder.enableControl( $buttonControls, event );
                     $('#builder_full_width_slider_element-button_icon_location').trigger('change');
                  }
               });
               $(document).on('change', '#builder_full_width_slider_element-button_icon_location', function(event) {
                  var $iconControl = $('#attribute-builder_full_width_slider_element-button_icon');
                  if ( 'none' === $(this).val() ) {
                     themefyreBuilder.disableControl( $iconControl, event );
                  }
                  else {
                     themefyreBuilder.enableControl( $iconControl, event );
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      $out = '';
      extract( $atts );
      switch ( $source ) {
         case 'html':
            $out .= '<p class="slide-element-description"><span>'.__('Raw HTML', 'themefyre_builder').'</span></p>';
            break;
         case 'header':
            $out .= '<'.$header_tag.'>'.$header_text.'</'.$header_tag.'>';
            break;
         case 'image':
            $out .= '<p class="slide-element-description"><span>'.__('Image', 'themefyre_builder').'</span></p>';
            break;
         case 'button':
            $icon = 'none' !== $button_icon_location && $button_icon ? '<span class="'.$button_icon.'"></span>' : '';
            $before_text = $icon && 'before' == $button_icon_location ? $icon.' ' : '';
            $after_text = $icon && 'after' == $button_icon_location ? ' '.$icon : '';
            if ( $before_text || $button_text || $after_text ) {
               $out .= '<span class="slide-button">'.$before_text.$button_text.$after_text.'</span>';
            }
            break;
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_slide_elements;
      $atts['content'] = $content;
      $builder_slide_elements[] = $atts;
   }

}