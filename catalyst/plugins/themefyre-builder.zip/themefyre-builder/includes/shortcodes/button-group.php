<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_button_group` and `builder_button_group_item` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_button_group_shortcodes() {
  builder_add_shortcode('Builder_Button_Group_Item_Shortcode', 'builder_button_group_item');
  builder_add_shortcode('Builder_Button_Group_Shortcode', 'builder_button_group');
}
add_action('init', 'builder_add_button_group_shortcodes');

/**
 * Button Group Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Button_Group_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Button_Group_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      $entrance_delay_options = array('none' => __('(no animated entrance delay)', 'themefyre_builder') );
      for ($i=250;$i<=5000;$i+=250) {
         $entrance_delay_options[$i] = $i.'ms';
      }

      $labels = array(
         'singular' => __( 'Button Group', 'themefyre_builder' ),
         'plural'   => __( 'Button Groups', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_button_group',
         'icon'            => 'admin-links',
         'tmce'            => true,
         'builder_role'    => 'content',
         'content_type'    => 'builder_button_group_item',
         'default_content' => '[builder_button_group_item text="'.__('Learn More', 'themefyre_builder').'"]'
                            . '[builder_button_group_item text="'.__('Buy Now', 'themefyre_builder').'"]',
      );

      $args['attributes']['size'] = array(
         'type'    => 'within',
         'title'   => __( 'Button Size', 'themefyre_builder' ),
         'desc'    => __( 'Will be applied to all buttons in this group.', 'themefyre_builder' ),
         'default' => 'normal',
         'options' => array(
            'small'  => __( 'Small', 'themefyre_builder' ),
            'normal' => __( 'Normal', 'themefyre_builder' ),
            'large'  => __( 'Large', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['halign'] = array(
         'type'    => 'within',
         'title'   => __( 'Horizontal Alignment', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->halign_options,
      );

      $args['attributes']['block'] = array(
         'type'  => 'bool',
         'title' => __( 'Block Buttons', 'themefyre_builder' ),
         'label' => __( 'Buttons in this group will fill the width of the container they are placed in.', 'themefyre_builder' ),
      );

      $args['attributes']['entrance'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->animated_entrance_options,
      );

      $args['attributes']['entrance_delay'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance Delay', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $entrance_delay_options,
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {
      ?>
         <style>
            .builder_button_group-module-preview > span,
            .builder_button_group-module-preview > div > span {
               display: inline-block;
               padding: 0 10px;
               height: 40px;
               line-height: 40px;
               border-radius: 4px;
               background: #555;
               margin: 0 4px 4px 0;
            }
         </style>
      <?php
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_button_group = function( args, content, $modal, $module ) {
                  var out = '', buttonArgs, buttonText, buttonIcon, beforeText, afterText;
                  if ( content && 'object' === typeof content && content.length ) {
                     _.each( content, function( item ) {
                        buttonArgs = item.attrs.named;
                        buttonIcon = 'undefined' !== typeof buttonArgs.icon_location && 'undefined' !== typeof buttonArgs.icon && 'none' !== buttonArgs.icon_location && buttonArgs.icon ? '<span class="'+buttonArgs.icon+'"></span>' : '';
                        beforeText = buttonIcon && 'before' === buttonArgs.icon_location ? buttonIcon+' ' : '';
                        afterText = buttonIcon && 'after' === buttonArgs.icon_location ? ' '+buttonIcon : '';
                        buttonText = 'undefined' !== typeof buttonArgs.text ? buttonArgs.text : '';
                        if ( beforeText || buttonText || afterText ) {
                           out += '<span>'+beforeText+buttonText+afterText+'</span>';
                        }
                     });
                  }
                  if ( out && 'undefined' !== typeof args.halign && 'none' !== args.halign ) {
                     out = '<div style="text-align:'+args.halign+';">'+out+'</div>';
                  }
                  return out;
               };
               $(document).on('change', '#builder_button_group-entrance', function(event) {
                  if ( 'none' === $(this).val() ) {
                     themefyreBuilder.disableControl( $('#attribute-builder_button_group-entrance_delay'), event );
                  }
                  else {
                     themefyreBuilder.enableControl( $('#attribute-builder_button_group-entrance_delay'), event );

                     // Scroll the entrance delay control into view
                     if ( undefined !== event.originalEvent ) {
                        var $scrollBox = $(this).closest('.builder-modal-content');
                        setTimeout( function() {
                           $scrollBox.animate( {
                              scrollTop: $scrollBox.prop('scrollHeight'),
                           }, 250 );
                        }, 255 );
                     }
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      global $builder_button_group_items;
      $builder_button_group_items = array();
      do_shortcode( $content );
      $out = '';
      foreach ( $builder_button_group_items as $item ) {
         $icon = 'none' !== $item['icon_location'] && $item['icon'] ? '<span class="'.$item['icon'].'"></span>' : '';
         $before_text = $icon && 'before' == $item['icon_location'] ? $icon.' ' : '';
         $after_text = $icon && 'after' == $item['icon_location'] ? ' '.$icon : '';
         if ( $before_text || $item['text'] || $after_text ) {
            $out .= '<span>'.$before_text.$item['text'].$after_text.'</span>';
         }
      }
      if ( $out && 'none' !== $halign ) {
         $out = '<div style="text-align:'.$halign.';">'.$out.'</div>';
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_button_group_items;
      $builder_button_group_items = array();
      if ( is_array( $content ) ) {
         foreach ( $content as $button ) {
            builder_shortcode_callback( 'builder_button_group_item', $button );
         }
      }
      else {
         do_shortcode( $content );
      }
      if ( empty( $builder_button_group_items ) ) {
         return '';
      }
      extract( $atts );

      $classes = builder_compile_html_class('builder-button-group', builder_get_bool( $block ) ? 'block-buttons' : '', $class);

      $inline_css = '';
      if ( 'none' !== $halign ) {
         $inline_css = ' style="text-align:'.$halign.'"';
      }

      // Animated entrance inline data
      $entrance_data = 'none' !== $entrance ? ' data-entrance="'.$entrance.'"' : '';
      if ( $entrance_data && 'none' !== $entrance_delay ) {
         $entrance_data .= ' data-entrance-delay="'.$entrance_delay.'"';
      }

      $num_buttons = count( $builder_button_group_items );
      $out = '<p class="'.$classes.'" id="'.$id.'"'.$inline_css.$entrance_data.$inline_attributes.'>';
      foreach ( $builder_button_group_items as $item ) {
         $icon_class = 'none' == $item['icon_location'] ? 'no-icon' : 'has-icon icon-location-'.$item['icon_location'];
         $icon = 'none' != $item['icon_location'] && $item['icon'] ? $item['icon'] : '';
         $before_text = 'before' == $item['icon_location'] && $icon ? builder_get_icon_html($icon, array('class'=>'builder-button-icon')) : '';
         $after_text = 'after' == $item['icon_location'] && $icon ? builder_get_icon_html($icon, array('class'=>'builder-button-icon')) : '';
         $classes = builder_compile_html_class('builder-button button', 'size-'.$size, 'style-'.$item['style'], $icon_class, $item['class']);
         $custom_font_css = $item['font'] ? ' style="'.$item['font'].'"' : '';

         if ( $before_text && $item['text'] ) {
            $before_text .= '<span class="builder-button-group-icon-spacer"></span>';
         }
         if ( $after_text && $item['text'] ) {
            $after_text = '<span class="builder-button-group-icon-spacer"></span>'.$after_text;
         }

         $out .= '<a class="'.$classes.'" id="'.$item['id'].'"'.builder_get_link_inline_html($item).$item['inline_attributes'].'>';
         $out .= $before_text.'<span class="builder-button-text"'.$custom_font_css.'>'.$item['text'].'</span>'.$after_text;
         $out .= '</a>';

         // Allows the theme to determine how buttons should be spaced out
         $num_buttons--;
         if ( $num_buttons ) {
            $out .= '<span class="builder-button-group-spacer"></span>';
         }
      }
      $out .= '</p>';

      return $out;
   }

}

/**
 * Button Group Item Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Button_Group_Item_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Button_Group_Item_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular' => __( 'Button', 'themefyre_builder' ),
         'plural'   => __( 'Buttons', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_button_group_item',
         'builder_role'    => 'child',
         'support_link'    => true,
         'label_attribute' => 'text',
      );

      $args['attributes']['text'] = array(
         'type'       => 'string',
         'title'      => __( 'Text', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['icon_location'] = array(
         'type'    => 'within',
         'title'   => __( 'Icon Location', 'themefyre_builder' ),
         'desc'    => __( 'Where the icon should be displayed, if at all.', 'themefyre_builder' ),
         'default' => 'none',
         'options' => array(
            'none'   => __( '(no button icon)', 'themefyre_builder' ),
            'before' => __( 'Before the button text', 'themefyre_builder' ),
            'after'  => __( 'After the button text', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['icon'] = array(
         'type'  => 'icon',
         'title' => __( 'Icon', 'themefyre_builder' ),
      );

      $args['attributes']['style'] = array(
         'type'    => 'within',
         'title'   => __( 'Style', 'themefyre_builder' ),
         'default' => 'default',
         'options' => builder_get_available_button_styles(),
      );

      $args['attributes']['font'] = array(
         'type'  => 'font',
         'title' => __( 'Font', 'themefyre_builder' ),
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {
      ?>
         <style>
            .builder_button_group_item-module-preview {
               text-align: center;
            }
            .builder_button_group_item-module-preview > span {
               display: inline-block;
               padding: 0 10px;
               height: 40px;
               line-height: 40px;
               border-radius: 4px;
               background: #f0f0f0;
               margin: 0 4px 4px 0;
            }
         </style>
      <?php
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_button_group_item = function( args, content, $modal, $module ) {
                  var buttonIcon = 'undefined' !== typeof args.icon_location && 'undefined' !== typeof args.icon && 'none' !== args.icon_location && args.icon ? '<span class="'+args.icon+'"></span>' : '';
                  var beforeText = buttonIcon && 'before' === args.icon_location ? buttonIcon+' ' : '';
                  var afterText = buttonIcon && 'after' === args.icon_location ? ' '+buttonIcon : '';
                  var buttonText = 'undefined' !== typeof args.text ? args.text : '';
                  if ( beforeText || buttonText || afterText ) {
                     return '<span>'+beforeText+buttonText+afterText+'</span>';
                  }
               };
               $(document).on('change', '#builder_button_group_item-icon_location', function(event) {
                  var $iconControl = $('#attribute-builder_button_group_item-icon');
                  if ( 'none' === $(this).val() ) {
                     themefyreBuilder.disableControl( $iconControl, event );
                  }
                  else {
                     themefyreBuilder.enableControl( $iconControl, event );
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      $icon = 'none' !== $icon_location && $icon ? '<span class="'.$icon.'"></span>' : '';
      $before_text = $icon && 'before' == $icon_location ? $icon.' ' : '';
      $after_text = $icon && 'after' == $icon_location ? ' '.$icon : '';
      if ( $before_text || $text || $after_text ) {
         return '<span>'.$before_text.$text.$after_text.'</span>';
      }
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_button_group_items;
      $builder_button_group_items[] = $atts;
   }

}