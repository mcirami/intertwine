<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_statistics_item` and `builder_statistics` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_statistics_shortcodes() {
  builder_add_shortcode('Builder_Statistics_Item_Shortcode', 'builder_statistics_item');
  builder_add_shortcode('Builder_Statistics_Shortcode', 'builder_statistics');
}
add_action('init', 'builder_add_statistics_shortcodes');

/**
 * Statistics Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Statistics_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Statistics_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular' => __( 'Statistics', 'themefyre_builder' ),
         'plural'   => __( 'Statistics', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_statistics',
         'icon'            => 'chart-bar',
         'tmce'            => true,
         'builder_role'    => 'content',
         'content_type'    => 'builder_statistics_item',
         'default_content' => '[builder_statistics_item title="'.__('Statistic One Title', 'themefyre_builder').'" value="25" unit_location="after" unit="%"]'
                            . '[builder_statistics_item title="'.__('Statistic Two Title', 'themefyre_builder').'" value="32" maximum="128" unit_location="after" unit="GB"]',
      );

      $args['attributes']['inverse'] = array(
         'type'  => 'bool',
         'title' => __( 'Inverse Style', 'themefyre_builder' ),
         'label' => __( 'Optimize module to be displayed on a dark background.', 'themefyre_builder' ),
      );

      $args['attributes']['animated'] = array(
         'type'    => 'bool',
         'title'   => __( 'Animated Entrance', 'themefyre_builder' ),
         'label'   => __( 'Statistics will animate to their values when they are scrolled to.', 'themefyre_builder' ),
         'default' => 'true',
      );

      $args['attributes']['values'] = array(
         'type'    => 'bool',
         'title'   => __( 'Display Values', 'themefyre_builder' ),
         'label'   => __( 'Each tasks respective value will be visible.', 'themefyre_builder' ),
         'default' => 'true',
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {
      ?>
         <style>
            .builder_statistics-module-preview div {
               height: 10px;
               border-radius: 3px;
            }
            .builder_statistics-module-preview > div {
               background: #333;
               margin-bottom: 15px;
            }
            .builder_statistics-module-preview > div:last-child {
               margin-bottom: 0;
            }
            .builder_statistics-module-preview > div > div {
               background: #656565;
            }
         </style>
      <?php
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_statistics = function( args, content, $modal, $module ) {
                  var out = '';
                  if ( content && 'object' === typeof content && content.length ) {
                     _.each( content, function( item ) {
                        out += themefyreBuilder.modulePreviewCallbacks.builder_statistics_item( item.attrs.named );
                     });
                  }
                  return out;
               };
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      global $builder_statistics_items;
      $builder_statistics_items = array();
      do_shortcode( $content );
      $out = '';
      foreach ( $builder_statistics_items as $item ) {
         if ( $item['title'] && $item['value'] ) {
            if ( ! $item['maximum'] ) {
               $item['maximum'] = 100;
            }
            $before_value = 'before' === $item['unit_location'] ? $item['unit'] : '';
            $after_value = 'after' === $item['unit_location'] ? $item['unit'] : '';

            $percentage = intval ( $item['value'] ) < intval( $item['maximum'] ) ? round( ( ( intval( $item['value'] ) / intval( $item['maximum'] ) ) * 100 ) ) : 100;
            $out .= '<p>'.$item['title'].' - '.$before_value.$item['value'].$after_value.' / '.$before_value.$item['maximum'].$after_value.'</p>';
            $out .= '<div><div style="width:'.$percentage.'%;"></div></div>';
         }
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_statistics_items;
      $builder_statistics_items = array();
      do_shortcode( $content );
      if ( empty( $builder_statistics_items ) ) {
         return '';
      }
      extract( $atts );

      // Get the bool values of our settings
      $animated = builder_get_bool( $animated );
      $values = builder_get_bool( $values );

      // Set up the animated entrance attributes
      $entrance_trigger_data = $animated ? ' data-entrance-trigger="animate-item"' : '';
      $entrance_chained_data = $animated ? ' data-entrance="chained"' : '';
      $entrance_delay = 0;

      $classes = builder_compile_html_class('builder-statistics', builder_get_bool( $inverse ) ? 'inverse' : '', $animated ? 'is-animated' : '', $values ? 'show-values' : '', $class);
      $out = '<div class="'.$classes.'" id="'.$id.'"'.$entrance_trigger_data.$inline_attributes.'>';
      foreach ( $builder_statistics_items as $item ) {
         if ( ! $item['maximum'] ) {
            $item['maximum'] = 100;
         }
         $statistic_classes = builder_compile_html_class('builder-statistics-item', $item['class']);
         $entrance_delay_data = $animated && $entrance_delay ? ' data-entrance-delay="'.$entrance_delay.'"' : '';
         $before_value = 'before' === $item['unit_location'] ? '<span class="builder-statistics-item-unit">'.$item['unit'].'</span>' : '';
         $after_value = 'after' === $item['unit_location'] ? '<span class="builder-statistics-item-unit">'.$item['unit'].'</span>' : '';
         $percentage = intval ( $item['value'] ) < intval( $item['maximum'] ) ? round( ( ( intval( $item['value'] ) / intval( $item['maximum'] ) ) * 100 ) ) : 100;
         $out .= '<div class="'.$statistic_classes.'" id="'.$item['id'].'"'.$entrance_chained_data.$entrance_delay_data.$item['inline_attributes'].'>';
         $out .= '<strong class="builder-statistics-item-title">'.$item['title'].'</strong>';
         $out .= '<div class="builder-statistics-item-bar">';
         $out .= '<span class="builder-statistics-item-data"><span class="builder-statistics-item-value">'.$before_value.$item['value'].$after_value.'</span><span class="builder-statistics-item-maximum">'.$before_value.$item['maximum'].$after_value.'</span></span>';
         $out .= '<div class="builder-statistics-item-bar-value" style="width:'.$percentage.'%;">';
         $out .= '<span class="builder-statistics-item-data"><span class="builder-statistics-item-value">'.$before_value.$item['value'].$after_value.'</span><span class="builder-statistics-item-maximum">'.$before_value.$item['maximum'].$after_value.'</span></span>';
         $out .= '</div>';
         $out .= '</div>';
         $out .= '</div>';

         // Increase the delay in animated entrance time
         if ( $animated ) {
            $entrance_delay += 250;
         }
      }
      $out .= '</div>';

      return $out;
   }

}

/**
 * Statistics Task Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Statistics_Item_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Statistics_Item_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular' => __( 'Statistic', 'themefyre_builder' ),
         'plural'   => __( 'Statistics', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_statistics_item',
         'builder_role'    => 'child',
         'label_attribute' => 'title',
      );

      $args['attributes']['title'] = array(
         'type'       => 'string',
         'title'      => __( 'Title', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['value'] = array(
         'type'        => 'string',
         'title'       => __( 'Value', 'themefyre_builder' ),
         'desc'        => __( 'The statistic will be displayed as this value out of the maximum value. Enter a numeric value only, should be less than the maximum value.', 'themefyre_builder' ),
      );

      $args['attributes']['maximum'] = array(
         'type'        => 'string',
         'title'       => __( 'Maximum Value', 'themefyre_builder' ),
         'desc'        => __( 'Enter a numeric value only. If no value is entered the maximum value will be assumed to be 100.', 'themefyre_builder' ),
         'placeholder' => '100',
      );

      $args['attributes']['unit_location'] = array(
         'type'    => 'within',
         'title'   => __( 'Unit Location', 'themefyre_builder' ),
         'desc'    => __( 'Where the unit indicator should be displayed, if at all.', 'themefyre_builder' ),
         'default' => 'none',
         'options' => array(
            'none'   => __( '(no unit indicator)', 'themefyre_builder' ),
            'before' => __( 'Before the value', 'themefyre_builder' ),
            'after'  => __( 'After the value', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['unit'] = array(
         'type'  => 'html_string',
         'title' => __( 'Unit', 'themefyre_builder' ),
         'desc'  => __( 'A unit to represent the values entered above. This can be anything, example units include: %, GB, Pounds, etc...', 'themefyre_builder' ),
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {
      ?>
         <style>
            .builder_statistics_item-module-preview div {
               height: 10px;
               border-radius: 3px;
            }
            .builder_statistics_item-module-preview > div {
               background: #f2f2f2;
            }
            .builder_statistics_item-module-preview > div > div {
               background: #d2d2d2;
            }
         </style>
      <?php
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_statistics_item = function( args, content, $modal, $module ) {
                  var out = '';
                  if ( 'undefined' === typeof args.value || ! args.value ) {
                     args.value = 0;
                  }
                  if ( 'undefined' === typeof args.maximum || ! args.maximum ) {
                     args.maximum = 100;
                  }
                  args.value = parseInt( args.value );
                  args.maximum = parseInt( args.maximum );
                  var unit = 'undefined' !== typeof args.unit_location && 'undefined' !== typeof args.unit && 'none' !== args.unit_location && args.unit ? args.unit : '';
                  var beforeText = unit && 'before' === args.unit_location ? unit : '';
                  var afterText = unit && 'after' === args.unit_location ? unit : '';
                  if ( args.value && 'undefined' !== typeof args.title && args.title ) {
                     var percent = args.value < args.maximum ? Math.round( ( args.value / args.maximum ) * 100 ) : 100;
                     out += '<p>'+args.title+' - '+beforeText+args.value+afterText+' / '+beforeText+args.maximum+afterText+'</p>';
                     out += '<div><div style="width:'+percent+'%;"></div></div>'
                  }
                  return out;
               };
               $(document).on('change', '#builder_statistics_item-unit_location', function(event) {
                  var $unitControl = $('#attribute-builder_statistics_item-unit');
                  if ( 'none' === $(this).val() ) {
                     themefyreBuilder.disableControl( $unitControl, event );
                  }
                  else {
                     themefyreBuilder.enableControl( $unitControl, event );
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      $out = '';
      if ( ! $maximum ) {
         $maximum = 100;
      }
      $before_value = 'before' === $unit_location ? $unit : '';
      $after_value = 'after' === $unit_location ? $unit : '';
      if ( $title && $value ) {
         $percentage = intval ( $value ) < intval( $maximum ) ? round( ( ( intval( $value ) / intval( $maximum ) ) * 100 ) ) : 100;
         $out .= '<p>'.$title.' - '.$before_value.$value.$after_value.' / '.$before_value.$maximum.$after_value.'</p>';
         $out .= '<div><div style="width:'.$percentage.'%;"></div></div>';
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_statistics_items;
      $builder_statistics_items[] = $atts;
   }

}