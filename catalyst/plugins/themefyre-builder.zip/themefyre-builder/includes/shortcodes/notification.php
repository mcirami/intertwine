<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_notification` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_notification_shortcode() {
  builder_add_shortcode('Builder_Notification_Shortcode', 'builder_notification');
}
add_action('init', 'builder_add_notification_shortcode');

/**
 * Notification Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Notification_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Notification_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      $entrance_delay_options = array('none' => __('(no animated entrance delay)', 'themefyre_builder') );
      for ($i=250;$i<=5000;$i+=250) {
         $entrance_delay_options[$i] = $i.'ms';
      }

      $labels = array(
         'singular' => __( 'Notification', 'themefyre_builder' ),
         'plural'   => __( 'Notifications', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_notification',
         'icon'            => 'warning',
         'tmce'            => true,
         'builder_role'    => 'content',
         'support_link'    => true,
         'label_attribute' => 'title',
      );

      $args['attributes']['title'] = array(
         'type'       => 'string',
         'title'      => __( 'Title', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['icon'] = array(
         'type'  => 'icon',
         'title' => __( 'Icon', 'themefyre_builder' ),
      );

      $args['attributes']['color_scheme'] = array(
         'type'    => 'within',
         'title'   => __( 'Color Scheme', 'themefyre_builder' ),
         'default' => 'information',
         'options' => array(
            'information' => __( 'Information', 'themefyre_builder' ),
            'success'     => __( 'Success', 'themefyre_builder' ),
            'error'       => __( 'Error', 'themefyre_builder' ),
            'warning'     => __( 'Warning', 'themefyre_builder' ),
            'custom'      => __( '(custom colors)', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['bg_color'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Background Color', 'themefyre_builder' ),
      );

      $args['attributes']['text_color'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Text Color', 'themefyre_builder' ),
      );

      $args['attributes']['entrance'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->animated_entrance_options,
      );

      $args['attributes']['entrance_delay'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance Delay', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $entrance_delay_options,
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {
      ?>
         <style>
            .builder_notification-module-preview {
               text-align: center;
            }
         </style>
      <?php
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_notification = function( args, content, $modal, $module ) {
                  var out = '';
                  if ( 'undefined' !== typeof args.icon && args.icon ) {
                     out += '<h3 class="notification-icon '+args.icon+'"></h3>';
                  }
                  if ( 'undefined' !== typeof args.title && args.title ) {
                     out += '<strong>'+args.title+'</strong>';
                  }
                  return out;
               };
               $(document).on('change', '#builder_notification-color_scheme', function(event) {
                  var $customControls = $('#attribute-builder_notification-bg_color, #attribute-builder_notification-text_color');
                  if ( 'custom' === $(this).val() ) {
                     themefyreBuilder.enableControl( $customControls, event );
                  }
                  else {
                     themefyreBuilder.disableControl( $customControls, event );
                  }
               });
               $(document).on('change', '#builder_notification-entrance', function(event) {
                  if ( 'none' === $(this).val() ) {
                     themefyreBuilder.disableControl( $('#attribute-builder_notification-entrance_delay'), event );
                  }
                  else {
                     themefyreBuilder.enableControl( $('#attribute-builder_notification-entrance_delay'), event );

                     // Scroll the entrance delay control into view
                     if ( undefined !== event.originalEvent ) {
                        var $scrollBox = $(this).closest('.builder-modal-content');
                        setTimeout( function() {
                           $scrollBox.animate( {
                              scrollTop: $scrollBox.prop('scrollHeight'),
                           }, 250 );
                        }, 255 );
                     }
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      $out = '';
      if ( $icon ) {
         $out .= '<h3 class="notification-icon '.$icon.'"></h3>';
      }
      if ( $title ) {
         $out .= '<strong>'.$title.'</strong>';
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      extract( $atts );

      // Make sure we have a title
      if ( ! $title ) {
         return '';
      }

      // Set up the link data, when applicable
      $link_data = builder_get_link_inline_html($atts);

      // Wrap our notification in a different tag depending on if a link has been applied
      $tag = $link_data ? 'a' : 'div';

      // Animated entrance inline data
      $entrance_data = 'none' !== $entrance ? ' data-entrance="'.$entrance.'"' : '';
      if ( $entrance_data && 'none' !== $entrance_delay ) {
         $entrance_data .= ' data-entrance-delay="'.$entrance_delay.'"';
      }

      // Begin with an empty string
      $inline_css = '';

      // Enable custom colors
      if ( 'custom' === $color_scheme ) {
         $bg_color = $bg_color ? $bg_color : '#000000';
         $text_color = $text_color ? $text_color : '#ffffff';
         $inline_css .= 'background-color:'.$bg_color.';color:'.$text_color.';';
      }

      // Wrap our inlice CSS in the `style` attribute
      if ( $inline_css ) {
         $inline_css = ' style="'.$inline_css.'"';
      }

      // Compile the list of classes
      $classes = builder_compile_html_class('builder-notification color-scheme-'.$color_scheme, $class);

      $out = '<'.$tag.' class="'.$classes.'" id="'.$id.'"'.$link_data.$inline_css.$entrance_data.$inline_attributes.'>';
      if ( $icon ) {
         $out .= builder_get_icon_html( $icon, array( 'class' => 'builder-notification-icon' ) );
      }
      $out .= '<p class="builder-notification-title">'.$title.'</p>';
      $out .= '</'.$tag.'>';

      return $out;
   }

}