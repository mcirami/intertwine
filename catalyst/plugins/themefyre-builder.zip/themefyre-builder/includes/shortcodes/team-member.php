<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_team_member` and `builder_team_member_item` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_team_member_shortcodes() {
  builder_add_shortcode('Builder_Team_Member_Shortcode', 'builder_team_member');
  builder_add_shortcode('Builder_Team_Member_Item_Shortcode', 'builder_team_member_item');
}
add_action('init', 'builder_add_team_member_shortcodes');

/**
 * Team Member Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Team_Member_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Team_Member_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      $entrance_delay_options = array('none' => __('(no animated entrance delay)', 'themefyre_builder') );
      for ($i=250;$i<=5000;$i+=250) {
         $entrance_delay_options[$i] = $i.'ms';
      }

      $labels = array(
         'singular' => __( 'Team Member', 'themefyre_builder' ),
         'plural'   => __( 'Team Members', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_team_member',
         'icon'            => 'businessman',
         'tmce'            => true,
         'builder_role'    => 'content',
         'content_type'    => 'builder_team_member_item',
         'content_first'   => false,
         'label_attribute' => 'name',
      );

      $args['attributes']['attachment_id'] = array(
         'type'  => 'image',
         'title' => __( 'Image', 'themefyre_builder' ),
      );

      $args['attributes']['attachment_height'] = array(
         'type'  => 'string',
         'title' => __( 'Image Height', 'themefyre_builder' ),
         'desc'  => __( 'If an image has been selected above you can force it to a custom height by entering a value here. If no image has been selected this value will control the height of the image placeholder which has a default height of 250px. The value must include a unit (px,em,etc...).', 'themefyre_builder' ),
      );

      $args['attributes']['name'] = array(
         'type'       => 'html_string',
         'title'      => __( 'Name', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['role'] = array(
         'type'       => 'html_string',
         'title'      => __( 'Role', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['bio'] = array(
         'type'       => 'html_string',
         'title'      => __( 'Bio', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['entrance'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance', 'themefyre_builder' ),
         'desc'    => __( 'Animated entrance will be applied to each toggle consecutively.', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->animated_entrance_options,
      );

      $args['attributes']['entrance_delay'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance Delay', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $entrance_delay_options,
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {
      ?>
         <style>
            .builder_team_member-module-preview {
               text-align: center;
               max-height: none !important;
            }
            .builder_team_member-module-preview:before {
               display: none !important;
            }
         </style>
      <?php
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_team_member = function( args, content, $modal, $module ) {
                  var out = '';
                  var $previewImage = $('.builder-preview-image[data-key="builder_team_member-attachment_id"] img', $modal);
                  if ( $previewImage.length ) {
                     out += '<img src="'+$previewImage.attr('src')+'" />';
                  }
                  if ( 'undefined' !== typeof args.name && args.name ) {
                     out += '<h3>'+args.name+'</h3>';
                  }
                  if ( 'undefined' !== typeof args.role && args.role ) {
                     out += '<p>'+args.role+'</p>';
                  }
                  return out;
               };
               $(document).on('change', '#builder_team_member-entrance', function(event) {
                  if ( 'none' === $(this).val() ) {
                     themefyreBuilder.disableControl( $('#attribute-builder_team_member-entrance_delay'), event );
                  }
                  else {
                     themefyreBuilder.enableControl( $('#attribute-builder_team_member-entrance_delay'), event );

                     // Scroll the entrance delay control into view
                     if ( undefined !== event.originalEvent ) {
                        var $scrollBox = $(this).closest('.builder-modal-content');
                        setTimeout( function() {
                           $scrollBox.animate( {
                              scrollTop: $scrollBox.prop('scrollHeight'),
                           }, 250 );
                        }, 255 );
                     }
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      $out = '';
      if ( $img_url = builder_get_attachment_src( $atts['attachment_id'], 'medium' ) ) {
         $out .= '<img src="'.$img_url.'" />';
      }
      if ( $name ) {
         $out .= '<h3>'.$name.'</h3>';
      }
      if ( $role ) {
         $out .= '<p>'.$role.'</p>';
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_team_member_items;
      $builder_team_member_items = array();
      do_shortcode( $content );
      extract( $atts );

      // Animated entrance inline data
      $entrance_data = 'none' !== $entrance ? ' data-entrance="'.$entrance.'"' : '';
      if ( $entrance_data && 'none' !== $entrance_delay ) {
         $entrance_data .= ' data-entrance-delay="'.$entrance_delay.'"';
      }

      // Compile the list of classes
      $classes = builder_compile_html_class('builder-team-member', $class);

      $out = '<div class="'.$classes.'" id="'.$id.'"'.$entrance_data.$inline_attributes.'>';

      $out .= '<div class="builder-team-member-header">';
      $out .= '<div class="builder-team-member-attachment">';
      if ( $img_url = builder_get_attachment_src( $attachment_id ) ) {
         if ( $attachment_height ) {
            $out .= '<div class="builder-team-member-attachment-image builder-bg-scale" style="background-image:url('.$img_url.');height:'.$attachment_height.'"></div>';
         }
         else {
            $out .= '<img class="builder-team-member-attachment-image" src="'.$img_url.'" alt="'.builder_get_attachment_alt( $attachment_id ).'" />';
         }
      }
      else {
         $attachment_height = $attachment_height ? $attachment_height : '250px';
         $out .= '<div class="builder-team-member-attachment-placeholder" style="height:'.$attachment_height.';"></div>';
      }
      $out .= '</div>';
      if ( $builder_team_member_items ) {
         $out .= '<div class="builder-team-member-links">';
         $out .= '<ul>';
         foreach ( $builder_team_member_items as $item ) {
            $item_link_data = builder_get_link_inline_html( $item );
            $item_classes = builder_compile_html_class('builder-team-member-link', $item['class']);
            $item_icon = $item['icon'] ? builder_get_icon_html($item['icon'], array('class' => 'builder-team-member-icon')) : '';
            $out .= '<li><a class="'.$item_classes.' id="'.$item['id'].'"'.$item_link_data.' title="'.$item['title'].'">'.$item_icon.'<span class="builder-team-member-link-title">'.$item['title'].'</span></a></li>';
         }
         $out .= '</ul>';
         $out .= '</div>';
      }
      $out .= '</div>';

      if ( $name ) {
         $out .= '<h3 class="builder-team-member-name">'.$name.'</h3>';
      }
      if ( $role ) {
         $out .= '<p class="builder-team-member-role">'.$role.'</p>';
      }
      if ( $bio ) {
         $out .= '<p class="builder-team-member-bio">'.$bio.'</p>';
      }

      $out .= '</div>';

      return $out;
   }

}

/**
 * Team Member Link Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Team_Member_Item_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Team_Member_Item_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular' => __( 'Link', 'themefyre_builder' ),
         'plural'   => __( 'Links', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_team_member_item',
         'builder_role'    => 'child',
         'label_attribute' => 'title',
         'support_link'    => true,
      );

      $args['attributes']['title'] = array(
         'type'       => 'string',
         'title'      => __( 'Title', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['icon'] = array(
         'type'  => 'icon',
         'title' => __( 'Icon', 'themefyre_builder' ),
      );

      parent::__construct( $args );
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_team_member_items;
      $builder_team_member_items[] = $atts;
   }

}