<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_contact_form` and `builder_contact_form_item` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_contact_forms_shortcodes() {
  builder_add_shortcode('Builder_Contact_Form_Shortcode', 'builder_contact_form');
  builder_add_shortcode('Builder_Contact_Form_Item_Shortcode', 'builder_contact_form_item');
}
add_action('init', 'builder_add_contact_forms_shortcodes');

/**
 * Contact Form Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Contact_Form_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Contact_Form_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular' => __( 'Contact Form', 'themefyre_builder' ),
         'plural'   => __( 'Contact Forms', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_contact_form',
         'icon'            => 'email-alt',
         'tmce'            => true,
         'builder_role'    => 'content',
         'content_type'    => 'builder_contact_form_item',
         'default_content' => '[builder_contact_form_item label="'.__('Full Name', 'themefyre_builder').'" type="text" width="1/2"]'
                            . '[builder_contact_form_item label="'.__('Email Address', 'themefyre_builder').'" type="email" width="1/2"]'
                            . '[builder_contact_form_item label="'.__('Message', 'themefyre_builder').'" type="textarea"]',
      );

      $args['attributes']['recipient_email'] = array(
         'type'        => 'string',
         'title'       => __( 'Recipient E-mail Address', 'themefyre_builder' ),
         'desc'        => sprintf( __( 'The email address that form submissions will be sent to, if left blank any form submissions will be sent to the admin email address <strong>(%s)</strong>. You can specify multiple email addresses, they must be separatd by only a comma.', 'themefyre_builder' ), get_option('admin_email') ),
         'placeholder' => get_option('admin_email'),
      );

      $args['attributes']['captcha'] = array(
         'type'  => 'bool',
         'title' => __( 'Captcha', 'themefyre_builder' ),
         'label' => __( 'End user must correctly fill out a captcha to submit this form.', 'themefyre_builder' ),
      );

      $args['attributes']['inverse'] = array(
         'type'  => 'bool',
         'title' => __( 'Inverse Style', 'themefyre_builder' ),
         'label' => __( 'Optimize module to be displayed on a dark background.', 'themefyre_builder' ),
      );

      $args['attributes']['button_label'] = array(
         'type'        => 'string',
         'title'       => __( 'Submit Button Label', 'themefyre_builder' ),
         'desc'        => __( 'The default is <strong>Submit</strong> if left blank.', 'themefyre_builder' ),
         'placeholder' => __( 'Submit', 'themefyre_builder' ),
         'searchable'  => true,
      );

      $args['attributes']['sent_message'] = array(
         'type'        => 'string',
         'title'       => __( 'Form Submitted Message', 'themefyre_builder' ),
         'desc'        => __( 'The message that users will see after submitting this form. Defaults to <strong>Your Message Has Been Sent</strong> if left blank.', 'themefyre_builder' ),
         'placeholder' => __( 'Your Message Has Been Sent', 'themefyre_builder' ),
      );

      $args['attributes']['email_subject'] = array(
         'type'        => 'string',
         'title'       => __( 'Recieved E-Mail Subject', 'themefyre_builder' ),
         'desc'        => sprintf( __( 'The subject line of the emails you will recieve from this form, if left blank it will default to <strong>New Message [Sent by contact form at %s]</strong>.', 'themefyre_builder' ), get_bloginfo('name') ),
         'placeholder' => sprintf( __( 'New Message [Sent by contact form at %s]', 'themefyre_builder' ), get_bloginfo('name') ),
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {
      ?>
         <style>
            .builder_contact_form-module-preview > div {
               border: 1px solid #666;
               margin-bottom: 15px;
               padding: 15px;
            }
            .builder_contact_form-module-preview > div:last-child {
               margin-bottom: 0;
            }
         </style>
      <?php
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_contact_form = function( args, content, $modal, $module ) {
                  var out = '', fieldArgs;
                  if ( content && 'object' === typeof content && content.length ) {
                     _.each( content, function( item ) {
                        fieldArgs = item.attrs.named;
                        if ( 'undefined' !== typeof fieldArgs.label && fieldArgs.label ) {
                           out += '<div>'+fieldArgs.label+'</div>';
                        }
                     });
                  }
                  return out;
               };
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      global $builder_contact_form_item;
      $builder_contact_form_item = array();
      do_shortcode( $content );
      $out = '';
      foreach ( $builder_contact_form_item as $item ) {
         if ( $item['label'] ) {
            $out .= '<div>'.$item['label'].'</div>';
         }
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_contact_form_item;
      $builder_contact_form_item = array();
      do_shortcode( $content );

      // Sanitize the fields
      foreach ( $builder_contact_form_item as $key => $item ) {

         // Make sure a label has been specified
         if ( ! isset($item['label']) || ! trim($item['label']) ) {
            unset( $builder_contact_form_item[$key] );
         }

         // Make sure select fields have at least one option
         if ( 'select' == $item['type'] && ! trim($item['options']) ) {
            unset( $builder_contact_form_item[$key] );
         }
      }

      // No need to continue if we don`t have any fields
      if ( empty( $builder_contact_form_item ) ) {
         return '';
      }
      extract( $atts );

      // Set up some args
      $form_id = $id;
      $submitted = isset($_POST[$form_id.'-submitted']);
      $email_body = '';
      $form_error = false;
      $email_sent = false;
      $num_fields = 0;
      $row_width = 0;

      // begin form HTML output
      $form_html  = '<form method="post" action="'.get_permalink().'">';
      $form_html .= '<div class="builder-form-fields">';

      // Begin review HTML output, if form has been submitted
      if ( $submitted ) {
         if ( ! trim($sent_message) ) $sent_message = __( 'Your Message Has Been Sent', 'themefyre_builder' );
         $review_html  = '<div class="builder-form-review">';
         $review_html .= '<h2 class="builder-form-title">'.$sent_message.'</h2>';
         $review_html .= '<ul>';
      }

      foreach ( $builder_contact_form_item as $item ) {
         $num_fields++;
         $field_error = false;
         $field_control = '';
         $field_id = $item['id'].'-control';
         $required = 'select' !== $item['type'] && builder_get_bool($item['required']);

         // Grab any submitted value
         $val = $submitted && isset($_POST[$field_id]) ? trim(stripslashes($_POST[$field_id])) : '';

         switch ( $item['type'] ) {
            case 'text':
               if ( $submitted ) {
                  if ( ! $val && $required ) {
                     $field_error = true;
                  }
                  $email_body .= $item['label'].': '.$val."\r\n\n";
                  $review_html .= '<li><strong>'.$item['label'].'</strong>: '.$val.'</li>';
               }
               $control_args = array(
                  'name' => $field_id,
                  'id' => $field_id,
                  'value' => $val,
                  'placeholder' => $item['placeholder'],
               );
               if ( $required ) {
                  $control_args['required'] = true;
               }
               $field_control = builder_get_input($control_args);
               break;

            case 'email':
               if ( $submitted ) {
                  if ( $required && ( ! $val || ! filter_var( $val, FILTER_VALIDATE_EMAIL ) ) ) {
                     $field_error = true;
                  }
                  $email_body .= $item['label'].': '.$val."\r\n\n";
                  $review_html .= '<li><strong>'.$item['label'].'</strong>: '.$val.'</li>';
               }
               $control_args = array(
                  'type' => 'email',
                  'name' => $field_id,
                  'id' => $field_id,
                  'value' => $val,
                  'placeholder' => $item['placeholder'],
               );
               if ( $required ) {
                  $control_args['required'] = true;
               }
               $field_control = builder_get_input($control_args);
               break;

            case 'checkbox':
               $val = $submitted && isset($_POST[$field_id]);
               if ( $submitted ) {
                  if ( ! $val && $required ) {
                     $field_error = true;
                  }
                  $val_text = $val ? __('Was checked', 'themefyre_builder') : __('Was not checked', 'themefyre_builder');
                  $email_body .= $item['label'].': '.$val_text."\r\n\n";
                  $review_html .= '<li><strong>'.$item['label'].'</strong>: '.$val_text.'</li>';
               }
               $control_args = array(
                  'type' => 'checkbox',
                  'name' => $field_id,
                  'id' => $field_id,
               );
               if ( $required ) {
                  $control_args['required'] = true;
               }
               if ( ( ! $submitted && builder_get_bool( $item['checked_on_load'] ) ) || ( $submitted && $val ) ) {
                  $control_args['checked'] = 'checked';
               }
               $field_control = '<label for="'.$field_id.'">'.builder_get_input($control_args).$item['label'].'</label>';
               break;

            case 'textarea':
               if ( $submitted ) {
                  if ( ! $val && $required ) {
                     $field_error = true;
                  }
                  $email_body .= $item['label'].': '.$val."\r\n\n";
                  $review_html .= '<li><strong>'.$item['label'].'</strong>: '.$val.'</li>';
               }
               $control_args = array(
                  'name' => $field_id,
                  'id' => $field_id,
                  'value' => $val,
                  'placeholder' => $item['placeholder'],
               );
               if ( $required ) {
                  $control_args['required'] = true;
               }
               $field_control = builder_get_textarea($control_args);
               break;

            case 'select':
               $options = array();
               foreach (explode( '|', $item['options'] ) as $option) {
                  $options[$option] = $option;
               }
               if ( $submitted ) {
                  $val = in_array($val, $options) ? $val : $options[0];
                  if ( ! $val && $required ) {
                     $field_error = true;
                  }
                  $email_body .= $item['label'].': '.$val."\r\n\n";
                  $review_html .= '<li><strong>'.$item['label'].'</strong>: '.$val.'</li>';
               }
               $control_args = array(
                  'name' => $field_id,
                  'id' => $field_id,
                  'value' => $val,
                  'options' => $options,
               );
               if ( $required ) {
                  $control_args['required'] = true;
               }
               $field_control = builder_get_select($control_args);
               break;
         }

         $field_error_class = '';
         if ( $field_error ) {
            $form_error = true;
            $field_error_class = 'has-error';
         }

         switch ( $item['width'] ) {
            case '1/2': $row_width += 0.5;  break;
            case '1/3': $row_width += 0.33; break;
            case '1/4': $row_width += 0.25; break;
            default: $row_width = 1;
         }

         $field_classes = builder_compile_html_class('builder-form-field', 'field-type-'.$item['type'], 'field-width-'.str_replace('/', '_', $item['width']), $item['class'], $field_error_class );
         $form_html .= '<div class="'.$field_classes.'" id="'.$item['id'].'" data-type="'.$item['type'].'"'.$item['inline_attributes'].'>';
         if ( 'checkbox' != $item['type'] ) {
            $form_html .= '<label for="'.$field_id.'">';
            $form_html .= $item['label'];
            if ( $required ) {
               $form_html .= '<span class="builder-form-required-marker">*</span>';
            }
            $form_html .= '</label>';
         }
         $form_html .= $field_control;
         $form_html .= '</div>';

         if ( 0.9 < $row_width ) {
            $form_html .= '<div class="clearfix"></div>';
            $row_width = 0;
         }

      }

      if ( builder_get_bool( $captcha ) ) {
         $field_error_class = '';
         $captcha_id = $form_id.'-captcha';
         if ( $submitted ) {
            $val = isset($_POST[$captcha_id]) ? absint($_POST[$captcha_id]) : '';
            if ( ! $val || $val !== 5 ) {
               $form_error = true;
               $field_error_class = ' has-error';
            }
         }
         $form_html .= '<div class="builder-form-field field-type-captcha'.$field_error_class.'">';
         $form_html .= '<div class="builder-form-captcha">';
         $form_html .= '<label for="'.$captcha_id.'" class="builder-form-captcha-equation">2 + 3 =</label>';
         $form_html .= '<input type="text" id="'.$captcha_id.'" name="'.$captcha_id.'" />';
         $form_html .= '</div>';
         $form_html .= '</div>';
      }

      // Finish form HTML
      $button_label = $button_label ? $button_label : apply_filters( 'builder_form_default_submit_button_label', __( 'Submit', 'themefyre_builder' ) );
      $form_html .= '</div>';
      $form_html .= '<div class="builder-form-submit">';
      $form_html .= '<input class="button builder-contact-form-button" type="submit" name="'.$form_id.'-submitted" value="'.$button_label.'" />';
      $form_html .= '</div>';
      $form_html .= '</form>';

      // Finish review HTML
      if ( $submitted ) {
         $review_html .= '</ul>';
         $review_html .= '</div>';
      }

      if ( $submitted && ! $form_error ) {

         // Determine which address the email should be sent to
         if ( ! $recipient_email ) {
            $recipient_email = get_option('admin_email');
         }

         // Provide an informative title for our message
         if ( ! $email_subject ) {
            $email_subject = sprintf( __( 'New Message [Sent by contact form at %s]', 'themefyre_builder' ), get_bloginfo('name') );
         }

         // Call the function to send the message
         $email_sent = wp_mail( $recipient_email, $email_subject, $email_body );

         // If email was not sent successfully
         if ( ! $email_sent ) {
            $form_html = '<p class="builder-form-send-error">'.__('An error occured while sending your message, please try again later.', 'themefyre_builder').'</p>';
         }
      }

      $out = $email_sent ? $review_html : $form_html;

      $classes = builder_compile_html_class('builder-contact-form', builder_get_bool( $inverse ) ? 'inverse' : '', $class);
      return '<div class="'.$classes.'" id="'.$form_id.'"'.$inline_attributes.'>'.$out.'</div>';
   }

}

/**
 * Form Field Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Contact_Form_Item_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Contact_Form_Item_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular' => __( 'Field', 'themefyre_builder' ),
         'plural'   => __( 'Fields', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_contact_form_item',
         'builder_role'    => 'child',
         'label_attribute' => 'label',
      );

      $args['attributes']['label'] = array(
         'type'       => 'string',
         'title'      => __( 'Field Label', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['type'] = array(
         'type'    => 'within',
         'title'   => __( 'Field Type', 'themefyre_builder' ),
         'desc'    => __( 'Which type of control this field should consist of.', 'themefyre_builder' ),
         'default' => 'text',
         'options' => array(
            'text'     => __( 'Text Input', 'themefyre_builder' ),
            'email'    => __( 'E-Mail Address', 'themefyre_builder' ),
            'checkbox' => __( 'Checkbox', 'themefyre_builder' ),
            'textarea' => __( 'Textarea', 'themefyre_builder' ),
            'select'   => __( 'Select Box', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['required'] = array(
         'type'    => 'bool',
         'title'   => __( 'Required Field', 'themefyre_builder' ),
         'label'   => __( 'This field is required for form submission.', 'themefyre_builder' ),
         'default' => 'true',
      );

      $args['attributes']['placeholder'] = array(
         'type'  => 'string',
         'title' => __( 'Field Placeholder', 'themefyre_builder' ),
         'desc'  => __( 'Placeholder to be displayed when this field is blank.', 'themefyre_builder' ),
      );

      $args['attributes']['width'] = array(
         'type'    => 'within',
         'title'   => __( 'Field Width', 'themefyre_builder' ),
         'desc'    => __( 'Displayed width of this field, fields will be placed side by side to fill the width of the form.', 'themefyre_builder' ),
         'default' => 'full',
         'options' => array(
            'full' => __( 'Full Width', 'themefyre_builder' ),
            '1/2'  => __( '1/2 Width (50%)', 'themefyre_builder' ),
            '1/3'  => __( '1/3 Width (33%)', 'themefyre_builder' ),
            '1/4'  => __( '1/4 Width (25%)', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['options'] = array(
         'type'  => 'bar_list',
         'title' => __( 'Available Options', 'themefyre_builder' ),
         'desc'  => __( 'Vertical Bar delimited list of available options, the first option will be used as the default.<br /> <strong>Example: Option 1|Option 2|Option 3</strong>', 'themefyre_builder' ),
      );

      $args['attributes']['checked_on_load'] = array(
         'type'  => 'bool',
         'title' => __( 'Checked on Load', 'themefyre_builder' ),
         'label' => __( 'This checkbox should be checked upon page load.', 'themefyre_builder' ),
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               $(document).on('change', '#builder_contact_form_item-type', function(event) {
                  var val = $(this).val(),
                      $placeholderControl = $('#attribute-builder_contact_form_item-placeholder'),
                      $optionsControl = $('#attribute-builder_contact_form_item-options'),
                      $sizeControl = $('#attribute-builder_contact_form_item-width'),
                      $initialControl = $('#attribute-builder_contact_form_item-checked_on_load'),
                      $requiredControl = $('#attribute-builder_contact_form_item-required');


                  // Select
                  if ( 'select' === val ) {
                     themefyreBuilder.enableControl( $optionsControl, event );
                     themefyreBuilder.disableControl( $requiredControl, event );
                  }
                  else {
                     themefyreBuilder.disableControl( $optionsControl, event );
                     themefyreBuilder.enableControl( $requiredControl, event );
                  }

                  // Checkbox
                  if ( 'checkbox' === val ) {
                     themefyreBuilder.enableControl( $initialControl, event );
                  }
                  else {
                     themefyreBuilder.disableControl( $initialControl, event );
                  }

                  // Show/Hide size control
                  if ( 'textarea' === val || 'checkbox' === val ) {
                     themefyreBuilder.disableControl( $sizeControl, event );
                  }
                  else {
                     themefyreBuilder.enableControl( $sizeControl, event );
                  }

                  // Show / hide placeholder control
                  if ( 'checkbox' === val || 'select' === val ) {
                     themefyreBuilder.disableControl( $placeholderControl, event );
                  }
                  else {
                     themefyreBuilder.enableControl( $placeholderControl, event );
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_contact_form_item;
      $builder_contact_form_item[] = $atts;
   }

}