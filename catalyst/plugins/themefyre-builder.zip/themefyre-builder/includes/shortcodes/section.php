<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_section` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_section_shortcode() {
  builder_add_shortcode('Builder_Section_Shortcode', 'builder_section');
}
add_action('init', 'builder_add_section_shortcode');

/**
 * Full-width Section Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Section_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Section_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      $labels = array(
         'singular' => __( 'Content Section', 'themefyre_builder' ),
         'plural'   => __( 'Content Sections', 'themefyre_builder' ),
      );

      $args = array(
         'labels'             => $labels,
         'tag'                => 'builder_section',
         'icon'               => 'welcome-add-page',
         'builder_role'       => 'full-width',
         'label_attribute'    => 'none',
         'support_background' => true,
      );

      $args['attribute_tabs']['extras'] = array(
         'title' => __( 'Extras', 'themefyre_builder' ),
         'ids'   => array( 'top_border_color', 'bottom_border_color', 'top_arrow_color', 'bottom_arrow_color' ),
      );

      $args['attributes']['min_height'] = array(
         'type'        => 'string',
         'title'       => __( 'Minimum Height', 'themefyre_builder' ),
         'desc'        => __( 'The value must include a unit (px,em,etc...). When enabled you will be able to determine how this section\'s content should be vertically aligned. <strong>To set the height as a percentage of total screen height, use the "vh" unit, for example 100vh = 100% total screen height.</strong>', 'themefyre_builder' ),
         'placeholder' => __( '(none, let the content dictate the height)', 'themefyre_builder' ),
      );

      $args['attributes']['valign'] = array(
         'type'    => 'within',
         'title'   => __( 'Content Vertical Alignment', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->valign_options,
      );

      $args['attributes']['parallax_content'] = array(
         'type'    => 'within',
         'title'   => __( 'Parallax Content', 'themefyre_builder' ),
         'default' => 'none',
         'options' => array(
            'none'                 => __( '(no parallax content)', 'themefyre_builder' ),
            'translate'            => __( 'Translate only', 'themefyre_builder' ),
            'fade'                 => __( 'Fade only', 'themefyre_builder' ),
            'scale'                => __( 'Scale only', 'themefyre_builder' ),
            'translate-fade'       => __( 'Translate and fade', 'themefyre_builder' ),
            'fade-scale'           => __( 'Fade and scale', 'themefyre_builder' ),
            'translate-scale'      => __( 'Translate and scale', 'themefyre_builder' ),
            'translate-fade-scale' => __( 'Translate, fade, and scale', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['stretched'] = array(
         'type'  => 'bool',
         'title' => __( 'Horizontally Stretched Content', 'themefyre_builder' ),
         'label' => __( 'Content will fill all available horizontal space.', 'themefyre_builder' ),
      );

      $args['attributes']['padding_top'] = array(
         'type'        => 'string',
         'title'       => __( 'Custom Top Padding', 'themefyre_builder' ),
         'desc'        => __( 'Custom amount of padding to use for the top of this section.<br />The value must include a unit (px,em,etc...).<br /><strong>You can enter "0" to have no padding.</strong>', 'themefyre_builder' ),
         'placeholder' => __( '(default padding amount)', 'themefyre_builder' ),
      );

      $args['attributes']['padding_bottom'] = array(
         'type'        => 'string',
         'title'       => __( 'Custom Bottom Padding', 'themefyre_builder' ),
         'desc'        => __( 'Custom amount of padding to use for the bottom of this section.<br />The value must include a unit (px,em,etc...).<br /><strong>You can enter "0" to have no padding.</strong>', 'themefyre_builder' ),
         'placeholder' => __( '(default padding amount)', 'themefyre_builder' ),
      );

      $args['attributes']['top_border_color'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Top Border Color', 'themefyre_builder' ),
         'desc'  => __( 'Selecting a color will display a 1px solid border below this content section.', 'themefyre_builder' ),
      );

      $args['attributes']['bottom_border_color'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Bottom Border Color', 'themefyre_builder' ),
         'desc'  => __( 'Selecting a color will display a 1px solid border below this content section.', 'themefyre_builder' ),
      );

      $args['attributes']['top_arrow_color'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Top Arrow Color', 'themefyre_builder' ),
         'desc'  => __( 'Selecting a color will display a downward pointing arrow below this content section.', 'themefyre_builder' ),
      );

      $args['attributes']['bottom_arrow_color'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Bottom Arrow Color', 'themefyre_builder' ),
         'desc'  => __( 'Selecting a color will display a downward pointing arrow below this content section.', 'themefyre_builder' ),
      );

      parent::__construct( $args );
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      extract( $atts );

      // grab the args for the background settings
      $bg_html = builder_get_background_html( $atts );

      // Parallax enabled content
      $parallax_content_attr = $parallax_content_class = '';
      if ( 'none' !== $parallax_content ) {
         $parallax_content_attr = ' data-parallax="'.$parallax_content.'"';
         $parallax_content_class = 'builder-parallax-viewport';
      }

      // Begin creating our list of inline styles
      $inline_css = $bg_html['inline_css'];

      // Custom top padding
      if ( '' !== $padding_top ) {
         $inline_css .= 'padding-top:'.$padding_top.';';
      }

      // Custom bottom padding
      if ( '' !== $padding_bottom ) {
         $inline_css .= 'padding-bottom:'.$padding_bottom.';';
      }

      // Custom minimum height
      if ( $min_height ) {
         $inline_css .= 'min-height:'.$min_height.';';
      }

      // Top border
      if ( '' !== $top_border_color ) {
         $inline_css .= 'border-top:1px solid '.$top_border_color.';';
      }

      // Bottom border
      if ( '' !== $bottom_border_color ) {
         $inline_css .= 'border-bottom:1px solid '.$bottom_border_color.';';
      }

      // Maybe wrap our inlice CSS in the `style` attribute
      if ( $inline_css ) {
         $inline_css = ' style="'.$inline_css.'"';
      }

      // Horizontally stretched class
      $streched_class = builder_get_bool( $stretched ) ? 'stretched' : '';

      // Vertical alignment class
      $valign_class = 'none' !== $valign ? 'builder-valign-'.$valign : '';

      // Top & bottom border, top & bottom
      $extras_classes = '';
      if ( '' !== $top_border_color ) {
         $extras_classes .= ' has-top-border';
      }
      if ( '' !== $bottom_border_color ) {
         $extras_classes .= ' has-bottom-border';
      }
      if ( '' !== $top_arrow_color ) {
         $extras_classes .= ' has-top-arrow';
      }
      if ( '' !== $bottom_arrow_color ) {
         $extras_classes .= ' has-bottom-arrow';
      }

      // Compile the class list
      $classes = builder_compile_html_class('builder-section', $streched_class, $extras_classes, $class);
      $viewport_classes = builder_compile_html_class('builder-section-viewport', $valign_class, $parallax_content_class, $bg_html['extra_class']);

      $out  = '<div class="'.$classes.'" id="'.$id.'"'.$inline_attributes.'>';
      if ( '' !== $top_arrow_color ) {
         $out .= '<div class="builder-section-arrow builder-section-arrow-top" style="border-bottom-color:'.$top_arrow_color.';"></div>';
      }
      $out .= '<div class="'.$viewport_classes.'"'.$inline_css.'>';
      $out .= $bg_html['inline_html'];
      if ( 'none' !== $valign ) {
         $out .= '<div class="builder-valign-target">';
      }
      $out .= '<div class="builder-content-wrap"'.$parallax_content_attr.'>';
      $out .= do_shortcode( $content );
      $out .= '</div>';
      if ( 'none' !== $valign ) {
         $out .= '</div>';
      }
      $out .= '</div>';
      if ( '' !== $bottom_arrow_color ) {
         $out .= '<div class="builder-section-arrow builder-section-arrow-bottom" style="border-top-color:'.$bottom_arrow_color.';"></div>';
      }
      $out .= '</div>';
      return $out;
   }

}