<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_instructions_item` and `builder_instructions` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_instructions_shortcodes() {
  builder_add_shortcode('Builder_Instructions_Item_Shortcode', 'builder_instructions_item');
  builder_add_shortcode('Builder_Instructions_Shortcode', 'builder_instructions');
}
add_action('init', 'builder_add_instructions_shortcodes');

/**
 * Instructions Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Instructions_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Instructions_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      $labels = array(
         'singular' => __( 'Instructions', 'themefyre_builder' ),
         'plural'   => __( 'Instructions', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_instructions',
         'icon'            => 'editor-ol',
         'tmce'            => true,
         'builder_role'    => 'content',
         'content_type'    => 'builder_instructions_item',
         'default_content' => '[builder_instructions_item title="'.__('Step One Title', 'themefyre_builder').'"]'.__('Step one content', 'themefyre_builder').'[/builder_instructions_item]'
                            . '[builder_instructions_item title="'.__('Step Two Title', 'themefyre_builder').'"]'.__('Step two content', 'themefyre_builder').'[/builder_instructions_item]',
      );

      $args['attributes']['inverse'] = array(
         'type'  => 'bool',
         'title' => __( 'Inverse Style', 'themefyre_builder' ),
         'label' => __( 'Optimize module to be displayed on a dark background.', 'themefyre_builder' ),
      );

      $args['attributes']['entrance'] = array(
         'type'    => 'bool',
         'title'   => __( 'Animated Entrance', 'themefyre_builder' ),
         'label'   => __( 'Steps will animate in when they are scrolled to.', 'themefyre_builder' ),
         'default' => 'true',
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {
      ?>
         <style>
            .builder-module[data-role="content"] .builder_instructions-module-preview .step-title:not(:first-child) {
               margin-top: 15px !important;
            }
         </style>
      <?php
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_instructions = function( args, content, $modal, $module ) {
                  var out = '', itemArgs, icon;
                  if ( content && 'object' === typeof content && content.length ) {
                     _.each( content, function( item ) {
                        itemArgs = item.attrs.named;
                        if ( 'undefined' !== typeof itemArgs.title && itemArgs.title ) {
                           icon = 'undefined' !== typeof itemArgs.icon && itemArgs.icon ? '<span class="'+itemArgs.icon+'"></span> ' : '';
                           out += '<h3 class="step-title">'+icon+itemArgs.title+'</h3>';
                           out += window.switchEditors.wpautop( item.content );
                        }
                     });
                  }
                  return out;
               };
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      global $builder_instructions_items;
      $builder_instructions_items = array();
      do_shortcode( $content );
      $out = '';
      foreach ( $builder_instructions_items as $item ) {
         if ( $item['title'] ) {
            $icon = $item['icon'] ? '<span class="'.$item['icon'].'"></span> ' : '';
            $out .= '<h3 class="step-title">'.$icon.$item['title'].'</h3>';
            $out .= wpautop( $item['content'] );
         }
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_instructions_items;
      $builder_instructions_items = array();
      do_shortcode( $content );
      if ( empty( $builder_instructions_items ) ) {
         return '';
      }
      extract( $atts );

      $entrance_delay = 0;
      $entrance_delay_data = '';
      $group_entrance_data = builder_get_bool( $entrance ) ? ' data-entrance-trigger="animate-step"' : '';
      $step_entrance_data = $group_entrance_data ? ' data-entrance="chained"' : '';

      $classes = builder_compile_html_class('builder-instructions', builder_get_bool( $inverse ) ? 'inverse' : '', $class);
      $out = '<div class="'.$classes.'" id="'.$id.'"'.$group_entrance_data.$inline_attributes.'>';

      $i = 0; foreach ( $builder_instructions_items as $item ) { $i++;
         if ( $step_entrance_data ) {
            $entrance_delay_data = ' data-entrance-delay="'.$entrance_delay.'"';
            $entrance_delay+=250;
         }
         $link_data = builder_get_link_inline_html($item);
         $superlink_class = $link_data ? 'builder-superlink' : '';
         $icon = $item['icon'] ? builder_get_icon_html($item['icon'], array( 'class' => 'builder-step-icon' ) ) : '';
         $step_classes = builder_compile_html_class('builder-instructions-step', $icon ? 'has-icon' : '', $superlink_class, $item['class']);
         $out .= '<div class="'.$step_classes.'" id="'.$item['id'].'"'.$step_entrance_data.$entrance_delay_data.$item['inline_attributes'].'>';
         $out .= '<div class="builder-step-symbol">';
         $out .= $icon ? $icon : '<span class="builder-step-number">'.$i.'</span>';
         $out .= '</div>';
         $out .= '<div class="builder-step-description">';
         $out .= '<h3 class="builder-step-title">'.$item['title'].'</h3>';
         $out .= '<div class="builder-step-content builder-tmce-content">'.apply_filters('the_content', $item['content']).'</div>';
         if ( $link_data ) {
            $out .= '<p class="builder-icon-box-link hide-if-js"><a'.$link_data.'>'.$item['title'].' &#8594;</a></p>';
         }
         $out .= '</div>';
         $out .= '</div>';
      }

      $out .= '</div>';

      return $out;
   }

}

/**
 * Instructions Item Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Instructions_Item_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Instructions_Item_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular' => __( 'Step', 'themefyre_builder' ),
         'plural'   => __( 'Steps', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_instructions_item',
         'builder_role'    => 'child',
         'content_type'    => 'editor',
         'label_attribute' => 'title',
         'support_link'    => true,
      );

      $args['attributes']['title'] = array(
         'type'       => 'string',
         'title'      => __( 'Title', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['icon'] = array(
         'type'  => 'icon',
         'title' => __( 'Icon', 'themefyre_builder' ),
         'desc'  => __( 'An icon to be displayed in place of the number representing this step.', 'themefyre_builder' ),
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_instructions_item = function( args, content, $modal, $module ) {
                  var out = '';
                  if ( 'undefined' !== typeof args.title && args.title ) {
                     var icon = 'undefined' !== typeof args.icon && args.icon ? '<span class="'+args.icon+'"></span> ' : '';
                     out += '<h3 class="step-title">'+icon+args.title+'</h3>';
                  }
                  out += content;
                  return out;
               };
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      $out = '';
      if ( $title ) {
         $icon = $icon ? '<span class="'.$icon.'"></span> ' : '';
         $out .= '<h3 class="step-title">'.$icon.$title.'</h3>';
      }
      if ( $content ) {
         $out .= wpautop( $content );
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_instructions_items;
      $atts['content'] = $content;
      $builder_instructions_items[] = $atts;
   }

}