<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_map_item`, `builder_map`, and `builder_full_width_map` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_map_shortcodes() {
  builder_add_shortcode('Builder_Map_Item_Shortcode', 'builder_map_item');
  builder_add_shortcode('Builder_Map_Shortcode', 'builder_map');
  builder_add_shortcode('Builder_Full_Width_Map_Shortcode', 'builder_full_width_map');
}
add_action('init', 'builder_add_map_shortcodes');

/**
 * Map MarkerShortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Map_Item_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Map_Item_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular'          => __( 'Map Marker', 'themefyre_builder' ),
         'plural'            => __( 'Map Markers', 'themefyre_builder' ),
         'content_tab_title' => __( 'Informational Popup', 'themefyre_builder' ),
      );

      $args = array(
         'labels'           => $labels,
         'tag'              => 'builder_map_item',
         'icon'             => 'location-alt',
         'builder_role'     => 'child',
         'content_type'     => 'editor',
         'label_attribute'  => 'address',
         'disable_advanced' => true,
      );

      $args['attributes']['address'] = array(
         'type'       => 'string',
         'title'      => __( 'Address', 'themefyre_builder' ),
         'desc'       => __( 'Please enter a complete and valid address.', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['popup_visibility'] = array(
         'type'    => 'within',
         'title'   => __( 'Popup Visibility', 'themefyre_builder' ),
         'default' => 'hidden',
         'options' => array(
            'hidden' => __( 'Always hidden', 'themefyre_builder' ),
            'load'   => __( 'Visible on map load', 'themefyre_builder' ),
            'click'  => __( 'Visible after marker click', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['popup_max_width'] = array(
         'type'        => 'string',
         'title'       => __( 'Popup Max Width', 'themefyre_builder' ),
         'desc'        => __( 'Enter a numeric value only <strong>in pixels</strong>. <strong>The default is 300</strong>.', 'themefyre_builder' ),
         'placeholder' => '300',
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               $(document).on('change', '#builder_map_item-popup_visibility', function(event) {
                  if ( 'hidden' === $(this).val() ) {
                     themefyreBuilder.disableControl( $('#attribute-builder_map_item-popup_max_width'), event );
                  }
                  else {
                     themefyreBuilder.enableControl( $('#attribute-builder_map_item-popup_max_width'), event );
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      if ( empty($atts['address']) ) {
         return;
      }
      global $builder_map_items;
      $atts['content'] = $content;
      $builder_map_items[] = $atts;
   }

}

/**
 * Map Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Map_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Map_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular' => __( 'Map', 'themefyre_builder' ),
         'plural'   => __( 'Maps', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_map',
         'icon'            => 'location-alt',
         'builder_role'    => 'content',
         'content_type'    => 'builder_map_item',
         'default_content' => '[builder_map_item address="New York, NY"][/builder_map_item]',
      );

      $zoom_level_options = array();
      for ($i=1; $i<22; $i++) {
         $zoom_level_options[$i] = $i;
      }

      $args['attributes']['zoom_level'] = array(
         'type'    => 'within',
         'title'   => __( 'Zoom Level', 'themefyre_builder' ),
         'desc'    => __( 'How zoomed in this map should be upon load, higher numbers are more zoomed in.', 'themefyre_builder' ),
         'default' => '15',
         'options' => $zoom_level_options,
      );

      $args['attributes']['zoom_control'] = array(
         'type'    => 'bool',
         'default' => 'true',
         'title'   => __( 'Zoom Control', 'themefyre_builder' ),
         'label'   => __( 'Display the zoom control for this map.', 'themefyre_builder' ),
      );

      $args['attributes']['draggable'] = array(
         'type'    => 'bool',
         'default' => 'true',
         'title'   => __( 'Draggable', 'themefyre_builder' ),
         'label'   => __( 'Enable dragging support for this map.', 'themefyre_builder' ),
      );

      $args['attributes']['height'] = array(
         'type'        => 'string',
         'title'       => __( 'Map Height', 'themefyre_builder' ),
         'desc'        => __( 'The value must include a unit (px,em,etc...).', 'themefyre_builder' ),
         'placeholder' => '300px',
      );

      $args['attributes']['custom_styling'] = array(
         'type'  => 'bool',
         'title' => __( 'Custom Styling', 'themefyre_builder' ),
         'label' => __( 'Enable custom map styling for the map colors.', 'themefyre_builder' ),
      );

      $args['attributes']['hue'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Map Hue', 'themefyre_builder' ),
         'desc'  => __( 'Custom color to be used as the general hue for this map.', 'themefyre_builder' ),
      );

      $args['attributes']['water_color'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Water Color', 'themefyre_builder' ),
         'desc'  => __( 'Custom color to be used as the water color for this map.', 'themefyre_builder' ),
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {
      ?>
         <style>
            .builder_map-module-preview > div {
               margin-bottom: 15px;
            }
            .builder_map-module-preview > div:last-child {
               margin-bottom: 0;
            }
         </style>
      <?php
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_map = function( args, content, $modal, $module ) {
                  var out = '', markerArgs;
                  if ( content && 'object' === typeof content && content.length ) {
                     _.each( content, function( shortcode, index ) {
                        markerArgs = shortcode.attrs.named;
                        if ( 'undefined' !== typeof markerArgs.address && markerArgs.address ) {
                           out += '<div><span class="dashicons dashicons-location"></span> '+markerArgs.address+'</div>';
                        }
                     });
                  }
                  return out;
               };
               $(document).on('change', '#builder_map-custom_styling', function(event) {
                  var $customControls = $('#attribute-builder_map-hue, #attribute-builder_map-water_color');
                  if ( $(this).prop('checked') ) {
                     themefyreBuilder.enableControl( $customControls, event );

                     // Scroll the custom style controls into view
                     if ( undefined !== event.originalEvent ) {
                        var $scrollBox = $customControls.closest('.builder-modal-content');
                        setTimeout( function() {
                           $scrollBox.animate( {
                              scrollTop: $scrollBox.prop('scrollHeight'),
                           }, 250 );
                        }, 255 );
                     }
                  }
                  else {
                     themefyreBuilder.disableControl( $customControls, event );
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      global $builder_map_items;
      $builder_map_items = array();
      do_shortcode( $content );
      $out = '';
      foreach ( $builder_map_items as $marker_args ) {
         if ( $marker_args['address'] ) {
            $out .= '<div><span class="dashicons dashicons-location"></span> '.$marker_args['address'].'</div>';
         }
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      return builder_map_shortcodes_callback( $atts, $content, $tag );
   }

}

/**
 * Full-width Map Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Full_Width_Map_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Full_Width_Map_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular' => __( 'Full Width Map', 'themefyre_builder' ),
         'plural'   => __( 'Full Width Maps', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_full_width_map',
         'icon'            => 'location',
         'builder_role'    => 'full-width',
         'content_type'    => 'builder_map_item',
         'default_content' => '[builder_map_item address="New York, NY"][/builder_map_item]',
      );

      $zoom_level_options = array();
      for ($i=1; $i<22; $i++) {
         $zoom_level_options[$i] = $i;
      }

      $args['attributes']['zoom_level'] = array(
         'type'    => 'within',
         'title'   => __( 'Zoom Level', 'themefyre_builder' ),
         'desc'    => __( 'How zoomed in this map should be upon load, higher numbers are more zoomed in.', 'themefyre_builder' ),
         'default' => '15',
         'options' => $zoom_level_options,
      );

      $args['attributes']['zoom_control'] = array(
         'type'    => 'bool',
         'default' => 'true',
         'title'   => __( 'Zoom Control', 'themefyre_builder' ),
         'label'   => __( 'Display the zoom control for this map.', 'themefyre_builder' ),
      );

      $args['attributes']['draggable'] = array(
         'type'    => 'bool',
         'default' => 'true',
         'title'   => __( 'Draggable', 'themefyre_builder' ),
         'label'   => __( 'Enable dragging support for this map.', 'themefyre_builder' ),
      );

      $args['attributes']['height'] = array(
         'type'        => 'string',
         'title'       => __( 'Map Height', 'themefyre_builder' ),
         'desc'        => __( 'The value must include a unit (px,em,etc...). <strong>To set the height as a percentage of total screen height, use the "vh" unit, for example 100vh = 100% total screen height.</strong>', 'themefyre_builder' ),
         'placeholder' => '375px',
      );

      $args['attributes']['custom_styling'] = array(
         'type'  => 'bool',
         'title' => __( 'Custom Styling', 'themefyre_builder' ),
         'label' => __( 'Enable custom map styling for the map colors.', 'themefyre_builder' ),
      );

      $args['attributes']['hue'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Map Hue', 'themefyre_builder' ),
         'desc'  => __( 'Custom color to be used as the general hue for this map.', 'themefyre_builder' ),
      );

      $args['attributes']['water_color'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Water Color', 'themefyre_builder' ),
         'desc'  => __( 'Custom color to be used as the water color for this map.', 'themefyre_builder' ),
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               $(document).on('change', '#builder_full_width_map-custom_styling', function(event) {
                  var $customControls = $('#attribute-builder_full_width_map-hue, #attribute-builder_full_width_map-water_color');
                  if ( $(this).prop('checked') ) {
                     themefyreBuilder.enableControl( $customControls, event );

                     // Scroll the custom style controls into view
                     if ( undefined !== event.originalEvent ) {
                        var $scrollBox = $customControls.closest('.builder-modal-content');
                        setTimeout( function() {
                           $scrollBox.animate( {
                              scrollTop: $scrollBox.prop('scrollHeight'),
                           }, 250 );
                        }, 255 );
                     }
                  }
                  else {
                     themefyreBuilder.disableControl( $customControls, event );
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      return builder_map_shortcodes_callback( $atts, $content, $tag );
   }

}

/**
 * Callback function for front end display of map shortcodes.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param array $atts Array of provided attributes.
 * @param string $content Any content provided for shortcode. (default: null)
 * @return string
 */
function builder_map_shortcodes_callback( $atts, $content = null, $tag = '' ) {
   global $builder_map_items;
   $builder_map_items = array();
   do_shortcode( $content );

   // Make sure at least one marker has been added
   if ( empty( $builder_map_items ) ) {
      return '';
   }

   extract( $atts );

   // Load the Google Maps API
   wp_enqueue_script('builder-gmaps-api');

   // Make sure a value has been set for the height
   if ( ! trim($height) ) {
      $height = 'builder_map' === $tag ? '300px' : '375px';
   }

   // Create the inline map styles
   if ( ! $custom_styling ) {
      $hue = $water_color = '';
   }

   $classes = builder_compile_html_class(str_replace('_', '-', $tag), 'builder-google-map hide-if-no-js', $class);
   $out  = '<div id="'.$id.'" class="'.$classes.'"'.$inline_attributes.'>';

   foreach ($builder_map_items as $item) {
      $max_width = ! empty( $item['popup_max_width'] ) && is_numeric($item['popup_max_width']) ? $item['popup_max_width'] : '300';
      $out .= '<div class="builder-google-map-marker" data-address="'.$item['address'].'" data-visibility="'.$item['popup_visibility'].'" data-max-width="'.$max_width.'">';
      $out .= '<div class="builder-google-map-marker-content builder-tmce-content">'.apply_filters('the_content', $item['content']).'</div>';
      $out .= '</div>';
   }

   $out .= '<div id="'.$id.'-viewport" class="builder-google-map-viewport" style="height:'.$height.';" data-hue="'.$hue.'" data-water-color="'.$water_color.'" data-zoom-control="'.$zoom_control.'" data-zoom-level="'.$zoom_level.'" data-draggable="'.$draggable.'"></div>';
   $out .= '</div>';
   return $out;
}