<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_testimonial_group` and `builder_testimonial_group_item` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_testimonial_shortcodes() {
  builder_add_shortcode('Builder_Testimonial_Group_Shortcode', 'builder_testimonial_group');
  builder_add_shortcode('Builder_Testimonial_Group_Item_Shortcode', 'builder_testimonial_group_item');
}
add_action('init', 'builder_add_testimonial_shortcodes');

/**
 * Testimonial Group Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Testimonial_Group_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Testimonial_Group_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      for ( $i=1; $i<4; $i++ ) {
         $carousel_column_options[$i] = $i;
      }
      for ( $i=2; $i<4; $i++ ) {
         $masonry_column_options[$i] = $i;
      }

      $labels = array(
         'singular' => __( 'Testimonial Group', 'themefyre_builder' ),
         'plural'   => __( 'Testimonial Groups', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_testimonial_group',
         'icon'            => 'format-quote',
         'tmce'            => true,
         'builder_role'    => 'content',
         'content_type'    => 'builder_testimonial_group_item',
         'default_content' => '[builder_testimonial_group_item author="Jane Doe" employer="Google" employer_url="http://google.com/"]Testimonial one text.[/builder_testimonial_group_item]'
                            . '[builder_testimonial_group_item author="John Doe" employer="yahoo" employer_url="http://yahoo.com/"]Testimonial two text.[/builder_testimonial_group_item]',
      );

      $args['attributes']['inverse'] = array(
         'type'  => 'bool',
         'title' => __( 'Inverse Style', 'themefyre_builder' ),
         'label' => __( 'Optimize module to be displayed on a dark background.', 'themefyre_builder' ),
      );

      $args['attributes']['style'] = array(
         'type'    => 'within',
         'title'   => __( 'Style', 'themefyre_builder' ),
         'default' => 'column',
         'options' => array(
            'column'   => __( 'Single column', 'themefyre_builder' ),
            'masonry'  => __( 'Masonry', 'themefyre_builder' ),
            'carousel' => __( 'Carousel', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['masonry_columns'] = array(
         'type'    => 'within',
         'title'   => __( 'Columns', 'themefyre_builder' ),
         'default' => '2',
         'options' => $masonry_column_options,
      );

      $args['attributes']['entrance'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance', 'themefyre_builder' ),
         'desc'    => __( 'Animated entrance will be applied to each testimonial consecutively.', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->animated_entrance_options,
      );

      $args['attributes']['carousel_columns'] = array(
         'type'    => 'within',
         'title'   => __( 'Columns', 'themefyre_builder' ),
         'default' => '1',
         'options' => $carousel_column_options,
      );

      $args['attributes']['carousel_scroll_number'] = array(
         'type'        => 'string',
         'title'       => __( 'Testimonials to Scroll', 'themefyre_builder' ),
         'desc'        => __( 'The number of images to scroll per slide change. By default this will be equivalent to the number of columns selected. Enter a numeric value only, the value entered here can not exceed the number of columns selected.', 'themefyre_builder' ),
         'placeholder' => __( '(same as number of columns)', 'themefyre_builder' ),
      );

      $args['attributes']['carousel_pager'] = array(
         'type'    => 'bool',
         'title'   => __( 'Pager Navigation', 'themefyre_builder' ),
         'label'   => __( 'Enable the carousel pager control', 'themefyre_builder' ),
         'default' => 'true',
      );

      $args['attributes']['carousel_auto'] = array(
         'type'  => 'bool',
         'title' => __( 'Automatically Change Slides', 'themefyre_builder' ),
         'label' => __( 'Automatically change slides at an interval you set.', 'themefyre_builder' ),
      );

      $args['attributes']['carousel_hover_pause'] = array(
         'type'    => 'bool',
         'title'   => __( 'Pause On Hover', 'themefyre_builder' ),
         'label'   => __( 'Pause the slider while it is moused over.', 'themefyre_builder' ),
         'default' => 'true',
      );

      $args['attributes']['carousel_interval'] = array(
         'type'        => 'string',
         'title'       => __( 'Slide Change Interval', 'themefyre_builder' ),
         'desc'        => __( 'The amount of time between each automatic slide change. Enter a <strong>numeric</strong> value only in <strong>milliseconds</strong>. 1000 milliseconds = 1 second.', 'themefyre_builder' ),
         'placeholder' => '4000',
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {
      ?>
         <style>
            .builder_testimonial_group-module-preview > div {
               margin-bottom: 15px;
            }
            .builder_testimonial_group-module-preview > div:last-child {
               margin-bottom: 0;
            }
            .builder_testimonial_group-module-preview > div > .testimonial {
               padding: 15px;
               border: 1px solid #666;
               position: relative;
            }
            .builder-module[data-role="content"] .builder_testimonial_group-module-preview > div > p.meta {
               padding-left: 16px !important;
            }
            .builder_testimonial_group-module-preview > div > .meta,
            .builder_testimonial_group-module-preview > div > .meta > * {
               height: 30px;
               line-height: 30px;
            }
            .builder_testimonial_group-module-preview > div > .meta > * {
               float: left;
               display: block;
            }
            .builder_testimonial_group-module-preview > div > .meta > .image {
               width: 30px;
               border-radius: 30px;
               background-size: cover;
               background-position: center center;
               margin-right: 10px;
            }
            .builder_testimonial_group-module-preview > div > .meta > strong:before {
               content: "/";
               margin: 0 5px;
            }
            .builder_testimonial_group-module-preview > div > .testimonial.has-arrow {
               margin-bottom: 15px;
            }
            .builder_testimonial_group-module-preview > div > .testimonial.has-arrow:after,
            .builder_testimonial_group-module-preview > div > .testimonial.has-arrow:before {
               top: 100%;
               left: 30px;
               border: solid transparent;
               content: " ";
               height: 0;
               width: 0;
               position: absolute;
               pointer-events: none;
            }

            .builder_testimonial_group-module-preview > div > .testimonial.has-arrow:after {
               border-color: rgba(85, 85, 85, 0);
               border-top-color: #444;
               border-width: 10px;
               margin-left: -10px;
            }
            .builder_testimonial_group-module-preview > div > .testimonial.has-arrow:before {
               border-color: rgba(102, 102, 102, 0);
               border-top-color: #666;
               border-width: 11px;
               margin-left: -11px;
            }
         </style>
      <?php
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_testimonial_group = function( args, content, $modal, $module ) {
                  var out = '';
                  $('.module-preview', $modal).each( function() {
                     out += '<div>'+$(this).html()+'</div>';
                  });
                  return out;
               };
               $(document).on('change', '#builder_testimonial_group-style', function(event) {
                  var value = $(this).val(),
                      $entranceControl = $('#attribute-builder_testimonial_group-entrance'),
                      $masonryControls = $('#attribute-builder_testimonial_group-masonry_columns'),
                      $carouselControls = $('#attribute-builder_testimonial_group-carousel_columns, #attribute-builder_testimonial_group-carousel_scroll_number, #attribute-builder_testimonial_group-carousel_pager, #attribute-builder_testimonial_group-carousel_auto'),
                      $autoControls = $('#attribute-builder_testimonial_group-carousel_hover_pause, #attribute-builder_testimonial_group-carousel_interval');
                  if ( 'masonry' === value ) {
                     themefyreBuilder.enableControl( $masonryControls, event );
                     themefyreBuilder.enableControl( $entranceControl, event );
                     themefyreBuilder.disableControl( $carouselControls, event );
                  }
                  else if ( 'carousel' === value ) {
                     themefyreBuilder.enableControl( $carouselControls, event );
                     themefyreBuilder.disableControl( $masonryControls, event );
                     themefyreBuilder.disableControl( $entranceControl, event );
                  }
                  else {
                     themefyreBuilder.disableControl( $carouselControls, event );
                     themefyreBuilder.disableControl( $masonryControls, event );
                     themefyreBuilder.enableControl( $entranceControl, event );
                  }
                  if ( 'carousel' === value && $('#builder_testimonial_group-carousel_auto').prop('checked') ) {
                     themefyreBuilder.enableControl( $autoControls, event );
                  }
                  else {
                     themefyreBuilder.disableControl( $autoControls, event );
                  }
               });
               $(document).on('change', '#builder_testimonial_group-carousel_auto', function(event) {
                  var $autoControls = $('#attribute-builder_testimonial_group-carousel_hover_pause, #attribute-builder_testimonial_group-carousel_interval');
                  if ( $(this).prop('checked') ) {
                     themefyreBuilder.enableControl( $autoControls, event );

                     // Scroll the custom style controls into view
                     if ( undefined !== event.originalEvent ) {
                        var $scrollBox = $(this).closest('.builder-modal-content');
                        setTimeout( function() {
                           $scrollBox.animate( {
                              scrollTop: $scrollBox.prop('scrollHeight'),
                           }, 250 );
                        }, 255 );
                     }
                  }
                  else {
                     themefyreBuilder.disableControl( $autoControls, event );
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      global $builder_testimonial_group_items;
      $builder_testimonial_group_items = array();
      do_shortcode( $content );
      $out = '';
      foreach ( $builder_testimonial_group_items as $item ) {
         $has_arrow_class = $item['author'] ? ' has-arrow' : '';
         $out .= '<div>';
         if ( $item['content'] ) {
            $out .= '<div class="testimonial'.$has_arrow_class.'">'.wpautop( $item['content'] ).'</div>';
         }
         if ( $item['author'] ) {
            $out .= '<p class="meta">';
            if ( $item_img_url = builder_get_attachment_src( $item['attachment_id'], 'medium' ) ) {
               $out .= '<span class="image" style="background-image:url('.$item_img_url.');"></span>';
            }
            $out .= '<em>'.$item['author'].'</em>';
            if ( $item['employer'] ) {
               $out .= '<strong>'.$item['employer'].'</strong>';
            }
            $out .= '</p>';
         }
         $out .= '</div>';
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_testimonial_group_items;
      $builder_testimonial_group_items = array();
      do_shortcode( $content );
      if ( empty( $builder_testimonial_group_items ) ) {
         return '';
      }
      extract( $atts );

      // Animated entrance data
      $entrance_delay = 0;
      $entrance_delay_data = '';
      $group_entrance_data = 'none' !== $entrance && 'carousel' !== $style ? ' data-entrance-trigger="'.$entrance.'"' : '';
      $testimonial_entrance_data = $group_entrance_data ? ' data-entrance="chained"' : '';

      // Masonry mode specific classes
      $masonry_class = 'masonry' === $style ? 'builder-grid-'.$masonry_columns.' spacing-2 builder-masonry' : '';

      // Carousel mode specific classes
      $carousel_class = 'carousel' === $style ? 'builder-carousel' : '';

      // Carousel mode specific attributes
      $carousel_data = '';
      if ( 'carousel' === $style ) {
         $carousel_scroll_number = intval( $carousel_scroll_number );
         $carousel_scroll_number = $carousel_scroll_number && $carousel_scroll_number < $carousel_columns ? $carousel_scroll_number : $carousel_columns;
         $carousel_data = ' data-carousel-columns="'.$carousel_columns.'" data-carousel-pager="'.$carousel_pager.'" data-carousel-scroll-number="'.$carousel_scroll_number.'"';
         if ( builder_get_bool( $carousel_auto ) ) {
            $interval = $carousel_interval ? intval( $carousel_interval ) : 4000;
            $carousel_data .= ' data-interval="'.$interval.'" data-hoverpause="'.$carousel_hover_pause.'"';
         }
      }

      $classes = builder_compile_html_class('builder-testimonial-group builder-testimonial-group-'.$style, $masonry_class, $carousel_class, builder_get_bool( $inverse ) ? 'inverse' : '', $class);
      $out = '<div class="'.$classes.'" id="'.$id.'"'.$group_entrance_data.$carousel_data.$inline_attributes.'>';

      foreach ( $builder_testimonial_group_items as $item ) {
         $item_has_meta = ! empty($item['attachment_id']) || ! empty($item['author']) || ! empty($item['employer']);
         $item_img_url = builder_get_attachment_src( $item['attachment_id'], 'medium' );
         if ( $testimonial_entrance_data ) {
            $entrance_delay_data = ' data-entrance-delay="'.$entrance_delay.'"';
            $entrance_delay+=250;
         }
         $item_classes = builder_compile_html_class('builder-testimonial', $item_has_meta ? 'has-meta' : '', $item_img_url ? 'has-image' : '', 'carousel' === $style ? 'builder-carousel-item' : '', $item['class']);
         $out .= '<div class="'.$item_classes.'" id="'.$item['id'].'"'.$item['inline_attributes'].$testimonial_entrance_data.$entrance_delay_data.'>';
         $out .= '<div class="builder-testimonial-wrap">';
         $out .= '<div class="builder-testimonial-content">'.apply_filters('the_content', $item['content']).'</div>';
         if ( $item_has_meta ) {
            $out .= '<div class="builder-testimonial-meta">';
            if ( $item_img_url  ) {
               $out .= '<div class="builder-testimonial-image builder-bg-scale" style="background-image:url('.$item_img_url.');"></div>';
            }
            if ( $item['author'] ) {
               $out .= '<span class="builder-testimonial-author">'.$item['author'].'</span>';
            }
            if ( $item['author'] && $item['employer'] ) {
               $out .= '<span class="builder-testimonial-meta-separator"></span>';
            }
            if ( $item['employer'] ) {
               $tag = $item['employer_url'] ? 'a' : 'span';
               $employer_url = $item['employer_url'] ? ' href="'.esc_url($item['employer_url']).'"' : '';
               if ( builder_get_bool( $item['employer_url_new_window'] ) ) {
                  $employer_url .= ' target="_blank"';
               }
               $out .= '<'.$tag.' class="builder-testimonial-employer"'.$employer_url.'>'.$item['employer'].'</'.$tag.'>';
            }
            $out .= '</div>';
         }
         $out .= '</div>';
         $out .= '</div>';
      }
      $out .= '</div>';

      return $out;
   }

}

/**
 * Testimonial Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Testimonial_Group_Item_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Testimonial_Group_Item_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular' => __( 'Testimonial', 'themefyre_builder' ),
         'plural'   => __( 'Testimonials', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_testimonial_group_item',
         'builder_role'    => 'child',
         'content_type'    => 'editor',
         'label_attribute' => 'author',
      );

      $args['attributes']['attachment_id'] = array(
         'type'  => 'image',
         'title' => __( 'Author Image', 'themefyre_builder' ),
      );

      $args['attributes']['author'] = array(
         'type'       => 'string',
         'title'      => __( 'Author Name', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['employer'] = array(
         'type'       => 'string',
         'title'      => __( 'Author Employer', 'themefyre_builder' ),
         'desc'       => __( 'The company the testimonial author works for.', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['employer_url'] = array(
         'type'        => 'string',
         'title'       => __( 'Author Employer URL', 'themefyre_builder' ),
         'placeholder' => 'http://...',
      );

      $args['attributes']['employer_url_new_window'] = array(
         'type'  => 'bool',
         'title' => __( 'Open Author Employer URL in New Window', 'themefyre_builder' ),
         'label' => __( 'Open the link to the Employer\'s URL in a new window/tab.', 'themefyre_builder' ),
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {
      ?>
         <style>
            .builder_testimonial_group_item-module-preview {
               font-style: italic;
            }
            .builder_testimonial_group_item-module-preview > .testimonial {
               padding: 15px;
               border: 1px solid #ddd;
               position: relative;
            }
            .builder-module[data-role="child"] .builder_testimonial_group_item-module-preview > p.meta {
               padding-left: 16px !important;
            }
            .builder_testimonial_group_item-module-preview > .meta,
            .builder_testimonial_group_item-module-preview > .meta > * {
               height: 30px;
               line-height: 30px;
            }
            .builder_testimonial_group_item-module-preview > .meta > * {
               float: left;
               display: block;
            }
            .builder_testimonial_group_item-module-preview > .meta > .image {
               width: 30px;
               border-radius: 30px;
               background-size: cover;
               background-position: center center;
               margin-right: 10px;
            }
            .builder_testimonial_group_item-module-preview > .meta > strong:before {
               content: "/";
               margin: 0 5px;
            }
            .builder_testimonial_group_item-module-preview > .testimonial.has-arrow {
               margin-bottom: 15px;
            }
            .builder_testimonial_group_item-module-preview > .testimonial.has-arrow:after,
            .builder_testimonial_group_item-module-preview > .testimonial.has-arrow:before {
               top: 100%;
               left: 30px;
               border: solid transparent;
               content: " ";
               height: 0;
               width: 0;
               position: absolute;
               pointer-events: none;
            }

            .builder_testimonial_group_item-module-preview > .testimonial.has-arrow:after {
               border-color: rgba(85, 85, 85, 0);
               border-top-color: #f9f9f9;
               border-width: 10px;
               margin-left: -10px;
            }
            .builder_testimonial_group_item-module-preview > .testimonial.has-arrow:before {
               border-color: rgba(102, 102, 102, 0);
               border-top-color: #ddd;
               border-width: 11px;
               margin-left: -11px;
            }
         </style>
      <?php
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_testimonial_group_item = function( args, content, $modal, $module ) {
                  var out = '',
                      hasArrowClass = 'undefined' !== typeof args.author && args.author ? ' has-arrow' : '',
                      $previewImage = $('.builder-preview-image[data-key="builder_testimonial_group_item-attachment_id"] img', $modal);
                  if ( content ) {
                     out += '<div class="testimonial'+hasArrowClass+'">'+window.switchEditors.wpautop( content )+'</div>';
                  }
                  if ( 'undefined' !== typeof args.author && args.author ) {
                     out += '<p class="meta">';
                     if ( $previewImage.length ) {
                        out += '<span class="image" style="background-image:url('+$previewImage.attr('src')+');"></span>';
                     }
                     out += '<em>'+args.author+'</em>';
                     if ( 'undefined' !== typeof args.employer && args.employer ) {
                        out += '<strong>'+args.employer+'</strong>';
                     }
                     out += '</p>';
                  }
                  return out;
               };
               $(document).on('change keyup', '#builder_testimonial_group_item-employer_url', function(event) {
                  if ( '' !== $(this).val() ) {
                     themefyreBuilder.enableControl( $('#attribute-builder_testimonial_group_item-employer_url_new_window'), event );

                     // Scroll the custom style controls into view
                     if ( undefined !== event.originalEvent ) {
                        var $scrollBox = $(this).closest('.builder-modal-content');
                        setTimeout( function() {
                           $scrollBox.animate( {
                              scrollTop: $scrollBox.prop('scrollHeight'),
                           }, 250 );
                        }, 255 );
                     }
                  }
                  else {
                     themefyreBuilder.disableControl( $('#attribute-builder_testimonial_group_item-employer_url_new_window'), event );
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      $out = '';
      $has_arrow_class = $author ? ' has-arrow' : '';
      if ( $content ) {
         $out .= '<div class="testimonial'.$has_arrow_class.'">'.wpautop( $content ).'</div>';
      }
      if ( $author ) {
         $out .= '<p class="meta">';
         if ( $item_img_url = builder_get_attachment_src( $attachment_id, 'medium' ) ) {
            $out .= '<span class="image" style="background-image:url('.$item_img_url.');"></span>';
         }
         $out .= '<em>'.$author.'</em>';
         if ( $employer ) {
            $out .= '<strong>'.$employer.'</strong>';
         }
         $out .= '</p>';
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_testimonial_group_items;
      $atts['content'] = $content;
      $builder_testimonial_group_items[] = $atts;
   }

}