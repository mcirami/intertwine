<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_icon_box` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_icon_box_shortcode() {
  builder_add_shortcode('Builder_Icon_Box_Shortcode', 'builder_icon_box');
}
add_action('init', 'builder_add_icon_box_shortcode');

/**
 * Icon Box Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Icon_Box_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Icon_Box_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      $entrance_delay_options = array('none' => __('(no animated entrance delay)', 'themefyre_builder') );
      for ($i=250;$i<=5000;$i+=250) {
         $entrance_delay_options[$i] = $i.'ms';
      }

      $labels = array(
         'singular' => __( 'Icon Box', 'themefyre_builder' ),
         'plural'   => __( 'Icon Boxes', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_icon_box',
         'icon'            => 'info',
         'tmce'            => true,
         'builder_role'    => 'content',
         'support_link'    => true,
         'label_attribute' => 'title',
         'content_type'    => 'editor',
      );

      $args['attributes']['title'] = array(
         'type'       => 'string',
         'title'      => __( 'Title', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['icon'] = array(
         'type'  => 'icon',
         'title' => __( 'Icon', 'themefyre_builder' ),
      );

      $args['attributes']['icon_location'] = array(
         'type'    => 'within',
         'title'   => __( 'Icon Location', 'themefyre_builder' ),
         'default' => 'above',
         'options' => array(
            'above'    => __( 'Above the title', 'themefyre_builder' ),
            'inline'   => __( 'Inline with the title', 'themefyre_builder' ),
            'adjacent' => __( 'Adjacent to the icon box', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['inverse'] = array(
         'type'  => 'bool',
         'title' => __( 'Inverse Style', 'themefyre_builder' ),
         'label' => __( 'Optimize module to be displayed on a dark background.', 'themefyre_builder' ),
      );

      $args['attributes']['icon_color'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Icon Color', 'themefyre_builder' ),
         'desc'  => __( 'Specify a custom color to be used for the icon, leave this blank to use the default color.', 'themefyre_builder' ),
      );

      $args['attributes']['entrance'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->animated_entrance_options,
      );

      $args['attributes']['entrance_delay'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance Delay', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $entrance_delay_options,
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {
      ?>
         <style>
            .builder_icon_box-module-preview {
               text-align: center;
            }
            .builder_icon_box-module-preview > .icon-box-icon {
               font-size: 35px;
               color: #eee;
            }
         </style>
      <?php
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_icon_box = function( args, content, $modal, $module ) {
                  var out = '';
                  if ( 'undefined' !== typeof args.icon && args.icon ) {
                     out += '<span class="icon-box-icon '+args.icon+'"></span>';
                  }
                  if ( 'undefined' !== typeof args.title && args.title ) {
                     out += '<h3>'+args.title+'</h3>';
                  }
                  if ( content ) {
                     out += '<div class="icon-box-content">'+window.switchEditors.wpautop(content)+'</div>';
                  }
                  return out;
               };
               $(document).on('change', '#builder_icon_box-entrance', function(event) {
                  if ( 'none' === $(this).val() ) {
                     themefyreBuilder.disableControl( $('#attribute-builder_icon_box-entrance_delay'), event );
                  }
                  else {
                     themefyreBuilder.enableControl( $('#attribute-builder_icon_box-entrance_delay'), event );

                     // Scroll the entrance delay control into view
                     if ( undefined !== event.originalEvent ) {
                        var $scrollBox = $(this).closest('.builder-modal-content');
                        setTimeout( function() {
                           $scrollBox.animate( {
                              scrollTop: $scrollBox.prop('scrollHeight'),
                           }, 250 );
                        }, 255 );
                     }
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      $out = '';
      if ( $icon ) {
         $out .= '<span class="icon-box-icon '.$icon.'"></span>';
      }
      if ( $title ) {
         $out .= '<h3>'.$title.'</h3>';
      }
      if ( $content ) {
         $out .= '<div class="icon-box-content">'.wpautop( $content ).'</div>';
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      extract( $atts );

      // Generate the icon HTML, whenever possible
      $icon = $icon ? builder_get_icon_html($icon, array( 'class' => 'builder-icon-box-icon' ) ) : '';

      // If there is no icon, do not display it anywhere
      if ( ! $icon ) {
         $icon_location = 'none';
      }

      // Set up the inline icon CSS when applicable
      $icon_color = $icon && $icon_color ? ' style="background-color:'.$icon_color.';color:'.$icon_color.';"' : '';

      // If the icon has been placed `inline` we prepend it to the title
      if ( 'inline' == $icon_location ) {
         if ( $icon_color ) {
            $icon = '<span class="builder-icon-box-icon-container"'.$icon_color.'>'.$icon.'</span>';
         }
         $title = $icon.$title;
      }

      // Set up the link data, when applicable
      $link_data = builder_get_link_inline_html($atts);
      $superlink_class = $link_data ? 'builder-superlink' : '';

      // Animated entrance inline data
      $entrance_data = 'none' !== $entrance ? ' data-entrance="'.$entrance.'"' : '';
      if ( $entrance_data && 'none' !== $entrance_delay ) {
         $entrance_data .= ' data-entrance-delay="'.$entrance_delay.'"';
      }

      // Compile the list of classes
      $classes = builder_compile_html_class('builder-icon-box', 'icon-location-'.$icon_location, $icon_color ? 'icon-custom-color' : '', builder_get_bool( $inverse ) ? 'inverse' : '', $superlink_class, $class);

      $out = '<article class="'.$classes.'" id="'.$id.'"'.$entrance_data.$inline_attributes.'>';
      if ( in_array( $icon_location, array('above', 'adjacent') ) ) {
         $out .= '<div class="builder-icon-box-icon-container"'.$icon_color.'>'.$icon.'</div>';
      }
      if ( 'adjacent' == $icon_location ) {
         $out .= '<div class="builder-icon-box-adjacent-container">';
      }
      $out .= '<h3 class="builder-icon-box-title">'.$title.'</h3>';
      $out .= '<div class="builder-icon-box-content">';
      $out .= '<div class="builder-tmce-content">'.apply_filters('the_content', $content).'</div>';
      if ( $link_data ) {
         $out .= '<p class="builder-icon-box-link hide-if-js"><a'.$link_data.'>'.$title.' &#8594;</a></p>';
      }
      $out .= '</div>';
      if ( 'adjacent' == $icon_location ) {
         $out .= '</div>';
      }
      $out .= '</article>';

      return $out;
   }

}