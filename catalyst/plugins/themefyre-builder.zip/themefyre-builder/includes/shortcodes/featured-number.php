<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_featured_number` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_featured_number_shortcode() {
  builder_add_shortcode('Builder_Featured_Number_Shortcode', 'builder_featured_number');
}
add_action('init', 'builder_add_featured_number_shortcode');

/**
 * Featured Number Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Featured_Number_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Featured_Number_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      $entrance_delay_options = array('none' => __('(no animated entrance delay)', 'themefyre_builder') );
      for ($i=250;$i<=5000;$i+=250) {
         $entrance_delay_options[$i] = $i.'ms';
      }

      $labels = array(
         'singular' => __( 'Featured Number', 'themefyre_builder' ),
         'plural'   => __( 'Featured Numbers', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_featured_number',
         'icon'            => 'dashboard',
         'tmce'            => true,
         'builder_role'    => 'content',
         'support_link'    => true,
         'label_attribute' => 'number',
      );

      $args['attributes']['number'] = array(
         'type'       => 'html_string',
         'title'      => __( 'Number', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['title'] = array(
         'type'       => 'html_string',
         'title'      => __( 'Title', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['color'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Color', 'themefyre_builder' ),
         'desc'  => __( 'This color will be applied to the number, and the title.', 'themefyre_builder' ),
      );

      $args['attributes']['entrance'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->animated_entrance_options,
      );

      $args['attributes']['entrance_delay'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance Delay', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $entrance_delay_options,
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {
      ?>
         <style>
            .builder_featured_number-module-preview {
               text-align: center;
            }
         </style>
      <?php
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_featured_number = function( args, content, $modal, $module ) {
                  var out = '';
                  if ( 'undefined' !== typeof args.number && args.number ) {
                     out += '<h3>'+args.number+'</h3>';
                  }
                  if ( 'undefined' !== typeof args.title && args.title ) {
                     out += '<p>'+args.title+'</p>';
                  }
                  return out;
               };
               $(document).on('change', '#builder_featured_number-entrance', function(event) {
                  if ( 'none' === $(this).val() ) {
                     themefyreBuilder.disableControl( $('#attribute-builder_featured_number-entrance_delay'), event );
                  }
                  else {
                     themefyreBuilder.enableControl( $('#attribute-builder_featured_number-entrance_delay'), event );

                     // Scroll the entrance delay control into view
                     if ( undefined !== event.originalEvent ) {
                        var $scrollBox = $(this).closest('.builder-modal-content');
                        setTimeout( function() {
                           $scrollBox.animate( {
                              scrollTop: $scrollBox.prop('scrollHeight'),
                           }, 250 );
                        }, 255 );
                     }
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      $out = '';
      if ( $number ) {
         $out .= '<h3>'.$number.'</h3>';
      }
      if ( $title ) {
         $out .= '<p>'.$title.'</p>';
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      extract( $atts );

      // Make sure a number was supplied
      if ( ! $number ) {
         return '';
      }

      // Set up the link data, when applicable
      $link_data = builder_get_link_inline_html($atts);
      $superlink_class = $link_data ? 'builder-superlink' : '';

      // Animated entrance inline data
      $entrance_data = 'none' !== $entrance ? ' data-entrance="'.$entrance.'"' : '';
      if ( $entrance_data && 'none' !== $entrance_delay ) {
         $entrance_data .= ' data-entrance-delay="'.$entrance_delay.'"';
      }

      // Set up the inline icon CSS when applicable
      $color = $color ? ' style="background-color:'.$color.';color:'.$color.';"' : '';

      // Compile the list of classes
      $classes = builder_compile_html_class('builder-featured-number', $superlink_class, $color ? 'custom-color' : '', $class);

      $out = '<div class="'.$classes.'" id="'.$id.'"'.$entrance_data.$color.$inline_attributes.'>';
      $out .= '<h3 class="builder-featured-number-number">'.$number.'</h3>';
      if ( $title ) {
         $out .= '<p class="builder-featured-number-title">'.$title.'</p>';
      }
      if ( $link_data ) {
         $link_text = $title ? $title : __( 'Learn More', 'themefyre_builder' );
         $out .= '<p class="builder-featured-number-link hide-if-js"><a'.$link_data.'>'.$link_text.' &#8594;</a></p>';
      }
      $out .= '</div>';

      return $out;
   }

}