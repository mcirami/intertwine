<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_header` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_header_shortcode() {
  builder_add_shortcode('Builder_Header_Shortcode', 'builder_header');
}
add_action('init', 'builder_add_header_shortcode');

/**
 * Header Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Header_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Header_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      $entrance_delay_options = array('none' => __('(no animated entrance delay)', 'themefyre_builder') );
      for ($i=250;$i<=5000;$i+=250) {
         $entrance_delay_options[$i] = $i.'ms';
      }

      for ( $i=1; $i<7; $i++ ) {
         $tag_options['h'.$i] = 'h'.$i;
      }

      $size_options['default'] = __('(default font size)', 'themefyre_builder');
      for ( $i=10; $i<151; $i++ ) {
         $size_options[$i.'px'] = $i.'px';
      }

      $labels = array(
         'singular' => __( 'Header',  'themefyre_builder' ),
         'plural'   => __( 'Headers', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_header',
         'icon'            => 'editor-textcolor',
         'tmce'            => true,
         'builder_role'    => 'content',
         'support_link'    => true,
         'label_attribute' => 'text',
      );

      $args['attribute_tabs']['advanced'] = array(
         'title' => __( 'Additional Controls', 'themefyre_builder' ),
         'ids'   => array( 'text_shadow', 'opacity', 'line_height', 'margin_top', 'margin_bottom' ),
      );

      $args['attributes']['text'] = array(
         'type'       => 'html_string',
         'title'      => __( 'Title', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['tag'] = array(
         'type'    => 'within',
         'title'   => __( 'HTML Tag', 'themefyre_builder' ),
         'default' => 'h1',
         'options' => $tag_options,
         'desc'    => __( 'This is mostly for SEO purposes and allows you to maintain the order of headers within your page.', 'themefyre_builder' ),
      );

      $args['attributes']['style'] = array(
         'type'    => 'within',
         'title'   => __( 'Predefined Styles', 'themefyre_builder' ),
         'default' => 'none',
         'options' => builder_get_available_text_styles(),
         'desc'    => __( 'Optionally select a predefined style set, you can still override the styles using the controls below.', 'themefyre_builder' ),
      );

      $args['attributes']['font'] = array(
         'type'  => 'font',
         'title' => __( 'Font Family', 'themefyre_builder' ),
      );

      $args['attributes']['font_size'] = array(
         'type'    => 'within',
         'title'   => __( 'Font Size', 'themefyre_builder' ),
         'default' => 'default',
         'options' => $size_options,
      );

      $args['attributes']['halign'] = array(
         'type'    => 'within',
         'title'   => __( 'Horizontal Alignment', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->halign_options,
      );

      $args['attributes']['color'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Color', 'themefyre_builder' ),
         'desc'  => __( 'Leave this blank to use the default color.', 'themefyre_builder' ),
      );

      $args['attributes']['entrance'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->animated_entrance_options,
      );

      $args['attributes']['entrance_delay'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance Delay', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $entrance_delay_options,
      );

      $args['attributes']['text_shadow'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Text Shadow', 'themefyre_builder' ),
         'desc'  => __( 'Select a color to serve as a text shadow for this header, leave this blank to have no applied text shadow.', 'themefyre_builder' ),
      );

      $args['attributes']['opacity'] = array(
         'type'    => 'within',
         'title'   => __( 'Opacity', 'themefyre_builder' ),
         'default' => '1',
         'options' => array(
            '1'   => __( '100% - Fully visible', 'themefyre_builder' ),
            '0.9' => '90%',
            '0.8' => '80%',
            '0.7' => '70%',
            '0.6' => '60%',
            '0.5' => '50%',
            '0.4' => '40%',
            '0.3' => '30%',
            '0.2' => '20%',
            '0.1' => '10%',
            '0'   => __( '0% - Not visible', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['line_height'] = array(
         'type'        => 'string',
         'title'       => __( 'Line Height', 'themefyre_builder' ),
         'placeholder' => __( '(default line height)', 'themefyre_builder' ),
      );

      $args['attributes']['margin_top'] = array(
         'type'        => 'string',
         'title'       => __( 'Top Margin', 'themefyre_builder' ),
         'desc'        => __( 'The value must include a unit (px,em,etc...).<br /><strong>You can enter "0" to have no margin.</strong>', 'themefyre_builder' ),
         'placeholder' => __( '(default top margin)', 'themefyre_builder' ),
      );

      $args['attributes']['margin_bottom'] = array(
         'type'        => 'string',
         'title'       => __( 'Bottom Margin', 'themefyre_builder' ),
         'desc'        => __( 'The value must include a unit (px,em,etc...).<br /><strong>You can enter "0" to have no margin.</strong>', 'themefyre_builder' ),
         'placeholder' => __( '(default bottom margin)', 'themefyre_builder' ),
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_header = function( args, content, $modal, $module ) {
                  var out = '';
                  if ( 'undefined' !== typeof args.text && args.text ) {
                     var tag = 'undefined' !== typeof args.tag && args.tag ? args.tag : 'h3';
                     out += '<'+tag+'>'+args.text+'</'+tag+'>';
                  }
                  if ( out && 'undefined' !== typeof args.halign && 'none' !== args.halign ) {
                     out = '<div style="text-align:'+args.halign+';">'+out+'</div>';
                  }
                  return out;
               };
               $(document).on('change', '#builder_header-entrance', function(event) {
                  if ( 'none' === $(this).val() ) {
                     themefyreBuilder.disableControl( $('#attribute-builder_header-entrance_delay'), event );
                  }
                  else {
                     themefyreBuilder.enableControl( $('#attribute-builder_header-entrance_delay'), event );

                     // Scroll the entrance delay control into view
                     if ( undefined !== event.originalEvent ) {
                        var $scrollBox = $(this).closest('.builder-modal-content');
                        setTimeout( function() {
                           $scrollBox.animate( {
                              scrollTop: $scrollBox.prop('scrollHeight'),
                           }, 250 );
                        }, 255 );
                     }
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      $out = '';
      if ( $text ) {
         $tag = $tag ? $tag : 'h3';
         $out .= '<'.$tag.'>'.$text.'</'.$tag.'>';
      }
      if ( $out && 'none' !== $halign ) {
         $out = '<div style="text-align:'.$halign.';">'.$out.'</div>';
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      extract( $atts );

      $inline_css = $font;

      if ( $color ) {
         $inline_css .= 'color:'.$color.';';
      }

      if ( 'none' !== $halign ) {
         $inline_css .= 'text-align:'.$halign.';';
      }

      if ( 'default' !== $font_size ) {
         $inline_css .= 'font-size:'.$font_size.';';
      }

      if ( '1' !== $opacity ) {
         $inline_css .= 'opacity:'.$opacity.';';
      }

      if ( '' !== $text_shadow ) {
         $inline_css .= 'text-shadow:'.builder_hex_to_rgba($text_shadow, 0.75).' 0px 1px 2px;';
      }

      if ( '' !== $line_height ) {
         $inline_css .= 'line-height:'.$line_height.';';
      }

      if ( '' !== $margin_top ) {
         $inline_css .= 'margin-top:'.$margin_top.';';
      }

      if ( '' !== $margin_bottom ) {
         $inline_css .= 'margin-bottom:'.$margin_bottom.';';
      }

      // Wrap our inlice CSS in the `style` attribute
      if ( $inline_css ) {
         $inline_css = ' style="'.$inline_css.'"';
      }

      // Animated entrance inline data
      $entrance_data = 'none' !== $entrance ? ' data-entrance="'.$entrance.'"' : '';
      if ( $entrance_data && 'none' !== $entrance_delay ) {
         $entrance_data .= ' data-entrance-delay="'.$entrance_delay.'"';
      }

      // If a link has been applied to the header
      if ( $link_inline_html = builder_get_link_inline_html( $atts ) ) {
         $text = '<a'.$link_inline_html.'>'.$text.'</a>';
      }

      $classes = builder_compile_html_class('builder-header', 'none' !== $style ? $style : '', $class);
      return '<'.$tag.' class="'.$classes.'" id="'.$id.'"'.$inline_css.$entrance_data.$inline_attributes.'>'.$text.'</'.$tag.'>';
   }

}