<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_timeline_item` and `builder_timeline` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_timeline_shortcodes() {
  builder_add_shortcode('Builder_Timeline_Item_Shortcode', 'builder_timeline_item');
  builder_add_shortcode('Builder_Timeline_Shortcode', 'builder_timeline');
}
add_action('init', 'builder_add_timeline_shortcodes');

/**
 * Timeline Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Timeline_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Timeline_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      $labels = array(
         'singular' => __( 'Timeline', 'themefyre_builder' ),
         'plural'   => __( 'Timelines', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_timeline',
         'icon'            => 'clock',
         'builder_role'    => 'content',
         'content_type'    => 'builder_timeline_item',
         'default_content' => '[builder_timeline_item title="'.__('Event One Title', 'themefyre_builder').'" year="1876" date="November 16"]Event one content.[/builder_timeline_item]'
                            . '[builder_timeline_item title="'.__('Event Two Title', 'themefyre_builder').'" year="1989" date="February 22"]Event two content.[/builder_timeline_item]',
      );

      $args['attributes']['alignment'] = array(
         'type'    => 'within',
         'title'   => __( 'Dates Location', 'themefyre_builder' ),
         'default' => 'alternate',
         'options' => array(
            'alternate'  => __( 'Alternate for each event', 'themefyre_builder' ),
            'left'       => __( 'Left of content', 'themefyre_builder' ),
            'right'      => __( 'Right of content', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['animated'] = array(
         'type'    => 'bool',
         'title'   => __( 'Animated Entrance', 'themefyre_builder' ),
         'label'   => __( 'Events will animate in consecutively when they are scrolled to.', 'themefyre_builder' ),
         'default' => 'true',
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {
      ?>
         <style>
            .builder_timeline-module-preview > div {
               border: 1px solid #666;
               margin-bottom: 15px;
               padding: 15px;
            }
            .builder_timeline-module-preview > div:last-child {
               margin-bottom: 0;
            }
            .builder_timeline-module-preview > div strong + em:before {
               content: " - ";
            }
         </style>
      <?php
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_timeline = function( args, content, $modal, $module ) {
                  var out = '', item_out = '', itemArgs;
                  if ( content && 'object' === typeof content && content.length ) {
                     _.each( content, function( item, index ) {
                        itemArgs = item.attrs.named;
                        item_out = '';
                        if ( 'undefined' !== typeof itemArgs.title && itemArgs.title ) {
                           item_out += '<h3>'+itemArgs.title+'</h3>';
                        }
                        if ( 'undefined' !== typeof itemArgs.year && itemArgs.year ) {
                           item_out += '<strong>'+itemArgs.year+'</strong>';
                        }
                        if ( 'undefined' !== typeof itemArgs.date && itemArgs.date ) {
                           item_out += '<em>'+itemArgs.date+'</em>';
                        }
                        if ( item_out ) {
                           out += '<div>'+item_out+'</div>';
                        }
                     });
                  }
                  return out;
               };
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      global $builder_timeline_items;
      $builder_timeline_items = array();
      do_shortcode( $content );
      $out = '';
      foreach ( $builder_timeline_items as $item ) {
         $item_out = '';
         if ( $item['title'] ) {
            $item_out .= '<h3>'.$item['title'].'</h3>';
         }
         if ( $item['year'] ) {
            $item_out .= '<strong>'.$item['year'].'</strong>';
         }
         if ( $item['date'] ) {
            $item_out .= '<em>'.$item['date'].'</em>';
         }
         if ( $item_out ) {
            $out .= '<div>'.$item_out.'</div>';
         }
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_timeline_items;
      $builder_timeline_items = array();
      do_shortcode( $content );
      if ( empty( $builder_timeline_items ) ) {
         return '';
      }
      extract( $atts );

      // Get the bool values of our settings
      $animated = builder_get_bool( $animated );

      $entrance_delay = 0;
      $entrance_delay_data = '';
      $group_entrance_data = $animated ? ' data-entrance-trigger="animate-event"' : '';
      $event_entrance_data = $group_entrance_data ? ' data-entrance="chained"' : '';

      $classes = builder_compile_html_class('builder-timeline', 'alignment-'.$alignment, $animated ? 'is-animated' : '', $class);
      $out = '<div class="'.$classes.'" id="'.$id.'"'.$group_entrance_data.$inline_attributes.'>';

      foreach ( $builder_timeline_items as $item ) {
         if ( $event_entrance_data ) {
            $entrance_delay_data = ' data-entrance-delay="'.$entrance_delay.'"';
            $entrance_delay+=250;
         }
         $event_classes = builder_compile_html_class('builder-timeline-event', $item['class']);
         $out .= '<section class="'.$event_classes.'" id="'.$item['id'].'"'.$event_entrance_data.$entrance_delay_data.$item['inline_attributes'].'>';

         $out .= '<div class="builder-timeline-event-meta">';
         $out .= '<div class="builder-timeline-event-meta-inside">';
         if ( trim( $item['year'] ) ) {
            $out .= '<h3 class="builder-timeline-event-year">'.$item['year'].'</h3>';
         }
         if ( trim( $item['date'] ) ) {
            $out .= '<p class="builder-timeline-event-date">'.$item['date'].'</p>';
         }
         $out .= '</div>';
         $out .= '</div>';

         $out .= '<div class="builder-timeline-event-description">';
         if ( $img_url = builder_get_attachment_src( $item['image'] ) ) {
            $out .= '<div class="builder-timeline-event-image">';
            $out .= '<img src="'.$img_url.'" alt="'.builder_get_attachment_alt( $item['image'] ).'" />';
            $out .= '</div>';
         }
         if ( trim( $item['title'] ) ) {
            $out .= '<h3 class="builder-timeline-event-title">'.$item['title'].'</h3>';
         }
         if ( trim( $item['content'] ) ) {
            $out .= '<div class="builder-timeline-event-content builder-tmce-content">'.apply_filters('the_content', $item['content']).'</div>';
         }
         $out .= '</div>';

         $out .= '</section>';
      }

      $out .= '</div>';

      return $out;
   }

}

/**
 * Timeline Event Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Timeline_Item_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Timeline_Item_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular' => __( 'Event', 'themefyre_builder' ),
         'plural'   => __( 'Events', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_timeline_item',
         'builder_role'    => 'child',
         'content_type'    => 'editor',
         'label_attribute' => 'title',
      );

      $args['attributes']['title'] = array(
         'type'       => 'html_string',
         'title'      => __( 'Title', 'themefyre_builder' ),
         'desc'       => __( 'You can leave this blank to have the event be displayed without a title.', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['date'] = array(
         'type'  => 'string',
         'title' => __( 'Month & Day, or Complete Date', 'themefyre_builder' ),
         'desc'  => __( 'Will be displayed below the year', 'themefyre_builder' ),
      );

      $args['attributes']['year'] = array(
         'type'  => 'string',
         'title' => __( 'Year', 'themefyre_builder' ),
         'desc'  => __( 'Should be a complete 4 digit number', 'themefyre_builder' ),
      );

      $args['attributes']['image'] = array(
         'type'  => 'image',
         'title' => __( 'Image', 'themefyre_builder' ),
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {
      ?>
         <style>
            .builder_timeline_item-module-preview > .event-date strong + em:before {
               content: " - ";
            }
            .builder_timeline_item-module-preview > .event-image {
               width: 100px !important;
            }
         </style>
      <?php
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_timeline_item = function( args, content, $modal, $module ) {
                  var out = '';
                  var $previewImage = $('.builder-preview-image[data-key="builder_timeline_item-image"] img', $modal);
                  if ( 'undefined' !== typeof args.title && args.title ) {
                     out += '<h3>'+args.title+'</h3>';
                  }
                  if ( ( 'undefined' !== typeof args.date && args.date ) || ( 'undefined' !== typeof args.year && args.year ) ) {
                     out += '<p class="event-date">';
                     if ( 'undefined' !== typeof args.year && args.year ) {
                        out += '<strong>'+args.year+'</strong>';
                     }
                     if ( 'undefined' !== typeof args.date && args.date ) {
                        out += '<em>'+args.date+'</em>';
                     }
                     out += '</p>';
                  }
                  if ( content ) {
                     out += window.switchEditors.wpautop( content );
                  }
                  else if ( $previewImage.length ) {
                     out += '<img class="event-image" src="'+$previewImage.attr('src')+'" />';
                  }
                  return out;
               };
            })(jQuery);
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      $out = '';
      if ( $title ) {
         $out .= '<h3>'.$title.'</h3>';
      }
      if ( $date || $year ) {
         $out .= '<p class="event-date">';
         if ( $year ) {
            $out .= '<strong>'.$year.'</strong>';
         }
         if ( $date ) {
            $out .= '<em>'.$date.'</em>';
         }
         $out .= '</p>';
      }
      if ( $content ) {
         $out .= $content;
      }
      else if ( $img_url = builder_get_attachment_src( $atts['image'], 'medium' ) ) {
         $out .= '<img class="event-image" src="'.$img_url.'" />';
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_timeline_items;
      $atts['content'] = $content;
      $builder_timeline_items[] = $atts;
   }

}