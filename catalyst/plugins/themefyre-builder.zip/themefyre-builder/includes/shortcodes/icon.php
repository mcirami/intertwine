<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_icon` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_icon_shortcode() {
  builder_add_shortcode('Builder_Icon_Shortcode', 'builder_icon');
}
add_action('init', 'builder_add_icon_shortcode');

/**
 * Icon Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Icon_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Icon_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      $border_width_options = array(
         'none' => __( '0px, no border', 'themefyre_builder' ),
      );
      for ($i=1;$i<=20;$i++) {
         $border_width_options[$i.'px'] = $i.'px';
      }

      $entrance_delay_options = array('none' => __('(no animated entrance delay)', 'themefyre_builder') );
      for ($i=250;$i<=5000;$i+=250) {
         $entrance_delay_options[$i] = $i.'ms';
      }

      $size_options = array();
      for ( $i=10; $i<301; $i++ ) {
         $size_options[$i] = $i.'px';
      }

      $labels = array(
         'singular' => __( 'Icon',  'themefyre_builder' ),
         'plural'   => __( 'Icons', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_icon',
         'icon'            => 'smiley',
         'tmce'            => true,
         'builder_role'    => 'content',
         'support_link'    => true,
         'label_attribute' => 'icon',
      );

      $args['attributes']['icon'] = array(
         'type'  => 'icon',
         'title' => __( 'Icon', 'themefyre_builder' ),
      );

      $args['attributes']['icon_size'] = array(
         'type'    => 'within',
         'title'   => __( 'Icon Size', 'themefyre_builder' ),
         'default' => '30',
         'options' => $size_options,
      );

      $args['attributes']['halign'] = array(
         'type'    => 'within',
         'title'   => __( 'Horizontal Alignment', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->halign_options,
      );

      $args['attributes']['color'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Color', 'themefyre_builder' ),
         'desc'  => __( 'Leave this blank to use the default color.', 'themefyre_builder' ),
      );

      $args['attributes']['opacity'] = array(
         'type'    => 'within',
         'title'   => __( 'Opacity', 'themefyre_builder' ),
         'default' => '1',
         'options' => array(
            '1'   => __( '100% - Fully visible', 'themefyre_builder' ),
            '0.9' => '90%',
            '0.8' => '80%',
            '0.7' => '70%',
            '0.6' => '60%',
            '0.5' => '50%',
            '0.4' => '40%',
            '0.3' => '30%',
            '0.2' => '20%',
            '0.1' => '10%',
            '0'   => __( '0% - Not visible', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['line_height'] = array(
         'type'        => 'string',
         'title'       => __( 'Line Height', 'themefyre_builder' ),
         'placeholder' => __( '(default line height)', 'themefyre_builder' ),
      );

      $args['attributes']['margin_top'] = array(
         'type'        => 'string',
         'title'       => __( 'Top Margin', 'themefyre_builder' ),
         'desc'        => __( 'The value must include a unit (px,em,etc...).<br /><strong>You can enter "0" to have no margin.</strong>', 'themefyre_builder' ),
         'placeholder' => __( '(default top margin)', 'themefyre_builder' ),
      );

      $args['attributes']['margin_bottom'] = array(
         'type'        => 'string',
         'title'       => __( 'Bottom Margin', 'themefyre_builder' ),
         'desc'        => __( 'The value must include a unit (px,em,etc...).<br /><strong>You can enter "0" to have no margin.</strong>', 'themefyre_builder' ),
         'placeholder' => __( '(default bottom margin)', 'themefyre_builder' ),
      );

      $args['attributes']['border_width'] = array(
         'type'    => 'within',
         'title'   => __( 'Border Width', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $border_width_options,
      );

      $args['attributes']['border_style'] = array(
         'type'    => 'within',
         'title'   => __( 'Border Style', 'themefyre_builder' ),
         'default' => 'solid',
         'options' => array(
            'solid'  => __( 'Solid', 'themefyre_builder' ),
            'dotted' => __( 'Dotted', 'themefyre_builder' ),
            'dashed' => __( 'Dashed', 'themefyre_builder' ),
            'double' => __( 'Double', 'themefyre_builder' ),
            'groove' => __( 'Groove', 'themefyre_builder' ),
            'ridge'  => __( 'Ridge', 'themefyre_builder' ),
            'inset'  => __( 'Inset', 'themefyre_builder' ),
            'outset' => __( 'Outset', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['border_color'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Border Color', 'themefyre_builder' ),
      );

      $args['attributes']['entrance'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->animated_entrance_options,
      );

      $args['attributes']['entrance_delay'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance Delay', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $entrance_delay_options,
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_icon = function( args, content, $modal, $module ) {
                  var out = '';
                  if ( 'undefined' !== typeof args.icon && args.icon ) {
                     out += '<h3 class="'+args.icon+'"></h3>';
                  }
                  if ( out && 'undefined' !== typeof args.halign && 'none' !== args.halign ) {
                     out = '<div style="text-align:'+args.halign+';">'+out+'</div>';
                  }
                  return out;
               };
               $(document).on('change', '#builder_icon-border_width', function(event) {
                  if ( 'none' !== $(this).val() ) {
                     themefyreBuilder.enableControl( $('#attribute-builder_icon-border_style, #attribute-builder_icon-border_color'), event );
                  }
                  else {
                     themefyreBuilder.disableControl( $('#attribute-builder_icon-border_style, #attribute-builder_icon-border_color'), event );
                  }
               });
               $(document).on('change', '#builder_icon-entrance', function(event) {
                  if ( 'none' === $(this).val() ) {
                     themefyreBuilder.disableControl( $('#attribute-builder_icon-entrance_delay'), event );
                  }
                  else {
                     themefyreBuilder.enableControl( $('#attribute-builder_icon-entrance_delay'), event );

                     // Scroll the entrance delay control into view
                     if ( undefined !== event.originalEvent ) {
                        var $scrollBox = $(this).closest('.builder-modal-content');
                        setTimeout( function() {
                           $scrollBox.animate( {
                              scrollTop: $scrollBox.prop('scrollHeight'),
                           }, 250 );
                        }, 255 );
                     }
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      $out = '';
      if ( $icon ) {
         $out .= '<h3 class="'.$icon.'"></h3>';
      }
      if ( $out && 'none' !== $halign ) {
         $out = '<div style="text-align:'.$halign.';">'.$out.'</div>';
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      extract( $atts );

      $inline_css = 'font-size:'.$icon_size.'px;width:'.($icon_size*1.75).'px;height:'.($icon_size*1.75).'px;line-height:'.($icon_size*1.5).'px;border-radius:'.($icon_size*1.75).'px;';

      if ( $color ) {
         $inline_css .= 'color:'.$color.';';
      }

      if ( '1' !== $opacity ) {
         $inline_css .= 'opacity:'.$opacity.';';
      }

      if ( '' !== $line_height ) {
         $inline_css .= 'line-height:'.$line_height.';';
      }

      if ( '' !== $margin_top ) {
         $inline_css .= 'margin-top:'.$margin_top.';';
      }

      if ( '' !== $margin_bottom ) {
         $inline_css .= 'margin-bottom:'.$margin_bottom.';';
      }

      if ( 'none' !== $border_width && $border_color ) {
         $inline_css .= "border:{$border_width} {$border_style} {$border_color};";
      }

      // Animated entrance inline data
      $entrance_data = 'none' !== $entrance ? ' data-entrance="'.$entrance.'"' : '';
      if ( $entrance_data && 'none' !== $entrance_delay ) {
         $entrance_data .= ' data-entrance-delay="'.$entrance_delay.'"';
      }

      // Compile class list
      $classes = builder_compile_html_class('builder-icon-shortode', 'icon-align-'.$halign, $class);

      // If a link has been applied to the icon
      $link_inline_html = builder_get_link_inline_html( $atts );

      $icon_args = array(
         'tag'         => $link_inline_html ? 'a' : 'div',
         'inline_html' => $link_inline_html.' style="'.$inline_css.'"'.$entrance_data.$inline_attributes,
      );

      return '<div class="'.$classes.'" id="'.$id.'">'.builder_get_icon_html( $icon, $icon_args ).'</div>';
   }

}