<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_image` and `builder_full_width_image` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_image_shortcodes() {
  builder_add_shortcode('Builder_Image_Shortcode', 'builder_image');
  builder_add_shortcode('Builder_Full_Width_Image_Shortcode', 'builder_full_width_image');
}
add_action('init', 'builder_add_image_shortcodes');

/**
 * Image Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Image_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Image_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      $entrance_delay_options = array('none' => __('(no animated entrance delay)', 'themefyre_builder') );
      for ($i=250;$i<=5000;$i+=250) {
         $entrance_delay_options[$i] = $i.'ms';
      }

      $labels = array(
         'singular' => __( 'Image', 'themefyre_builder' ),
         'plural'   => __( 'Images', 'themefyre_builder' ),
      );

      $args = array(
         'labels'       => $labels,
         'tag'          => 'builder_image',
         'icon'         => 'format-image',
         'builder_role' => 'content',
         'support_link' => true,
      );

      $args['attributes']['attachment_id'] = array(
         'type'  => 'image',
         'title' => __( 'Image', 'themefyre_builder' ),
      );

      $args['attributes']['size'] = array(
         'type'    => 'within',
         'title'   => __( 'Image Size', 'themefyre_builder' ),
         'desc'    => __( 'WordPress stores multiple sizes of each image, specify which size you would like to display.', 'themefyre_builder' ),
         'default' => 'full',
         'options' => builder_get_available_attachment_sizes(),
      );

      $args['attributes']['show_caption'] = array(
         'type'  => 'bool',
         'title' => __( 'Display Caption', 'themefyre_builder' ),
         'label' => __( 'Display caption below image.', 'themefyre_builder' ),
      );

      $args['attributes']['rounded_corners'] = array(
         'type'  => 'bool',
         'title' => __( 'Rounded Corners', 'themefyre_builder' ),
         'label' => __( 'Display image with slightly rounded corners.', 'themefyre_builder' ),
      );

      $args['attributes']['max_width'] = array(
         'type'  => 'string',
         'title' => __( 'Maximum Width', 'themefyre_builder' ),
         'desc'  => __( 'In addition to specifying which image file to use, you can also control the maximum width the image is displayed as, the value must include a unit (px,em,etc...)', 'themefyre_builder' ),
         'placeholder' => __( '(size of container)', 'themefyre_builder' ),
      );

      $args['attributes']['halign'] = array(
         'type'    => 'within',
         'title'   => __( 'Horizontal Alignment', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->halign_options,
      );

      $args['attributes']['entrance'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->animated_entrance_options,
      );

      $args['attributes']['entrance_delay'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance Delay', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $entrance_delay_options,
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {
      ?>
         <style>
            .builder_image-module-preview {
               text-align: center;
               max-height: none !important;
            }
            .builder_image-module-preview:before {
               display: none !important;
            }
         </style>
      <?php
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_image = function( args, content, $modal, $module ) {
                  var $previewImage = $('.builder-preview-image[data-key="builder_image-attachment_id"] img', $modal);
                  if ( $previewImage.length ) {
                     return '<img src="'+$previewImage.attr('src')+'" />';
                  }
               };
               $(document).on('change', '#builder_image-entrance', function(event) {
                  if ( 'none' === $(this).val() ) {
                     themefyreBuilder.disableControl( $('#attribute-builder_image-entrance_delay'), event );
                  }
                  else {
                     themefyreBuilder.enableControl( $('#attribute-builder_image-entrance_delay'), event );

                     // Scroll the entrance delay control into view
                     if ( undefined !== event.originalEvent ) {
                        var $scrollBox = $(this).closest('.builder-modal-content');
                        setTimeout( function() {
                           $scrollBox.animate( {
                              scrollTop: $scrollBox.prop('scrollHeight'),
                           }, 250 );
                        }, 255 );
                     }
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      if ( $img_url = builder_get_attachment_src( $atts['attachment_id'], 'medium' ) ) {
         return '<img src="'.$img_url.'" />';
      }
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      extract( $atts );

      if ( ! $img_url = builder_get_attachment_src( $attachment_id, $size ) ) {
         return '';
      }

      $classes = builder_compile_html_class('builder-image', 'halign-image-'.$halign, builder_get_bool($rounded_corners) ? 'builder-rounded-corners' : '', $class);
      $link_data = builder_get_link_inline_html($atts);
      $caption = builder_get_attachment_caption($attachment_id);
      $title_attr = $caption ? ' title="'.$caption.'"' : '';

      $inline_css = '';
      if ( $max_width ) {
         $inline_css = ' style="width:100%;max-width:'.$max_width.';"';
      }

      // Animated entrance inline data
      $entrance_data = 'none' !== $entrance ? ' data-entrance="'.$entrance.'"' : '';
      if ( $entrance_data && 'none' !== $entrance_delay ) {
         $entrance_data .= ' data-entrance-delay="'.$entrance_delay.'"';
      }

      $out = '<figure class="'.$classes.'" id="'.$id.'"'.$inline_attributes.'>';
      if ( $link_data ) {
         $out .= '<a'.$link_data.'>';
      }
      $out .= '<img src="'.$img_url.'" alt="'.builder_get_attachment_alt($attachment_id).'"'.$inline_css.$title_attr.$entrance_data.' />';
      if ( $link_data ) {
         $out .= '</a>';
      }
      if ( builder_get_bool($show_caption) ) {
         $caption = builder_get_attachment_caption($attachment_id);
         if ( ! $caption ) $caption = get_the_title($attachment_id);
         $out .= '<figcaption class="builder-image-caption builder-caption">'.$caption.'</figcaption>';
      }
      $out .= '</figure>';

      return $out;
   }

}

/**
 * Full-width Image Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Full_Width_Image_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Full_Width_Image_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      $labels = array(
         'singular' => __( 'Full Width Image', 'themefyre_builder' ),
         'plural'   => __( 'Full Width Images', 'themefyre_builder' ),
      );

      $args = array(
         'labels'       => $labels,
         'tag'          => 'builder_full_width_image',
         'icon'         => 'format-image',
         'builder_role' => 'full-width',
         'support_link' => true,
      );

      $args['attributes']['attachment_id'] = array(
         'type'  => 'image',
         'title' => __( 'Image', 'themefyre_builder' ),
      );

      parent::__construct( $args );
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      extract( $atts );

      if ( ! $img_url = builder_get_attachment_src( $attachment_id ) ) {
         return '';
      }

      $classes = builder_compile_html_class('builder-full-width-image', $class);
      $link_data = builder_get_link_inline_html($atts);

      $out = '<figure class="'.$classes.'" id="'.$id.'"'.$inline_attributes.'>';
      if ( $link_data ) {
         $out .= '<a'.$link_data.'>';
      }
      $out .= '<img src="'.$img_url.'" alt="'.builder_get_attachment_alt($attachment_id).'" />';
      if ( $link_data ) {
         $out .= '</a>';
      }
      $out .= '</figure>';

      return $out;
   }

}