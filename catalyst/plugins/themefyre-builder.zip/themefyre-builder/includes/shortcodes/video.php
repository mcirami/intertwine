<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_video` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_video_shortcode() {
  builder_add_shortcode('Builder_Video_Shortcode', 'builder_video');
}
add_action('init', 'builder_add_video_shortcode');

/**
 * Video Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Video_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Video_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular' => __( 'Video', 'themefyre_builder' ),
         'plural'   => __( 'Videos', 'themefyre_builder' ),
      );

      $args = array(
         'labels'       => $labels,
         'tag'          => 'builder_video',
         'icon'         => 'video-alt',
         'builder_role' => 'content',
      );

      $args['attributes']['caption'] = array(
         'type'       => 'string',
         'title'      => __( 'Caption', 'themefyre_builder' ),
         'desc'       => __( 'Will be displayed immediately below the video.', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['source'] = array(
         'type'    => 'within',
         'title'   => __( 'Video Source', 'themefyre_builder' ),
         'default' => 'embed',
         'options' => array(
            'embed'  => __( '3rd party embed', 'themefyre_builder' ),
            'html'   => __( 'HTML5 video', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['embed'] = array(
         'type'       => 'string',
         'title'      => __( 'Video URL', 'themefyre_builder' ),
         'desc'       => __( 'Paste a complete supported 3rd party video embed URL here.', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['webm'] = array(
         'type'       => 'video',
         'title'      => __( 'WebM URL', 'themefyre_builder' ),
         'desc'       => __( '<strong>WebM</strong> file to use for the video.', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['ogg'] = array(
         'type'       => 'video',
         'title'      => __( 'Ogg URL', 'themefyre_builder' ),
         'desc'       => __( '<strong>Ogg</strong> file to use for the video.', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['mp4'] = array(
         'type'       => 'video',
         'title'      => __( 'MP4 URL', 'themefyre_builder' ),
         'desc'       => __( '<strong>MP4</strong> file to use for the video.', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['auto'] = array(
         'type'  => 'bool',
         'title' => __( 'Autoplay', 'themefyre_builder' ),
         'label' => __( 'The video will play automatically.', 'themefyre_builder' ),
      );

      $args['attributes']['audio'] = array(
         'type'    => 'bool',
         'default' => 'true',
         'title'   => __( 'Audio', 'themefyre_builder' ),
         'label'   => __( 'Enable audio for the video.', 'themefyre_builder' ),
      );

      $args['attributes']['loop'] = array(
         'type'  => 'bool',
         'title' => __( 'Loop', 'themefyre_builder' ),
         'label' => __( 'The video will continually loop.', 'themefyre_builder' ),
      );

      $args['attributes']['controls'] = array(
         'type'    => 'bool',
         'default' => 'true',
         'title'   => __( 'Controls', 'themefyre_builder' ),
         'label'   => __( 'Display video controls.', 'themefyre_builder' ),
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               $(document).on('change', '#builder_video-source', function(event) {
                  var source = $(this).val(),
                      $embedControls = $('#attribute-builder_video-embed'),
                      $htmlControls = $('#attribute-builder_video-webm, #attribute-builder_video-ogg, #attribute-builder_video-mp4, #attribute-builder_video-auto, #attribute-builder_video-audio, #attribute-builder_video-loop, #attribute-builder_video-controls');

                  if ( 'embed' === source ) {
                     themefyreBuilder.disableControl( $htmlControls, event );
                     themefyreBuilder.enableControl( $embedControls, event );
                  }
                  else if ( 'html' === source ) {
                     themefyreBuilder.disableControl( $embedControls, event );
                     themefyreBuilder.enableControl( $htmlControls, event );
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      extract( $atts );

      // First let`s set up the HTML for our video
      $video = '';
      switch ( $source ) {
         case 'embed':
            $video = wp_oembed_get($embed);
            break;
         case 'html':
            $sources_html = '';
            foreach ( array( 'webm', 'ogg', 'mp4') as $file_type ) {
               if ( ! empty( $atts[$file_type] ) ) {
                  $sources_html .= '<source src="'.$atts[$file_type].'" type="video/'.$file_type.'" />';
               }
            }

            // This means we have at least one `valid` source
            if ( $sources_html ) {
               $auto = builder_get_bool( $auto ) ? ' autoplay' : '';
               $audio = ! builder_get_bool( $audio ) ? ' muted' : '';
               $loop = builder_get_bool( $loop ) ? ' loop' : '';
               $controls = builder_get_bool( $controls ) ? ' controls' : '';
               $video = '<video'.$auto.$audio.$loop.$controls.'>'.$sources_html.'</video>';
            }
            break;
      }

      // No video to display, do nothing
      if ( empty( $video ) ) {
         return '';
      }

      // Compile class list
      $classes = builder_compile_html_class('builder-video video-source-'.$source, $class);

      $out  = '<figure class="'.$classes.'" id="'.$id.'"'.$inline_attributes.'>';
      $out .= $video;
      if ( $caption ) {
         $out .= '<figcaption class="builder-video-caption builder-caption">'.$caption.'</figcaption>';
      }
      $out .= '</figure>';
      return $out;
   }

}