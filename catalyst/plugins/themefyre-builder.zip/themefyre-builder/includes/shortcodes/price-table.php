<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_price_table` and `builder_price_table_item` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_price_table_shortcodes() {
  builder_add_shortcode('Builder_Price_Table_Shortcode', 'builder_price_table');
  builder_add_shortcode('Builder_Price_Table_Item_Shortcode', 'builder_price_table_item');
}
add_action('init', 'builder_add_price_table_shortcodes');

/**
 * Price Table Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Price_Table_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Price_Table_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      $entrance_delay_options = array('none' => __('(no animated entrance delay)', 'themefyre_builder') );
      for ($i=250;$i<=5000;$i+=250) {
         $entrance_delay_options[$i] = $i.'ms';
      }

      $labels = array(
         'singular' => __( 'Price Table', 'themefyre_builder' ),
         'plural'   => __( 'Price Tables', 'themefyre_builder' ),
      );

      $args = array(
         'labels'           => $labels,
         'tag'              => 'builder_price_table',
         'icon'             => 'cart',
         'tmce'             => true,
         'builder_role'     => 'content',
         'content_type'     => 'builder_price_table_item',
         'default_content'  => '[builder_price_table_item title="'.__('Feature One', 'themefyre_builder').'"]'
                             . '[builder_price_table_item title="'.__('Feature Two', 'themefyre_builder').'"]',
         'content_first'    => false,
         'support_link'     => true,
         'label_attribute'  => 'title',
      );

      $args['attributes']['title'] = array(
         'type'       => 'string',
         'title'      => __( 'Title', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['description'] = array(
         'type'       => 'html_string',
         'title'      => __( 'Description', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['inverse'] = array(
         'type'  => 'bool',
         'title' => __( 'Inverse Style', 'themefyre_builder' ),
         'label' => __( 'Optimize module to be displayed on a dark background.', 'themefyre_builder' ),
      );

      $args['attributes']['featured'] = array(
         'type'  => 'bool',
         'title' => __( 'Featured', 'themefyre_builder' ),
         'label' => __( 'This price table will be featured and stand out from the others (if any).', 'themefyre_builder' ),
      );

      $args['attributes']['price'] = array(
         'type'  => 'html_string',
         'title' => __( 'Price', 'themefyre_builder' ),
      );

      $args['attributes']['below_price'] = array(
         'type'  => 'html_string',
         'title' => __( 'Below Price', 'themefyre_builder' ),
      );

      $args['attributes']['button_text'] = array(
         'type'        => 'string',
         'title'       => __( 'Button Text', 'themefyre_builder' ),
         'desc'        => __( 'Only applicable when this price table has had a link applied to it.', 'themefyre_builder' ),
         'placeholder' => __( 'Learn More', 'themefyre_builder' ),
         'searchable'  => true,
      );

      $args['attributes']['entrance'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->animated_entrance_options,
      );

      $args['attributes']['entrance_delay'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance Delay', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $entrance_delay_options,
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {
      ?>
         <style>
            .builder_price_table-module-preview {
               text-align: center;
            }
         </style>
      <?php
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_price_table = function( args, content, $modal, $module ) {
                  var out = '';
                  if ( 'undefined' !== typeof args.price && args.price ) {
                     out += '<h3>'+args.price+'</h3>';
                  }
                  if ( 'undefined' !== typeof args.below_price && args.below_price ) {
                     out += '<p>'+args.below_price+'</p>';
                  }
                  return out;
               };
               $(document).on('change', '#builder_price_table-entrance', function(event) {
                  if ( 'none' === $(this).val() ) {
                     themefyreBuilder.disableControl( $('#attribute-builder_price_table-entrance_delay'), event );
                  }
                  else {
                     themefyreBuilder.enableControl( $('#attribute-builder_price_table-entrance_delay'), event );

                     // Scroll the entrance delay control into view
                     if ( undefined !== event.originalEvent ) {
                        var $scrollBox = $(this).closest('.builder-modal-content');
                        setTimeout( function() {
                           $scrollBox.animate( {
                              scrollTop: $scrollBox.prop('scrollHeight'),
                           }, 250 );
                        }, 255 );
                     }
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      $out = '';
      if ( $price ) {
         $out .= '<h3>'.$price.'</h3>';
      }
      if ( $below_price ) {
         $out .= '<p>'.$below_price.'</p>';
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_price_table_items;
      $builder_price_table_items = array();
      do_shortcode( $content );
      extract( $atts );

      // Set up the link data, when applicable
      $link_data = builder_get_link_inline_html($atts);
      $superlink_class = $link_data ? 'builder-superlink' : '';

      // Animated entrance inline data
      $entrance_data = 'none' !== $entrance ? ' data-entrance="'.$entrance.'"' : '';
      if ( $entrance_data && 'none' !== $entrance_delay ) {
         $entrance_data .= ' data-entrance-delay="'.$entrance_delay.'"';
      }

      // Compile the list of classes
      $classes = builder_compile_html_class('builder-price-table', $superlink_class, builder_get_bool( $featured ) ? 'featured' : '', builder_get_bool( $inverse ) ? 'inverse' : '', $class);

      $out  = '<section class="'.$classes.'" id="'.$id.'"'.$entrance_data.$inline_attributes.'>';

      $out .= '<header class="builder-price-table-header">';
      if ( $title ) {
         $out .= '<h3 class="builder-price-table-title">'.$title.'</h3>';
      }
      if ( $description ) {
         $out .= '<p class="builder-price-table-description">'.$description.'</p>';
      }
      $out .= '</header>';

      $out .= '<div class="builder-price-table-features">';
      if ( ! empty( $builder_price_table_items ) ) {
         $out .= '<ul class="builder-price-table-features-list">';
         foreach ( $builder_price_table_items as $item ) {
            if ( ! $item['icon'] && ! $item['title'] ) {
               continue;
            }
            $icon = $item['icon'] ? builder_get_icon_html($item['icon'], array( 'class' => 'builder-price-table-feature-icon' ) ) : '';
            $out .= '<li class="builder-price-table-feature">'.$icon.$item['title'].'</li>';
         }
         $out .= '</ul>';
      }
      $out .= '</div>';

      $out .= '<footer class="builder-price-table-footer">';
      if ( $price || $below_price ) {
         $out .= '<div class="builder-price-table-price">';
         if ( $price ) {
            $out .= '<span class="builder-price-table-price-content">'.$price.'</span>';
         }
         if ( $below_price ) {
            $out .= '<span class="builder-price-table-price-below">'.$below_price.'</span>';
         }
         $out .= '</div>';
      }
      if ( $link_data ) {
         $button_text = $button_text ? $button_text : __( 'Lean More', 'themefyre_builder' );
         $out .= '<div class="builder-price-table-button-wrap">';
         $out .= '<a class="builder-price-table-button"'.$link_data.'><span class="builder-price-table-button-text">'.$button_text.'</span></a>';
         $out .= '</div>';
      }
      $out .= '</footer>';

      $out .= '</section>';
      return $out;
   }

}

/**
 * Price Table Feature Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Price_Table_Item_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Price_Table_Item_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular' => __( 'Feature', 'themefyre_builder' ),
         'plural'   => __( 'Features', 'themefyre_builder' ),
      );

      $args = array(
         'labels'           => $labels,
         'tag'              => 'builder_price_table_item',
         'builder_role'     => 'child',
         'label_attribute'  => 'title',
         'disable_advanced' => true,
      );

      $args['attributes']['title'] = array(
         'type'       => 'html_string',
         'title'      => __( 'Title', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['icon'] = array(
         'type'  => 'icon',
         'title' => __( 'Icon', 'themefyre_builder' ),
         'desc'  => __( 'Optionally select an icon to be prepended to the title.', 'themefyre_builder' ),
      );

      parent::__construct( $args );
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_price_table_items;
      $atts['content'] = $content;
      $builder_price_table_items[] = $atts;
   }

}