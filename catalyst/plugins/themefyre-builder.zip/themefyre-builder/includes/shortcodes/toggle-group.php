<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_toggle_group` and `builder_toggle_group_item` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_toggle_group_shortcodes() {
  builder_add_shortcode('Builder_Toggle_Group_Shortcode', 'builder_toggle_group');
  builder_add_shortcode('Builder_Toggle_Group_Item_Shortcode', 'builder_toggle_group_item');
}
add_action('init', 'builder_add_toggle_group_shortcodes');

/**
 * Toggle Group Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Toggle_Group_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Toggle_Group_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      $labels = array(
         'singular' => __( 'Toggle Group', 'themefyre_builder' ),
         'plural'   => __( 'Toggle Groups', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_toggle_group',
         'icon'            => 'editor-justify',
         'tmce'            => true,
         'builder_role'    => 'content',
         'content_type'    => 'builder_toggle_group_item',
         'default_content' => '[builder_toggle_group_item title="'.__('Toggle One Title', 'themefyre_builder').'"]Toggle one content.[/builder_toggle_group_item]'
                            . '[builder_toggle_group_item title="'.__('Toggle Two Title', 'themefyre_builder').'"]Toggle two content.[/builder_toggle_group_item]',
      );

      $args['attributes']['first_open'] = array(
         'type'  => 'bool',
         'title' => __( 'First Open', 'themefyre_builder' ),
         'label' => __( 'Force the first toggle to be open on page load.', 'themefyre_builder' ),
      );

      $args['attributes']['allow_multi'] = array(
         'type'  => 'bool',
         'title' => __( 'Allow Multi', 'themefyre_builder' ),
         'label' => __( 'Allow multiple toggles to be open at one time.', 'themefyre_builder' ),
      );

      $args['attributes']['entrance'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance', 'themefyre_builder' ),
         'desc'    => __( 'Animated entrance will be applied to each toggle consecutively.', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->animated_entrance_options,
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {
      ?>
         <style>
            .builder_toggle_group-module-preview > div {
               border: 1px solid #666;
               margin-bottom: 15px;
               padding: 15px;
            }
            .builder_toggle_group-module-preview > div:last-child {
               margin-bottom: 0;
            }
         </style>
      <?php
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_toggle_group = function( args, content, $modal, $module ) {
                  var out = '', itemArgs;
                  if ( content && 'object' === typeof content && content.length ) {
                     _.each( content, function( item, index ) {
                        itemArgs = item.attrs.named;
                        if ( 'undefined' !== typeof itemArgs.title && itemArgs.title ) {
                           out += '<div>'+itemArgs.title+'</div>';
                        }
                     });
                  }
                  return out;
               };
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      global $builder_toggle_group_items;
      $builder_toggle_group_items = array();
      do_shortcode( $content );
      $out = '';
      foreach ( $builder_toggle_group_items as $item ) {
         if ( $item['title'] ) {
            $out .= '<div>'.$item['title'].'</div>';
         }
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_toggle_group_items;
      $builder_toggle_group_items = array();
      do_shortcode( $content );
      if ( empty( $builder_toggle_group_items ) ) {
         return '';
      }
      extract( $atts );

      $filters = array();
      foreach ( $builder_toggle_group_items as $toggle ) {
         if ( $toggle['tags'] ) {
            $filters = array_merge( $filters, explode( ',', $toggle['tags'] ) );
         }
      }

      $entrance_delay = 0;
      $entrance_delay_data = '';
      $group_entrance_data = 'none' !== $entrance ? ' data-entrance-trigger="'.$entrance.'"' : '';
      $toggle_entrance_data = $group_entrance_data ? ' data-entrance="chained"' : '';

      $classes = builder_compile_html_class('builder-toggle-group', $class);
      $out = '<div class="'.$classes.'" id="'.$id.'" data-first-open="'.$first_open.'" data-allow-multi="'.$allow_multi.'"'.$group_entrance_data.$inline_attributes.'>';

      if ( ! empty( $filters ) ) {
         $out .= '<nav class="builder-toggle-group-filter-list builder-filter-list hide-if-no-js">';
         $out .= '<h3 class="screen-reader-text">'.__('Toggle Group Navigation', 'themefyre_builder').'</h3>';
         $out .= '<ul>';
         $out .= '<li class="is-active"><a data-filter="*">'.__('All', 'themefyre_builder').'</a></li>';
         foreach ( array_unique( $filters ) as $filter ) {
            $out .= '<li><a data-filter="'.$filter.'">'.$filter.'</a></li>';
         }
         $out .= '</ul>';
         $out .= '</nav>';
      }

      foreach ( $builder_toggle_group_items as $item ) {
         if ( $toggle_entrance_data ) {
            $entrance_delay_data = ' data-entrance-delay="'.$entrance_delay.'"';
            $entrance_delay+=250;
         }
         $item_classes = builder_compile_html_class('builder-toggle', $item['class']);
         $tags = $item['tags'] ? ' data-tags="'.$item['tags'].'"' : '';
         if ( $toggle_entrance_data || $entrance_delay_data ) {
            $out .= '<div class="builder-toggle-animated-entrance-wrap"'.$toggle_entrance_data.$entrance_delay_data.'>';
         }
         $out .= '<section class="'.$item_classes.'" id="'.$item['id'].'"'.$tags.$item['inline_attributes'].'>';
         $out .= '<h3 class="builder-toggle-title builder-toggle-handle">'.$item['title'].'</h3>';
         $out .= '<div class="builder-toggle-content"><div class="builder-tmce-content">'.apply_filters('the_content', $item['content']).'</div></div>';
         $out .= '</section>';
         if ( $toggle_entrance_data || $entrance_delay_data ) {
            $out .= '</div>';
         }
      }

      $out .= '</div>';

      return $out;
   }

}

/**
 * Toggle Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Toggle_Group_Item_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Toggle_Group_Item_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular' => __( 'Toggle', 'themefyre_builder' ),
         'plural'   => __( 'Toggles', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_toggle_group_item',
         'builder_role'    => 'child',
         'content_type'    => 'editor',
         'label_attribute' => 'title',
      );

      $args['attributes']['title'] = array(
         'type'       => 'string',
         'title'      => __( 'Title', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['tags'] = array(
         'type'  => 'comma_list',
         'title' => __( 'Tags', 'themefyre_builder' ),
         'desc'  => __( 'A comma delimited list of tags, if one or more toggles has tags applied to it then the toggle group will be filterable.', 'themefyre_builder' ),
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {
      ?>
         <style>
            .builder_toggle_group_item-module-preview > .toggle-tags > span {
               background: #f0f0f0;
               display: inline-block;
               padding: 0 10px;
               height: 40px;
               line-height: 40px;
               border-radius: 4px;
               margin: 4px;
            }
            .builder_toggle_group_item-module-preview > .toggle-tags > span .dashicons {
               vertical-align: middle;
               margin-top: -3px;
            }
         </style>
      <?php
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_toggle_group_item = function( args, content, $modal, $module ) {
                  var out = '';
                  if ( 'undefined' !== typeof args.title && args.title ) {
                     out += '<h3 class="toggle-title">'+args.title+'</h3>';
                  }
                  out += window.switchEditors.wpautop( content );
                  if ( 'undefined' !== typeof args.tags && args.tags ) {
                     var tags = args.tags.split(',');
                     out += '<div class="toggle-tags">';
                     _.each( tags, function( tag ) {
                        out += '<span><span class="dashicons dashicons-tag"></span> '+tag+'</span>';
                     });
                     out += '</div>';
                  }
                  return out;
               };
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      $out = '';
      if ( $title ) {
         $out .= '<h3 class="toggle-title">'.$title.'</h3>';
      }
      if ( $content ) {
         $out .= wpautop( $content );
      }
      if ( $tags ) {
         $out .= '<div class="toggle-tags">';
         foreach ( explode(',', $tags) as $tag ) {
            $out .= '<span><span class="dashicons dashicons-tag"></span> '.$tag.'</span>';
         }
         $out .= '</div>';
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_toggle_group_items;
      $atts['content'] = $content;
      $builder_toggle_group_items[] = $atts;
   }

}