<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_tab_group_item` and `builder_tab_group` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_tab_group_shortcodes() {
  builder_add_shortcode('Builder_Tab_Group_Item_Shortcode', 'builder_tab_group_item');
  builder_add_shortcode('Builder_Tab_Group_Shortcode', 'builder_tab_group');
}
add_action('init', 'builder_add_tab_group_shortcodes');

/**
 * Tab Group Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Tab_Group_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Tab_Group_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      $entrance_delay_options = array('none' => __('(no animated entrance delay)', 'themefyre_builder') );
      for ($i=250;$i<=5000;$i+=250) {
         $entrance_delay_options[$i] = $i.'ms';
      }

      $labels = array(
         'singular' => __( 'Tab Group', 'themefyre_builder' ),
         'plural'   => __( 'Tab Groups', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_tab_group',
         'icon'            => 'category',
         'tmce'            => true,
         'builder_role'    => 'content',
         'content_type'    => 'builder_tab_group_item',
         'default_content' => '[builder_tab_group_item title="'.__('Tab One Title', 'themefyre_builder').'"]Tab one content.[/builder_tab_group_item]'
                            . '[builder_tab_group_item title="'.__('Tab Two Title', 'themefyre_builder').'"]Tab two content.[/builder_tab_group_item]',
      );

      $args['attributes']['entrance'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->animated_entrance_options,
      );

      $args['attributes']['entrance_delay'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance Delay', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $entrance_delay_options,
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {
      ?>
         <style>
            .builder_tab_group-module-preview > .tabs {
               position: relative;
               z-index: 10;
               overflow: hidden;
               border-left: 1px solid #666;
               margin-bottom: -1px;
               height: 52px;
            }
            .builder_tab_group-module-preview > .tabs strong {
               float: left;
               padding: 0 15px;
               border-top: 1px solid #666;
               border-right: 1px solid #666;
               font-weight: 100;
               height: 50px;
               line-height: 50px;
            }
            .builder_tab_group-module-preview > .tabs strong:first-child {
               border-bottom: 1px solid #444;
            }
            .builder_tab_group-module-preview > .content {
               position: relative;
               z-index: 5;
               padding: 15px;
               border: 1px solid #666;
            }
         </style>
      <?php
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_tab_group = function( args, content, $modal, $module ) {
                  var out = '', itemArgs, icon;
                  if ( content && 'object' === typeof content && content.length ) {
                     _.each( content, function( item ) {
                        itemArgs = item.attrs.named;
                        if ( 'undefined' !== typeof itemArgs.title && itemArgs.title ) {
                           icon = 'undefined' !== typeof itemArgs.icon && itemArgs.icon ? '<span class="'+itemArgs.icon+'"></span> ' : '';
                           out += '<strong>'+icon+itemArgs.title+'</strong>';
                        }
                     });
                     if ( out ) {
                        out = '<div class="tabs">'+out+'</div>';
                        out += '<div class="content">'+window.switchEditors.wpautop( content[0].content )+'</div>';
                     }
                  }
                  return out;
               };
               $(document).on('change', '#builder_tab_group-entrance', function(event) {
                  if ( 'none' === $(this).val() ) {
                     themefyreBuilder.disableControl( $('#attribute-builder_tab_group-entrance_delay'), event );
                  }
                  else {
                     themefyreBuilder.enableControl( $('#attribute-builder_tab_group-entrance_delay'), event );
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      global $builder_tab_group_items;
      $builder_tab_group_items = array();
      do_shortcode( $content );
      $out = '';
      foreach ( $builder_tab_group_items as $item ) {
         if ( $item['title'] ) {
            $icon = $item['icon'] ? '<span class="'.$item['icon'].'"></span> ' : '';
            $out .= '<strong>'.$icon.$item['title'].'</strong>';
         }
      }
      if ( $out ) {
         $out = '<div class="tabs">'.$out.'</div>';
         $out .= '<div class="content">'.wpautop( $builder_tab_group_items[0]['content'] ).'</div>';
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_tab_group_items;
      $builder_tab_group_items = array();
      do_shortcode( $content );
      if ( empty( $builder_tab_group_items ) ) {
         return '';
      }
      extract( $atts );

      $has_icons_class = '';
      foreach ( $builder_tab_group_items as $item ) {
         if ( builder_get_icon_html( $item['icon'] ) ) {
            $has_icons_class = 'has-icons';
            break;
         }
      }

      $classes = builder_compile_html_class('builder-tab-group', $has_icons_class, $class);

      // Animated entrance inline data
      $entrance_data = 'none' !== $entrance ? ' data-entrance="'.$entrance.'"' : '';
      if ( $entrance_data && 'none' !== $entrance_delay ) {
         $entrance_data .= ' data-entrance-delay="'.$entrance_delay.'"';
      }

      $out  = '<div class="'.$classes.'" id="'.$id.'"'.$entrance_data.$inline_attributes.'>';
      $out .= '<nav class="builder-tab-group-tabs">';
      $out .= '<ul>';
      foreach ( $builder_tab_group_items as $item_number => $item ) {
         $active_class = 0 == $item_number ? ' is-active' : '';
         $icon = $item['icon'] ? builder_get_icon_html($item['icon'], array('class' => 'builder-tab-group-tab-icon')) : '';
         $has_icons_class = $icon ? ' has-icon' : '';
         $out .= '<li class="builder-tab-group-tab'.$has_icons_class.$active_class.'"><a>'.$icon.$item['title'].'</a></li>';
      }
      $out .= '</ul>';
      $out .= '</nav>';

      $out .= '<div class="builder-tab-group-panes">';
      foreach ( $builder_tab_group_items as $item_number => $item ) {
         $active_class = 0 == $item_number ? ' is-active' : '';
         $pane_classes = builder_compile_html_class('builder-tab-group-pane', $item['class'], $active_class);
         $icon = $item['icon'] ? builder_get_icon_html($item['icon'], array( 'class' => 'builder-tab-group-pane-icon')) : '';
         $out .= '<section class="'.$pane_classes.'" id="'.$item['id'].'"'.$item['inline_attributes'].'>';
         $out .= '<h3 class="builder-tab-group-pane-title">'.$icon.$item['title'].'</h3>';
         $out .= '<div class="builder-tab-group-pane-content"><div class="builder-tmce-content">'.apply_filters('the_content', $item['content']).'</div></div>';
         $out .= '</section>';
      }
      $out .= '</div>';
      $out .= '</div>';

      return $out;
   }

}

/**
 * Tab Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Tab_Group_Item_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Tab_Group_Item_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular' => __( 'Tab', 'themefyre_builder' ),
         'plural'   => __( 'Tabs', 'themefyre_builder' ),
      );

      $args = array(
         'labels'           => $labels,
         'tag'              => 'builder_tab_group_item',
         'builder_role'     => 'child',
         'content_type'     => 'editor',
         'label_attribute'  => 'title',
      );

      $args['attributes']['title'] = array(
         'type'       => 'string',
         'title'      => __( 'Title', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['icon'] = array(
         'type'  => 'icon',
         'title' => __( 'Icon', 'themefyre_builder' ),
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_tab_group_item = function( args, content, $modal, $module ) {
                  var out = '';
                  if ( 'undefined' !== typeof args.title && args.title ) {
                     var icon = 'undefined' !== typeof args.icon && args.icon ? '<span class="'+args.icon+'"></span> ' : '';
                     out += '<h3 class="tab-title">'+icon+args.title+'</h3>';
                  }
                  out += window.switchEditors.wpautop( content );
                  return out;
               };
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      $out = '';
      if ( $title ) {
         $icon = $icon ? '<span class="'.$icon.'"></span> ' : '';
         $out .= '<h3 class="tab-title">'.$icon.$title.'</h3>';
      }
      if ( $content ) {
         $out .= wpautop( $content );
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_tab_group_items;
      $atts['content'] = $content;
      $builder_tab_group_items[] = $atts;
   }

}