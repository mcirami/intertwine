<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_call_to_action` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_call_to_action_shortcode() {
  builder_add_shortcode('Builder_Call_To_Action_Shortcode', 'builder_call_to_action');
}
add_action('init', 'builder_add_call_to_action_shortcode');

/**
 * Call to Action Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Call_To_Action_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Call_To_Action_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      $entrance_delay_options = array('none' => __('(no animated entrance delay)', 'themefyre_builder') );
      for ($i=250;$i<=5000;$i+=250) {
         $entrance_delay_options[$i] = $i.'ms';
      }

      $labels = array(
         'singular' => __( 'Call to Action', 'themefyre_builder' ),
         'plural'   => __( 'Call to Actions', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_call_to_action',
         'icon'            => 'megaphone',
         'tmce'            => true,
         'builder_role'    => 'content',
         'support_link'    => true,
         'label_attribute' => 'title',
      );

      $args['attributes']['title'] = array(
         'type'       => 'string',
         'title'      => __( 'Title', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['tagline'] = array(
         'type'       => 'html_string',
         'title'      => __( 'Tagline', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['inverse'] = array(
         'type'      => 'bool',
         'title'     => __( 'Inverse Style', 'themefyre_builder' ),
         'label'     => __( 'Optimize module to be displayed on a dark background.', 'themefyre_builder' ),
      );

      $args['attributes']['button_text'] = array(
         'type'        => 'string',
         'title'       => __( 'Button Text', 'themefyre_builder' ),
         'desc'        => __( 'Defaults to <strong>Learn More</strong>', 'themefyre_builder' ),
         'placeholder' => __( 'Learn More', 'themefyre_builder' ),
         'searchable'  => true,
      );

      $args['attributes']['halign'] = array(
         'type'    => 'within',
         'title'   => __( 'Horizontal Alignment', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->halign_options,
      );

      $args['attributes']['entrance'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->animated_entrance_options,
      );

      $args['attributes']['entrance_delay'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance Delay', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $entrance_delay_options,
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_call_to_action = function( args, content, $modal, $module ) {
                  var out = '';
                  if ( 'undefined' !== typeof args.title && args.title ) {
                     out += '<h3>'+args.title+'</h3>';
                  }
                  if ( 'undefined' !== typeof args.tagline && args.tagline ) {
                     out += '<p>'+args.tagline+'</p>';
                  }
                  if ( out && 'undefined' !== typeof args.halign && 'none' !== args.halign ) {
                     out = '<div style="text-align:'+args.halign+';">'+out+'</div>';
                  }
                  return out;
               };
               $(document).on('change', '#builder_call_to_action-entrance', function(event) {
                  if ( 'none' === $(this).val() ) {
                     themefyreBuilder.disableControl( $('#attribute-builder_call_to_action-entrance_delay'), event );
                  }
                  else {
                     themefyreBuilder.enableControl( $('#attribute-builder_call_to_action-entrance_delay'), event );

                     // Scroll the entrance delay control into view
                     if ( undefined !== event.originalEvent ) {
                        var $scrollBox = $(this).closest('.builder-modal-content');
                        setTimeout( function() {
                           $scrollBox.animate( {
                              scrollTop: $scrollBox.prop('scrollHeight'),
                           }, 250 );
                        }, 255 );
                     }
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      $out = '';
      if ( $title ) {
         $out .= '<h3>'.$title.'</h3>';
      }
      if ( $tagline ) {
         $out .= '<p>'.$tagline.'</p>';
      }
      if ( $out && 'none' !== $halign ) {
         $out = '<div style="text-align:'.$halign.';">'.$out.'</div>';
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      extract( $atts );

      $inline_css = 'none' !== $halign ? ' style="text-align:'.$halign.';"' : '';
      $button_text = trim($button_text) ? trim($button_text) : __( 'Learn More', 'themefyre_builder' );
      $link_data = builder_get_link_inline_html($atts);
      $classes = builder_compile_html_class('builder-call-to-action', $link_data ? 'builder-superlink' : '', builder_get_bool( $inverse ) ? 'inverse' : '', $class );

      // Animated entrance inline data
      $entrance_data = 'none' !== $entrance ? ' data-entrance="'.$entrance.'"' : '';
      if ( $entrance_data && 'none' !== $entrance_delay ) {
         $entrance_data .= ' data-entrance-delay="'.$entrance_delay.'"';
      }

      $out = '<div class="'.$classes.'" id="'.$id.'"'.$inline_css.$entrance_data.$inline_attributes.'>';

      if ( $title ) {
         $out .= '<h2>'.$title.'</h2>';
      }

      if ( $tagline ) {
         $out .= '<p>'.$tagline.'</p>';
      }

      if ( $link_data ) {
         $button_text = '<span class="builder-button-text">'.$button_text.'</span>';
         $out .= '<a class="button"'.$link_data.'>'.$button_text.'</a>';
      }

      $out .= '</div>';

      return $out;
   }

}