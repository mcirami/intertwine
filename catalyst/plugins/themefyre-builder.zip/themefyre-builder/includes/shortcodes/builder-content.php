<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Callback for the `builder_content` shortcode.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param array $atts Array of provided attributes.
 * @param string $content Any content provided for shortcode. (default: null)
 * @return string
 */
function builder_content_callback( $atts, $content = null ) {

   // If no post ID has been set, return nothing.
   if ( ! isset( $atts['post_id'] ) ) {
      return '';
   }

   // Grab the correct meta keys depending on whether or not we`re in preview mode
   $content_meta_key = is_preview() ? '_themefyre_builder_temporary_value' : '_themefyre_builder_value';
   $css_meta_key = is_preview() ? '_themefyre_builder_temporary_css' : '_themefyre_builder_css';

   // Grab any values created by the page builder for the specified post ID
   $content = do_shortcode( get_post_meta( $atts['post_id'], $content_meta_key, true ) );
   $css = get_post_meta( $atts['post_id'], $css_meta_key, true );

   // Begin with an ampty string
   $out = '';

   // Ouput any custom CSS
   if ( $css ) {
      $out .= '<style>'.$css.'</style>';
   }

   // Append the actual content
   $out .= '<div class="builder-container">'.$content.'</div>';

   return $out;
}
add_shortcode( 'builder_content', 'builder_content_callback' );