<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_audio` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_audio_shortcode() {
  builder_add_shortcode('Builder_Audio_Shortcode', 'builder_audio');
}
add_action('init', 'builder_add_audio_shortcode');

/**
 * Audio Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Audio_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Audio_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular' => __( 'Audio', 'themefyre_builder' ),
         'plural'   => __( 'Audios', 'themefyre_builder' ),
      );

      $args = array(
         'labels'       => $labels,
         'tag'          => 'builder_audio',
         'icon'         => 'format-audio',
         'builder_role' => 'content',
      );

      $args['attributes']['caption'] = array(
         'type'       => 'html_string',
         'title'      => __( 'Caption', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['source'] = array(
         'type'    => 'within',
         'title'   => __( 'Audio Source', 'themefyre_builder' ),
         'default' => 'embed',
         'options' => array(
            'embed'  => __( '3rd party embed', 'themefyre_builder' ),
            'html'   => __( 'HTML5 audio', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['embed'] = array(
         'type'       => 'string',
         'title'      => __( 'Audio URL', 'themefyre_builder' ),
         'desc'       => __( 'Paste a complete supported 3rd party audio embed URL here.', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['mp3'] = array(
         'type'       => 'audio',
         'title'      => __( 'MP3 URL', 'themefyre_builder' ),
         'desc'       => __( '<strong>MP3</strong> file to use for the audio player.', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['wav'] = array(
         'type'       => 'audio',
         'title'      => __( 'Wav URL', 'themefyre_builder' ),
         'desc'       => __( '<strong>Wav</strong> file to use for the audio player.', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['ogg'] = array(
         'type'       => 'audio',
         'title'      => __( 'OGG URL', 'themefyre_builder' ),
         'desc'       => __( '<strong>OGG</strong> file to use for the audio player.', 'themefyre_builder' ),
         'searchable' => true,
      );

      $args['attributes']['auto'] = array(
         'type'  => 'bool',
         'title' => __( 'Autoplay', 'themefyre_builder' ),
         'label' => __( 'The audio player will play automatically.', 'themefyre_builder' ),
      );

      $args['attributes']['loop'] = array(
         'type'  => 'bool',
         'title' => __( 'Loop', 'themefyre_builder' ),
         'label' => __( 'The audio player will continually loop.', 'themefyre_builder' ),
      );

      $args['attributes']['controls'] = array(
         'type'    => 'bool',
         'default' => 'true',
         'title'   => __( 'Controls', 'themefyre_builder' ),
         'label'   => __( 'Display audio player controls.', 'themefyre_builder' ),
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               $(document).on('change', '#builder_audio-source', function(event) {
                  var source = $(this).val(),
                      $embedControls = $('#attribute-builder_audio-embed'),
                      $htmlControls = $('#attribute-builder_audio-mp3, #attribute-builder_audio-wav, #attribute-builder_audio-ogg, #attribute-builder_audio-auto, #attribute-builder_audio-loop, #attribute-builder_audio-controls');

                  if ( 'embed' === source ) {
                     themefyreBuilder.disableControl( $htmlControls, event );
                     themefyreBuilder.enableControl( $embedControls, event );
                  }
                  else if ( 'html' === source ) {
                     themefyreBuilder.disableControl( $embedControls, event );
                     themefyreBuilder.enableControl( $htmlControls, event );
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      extract( $atts );

      // First let`s set up the HTML for our audio
      $audio = '';
      switch ( $source ) {
         case 'embed':
            $audio = wp_oembed_get($embed);
            break;
         case 'html':
            $sources_html = '';
            foreach ( array( 'mp3' => 'mpeg', 'wav' => 'wav', 'ogg' => 'ogg' ) as $file_type => $mime_type ) {
               if ( ! empty( $atts[$file_type] ) ) {
                  $sources_html .= '<source src="'.$atts[$file_type].'" type="audio/'.$mime_type.'" />';
               }
            }

            // This means we have at least one `valid` source
            if ( $sources_html ) {
               $auto = builder_get_bool( $auto ) ? ' autoplay' : '';
               $loop = builder_get_bool( $loop ) ? ' loop' : '';
               $controls = builder_get_bool( $controls ) ? ' controls' : '';
               $audio = '<audio'.$auto.$loop.$controls.'>'.$sources_html.'</audio>';
            }
            break;
      }

      // No audio to display, do nothing
      if ( empty( $audio ) ) {
         return '';
      }

      // Compile class list
      $classes = builder_compile_html_class('builder-audio', $class);

      $out  = '<figure class="'.$classes.'" id="'.$id.'"'.$inline_attributes.'>';
      $out .= $audio;
      if ( $caption ) {
         $out .= '<figcaption class="builder-audio-caption builder-caption">'.$caption.'</figcaption>';
      }
      $out .= '</figure>';
      return $out;
   }

}