<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_spacer` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_spacer_shortcode() {
  builder_add_shortcode('Builder_Spacer_Shortcode', 'builder_spacer');
}
add_action('init', 'builder_add_spacer_shortcode');

/**
 * Spacer Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Spacer_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Spacer_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular' => __( 'Spacer', 'themefyre_builder' ),
         'plural'   => __( 'Spacers', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_spacer',
         'icon'            => 'editor-insertmore',
         'builder_role'    => 'content',
         'label_attribute' => 'size',
      );

      $args['attributes']['size'] = array(
         'type'        => 'string',
         'title'       => __( 'Spacer Size', 'themefyre_builder' ),
         'desc'        => __( 'Enter a CSS friendly value, must include a unit (px,em,etc...).<br /><strong>Leave this blank to use the default value which is determined by the currently active theme.</strong>', 'themefyre_builder' ),
         'placeholder' => sprintf( __( '(default size, currently: %s)', 'themefyre_builder' ), builder_get_theme_content_spacer_size() ),
      );

      parent::__construct( $args );
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      $default_size_class = ! $size ? 'builder-spacer-default-size' : '';
      if ( ! $size ) {
        $size = builder_get_theme_content_spacer_size();
      }
      $classes = builder_compile_html_class('builder-spacer', $default_size_class, 'clearfix', $class);
      return '<div class="'.$classes.'" id="'.$id.'" style="height:'.$size.';"'.$inline_attributes.'></div>';
   }

}