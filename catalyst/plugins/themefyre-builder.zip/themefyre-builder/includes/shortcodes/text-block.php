<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_text_block` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_text_block_shortcode() {
  builder_add_shortcode('Builder_Text_Block_Shortcode', 'builder_text_block');
}
add_action('init', 'builder_add_text_block_shortcode');

/**
 * Text Block Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Text_Block_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Text_Block_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      $entrance_delay_options = array('none' => __('(no animated entrance delay)', 'themefyre_builder') );
      for ($i=250;$i<=5000;$i+=250) {
         $entrance_delay_options[$i] = $i.'ms';
      }

      $labels = array(
         'singular' => __( 'Text Block', 'themefyre_builder' ),
         'plural'   => __( 'Text Blocks', 'themefyre_builder' ),
      );

      $args = array(
         'labels'        => $labels,
         'tag'           => 'builder_text_block',
         'icon'          => 'editor-paragraph',
         'builder_role'  => 'content',
         'content_type'  => 'editor',
         'content_first' => true,
      );

      $args['attributes']['entrance'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->animated_entrance_options,
      );

      $args['attributes']['entrance_delay'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance Delay', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $entrance_delay_options,
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_text_block = function( args, content, $modal, $module ) {
                  return content;
               };
               $(document).on('change', '#builder_text_block-entrance', function(event) {
                  if ( 'none' === $(this).val() ) {
                     themefyreBuilder.disableControl( $('#attribute-builder_text_block-entrance_delay'), event );
                  }
                  else {
                     themefyreBuilder.enableControl( $('#attribute-builder_text_block-entrance_delay'), event );
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      if ( $content ) {
         return wpautop( $content );
      }
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      extract( $atts );

      // Compile class list
      $classes = builder_compile_html_class('builder-text-block', $class);

      // Animated entrance inline data
      $entrance_data = 'none' !== $entrance ? ' data-entrance="'.$entrance.'"' : '';
      if ( $entrance_data && 'none' !== $entrance_delay ) {
         $entrance_data .= ' data-entrance-delay="'.$entrance_delay.'"';
      }

      $out  = '<div class="'.$classes.'" id="'.$id.'"'.$entrance_data.$inline_attributes.'>';
      $out .= '<div class="builder-tmce-content">'.apply_filters('the_content', $content).'</div>';
      $out .= '</div>';
      return $out;
   }

}