<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_promo_box_item` and `builder_promo_box` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_promo_box_shortcodes() {
  builder_add_shortcode('Builder_Promo_Box_Item_Shortcode', 'builder_promo_box_item');
  builder_add_shortcode('Builder_Promo_Box_Shortcode', 'builder_promo_box');
}
add_action('init', 'builder_add_promo_box_shortcodes');

/**
 * Promo Box Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Promo_Box_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Promo_Box_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      $labels = array(
         'singular' => __( 'Promo Box', 'themefyre_builder' ),
         'plural'   => __( 'Promo Boxs', 'themefyre_builder' ),
      );

      $args = array(
         'labels'             => $labels,
         'tag'                => 'builder_promo_box',
         'icon'               => 'external',
         'tmce'               => true,
         'builder_role'       => 'content',
         'content_type'       => 'builder_promo_box_item',
         'support_link'       => true,
         'support_background' => true,
         'default_content'    => '[builder_promo_box_item text="'.__('Promo Box Line One', 'themefyre_builder').'"]'
                               . '[builder_promo_box_item text="'.__('Promo Box Line Two', 'themefyre_builder').'"]',
      );

      $args['attributes']['height'] = array(
         'type'        => 'string',
         'title'       => __( 'Height', 'themefyre_builder' ),
         'desc'        => __( 'The value must include a unit (px,em,etc...). The default value is 300px.', 'themefyre_builder' ),
         'placeholder' => '300px',
      );

      $args['attributes']['color'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Text Color', 'themefyre_builder' ),
         'desc'  => __( 'The color to be applied to all content, if none is selected the content will be white.', 'themefyre_builder' ),
      );

      $args['attributes']['text_shadow'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Text Shadow', 'themefyre_builder' ),
         'desc'  => __( 'Optionally specify a color to serve as a text shadow to be applied to all content, if none is selected there will be no text shadow,', 'themefyre_builder' ),
      );

      $args['attributes']['halign'] = array(
         'type'    => 'within',
         'title'   => __( 'Content Horizontal Alignment', 'themefyre_builder' ),
         'default' => 'center',
         'options' => $builder->halign_options,
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_promo_box = function( args, content, $modal, $module ) {
                  var out = '';
                  if ( content && 'object' === typeof content && content.length ) {
                     _.each( content, function( shortcode ) {
                        lineArgs = shortcode.attrs.named;
                        if ( 'undefined' !== typeof lineArgs.text && lineArgs.text ) {
                           out += '<p>'+lineArgs.text+'</p>';
                        }
                     });
                  }
                  if ( out && 'undefined' !== typeof args.halign && 'none' !== args.halign ) {
                     out = '<div style="text-align:'+args.halign+';">'+out+'</div>';
                  }
                  return out;
               };
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      global $builder_promo_box_items;
      $builder_promo_box_items = array();
      do_shortcode( $content );
      $out = '';
      foreach ( $builder_promo_box_items as $line_args ) {
         if ( $line_args['text'] ) {
            $out .= '<p>'.$line_args['text'].'</p>';
         }
      }
      if ( $out && 'none' !== $halign ) {
         $out = '<div style="text-align:'.$halign.';">'.$out.'</div>';
      }
      return $out;
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_promo_box_items, $_themefyre_builder_current_column_size;
      $builder_promo_box_items = array();
      do_shortcode( $content );
      extract( $atts );

      // Set up the link data, when applicable
      $link_data = builder_get_link_inline_html($atts);
      $promo_box_tag = $link_data ? 'a' : 'div';

      // grab the args for the background settings
      $bg_html = builder_get_background_html( $atts );

      // Make sure a value has been set for the height
      if ( ! trim( $height ) ) {
         $height = '300px';
      }

      // Make sure a value has been set for the color
      if ( ! trim( $color ) ) {
         $color = '#ffffff';
      }

      // Begin creating our list of inline styles
      $inline_css = $bg_html['inline_css'];

      $inline_css .= 'height:'.$height.';color:'.$color.';';

      if ( '' !== $text_shadow ) {
         $inline_css .= 'text-shadow:'.builder_hex_to_rgba($text_shadow, 0.75).' 0px 1px 1px;';
      }
      else {
         $inline_css .= 'text-shadow:none;';
      }

      if ( 'none' !== $halign ) {
         $inline_css .= 'text-align:'.$halign.';';
      }

      // Wrap our inlice CSS in the `style` attribute
      $inline_css = ' style="'.$inline_css.'"';

      $classes = builder_compile_html_class('builder-promo-box', $bg_html['extra_class'], $class);
      $out = '<'.$promo_box_tag.$link_data.' class="'.$classes.'" id="'.$id.'"'.$inline_css.$inline_attributes.'>';
      $out .= $bg_html['inline_html'];

      $out .= '<div class="builder-promo-box-content">';
      foreach ( $builder_promo_box_items as $item ) {
         $line_inline_css = $item['font'].'opacity:'.$item['opacity'].';';
         if ( 'default' !== $item['font_size'] ) {
            $line_inline_css .= 'font-size:'.$item['font_size'].';';
         }
         if ( 'none' !== $halign ) {
            $line_inline_css .= 'text-align:'.$halign.';';
         }
         $line_classes = builder_compile_html_class('builder-promo-box-line', 'none' !== $item['style'] ? $item['style'] : '', $item['class']);
         $out .= '<span class="'.$line_classes.'" id="'.$item['id'].'" style="'.$line_inline_css.'">'.$item['text'].'</span>';
      }
      $out .= '</div>';

      $out .= '</'.$promo_box_tag.'>';

      return $out;
   }

}

/**
 * Promo Box Line Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Promo_Box_Item_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Promo_Box_Item_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      $size_options['default'] = __('(default font size)', 'themefyre_builder');
      for ( $i=10; $i<151; $i++ ) {
         $size_options[$i.'px'] = $i.'px';
      }

      $labels = array(
         'singular' => __( 'Line', 'themefyre_builder' ),
         'plural'   => __( 'Lines', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_promo_box_item',
         'builder_role'    => 'child',
         'label_attribute' => 'text',
      );

      $args['attributes']['text'] = array(
         'type'  => 'html_string',
         'title' => __( 'Title', 'themefyre_builder' ),
      );

      $args['attributes']['style'] = array(
         'type'    => 'within',
         'title'   => __( 'Predefined Styles', 'themefyre_builder' ),
         'default' => 'none',
         'options' => builder_get_available_text_styles(),
         'desc'    => __( 'Optionally select a predefined style set, you can still override the styles using the controls below.', 'themefyre_builder' ),
      );

      $args['attributes']['font'] = array(
         'type'  => 'font',
         'title' => __( 'Font Family', 'themefyre_builder' ),
      );

      $args['attributes']['font_size'] = array(
         'type'    => 'within',
         'title'   => __( 'Font Size', 'themefyre_builder' ),
         'default' => 'default',
         'options' => $size_options,
      );

      $args['attributes']['opacity'] = array(
         'type'    => 'within',
         'title'   => __( 'Opacity', 'themefyre_builder' ),
         'default' => '1',
         'options' => array(
            '1'   => __( '100% - Fully visible', 'themefyre_builder' ),
            '0.9' => '90%',
            '0.8' => '80%',
            '0.7' => '70%',
            '0.6' => '60%',
            '0.5' => '50%',
            '0.4' => '40%',
            '0.3' => '30%',
            '0.2' => '20%',
            '0.1' => '10%',
            '0'   => __( '0% - Not visible', 'themefyre_builder' ),
         ),
      );

      parent::__construct( $args );
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_promo_box_items;
      $builder_promo_box_items[] = $atts;
   }

}