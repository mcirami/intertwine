<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_row`, `builder_column` and `builder_column_row` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_row_shortcode() {
  builder_add_shortcode('Builder_Row_Shortcode', 'builder_row');
  builder_add_shortcode('Builder_Column_Shortcode', 'builder_column');
  builder_add_shortcode('Builder_Column_Row_Shortcode', 'builder_column_row');
}
add_action('init', 'builder_add_row_shortcode');

/**
 * Row Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Row_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Row_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      $border_width_options = array(
         'none' => __( '0px, no border', 'themefyre_builder' ),
      );
      for ($i=1;$i<=20;$i++) {
         $border_width_options[$i.'px'] = $i.'px';
      }

      $labels = array(
         'singular' => __( 'Row', 'themefyre_builder' ),
         'plural'   => __( 'Rows', 'themefyre_builder' ),
      );

      $args = array(
         'labels'             => $labels,
         'tag'                => 'builder_row',
         'builder_role'       => 'row',
         'label_attribute'    => 'none',
         'support_background' => true,
      );

      $args['attribute_tabs']['content_halign'] = array(
         'title' => __( 'Content Horizontal Alignment', 'themefyre_builder' ),
         'ids'   => array( 'content_max_width', 'content_halign' ),
      );

      $args['attributes']['bottom_margin'] = array(
         'type'        => 'string',
         'title'       => __( 'Bottom Margin', 'themefyre_builder' ),
         'desc'        => __( 'Enter a CSS friendly value, must include a unit (px,em,etc...). Can be used to space out your rows.', 'themefyre_builder' ),
         'placeholder' => __( '(no bottom margin)', 'themefyre_builder' ),
      );

      $args['attributes']['padding'] = array(
         'type'        => 'string',
         'title'       => __( 'Padding Amount', 'themefyre_builder' ),
         'desc'        => __( 'Amount of padding to use for this row, the default is 0. Any value that is acceptable for the CSS attribute "padding" will work here.', 'themefyre_builder' ),
         'placeholder' => __( '(no padding)', 'themefyre_builder' ),
      );

      $args['attributes']['border_width'] = array(
         'type'    => 'within',
         'title'   => __( 'Border Width', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $border_width_options,
      );

      $args['attributes']['border_style'] = array(
         'type'    => 'within',
         'title'   => __( 'Border Style', 'themefyre_builder' ),
         'default' => 'solid',
         'options' => array(
            'solid'  => __( 'Solid', 'themefyre_builder' ),
            'dotted' => __( 'Dotted', 'themefyre_builder' ),
            'dashed' => __( 'Dashed', 'themefyre_builder' ),
            'double' => __( 'Double', 'themefyre_builder' ),
            'groove' => __( 'Groove', 'themefyre_builder' ),
            'ridge'  => __( 'Ridge', 'themefyre_builder' ),
            'inset'  => __( 'Inset', 'themefyre_builder' ),
            'outset' => __( 'Outset', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['border_color'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Border Color', 'themefyre_builder' ),
      );

      $args['attributes']['content_max_width'] = array(
         'type'  => 'string',
         'title' => __( 'Content Maximum Width', 'themefyre_builder' ),
         'desc'  => __( 'Limit the width of the content. Value must include a unit (px,em,etc...). Use of percentages is not advised as this can create problems on smaller screens such as mobile devices.', 'themefyre_builder' ),
         'placeholder' => __( '(no maximum width)', 'themefyre_builder' ),
      );

      $args['attributes']['content_halign'] = array(
         'type'    => 'within',
         'title'   => __( 'Content Horizontal Alignment', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->halign_options,
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               $(document).on('change', '#builder_row-border_width', function(event) {
                  if ( 'none' !== $(this).val() ) {
                     themefyreBuilder.enableControl( $('#attribute-builder_row-border_style, #attribute-builder_row-border_color'), event );
                  }
                  else {
                     themefyreBuilder.disableControl( $('#attribute-builder_row-border_style, #attribute-builder_row-border_color'), event );
                  }
               });
               $(document).on('change keyup', '#builder_row-content_max_width', function(event) {
                  if ( '' !== $(this).val() ) {
                     themefyreBuilder.enableControl( $('#attribute-builder_row-content_halign'), event );
                  }
                  else {
                     themefyreBuilder.disableControl( $('#attribute-builder_row-content_halign'), event );
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $_themefyre_builder_current_column_size;
      extract( $atts );

      $_themefyre_builder_current_column_size = '1';

      // Create the inline padding CSS styles
      $padding_css = $padding ? "padding:{$padding};" : '';

      // Create the inline border CSS styles
      $border_css = 'none' !== $border_width && $border_color ? "border:{$border_width} {$border_style} {$border_color};" : '';

      // Create the inline bg CSS styles
      $bg_html = builder_get_background_html( $atts );

      // Create the final inline CSS attribute
      $inline_style = $padding_css.$border_css.$bg_html['inline_css'] ? ' style="'.$padding_css.$border_css.$bg_html['inline_css'].'"' : '';

      $classes = builder_compile_html_class('builder-row', $bg_html['extra_class'], $class);

      $out = '<div class="'.$classes.'" id="'.$id.'"'.$inline_style.' data-column-size="1"'.$inline_attributes.'>';
      $out .= $bg_html['inline_html'];
      if ( '' !== $content_max_width ) {
         $inline_css = 'max-width:'.$content_max_width.';';
         if ( 'center' == $content_halign ) {
            $inline_css .= 'margin:0 auto;';
         }
         else if ( 'none' !== $content_halign ) {
            $inline_css .= 'float:'.$content_halign.';';
         }
         $out .= '<div class="builder-row-content-wrap">';
         $out .= '<div class="builder-row-content" style="'.$inline_css.'">';
      }
      $out .= do_shortcode($content);
      if ( '' !== $content_max_width ) {
         $out .= '</div>';
         $out .= '</div>';
      }
      $out .= '</div>';

      // Append a spacer element to simulate the bottom margin CSS
      if ( $bottom_margin ) {
         $out .= '<div class="builder-row-spacer" style="margin-bottom:'.$bottom_margin.'"></div>';
      }

      return $out;
   }

}

/**
 * Column Row Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Column_Row_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Column_Row_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      $labels = array(
         'singular' => __( 'Column Row', 'themefyre_builder' ),
         'plural'   => __( 'Column Rows', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_column_row',
         'builder_role'    => 'row',
         'label_attribute' => 'none',
      );

      $args['attributes']['bottom_margin'] = array(
         'type'        => 'string',
         'title'       => __( 'Bottom Margin', 'themefyre_builder' ),
         'desc'        => __( 'Enter a CSS friendly value, must include a unit (px,em,etc...). Can be used to space out your rows.', 'themefyre_builder' ),
         'placeholder' => __( '(no bottom margin)', 'themefyre_builder' ),
      );

      $args['attributes']['spacing'] = array(
         'type'    => 'within',
         'title'   => __( 'Column Spacing', 'themefyre_builder' ),
         'desc'    => __( 'Amount of spacing to be displayed between each column. <strong>If this option is set to "No Spacing" then the columns in this column row will be forced to the same height. This change will only be noticable if one or more of the columns has a custom background.</strong>', 'themefyre_builder' ),
         'default' => '2',
         'options' => array(
            'none' => __( 'No spacing', 'themefyre_builder' ),
            '1'    => __( 'Less', 'themefyre_builder' ),
            '2'    => __( 'Normal', 'themefyre_builder' ),
            '3'    => __( 'More', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['valign'] = array(
         'type'    => 'within',
         'title'   => __( 'Vertical Alignment', 'themefyre_builder' ),
         'desc'    => __( 'How the columns should be vertically aligned with each other.', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->valign_options,
      );

      parent::__construct( $args );
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $_themefyre_builder_current_column_size;
      extract( $atts );

      // Array of allowed special layouts
      $allowed_custom_layouts = array(
         '1_3-2_3',
         '2_3-1_3',
         '2_5-3_5',
         '3_5-2_5',
         '3_4-1_4',
         '1_4-3_4',
         '1_2-1_4-1_4',
         '1_4-1_2-1_4',
         '1_4-1_4-1_2',
      );

      // Grab any defined columns
      // Store the processed content so it can be used later
      global $builder_columns;
      $builder_columns = array();
      $processed_content = do_shortcode( $content );

      // Not enough columns, do not return anything
      if ( ! is_array( $builder_columns ) || 2 > count( $builder_columns ) ) {
         return '';
      }

      // Limit number of columns to 6
      $builder_columns = array_slice( $builder_columns, 0, 6 );
      $num_columns = count( $builder_columns );

      // Check to see if a valid custom layout has been supplied
      $custom_layout = array();
      foreach ($builder_columns as $column_config) {
         if ( empty($column_config['span']) ) {
            $custom_layout = array();
            break;
         }
         $custom_layout[] = str_replace('/', '_', $column_config['span']);
      }

      // Make sure the custom layout (if any) is valid
      if ( ! empty($custom_layout) && ! in_array(implode('-', $custom_layout), $allowed_custom_layouts) ) {
         $custom_layout = array();
      }

      // Create the CSS friendly layout class
      $layout_class = ! empty($custom_layout) ? implode('-', $custom_layout) : $num_columns;

      // If spacing & valign have been set to `none` set valign to top
      // this way, the columns will have equal height, as expected.
      if ( 'none' == $spacing && 'none' == $valign ) {
         $valign = 'top';
      }

      // Create the CSS friendly v-alignment class
      $valign_class = 'none' !== $valign ? 'valign-columns-'.$valign : '';

      // Finally output our HTML
      $classes = builder_compile_html_class('builder-column-row', 'builder-columns-'.$layout_class, 'spacing-'.$spacing, $valign_class, $class);
      $out = '<div class="'.$classes.'" id="'.$id.'"'.$inline_attributes.'>';
      for ( $i=0; $i<$num_columns; $i++ ) {
         $column_size = ! empty($custom_layout) ? $custom_layout[$i] : '1_'.$num_columns;

         // Set the global size indicator to the current column size
         $_themefyre_builder_current_column_size = $column_size;

         // Create the inline padding CSS styles
         $padding_css = $builder_columns[$i]['padding'] ? "padding:{$builder_columns[$i]['padding']};" : '';

         // Create the inline border CSS styles
         $border_css = 'none' !== $builder_columns[$i]['border_width'] && $builder_columns[$i]['border_color'] ? "border:{$builder_columns[$i]['border_width']} {$builder_columns[$i]['border_style']} {$builder_columns[$i]['border_color']};" : '';

         // Grab the HTML for the background configuration
         $bg_html = builder_get_background_html( $builder_columns[$i] );

         // Create the final inline CSS attribute & correctly plce the background HTML
         $inner_style = $outer_style = $outer_css_class = $inner_bg_extra_class = '';
         if ( 'none' === $spacing ) {
            $outer_style = $border_css.$bg_html['inline_css'] ? ' style="'.$border_css.$bg_html['inline_css'].'"' : '';
            $inner_style = $padding_css ? ' style="'.$padding_css.'"' : '';
            if ( $bg_html['extra_class'] ) {
               $outer_css_class = ' class="'.$bg_html['extra_class'].'"';
            }
         }
         else {
            $inner_style = $padding_css.$border_css.$bg_html['inline_css'] ? ' style="'.$padding_css.$border_css.$bg_html['inline_css'].'"' : '';
            $inner_bg_extra_class = $bg_html['extra_class'];
         }

         $order_class = '';
         if ( 0 === $i ) {
            $order_class = 'builder-column-first';
         }
         else if ( ($i+1) === $num_columns ) {
            $order_class = 'builder-column-last';
         }
         $column_classes = builder_compile_html_class('builder-column', 'builder-column-span-'.$column_size, $order_class, $inner_bg_extra_class, $builder_columns[$i]['class']);
         $out .= '<div'.$outer_style.$outer_css_class.'>';
         if ( 'none' === $spacing ) {
            $out .= $bg_html['inline_html'];
         }
         $out .= '<div class="'.$column_classes.'" id="'.$builder_columns[$i]['id'].'"'.$inner_style.' data-column-size="'.$column_size.'"'.$builder_columns[$i]['inline_attributes'].'>';
         if ( 'none' !== $spacing ) {
            $out .= $bg_html['inline_html'];
         }
         $out .= do_shortcode($builder_columns[$i]['content']);
         $out .= '</div>';
         $out .= '</div>';
      }
      $out .= '</div>';

      // Wrap output if columns have been vertically aligned
      if ( 'none' !== $valign ) {
         $out = '<div class="builder-column-row-valign-wrapper spacing-'.$spacing.'">'.$out.'</div>';
      }

      // Append a spacer element to simulate the bottom margin CSS
      if ( $bottom_margin ) {
         $out .= '<div class="builder-row-spacer" style="margin-bottom:'.$bottom_margin.'"></div>';
      }

      return $out;
   }

}

/**
 * Column Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Column_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Column_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $border_width_options = array(
         'none' => __( '0px, no border', 'themefyre_builder' ),
      );
      for ($i=1;$i<=20;$i++) {
         $border_width_options[$i.'px'] = $i.'px';
      }

      $labels = array(
         'singular' => __( 'Column', 'themefyre_builder' ),
         'plural'   => __( 'Columns', 'themefyre_builder' ),
      );

      $args = array(
         'labels'             => $labels,
         'tag'                => 'builder_column',
         'builder_role'       => 'column',
         'label_attribute'    => 'none',
         'support_background' => true,
      );

      $args['attributes']['span'] = array( 'type' => 'dev' );

      $args['attributes']['padding'] = array(
         'type'  => 'string',
         'title' => __( 'Padding Amount', 'themefyre_builder' ),
         'desc'  => __( 'Amount of padding to use for this column, the default is 0. Any value that is acceptable for the CSS attribute "padding" will work here.', 'themefyre_builder' ),
         'placeholder' => __( 'No padding', 'themefyre_builder' ),
      );

      $args['attributes']['border_width'] = array(
         'type'    => 'within',
         'title'   => __( 'Border Width', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $border_width_options,
      );

      $args['attributes']['border_style'] = array(
         'type'    => 'within',
         'title'   => __( 'Border Style', 'themefyre_builder' ),
         'default' => 'solid',
         'options' => array(
            'solid'  => __( 'Solid', 'themefyre_builder' ),
            'dotted' => __( 'Dotted', 'themefyre_builder' ),
            'dashed' => __( 'Dashed', 'themefyre_builder' ),
            'double' => __( 'Double', 'themefyre_builder' ),
            'groove' => __( 'Groove', 'themefyre_builder' ),
            'ridge'  => __( 'Ridge', 'themefyre_builder' ),
            'inset'  => __( 'Inset', 'themefyre_builder' ),
            'outset' => __( 'Outset', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['border_color'] = array(
         'type'  => 'hex_code',
         'title' => __( 'Border Color', 'themefyre_builder' ),
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               $(document).on('change', '#builder_column-border_width', function(event) {
                  if ( 'none' !== $(this).val() ) {
                     themefyreBuilder.enableControl( $('#attribute-builder_column-border_style, #attribute-builder_column-border_color'), event );
                  }
                  else {
                     themefyreBuilder.disableControl( $('#attribute-builder_column-border_style, #attribute-builder_column-border_color'), event );
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_columns;
      $atts['content'] = $content;
      $builder_columns[] = $atts;
   }

}