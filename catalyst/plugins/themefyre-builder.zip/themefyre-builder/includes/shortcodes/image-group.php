<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_image_group` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_image_group_shortcodes() {
  builder_add_shortcode('Builder_Image_Group_Shortcode', 'builder_image_group');
  builder_add_shortcode('Builder_Image_Group_Item_Shortcode', 'builder_image_group_item');
}
add_action('init', 'builder_add_image_group_shortcodes');

/**
 * Image Group Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Image_Group_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Image_Group_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      for ( $i=2; $i<7; $i++ ) {
         $grid_column_options[$i] = $i;
      }
      for ( $i=1; $i<7; $i++ ) {
         $carousel_column_options[$i] = $i;
      }

      $labels = array(
         'singular' => __( 'Image Group', 'themefyre_builder' ),
         'plural'   => __( 'Image Groups', 'themefyre_builder' ),
      );

      $args = array(
         'labels'       => $labels,
         'tag'          => 'builder_image_group',
         'icon'         => 'format-gallery',
         'builder_role' => 'content',
         'content_type' => 'builder_image_group_item',
      );

      $args['attribute_tabs'] = array(
         'style' => array(
            'title' => __( 'Style', 'themefyre_builder' ),
            'ids'   => array( 'style', 'rounded_corners', 'grid_columns', 'grid_spacing', 'force_height', 'show_captions', 'entrance', 'carousel_columns', 'carousel_scroll_number', 'carousel_pager', 'slider_transition', 'slider_controls', 'slider_auto', 'slider_hover_pause', 'slider_interval' ),
         ),
      );

      $args['attributes']['random'] = array(
         'type'  => 'bool',
         'title' => __( 'Random Order', 'themefyre_builder' ),
         'label' => __( 'Gallery images will be displayed in a random order.', 'themefyre_builder' ),
      );

      $args['attributes']['style'] = array(
         'type'    => 'within',
         'title'   => __( 'Gallery Style', 'themefyre_builder' ),
         'default' => 'grid',
         'options' => array(
            'grid'    => __( 'Grid', 'themefyre_builder' ),
            'masonry' => __( 'Masonry', 'themefyre_builder' ),
            'carousel' => __( 'Carousel', 'themefyre_builder' ),
            'slider' => __( 'Slider', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['rounded_corners'] = array(
         'type'  => 'bool',
         'title' => __( 'Rounded Corners', 'themefyre_builder' ),
         'label' => __( 'Display images with slightly rounded corners.', 'themefyre_builder' ),
      );

      $args['attributes']['grid_columns'] = array(
         'type'    => 'within',
         'title'   => __( 'Columns', 'themefyre_builder' ),
         'default' => '4',
         'options' => $grid_column_options,
      );

      $args['attributes']['grid_spacing'] = array(
         'type'    => 'within',
         'title'   => __( 'Column Spacing', 'themefyre_builder' ),
         'default' => '2',
         'options' => array(
            'none' => __( 'No spacing', 'themefyre_builder' ),
            '1'    => __( 'Less', 'themefyre_builder' ),
            '2'    => __( 'Normal', 'themefyre_builder' ),
            '3'    => __( 'More', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['force_height'] = array(
         'type'  => 'string',
         'title' => __( 'Forced Image Height', 'themefyre_builder' ),
         'desc'  => __( 'The value must include a unit (px,em,etc...). Images will be resized proportionally.', 'themefyre_builder' ),
      );

      $args['attributes']['show_captions'] = array(
         'type'  => 'bool',
         'title' => __( 'Display Captions', 'themefyre_builder' ),
         'label' => __( 'Display image captions.', 'themefyre_builder' ),
      );

      $args['attributes']['entrance'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance', 'themefyre_builder' ),
         'desc'    => __( 'Animated entrance will be applied to each gallery image consecutively.', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->animated_entrance_options,
      );

      $args['attributes']['carousel_columns'] = array(
         'type'    => 'within',
         'title'   => __( 'Columns', 'themefyre_builder' ),
         'default' => '4',
         'options' => $carousel_column_options,
      );

      $args['attributes']['carousel_scroll_number'] = array(
         'type'        => 'string',
         'title'       => __( 'Images to Scroll', 'themefyre_builder' ),
         'desc'        => __( 'The number of images to scroll per slide change. By default this will be equivalent to the number of columns selected. Enter a numeric value only, the value entered here can not exceed the number of columns selected.', 'themefyre_builder' ),
         'placeholder' => __( '(same as number of columns)', 'themefyre_builder' ),
      );

      $args['attributes']['carousel_pager'] = array(
         'type'    => 'bool',
         'title'   => __( 'Pager Navigation', 'themefyre_builder' ),
         'label'   => __( 'Enable the carousel pager control', 'themefyre_builder' ),
         'default' => 'true',
      );

      $args['attributes']['slider_transition'] = array(
         'type'  => 'within',
         'title' => __( 'Slide Transition', 'themefyre_builder' ),
         'desc'  => __( 'Animation mode for slide transitions.', 'themefyre_builder' ),
         'default' => 'slide',
         'options' => array(
            'slide' => __( 'Slide', 'themefyre_builder' ),
            'fade'  => __( 'Fade', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['slider_controls'] = array(
         'type'    => 'within',
         'title'   => __( 'Enabled Controls', 'themefyre_builder' ),
         'default' => 'both',
         'options' => array(
            'both'      => __( 'Pager & direction nav', 'themefyre_builder' ),
            'pager'     => __( 'Pager only', 'themefyre_builder' ),
            'direction' => __( 'Direction nav only', 'themefyre_builder' ),
            'none'      => __( 'None, no manual controls', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['slider_auto'] = array(
         'type'  => 'bool',
         'title' => __( 'Automatically Change Slides', 'themefyre_builder' ),
         'label' => __( 'Automatically change slides at an interval you set.', 'themefyre_builder' ),
      );

      $args['attributes']['slider_hover_pause'] = array(
         'type'    => 'bool',
         'title'   => __( 'Pause On Hover', 'themefyre_builder' ),
         'label'   => __( 'Pause the slider while it is moused over.', 'themefyre_builder' ),
         'default' => 'true',
      );

      $args['attributes']['slider_interval'] = array(
         'type'        => 'string',
         'title'       => __( 'Slide Change Interval', 'themefyre_builder' ),
         'desc'        => __( 'The amount of time between each automatic slide change. Enter a <strong>numeric</strong> value only in <strong>milliseconds</strong>. 1000 milliseconds = 1 second.', 'themefyre_builder' ),
         'placeholder' => '4000',
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {
      ?>
         <style>
            .builder_image_group-module-preview ul {
               margin: 0;
               overflow: hidden;
               padding: 0;
            }
            .builder_image_group-module-preview ul li {
               display: block;
               float: left;
               height: 60px;
               width: 60px;
               background-size: cover;
               margin: 0 5px 5px 0;
            }
         </style>
      <?php
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_image_group = function( args, content, $modal, $module ) {
                  var out = '';
                  $('.builder_image_group_item-module-preview img', $modal).each( function() {
                     out += '<li style="background-image:url('+$(this).attr('src')+');"></li>';
                  });
                  if ( out ) {
                     return '<ul>'+out+'</ul>';
                  }
               };
               $(document).on('change', '#builder_image_group-style', function(event) {
                  var style = $(this).val(),
                      $gridControls = $('#attribute-builder_image_group-grid_columns, #attribute-builder_image_group-grid_spacing, #attribute-builder_image_group-entrance'),
                      $carouselControls = $('#attribute-builder_image_group-carousel_columns, #attribute-builder_image_group-carousel_scroll_number, #attribute-builder_image_group-carousel_pager'),
                      $sliderControls = $('#attribute-builder_image_group-slider_transition, #attribute-builder_image_group-slider_controls');

                  if ( 'grid' === style || 'masonry' === style ) {
                     themefyreBuilder.disableControl( $carouselControls, event );
                     themefyreBuilder.disableControl( $sliderControls, event );
                     themefyreBuilder.enableControl( $gridControls, event );

                     // Must be enabled/disabled separately
                     themefyreBuilder.disableControl( $('#attribute-builder_image_group-slider_auto, #attribute-builder_image_group-slider_hover_pause, #attribute-builder_image_group-slider_interval'), event );
                     themefyreBuilder.enableControl( $('#attribute-builder_image_group-link_type, #attribute-builder_image_group-rounded_corners, #attribute-builder_image_group-show_captions'), event );

                     if ( 'grid' === style ) {
                        themefyreBuilder.enableControl( $('#attribute-builder_image_group-force_height'), event );
                     }
                     else {
                        themefyreBuilder.disableControl( $('#attribute-builder_image_group-force_height'), event );
                     }
                  }
                  else if ( 'carousel' === style ) {
                     themefyreBuilder.disableControl( $gridControls, event );
                     themefyreBuilder.disableControl( $sliderControls, event );
                     themefyreBuilder.enableControl( $carouselControls, event );

                     // Must be enabled/disabled separately
                     themefyreBuilder.enableControl( $('#attribute-builder_image_group-link_type, #attribute-builder_image_group-rounded_corners, #attribute-builder_image_group-show_captions, #attribute-builder_image_group-force_height, #attribute-builder_image_group-slider_auto'), event );

                     // Show/hide the controls for automatic slide change
                     if ( $('#builder_image_group-slider_auto').prop('checked') ) {
                        themefyreBuilder.enableControl( $('#attribute-builder_image_group-slider_hover_pause, #attribute-builder_image_group-slider_interval'), event );
                     }
                     else {
                        themefyreBuilder.disableControl( $('#attribute-builder_image_group-slider_hover_pause, #attribute-builder_image_group-slider_interval'), event );
                     }
                  }
                  else if ( 'slider' === style ) {
                     themefyreBuilder.disableControl( $gridControls, event );
                     themefyreBuilder.disableControl( $carouselControls, event );
                     themefyreBuilder.enableControl( $sliderControls, event );

                     // Must be enabled/disabled separately
                     themefyreBuilder.disableControl( $('#attribute-builder_image_group-rounded_corners, #attribute-builder_image_group-show_captions'), event );
                     themefyreBuilder.enableControl( $('#attribute-builder_image_group-link_type, #attribute-builder_image_group-slider_auto'), event );

                     // Show/hide the controls for automatic slide change
                     if ( $('#builder_image_group-slider_auto').prop('checked') ) {
                        themefyreBuilder.enableControl( $('#attribute-builder_image_group-slider_hover_pause, #attribute-builder_image_group-slider_interval'), event );
                     }
                     else {
                        themefyreBuilder.disableControl( $('#attribute-builder_image_group-slider_hover_pause, #attribute-builder_image_group-slider_interval'), event );
                     }
                  }
               });
               $(document).on('change', '#builder_image_group-slider_auto', function(event) {
                  if ( $(this).prop('checked') ) {
                     themefyreBuilder.enableControl( $('#attribute-builder_image_group-slider_hover_pause, #attribute-builder_image_group-slider_interval'), event );

                     // Scroll the custom style controls into view
                     if ( undefined !== event.originalEvent ) {
                        var $scrollBox = $(this).closest('.builder-modal-content');
                        setTimeout( function() {
                           $scrollBox.animate( {
                              scrollTop: $scrollBox.prop('scrollHeight'),
                           }, 250 );
                        }, 255 );
                     }
                  }
                  else {
                     themefyreBuilder.disableControl( $('#attribute-builder_image_group-slider_hover_pause, #attribute-builder_image_group-slider_interval'), event );
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      global $builder_image_group_items;
      $builder_image_group_items = array();
      do_shortcode( $content );
      $out = '';
      foreach ( $builder_image_group_items as $item ) {
         if ( ! $img_url = builder_get_attachment_src( $item['attachment_id'], 'thumbnail' ) ) {
            continue;
         }
         $out .= '<li style="background-image:url('.$img_url.');"></li>';
      }
      if ( $out ) {
         return '<ul>'.$out.'</ul>';
      }
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_image_group_items;
      $builder_image_group_items = array();
      do_shortcode( $content );

      // Make sure at least 1 iage was supplied
      if ( ! $builder_image_group_items ) {
         return '';
      }

      // Randomize our attachment ID`s
      if ( builder_get_bool( $atts['random'] ) ) {
         shuffle( $builder_image_group_items );
      }

      return call_user_func( array( $this, 'masonry' === $atts['style'] ? 'grid' : $atts['style'] ), $atts );
   }

   /**
    * Callback function for front end display of shortcode in `grid/masonry` mode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @return string
    */
   public function grid( $atts ) {
      extract( $atts );
      global $builder_image_group_items;

      // Animated entrance attributes
      $entrance_delay = 0;
      $entrance_delay_data = '';
      $group_entrance_data = 'none' !== $entrance ? ' data-entrance-trigger="'.$entrance.'"' : '';
      $image_entrance_data = $group_entrance_data ? ' data-entrance="chained"' : '';

      // Lightbox gallery data
      $group_lightbox_data = 'lightbox' === $link_type ? ' data-builder-lightbox-role="gallery"' : '';

      // Spacing class
      $spacing_class = 'none' !== $grid_spacing ? 'spacing-'.$grid_spacing : '';

      // Masonry class
      $masonry_class = 'masonry' === $style ? 'builder-masonry' : '';

      // Rounded corners class
      $rounded_corners_class = builder_get_bool($rounded_corners) ? ' builder-rounded-corners' : '';

      // Compile the list of classes
      $classes = builder_compile_html_class('builder-gallery', 'builder-gallery-'.$style, 'builder-grid-'.$grid_columns, $spacing_class, $masonry_class, $class);

      $out = '<div class="'.$classes.'" id="'.$id.'"'.$group_entrance_data.$group_lightbox_data.$inline_attributes.'>';

      $i = 0;
      foreach ( $builder_image_group_items as $item ) {
         if ( ! $img_url = builder_get_attachment_src( $item['attachment_id'], $item['size'] ) ) {
            continue;
         }
         $i++;
         if ( $image_entrance_data ) {
            $entrance_delay_data = ' data-entrance-delay="'.$entrance_delay.'"';
            $entrance_delay+=250;
         }
         $link_data = builder_get_link_inline_html($item);
         $caption = builder_get_attachment_caption( $item['attachment_id'] );
         $out .= '<figure class="builder-gallery-item" id="'.$id.'-item-'.$i.'">';
         if ( $link_data ) {
            $out .= '<a'.$link_data.'>';
         }
         if ( 'grid' === $style && $force_height ) {
            $out .= '<div style="background-image:url('.$img_url.');height:'.$force_height.';" class="builder-bg-scale'.$rounded_corners_class.'"'.$image_entrance_data.$entrance_delay_data.'></div>';
         }
         else {
            $out .= '<img src="'.$img_url.'" alt="'.builder_get_attachment_alt($item['attachment_id']).'" class="'.$rounded_corners_class.'"'.$image_entrance_data.$entrance_delay_data.'>';
         }
         if ( $link_data ) {
            $out .= '</a>';
         }
         if ( builder_get_bool( $show_captions ) && $caption ) {
            $out .= '<figcaption class="builder-gallery-caption builder-caption">'.$caption.'</figcaption>';
         }
         $out .= '</figure>';
      }

      $out .= '</div>';
      return $out;
   }

   /**
    * Callback function for front end display of shortcode in `carousel` mode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @return string
    */
   public function carousel( $atts ) {
      extract( $atts );
      global $builder_image_group_items;

      // The number of images to scroll per slide change
      $carousel_scroll_number = intval( $carousel_scroll_number );
      $carousel_scroll_number = $carousel_scroll_number && $carousel_scroll_number < $carousel_columns ? $carousel_scroll_number : $carousel_columns;

      // Lightbox gallery data
      $group_lightbox_data = 'lightbox' === $link_type ? ' data-builder-lightbox-role="gallery"' : '';

      // Automatic interval data
      $interval_data = '';
      if ( builder_get_bool( $slider_auto ) ) {
         $interval = $slider_interval ? intval( $slider_interval ) : 4000;
         $interval_data = ' data-interval="'.$interval.'" data-hoverpause="'.$slider_hover_pause.'"';
      }

      // Compile the list of classes
      $classes = builder_compile_html_class('builder-gallery builder-gallery-carousel builder-carousel', $class);

      $out = '<div class="'.$classes.'" id="'.$id.'" data-carousel-columns="'.$carousel_columns.'" data-carousel-pager="'.$carousel_pager.'" data-carousel-scroll-number="'.$carousel_scroll_number.'"'.$group_lightbox_data.$interval_data.$inline_attributes.'>';

      $i = 0;
      foreach ( $builder_image_group_items as $item ) {
         if ( ! $img_url = builder_get_attachment_src( $item['attachment_id'], $item['size'] ) ) {
            continue;
         }
         $i++;
         $link_data = builder_get_link_inline_html($item);
         $caption = builder_get_attachment_caption( $item['attachment_id'] );

         $out .= '<figure class="builder-carousel-item builder-gallery-item" id="'.$id.'-item-'.$i.'">';
         if ( $link_data ) {
            $out .= '<a'.$link_data.'>';
         }
         if ( $force_height ) {
            $out .= '<div style="background-image:url('.$img_url.');height:'.$force_height.';" class="builder-bg-scale'.$rounded_corners_class.'"></div>';
         }
         else {
            $out .= '<img src="'.$img_url.'" alt="'.builder_get_attachment_alt($item['attachment_id']).'" class="'.$rounded_corners_class.'">';
         }
         if ( $link_data ) {
            $out .= '</a>';
         }
         if ( builder_get_bool( $show_captions ) && $caption ) {
            $out .= '<figcaption class="builder-gallery-caption builder-caption">'.$caption.'</figcaption>';
         }
         $out .= '</figure>';
      }

      $out .= '</div>';
      return $out;
   }

   /**
    * Callback function for front end display of shortcode in `slider` mode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @return string
    */
   public function slider( $atts ) {
      extract( $atts );
      global $builder_image_group_items;

      // Lightbox gallery data
      $group_lightbox_data = 'lightbox' === $link_type ? ' data-builder-lightbox-role="gallery"' : '';

      // Automatic interval data
      $interval_data = '';
      if ( builder_get_bool( $slider_auto ) ) {
         $interval = $slider_interval ? intval( $slider_interval ) : 4000;
         $interval_data = ' data-interval="'.$interval.'" data-hoverpause="'.$slider_hover_pause.'"';
      }

      // Compile the list of classes
      $classes = builder_compile_html_class('builder-gallery builder-gallery-slider builder-slider', $class);

      $out = '<div class="'.$classes.'" id="'.$id.'" data-controls="'.$slider_controls.'" data-transition="'.$slider_transition.'"'.$group_lightbox_data.$interval_data.$inline_attributes.'>';

      $i = 0;
      foreach ( $builder_image_group_items as $item ) {
         if ( ! $img_url = builder_get_attachment_src( $item['attachment_id'], $item['size'] ) ) {
            continue;
         }
         $i++;
         $link_data = builder_get_link_inline_html($item);
         $caption = builder_get_attachment_caption( $item['attachment_id'] );

         $out .= '<figure class="builder-slider-item builder-gallery-item" id="'.$id.'-item-'.$i.'">';
         if ( $link_data ) {
            $out .= '<a'.$link_data.'>';
         }
         if ( $force_height ) {
            $out .= '<div style="background-image:url('.$img_url.');height:'.$force_height.';" class="builder-bg-scale"></div>';
         }
         else {
            $out .= '<img src="'.$img_url.'" alt="'.builder_get_attachment_alt($item['attachment_id']).'">';
         }
         if ( $link_data ) {
            $out .= '</a>';
         }
         $out .= '</figure>';
      }

      $out .= '</div>';
      return $out;
   }

}

/**
 * Image Group Item Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Image_Group_Item_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Image_Group_Item_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      $labels = array(
         'singular' => __( 'Image', 'themefyre_builder' ),
         'plural'   => __( 'Images', 'themefyre_builder' ),
      );

      $args = array(
         'labels'       => $labels,
         'tag'          => 'builder_image_group_item',
         'icon'         => 'format-image',
         'builder_role' => 'child',
         'support_link' => true,
      );

      $args['attributes']['attachment_id'] = array(
         'type'  => 'image',
         'title' => __( 'Image', 'themefyre_builder' ),
      );

      $args['attributes']['size'] = array(
         'type'    => 'within',
         'title'   => __( 'Image Size', 'themefyre_builder' ),
         'desc'    => __( 'WordPress stores multiple sizes of each image, specify which size you would like to display.', 'themefyre_builder' ),
         'default' => 'full',
         'options' => builder_get_available_attachment_sizes(),
      );

      parent::__construct( $args );
   }

   /**
    * Loads inline CSS for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_styles() {
      ?>
         <style>
            .builder_image_group_item-module-preview {
               text-align: center;
               max-height: none !important;
            }
            .builder_image_group_item-module-preview:before {
               display: none !important;
            }
         </style>
      <?php
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               themefyreBuilder.modulePreviewCallbacks.builder_image_group_item = function( args, content, $modal, $module ) {
                  var $previewImage = $('.builder-preview-image[data-key="builder_image_group_item-attachment_id"] img', $modal);
                  if ( $previewImage.length ) {
                     return '<img src="'+$previewImage.attr('src')+'" />';
                  }
               };
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback to be used to output a preview within the page builder
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @param string $tag The shortcode tag. (default: null)
    * @return string
    */
   public function builder_preview_callback( $atts, $content = null, $tag = '' ) {
      if ( $img_url = builder_get_attachment_src( $atts['attachment_id'], 'medium' ) ) {
         return '<img src="'.$img_url.'" />';
      }
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $builder_image_group_items;
      $builder_image_group_items[] = $atts;
   }

}