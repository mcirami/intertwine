[builder_full_width_map controls="none" height="75vh" zoom="14"]
   [builder_map_marker address="New York, NY" popup_visibility="load"]<h4>Location Info</h4>

Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam.[/builder_map_marker]
[/builder_full_width_map]

[builder_section]
   [builder_column_row]
      [builder_column]
         [builder_header text="Drop us a Line" tag="h2"]
         [builder_text_block]Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat dolor sit amet, consectetuer adipiscing elit.[/builder_text_block]
         [builder_contact_form]
            [builder_contact_form_field label="Full Name" type="text" width="1/2"]
            [builder_contact_form_field label="Email Address" type="email" width="1/2"]
            [builder_contact_form_field label="Message" type="textarea"]
         [/builder_contact_form]
      [/builder_column]
      [builder_column]
         [builder_header text="Locations" tag="h2"]
         [builder_toggle_group first_open="true" allow_multi="false"]
            [builder_toggle_group_toggle title="New York, NY"]Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat dolor sit amet, consectetuer adipiscing elit.

Address: 123 Somewhere ST, New York, NY 54321
Hours: Mon - Fri 9AM - 5PM[/builder_toggle_group_toggle]
            [builder_toggle_group_toggle title="Miami, FL"]Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat dolor sit amet, consectetuer adipiscing elit.

Address: 123 Somewhere ST, New York, NY 54321
Hours: Mon - Fri 9AM - 5PM[/builder_toggle_group_toggle]
         [/builder_toggle_group]
      [/builder_column]
   [/builder_column_row]
[/builder_section]