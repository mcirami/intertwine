<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_recent_projects` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 */
function builder_add_recent_projects_shortcode() {
  builder_add_shortcode('Builder_Recent_Projects_Shortcode', 'builder_recent_projects');
}
add_action('init', 'builder_add_recent_projects_shortcode');

/**
 * Recent Projects Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Recent_Projects_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Recent_Projects_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $builder = builder();

      for ( $i=1; $i<7; $i++ ) {
         $column_options[$i] = $i;
      }

      $labels = array(
         'singular' => __( 'Recent Projects', 'themefyre_builder' ),
         'plural'   => __( 'Recent Projects', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_recent_projects',
         'icon'            => 'admin-post',
         'tmce'            => true,
         'builder_role'    => 'content',
         'builder_source'  => 'Themefyre Portfolio',
      );

      $args['attributes']['category'] = array(
         'type'    => 'within',
         'title'   => __( 'Category', 'themefyre_builder' ),
         'default' => 'none',
         'options' => array( $this, 'get_categories' ),
         'desc'    => __( 'Only show most recent projects from a specific category.', 'themefyre_builder' ),
      );

      $args['attributes']['number_posts'] = array(
         'type'  => 'string',
         'title' => __( 'Maximum Number of Posts', 'themefyre_builder' ),
         'desc'  => __( 'Enter a numeric value only. Leave this blank for the number of posts to match the number of columns selected.', 'themefyre_builder' ),
         'placeholder' => __( '(same as number of columns selected)', 'themefyre_builder' ),
      );

      $args['attributes']['columns'] = array(
         'type'    => 'within',
         'title'   => __( 'Columns', 'themefyre_builder' ),
         'default' => '4',
         'options' => $column_options,
      );

      $args['attributes']['column_spacing'] = array(
         'type'    => 'within',
         'title'   => __( 'Column Spacing', 'themefyre_builder' ),
         'default' => '2',
         'options' => array(
            'none' => __( 'No spacing', 'themefyre_builder' ),
            '1'    => __( 'Less', 'themefyre_builder' ),
            '2'    => __( 'Normal', 'themefyre_builder' ),
            '3'    => __( 'More', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['style'] = array(
         'type'    => 'within',
         'title'   => __( 'Style', 'themefyre_builder' ),
         'default' => 'grid',
         'options' => array(
            'grid'     => __( 'Grid', 'themefyre_builder' ),
            'carousel' => __( 'Carousel', 'themefyre_builder' ),
         ),
      );

      $args['attributes']['entrance'] = array(
         'type'    => 'within',
         'title'   => __( 'Animated Entrance', 'themefyre_builder' ),
         'desc'    => __( 'Animated entrance will be applied to each post consecutively.', 'themefyre_builder' ),
         'default' => 'none',
         'options' => $builder->animated_entrance_options,
      );

      $args['attributes']['carousel_scroll_number'] = array(
         'type'        => 'string',
         'title'       => __( 'Posts to Scroll', 'themefyre_builder' ),
         'desc'        => __( 'The number of posts to scroll per slide change. By default this will be equivalent to the number of columns selected. Enter a numeric value only, the value entered here can not exceed the number of columns selected.', 'themefyre_builder' ),
         'placeholder' => __( '(same as number of columns)', 'themefyre_builder' ),
      );

      $args['attributes']['carousel_pager'] = array(
         'type'    => 'bool',
         'title'   => __( 'Pager Navigation', 'themefyre_builder' ),
         'label'   => __( 'Enable the carousel pager control', 'themefyre_builder' ),
         'default' => 'true',
      );

      $args['attributes']['carousel_auto'] = array(
         'type'  => 'bool',
         'title' => __( 'Automatically Change Slides', 'themefyre_builder' ),
         'label' => __( 'Automatically change slides at an interval you set.', 'themefyre_builder' ),
      );

      $args['attributes']['carousel_hover_pause'] = array(
         'type'    => 'bool',
         'title'   => __( 'Pause On Hover', 'themefyre_builder' ),
         'label'   => __( 'Pause the carousel while it is moused over.', 'themefyre_builder' ),
         'default' => 'true',
      );

      $args['attributes']['carousel_interval'] = array(
         'type'        => 'string',
         'title'       => __( 'Slide Change Interval', 'themefyre_builder' ),
         'desc'        => __( 'The amount of time between each automatic slide change. Enter a <strong>numeric</strong> value only in <strong>milliseconds</strong>. 1000 milliseconds = 1 second.', 'themefyre_builder' ),
         'placeholder' => '4000',
      );

      parent::__construct( $args );
   }

   /**
    * Callback function for providing a list of available project categories
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @return array
    */
   public function get_categories() {
      $options = array( 'none' => __( '(all categories)', 'themefyre_builder' ) );
      $terms = get_terms('project_category');
      if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
         foreach ( $terms as $category ) {
            $options[$category->term_id] = $category->name . ' ('.$category->count.')';
         }
      }
      return $options;
   }

   /**
    * Loads inline JavaScript for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function builder_inline_script() {
      ?>
         <script>
            (function($) {
               $(document).on('change', '#builder_recent_projects-style', function(event) {
                  var style = $(this).val(),
                      $gridControls = $('#attribute-builder_recent_projects-entrance'),
                      $carouselControls = $('#attribute-builder_recent_projects-carousel_scroll_number, #attribute-builder_recent_projects-carousel_pager, #attribute-builder_recent_projects-carousel_auto');

                  if ( 'grid' === style ) {
                     themefyreBuilder.enableControl( $gridControls, event );
                     themefyreBuilder.disableControl( $carouselControls, event );
                     themefyreBuilder.disableControl( $('#attribute-builder_recent_projects-carousel_hover_pause, #attribute-builder_recent_projects-carousel_interval'), event );
                  }
                  else if ( 'carousel' === style ) {
                     themefyreBuilder.enableControl( $carouselControls, event );
                     themefyreBuilder.disableControl( $gridControls, event );
                     if ( $('#builder_recent_projects-carousel_auto').prop('checked') ) {
                        themefyreBuilder.enableControl( $('#attribute-builder_recent_projects-carousel_hover_pause, #attribute-builder_recent_projects-carousel_interval'), event );
                     }
                     else {
                        themefyreBuilder.disableControl( $('#attribute-builder_recent_projects-carousel_hover_pause, #attribute-builder_recent_projects-carousel_interval'), event );
                     }
                  }
               });
               $(document).on('change', '#builder_recent_projects-carousel_auto', function(event) {
                  if ( $(this).prop('checked') ) {
                     themefyreBuilder.enableControl( $('#attribute-builder_recent_projects-carousel_hover_pause, #attribute-builder_recent_projects-carousel_interval'), event );

                     // Scroll the custom style controls into view
                     if ( undefined !== event.originalEvent ) {
                        var $scrollBox = $(this).closest('.builder-modal-content');
                        setTimeout( function() {
                           $scrollBox.animate( {
                              scrollTop: $scrollBox.prop('scrollHeight'),
                           }, 250 );
                        }, 255 );
                     }
                  }
                  else {
                     themefyreBuilder.disableControl( $('#attribute-builder_recent_projects-carousel_hover_pause, #attribute-builder_recent_projects-carousel_interval'), event );
                  }
               });
            }(jQuery));
         </script>
      <?php
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      global $post;
      extract( $atts );

      // Grab all queried posts
      $all_posts = get_posts( array(
         'post_type'        => 'project',
         'posts_per_page'   => $number_posts ? $number_posts : $columns,
         'project_category' => 'none' !== $category ? $category : '',
      ) );

      $config_class = $config_data = '';
      if ( 'grid' === $style ) {
         $extra_class = 'builder-posts-grid builder-grid-'.$columns;
      }
      else if ( 'carousel' === $style ) {
         $carousel_scroll_number = intval( $carousel_scroll_number );
         $carousel_scroll_number = $carousel_scroll_number && $carousel_scroll_number < $columns ? $carousel_scroll_number : $columns;
         $extra_class = 'builder-posts-carousel builder-carousel';
         $config_data = ' data-carousel-columns="'.$columns.'" data-carousel-pager="'.$carousel_pager.'" data-carousel-scroll-number="'.$carousel_scroll_number.'"';
         if ( builder_get_bool( $carousel_auto ) ) {
            $interval = $carousel_interval ? intval( $carousel_interval ) : 4000;
            $config_data .= ' data-interval="'.$interval.'" data-hoverpause="'.$carousel_hover_pause.'"';
         }
      }
      if ( 'none' !== $column_spacing ) {
         $extra_class .= ' spacing-'.$column_spacing;
      }

      $classes = builder_compile_html_class('builder-recent-projects builder-recent-posts', $extra_class, $class );
      $out = '<div class="'.$classes.'" id="'.$id.'"'.$config_data.$inline_attributes.'>';
      foreach ( $all_posts as $post ) {
         setup_postdata( $post );
         $thumbnail_style = $thumbnail_class = '';
         if ( has_post_thumbnail() && $img_info = wp_get_attachment_image_src( get_post_thumbnail_id(), 'builder-posts-carousel' ) ) {
            $thumbnail_style = ' style="background-image:url('.$img_info[0].');"';
            $thumbnail_class = ' builder-bg-scale';
         }
         if ( 'grid' === $style ) {
            $out .= '<div>';
         }
         else if ( 'carousel' === $style ) {
            $out .= '<div class="builder-carousel-item">';
         }
         $out .= '<a href="'.get_permalink().'">';
         $out .= '<div class="post-thumbnail'.$thumbnail_class.'"'.$thumbnail_style.'></div>';
         $out .= '<div class="post-caption">';
         $out .= '<span class="post-title">'.get_the_title().'</span>';
         $out .= '<span class="post-date">'.get_the_date().'</span>';
         $out .= '</div>';
         $out .= '</a>';
         $out .= '</div>';
      }
      wp_reset_postdata();
      $out .= '</div>';

      return $out;
   }

}