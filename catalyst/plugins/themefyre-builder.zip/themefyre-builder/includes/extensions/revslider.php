<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_revslider` and `builder_full_width_revslider` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 * @uses builder_is_plugin_active()
 */
function builder_add_revslider_shortcodes() {

  // Make sure the RevSlider plugin is active
  if ( ! builder_is_plugin_active('revslider/revslider.php') ) {
    return;
  }

  builder_add_shortcode('Builder_RevSlider_Shortcode', 'builder_revslider');
  builder_add_shortcode('Builder_Full_Width_RevSlider_Shortcode', 'builder_full_width_revslider');
}
add_action('init', 'builder_add_revslider_shortcodes');

/**
 * Returns an associative array containing a list of available Revolution Sliders
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @return array
 */
function builder_get_available_revsliders() {
  global $wpdb;

   $available_sliders = array(
      'none' => __('None', 'themefyre_builder'),
   );

   $table_name = $wpdb->prefix.'revslider_sliders';

   // Check if table exists
   if ( $wpdb->get_var("SHOW TABLES LIKE '$table_name'") == $table_name ) {
      if ( $revsliders = $wpdb->get_results("SELECT * FROM $table_name") ) {
         foreach ( $revsliders as $slider ) {
            if ( empty($slider->alias) ) {
               continue;
            }
            $available_sliders[$slider->alias] = ! empty($slider->title) ? $slider->title : $slider->alias;
         }
      }
   }

   return $available_sliders;
}

/**
 * RevSlider Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_RevSlider_Shortcode extends Builder_Shortcode {

   /**
    * Builder_RevSlider_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular' => __( 'Revolution Slider', 'themefyre_builder' ),
         'plural'   => __( 'Revolution Sliders', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_revslider',
         'icon'            => 'images-alt2',
         'builder_role'    => 'content',
         'builder_source'  => 'Revolution Slider',
      );

      $args['attributes']['slider_alias'] = array(
         'type'    => 'within',
         'title'   => __( 'Which Revolution Slider', 'themefyre_builder' ),
         'desc'    => __( 'Which Revolution Slider should be displayed here.', 'themefyre_builder' ),
         'default' => 'none',
         'options' => 'builder_get_available_revsliders',
      );

      parent::__construct( $args );
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      if ( empty($slider_alias) || 'none' == $slider_alias ) {
         return '';
      }
      $classes = builder_compile_html_class('builder-revslider', $class);
      return '<div class="'.$classes.'" id="'.$id.'">'.do_shortcode("[rev_slider {$slider_alias}]").'</div>';
   }

}

/**
 * Full Width RevSlider Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Full_Width_RevSlider_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Full_Width_RevSlider_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular' => __( 'Full Width Revolution Slider', 'themefyre_builder' ),
         'plural'   => __( 'Full Width Revolution Sliders', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_full_width_revslider',
         'icon'            => 'images-alt2',
         'builder_role'    => 'full-width',
         'builder_source'  => 'Revolution Slider',
      );

      $args['attributes']['slider_alias'] = array(
         'type'    => 'within',
         'title'   => __( 'Which Revolution Slider', 'themefyre_builder' ),
         'desc'    => __( 'Which Revolution Slider should be displayed here.', 'themefyre_builder' ),
         'default' => 'none',
         'options' => 'builder_get_available_revsliders',
      );

      parent::__construct( $args );
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      if ( empty($slider_alias) || 'none' == $slider_alias ) {
         return '';
      }
      $classes = builder_compile_html_class('builder-full-width-revslider', $class);
      return '<div class="'.$classes.'" id="'.$id.'">'.do_shortcode("[rev_slider {$slider_alias}]").'</div>';
   }

}