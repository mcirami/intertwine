<?php

// No direct access
defined( 'ABSPATH' ) or exit;

// Option to enable the default lightbox script
add_option( 'builder_enable_woocommerce_default_lightbox', false );

// Prevent WooCommerce from loading its native lightbox script
//
// This will allow us to hijack it later with the inlcuded lightbox.
if ( ! get_option('builder_enable_woocommerce_default_lightbox') ) {
   update_option( 'woocommerce_enable_lightbox', false );
}

/**
 * Prints the necessary inline script for adding lightbox support to product pages
 *
 * @since Themefyre Page Builder 0.0.0
 */
function builder_woocommerce_product_lightbox_script() {

   // Make sure we`re visiting a product page
   if ( ! is_product() ) {
      return;
   }

   // Make sure the default lightbox has not been enabled
   if ( get_option('builder_enable_woocommerce_default_lightbox') ) {
      return;
   }
   ?>
      <script>
         ;(function($) {
            // When WooCommerce is enabled we use the builder lightbox script instead
            // of the native WooCommerce script. This will utilize fewer resources,
            // ultimately resulting in better page speeds.
            $(document).ready( function() {
               var $gallery = $('body.woocommerce.single-product .product .images');

               // Make sure there is a product gallery to work with
               if ( ! $gallery.length ) {
                  return;
               }

               // If there is only 1 image in the `gallery`
               if ( 1 === $('a', $gallery).length ) {
                  $('a', $gallery).magnificPopup({
                     key:                 'builder-woocommerce-product-image',
                     midClick:            true,
                     closeBtnInside:      true,
                     fixedContentPos:     false,
                     type:                'image',
                     closeOnContentClick: true,
                     removalDelay: 250,
                     mainClass: 'mfp-zoom-in',
                     callbacks: {
                        open: function() {
                           $.magnificPopup.instance.next = function() {
                              var self = this;
                              self.wrap.removeClass('mfp-image-loaded');
                              setTimeout( function() { $.magnificPopup.proto.next.call( self ); }, 250 );
                           }
                           $.magnificPopup.instance.prev = function() {
                              var self = this;
                              self.wrap.removeClass('mfp-image-loaded');
                              setTimeout( function() { $.magnificPopup.proto.prev.call( self ); }, 250 );
                           }
                        },
                        imageLoadComplete: function() {
                           var self = this;
                           setTimeout(function() { self.wrap.addClass('mfp-image-loaded'); }, 5);
                        },
                     },
                  });
               }

               // If there is more that 1 image in the gallery
               else {
                  $gallery.magnificPopup({
                     key:             'builder-woocommerce-product-gallery',
                     midClick:        true,
                     closeBtnInside:  true,
                     fixedContentPos: false,
                     delegate:        'a',
                     type:            'image',
                     gallery: {
                        enabled: true,
                        tCounter: '<span class="mfp-counter">%curr% / %total%</span>',
                     },
                     removalDelay: 250,
                     mainClass: 'mfp-zoom-in',
                     callbacks: {
                        open: function() {
                           $.magnificPopup.instance.next = function() {
                              var self = this;
                              self.wrap.removeClass('mfp-image-loaded');
                              setTimeout( function() { $.magnificPopup.proto.next.call( self ); }, 250 );
                           }
                           $.magnificPopup.instance.prev = function() {
                              var self = this;
                              self.wrap.removeClass('mfp-image-loaded');
                              setTimeout( function() { $.magnificPopup.proto.prev.call( self ); }, 250 );
                           }
                        },
                        imageLoadComplete: function() {
                           var self = this;
                           setTimeout(function() { self.wrap.addClass('mfp-image-loaded'); }, 5);
                        },
                     },
                  });
               }
            });
         }(jQuery));
      </script>
   <?php
}
add_action( 'wp_footer', 'builder_woocommerce_product_lightbox_script' );

/**
 * Function to remove the option to enable lightbox from the WooCommerce settings page.
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param array $options Existing options array
 * @return array
 */
function builder_woocommerce_filter_settings( $options ) {
   if ( get_option('builder_enable_woocommerce_default_lightbox') ) {
      return $options;
   }
   foreach ( $options as $key => $option ) {
      if ( isset( $option['id'] ) && 'woocommerce_enable_lightbox' === $option['id'] ) {
         unset( $options[$key] );
      }
   }
   return $options;
}
add_filter( 'woocommerce_product_settings', 'builder_woocommerce_filter_settings' );

/**
 * Adds the WooCommerce integration section to the settings page
 *
 * @since Themefyre Page Builder 0.0.0
 */
function builder_woocommerce_settings_admin_init() {
   add_settings_section(
      'woocommerse_settings',
      __('WooCommerce Integration', 'themefyre_builder'),
      'builder_woocommerce_settings_section_description',
      'builder-settings'
   );

   add_settings_field(
      'enable_woocommerce_default_lightbox',
      __('WooCommerce Lightbox', 'themefyre_builder'),
      'builder_enable_woocommerce_default_lightbox_callback',
      'builder-settings',
      'woocommerse_settings'
   );

   register_setting('builder-settings', 'builder_enable_woocommerce_default_lightbox', 'builder_enable_woocommerce_default_lightbox_update' );
}
add_action( 'admin_init', 'builder_woocommerce_settings_admin_init' );

/**
 * Description for the WooCommerce integration section
 *
 * @since Themefyre Page Builder 0.0.0
 */
function builder_woocommerce_settings_section_description() {
   printf( '<p>%s</p>', esc_html__('Themefyre page builder integrates with WooCommerce and allows you to use the included page builder lightbox insead of the one included with WooCommerce. This is to increase page speed and adds consistency to your site. Using the below control you can disable the page builder lightbox for WooCommerce product images, allowing you to enable the lightbox script included with WooCommerce.', 'themefyre_builder') );
}

/**
 * Callback for the lightbox integration control
 *
 * @since Themefyre Page Builder 0.0.0
 */
function builder_enable_woocommerce_default_lightbox_callback() {
   $args = array(
      'type' => 'checkbox',
      'id' => 'builder-enable-woocommerce-default-lightbox',
      'name' => 'builder_enable_woocommerce_default_lightbox',
      'value' => 'enabled',
   );

   if ( get_option('builder_enable_woocommerce_default_lightbox') ) {
      $args['checked'] = 'checked';
   }

   printf( '<label for="builder-enable-woocommerce-default-lightbox">%s</label>', builder_get_input( $args ) . esc_html__( 'Enable the WooCommerce lightbox and disable the page builder lightbox for WooCommerce product images.', 'themefyre_builder' ) );
   printf( '<p class="description">%s</p>', esc_html__('Please note that if this option is checked upon saving changes you may need to navigate to the WooCommerce settings page for "Products" (WooCommerce > Products > Display) from your WordPress dashboard and enable the option for "Product Image Gallery" in order to use the default WooCommerce lightbox.', 'themefyre_builder') );
}

/**
 * Update the lightbox integration control value
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @param string $submitted The submitted value
 * @return bool
 */
function builder_enable_woocommerce_default_lightbox_update( $submitted ) {
   $submitted = 'enabled' === $submitted;

   // If this option was turned off before and is now being turned on
   if ( $submitted && ! get_option('builder_enable_woocommerce_default_lightbox') ) {

      // Reset the WooCommerce enable lightbox option to true
      update_option( 'woocommerce_enable_lightbox', true );
   }
   return $submitted;
}