<?php

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Registers the `builder_layerslider` and `builder_full_width_layerslider` shortcode
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @uses builder_add_shortcode()
 * @uses builder_is_plugin_active()
 */
function builder_add_layerslider_shortcodes() {

  // Make sure the LayerSlider plugin is active
  if ( ! builder_is_plugin_active('LayerSlider/layerslider.php') ) {
    return;
  }

  builder_add_shortcode('Builder_LayerSlider_Shortcode', 'builder_layerslider');
  builder_add_shortcode('Builder_Full_Width_LayerSlider_Shortcode', 'builder_full_width_layerslider');
}
add_action('init', 'builder_add_layerslider_shortcodes');

/**
 * Returns an associative array containing a list of available LayerSliders
 *
 * @since Themefyre Page Builder 0.0.0
 *
 * @return array
 */
function builder_get_available_layersliders() {
   $available_sliders = array(
      'none' => __('None', 'themefyre_builder'),
   );

   if ( method_exists('LS_Sliders', 'find') ) {
      $args = array(
         'orderby' => 'date_m',
         'limit'   => 99999,
         'data'    => false
      );

      foreach ( LS_Sliders::find( $args ) as $slider ) {
         if ( empty($slider['id']) ) {
            continue;
         }
         $available_sliders[$slider['id']] = ! empty($slider['name']) ? $slider['name'] : sprintf( __( 'Unnamed Slider [ID: %s]', 'themefyre_builder' ), $slider['id'] );
      }
   }

   return $available_sliders;
}

/**
 * Full Width LayerSlider Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_Full_Width_LayerSlider_Shortcode extends Builder_Shortcode {

   /**
    * Builder_Full_Width_LayerSlider_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular' => __( 'Full Width LayerSlider', 'themefyre_builder' ),
         'plural'   => __( 'Full Width LayerSliders', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_full_width_layerslider',
         'icon'            => 'images-alt2',
         'builder_role'    => 'full-width',
         'builder_source'  => 'LayerSlider WP',
      );

      $args['attributes']['slider_id'] = array(
         'type'    => 'within',
         'title'   => __( 'Which LayerSlider', 'themefyre_builder' ),
         'desc'    => __( 'Which LayerSlider should be displayed here.', 'themefyre_builder' ),
         'default' => 'none',
         'options' => 'builder_get_available_layersliders',
      );

      parent::__construct( $args );
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      if ( empty($slider_id) || 'none' == $slider_id ) {
         return '';
      }
      $classes = builder_compile_html_class('builder-full-width-layerslider', $class);
      return '<div class="'.$classes.'" id="'.$id.'">'.do_shortcode('[layerslider id="'.$slider_id.'"]').'</div>';
   }

}

/**
 * LayerSlider Shortcode Class
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
class Builder_LayerSlider_Shortcode extends Builder_Shortcode {

   /**
    * Builder_LayerSlider_Shortcode Constructor.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __construct() {
      $labels = array(
         'singular' => __( 'LayerSlider', 'themefyre_builder' ),
         'plural'   => __( 'LayerSliders', 'themefyre_builder' ),
      );

      $args = array(
         'labels'          => $labels,
         'tag'             => 'builder_layerslider',
         'icon'            => 'images-alt2',
         'builder_role'    => 'content',
         'builder_source'  => 'LayerSlider WP',
      );

      $args['attributes']['slider_id'] = array(
         'type'    => 'within',
         'title'   => __( 'Which LayerSlider', 'themefyre_builder' ),
         'desc'    => __( 'Which LayerSlider should be displayed here.', 'themefyre_builder' ),
         'default' => 'none',
         'options' => 'builder_get_available_layersliders',
      );

      parent::__construct( $args );
   }

   /**
    * Callback function for front end display of shortcode.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    *
    * @param array $atts Array of provided attributes.
    * @param string $content Any content provided for shortcode. (default: null)
    * @return string
    */
   public function shortcode( $atts, $content = null, $tag = '' ) {
      extract( $atts );
      if ( empty($slider_id) || 'none' == $slider_id ) {
         return '';
      }
      $classes = builder_compile_html_class('builder-full-width-layerslider', $class);
      return '<div class="'.$classes.'" id="'.$id.'">'.do_shortcode('[layerslider id="'.$slider_id.'"]').'</div>';
   }

}