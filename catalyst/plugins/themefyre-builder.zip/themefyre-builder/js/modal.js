// Ensure availability of the global themefyreBuilder object
window.themefyreBuilder = window.themefyreBuilder || {};

(function($, _) {
   "use strict";

   // Adds the container element for the modals
   $(document).ready( function() {
      var $container = $('<div />', { id:"builder-admin-modals-absolute-container" });

      // Closing only the top modal
      $container.on('cancelmodalstop', function() {
         var $modals = $container.children('.builder-admin-modal');
         if ( $modals.length ) {
            $modals.last().trigger('modalcancel');
         }
      });

      // Closing all modals
      $container.on('cancelmodalsall', function() {
         var $modals = $container.children('.builder-admin-modal');
         if ( $modals.length ) {
            $modals.trigger('modalcancel');
         }
      });

      // Revealing the loader
      $container.on('appendloader', function() {
         $container.trigger('removeloader').append('<div id="builder-admin-modals-loading"></div>');
         $container.trigger('contentupdated');
      });

      // Removing the loader
      $container.on('removeloader', function() {
         var $loader = $('#builder-admin-modals-loading');
         if ( $loader.length ) {
            $loader.remove();
         }
         $container.trigger('contentupdated');
      });

      // Pressing the black area around the modals
      $container.on('mousedown', function(event) {
         if ( 'builder-admin-modals-absolute-container' === event.target.id ) {
            $container.trigger('cancelmodalstop');
         }
      });

      // When the content of the container is updated
      $container.on('contentupdated', function() {
         var $children = $container.children();
         $children.filter('.builder-admin-modal').addClass('modal-in-background');
         $children.last().removeClass('modal-in-background');
         if ( $children.length ) {
            $('body').addClass('builder-admin-modal-active');
         }
         else {
            $('body').removeClass('builder-admin-modal-active');
         }
      });

      // Finally, add the container
      $('body').append( $container );
   });

   // Keyboard functionality for active modals
   $(document).on('keydown', function(event) {

      // Do not do anything if a WordPress modal is open, or if there is no TF modal open
      if ( $('body').hasClass('modal-open') || ! $('body').hasClass('builder-admin-modal-active') ) {
         return;
      }

      switch (event.keyCode) {

         // ESC Key
         case 27:
            $('#builder-admin-modals-absolute-container').trigger('cancelmodalstop');
            event.stopImmediatePropagation();
            event.preventDefault();
            break;

         // ENTER Key
         case 13:
            if ( 'textarea' !== event.target.tagName.toLowerCase() ) {
               var $modals = $('#builder-admin-modals-absolute-container').children('.builder-admin-modal');
               if ( $modals.length && $modals.last().hasClass('has-confirm') ) {
                  $modals.last().trigger('modalconfirm');
                  event.stopImmediatePropagation();
                  event.preventDefault();
               }
            }
            break;
      }
   });

   // Themefyre Page Builder Modal Functionality
   //
   // Mostly used for the Shortcode Composer/Page Builder.
   themefyreBuilder.builderModal = function( options ) {
      var defaults = {
         title: "",                 // Displayed title for the modal window
         id: "",                    // Add a custom ID attribute to the modal, will be prepended with `builder-admin-modal-`
         add_class: "",             // Any additional classes to be applied to the outermost container
         content: null,             // Preloaded content in string form, if none is provided the AJAX callback will be used
         ajax_callback: "",         // Name of PHP AJAX hook registered with WordPress to get the content from
         show_confirm: false,       // Whether or not the `Confirm` button should be displayed
         on_open: function() {},    // Function that is called once the modal is loaded and opened
         on_cancel: function() {},  // Function that is always called once the modal is canceled
         on_close: function() {},   // Function that is always called once the modal is closed
         on_confirm: function() {}, // Function that is only called when the user presses the `confirm` button
      };

      // Create the options object
      this.options = $.extend({}, defaults, options);

      // Start the admin modal instance
      this.init();
   };

   _.extend( themefyreBuilder.builderModal.prototype, {

      // Start the admin modal instance
      init: function() {
         var self = this;

         // Check if content has already been supplied
         if ( self.options.content ) {
            self.open_modal( self.options.content );
         }

         // If not, check for an AJAX callback
         else if ( self.options.ajax_callback ) {

            // Append the loader
            self.append_loader();

            var data = {
               action: 'builder_ajax_'+self.options.ajax_callback
            };

            // Execute AJAX callback
            $.ajax({
               type: 'POST',
               url: builderModalLocalize.ajax_url,
               data: data,
               error: function() {
                  alert(builderModalLocalize.ajax_error);
               },
               success: function( response ) {

                  // User was logged out
                  if ( 0 === response ) {
                     alert(builderModalLocalize.ajax_logged_out);
                  }

                  // Nonce timeout
                  else if ( '-1' === response ) {
                     alert(builderModalLocalize.ajax_nonce_error);
                  }

                  // We made it here, open the modal
                  self.open_modal( response );
               },
               complete: function() {
                  self.remove_loader();
               }
            });
         }
      },

      // Creates and returns the complete modal jQuery object
      create_modal: function( modal_content ) {
         var self = this;

         // Modal wrapper
         var $modal = $('<div />', { "class":"builder-admin-modal" });

         // If the modal contains tabs
         if ( $('.builder-modal-tab', $(modal_content)).length ) {
            $modal.addClass('modal-has-tabs');
         }

         // Add any additionally supplied classes
         $modal.addClass(self.options.add_class);

         // Modal header
         var $header = $('<header />', { "class":"builder-modal-header" });

         // Add the title
         if ( self.options.title ) {
            var $title = $('<h2 />', { "class":"builder-modal-title", text:self.options.title });
            $header.append( $title );
         }

         // Modal menu
         var $menu = $('<div />', { "class":"builder-modal-menu" });

         // Add the confirm button
         if ( self.options.show_confirm ) {
            var $confirm = $('<button />', { "class":"builder-modal-button modal-confirm", html:'<span class="dashicons dashicons-yes"></span>', type:'button' });
            $menu.append( $confirm );
            $modal.addClass('has-confirm');
         }

         // Add the cancel button
         var $cancel = $('<button />', { "class":"builder-modal-button modal-cancel", html:'<span class="dashicons dashicons-no-alt"></span>', type:'button' });
         $menu.append( $cancel );

         // Add the menu to the header, and the header to the modal
         $header.append( $menu );
         $modal.append( $header );

         // Add the modal body
         var $body = $('<div />', { "class":"builder-modal-body", html:'<div class="builder-modal-content">'+modal_content+'</div>' });
         $modal.append( $body );

         self.attach_events( $modal );

         return $modal;
      },

      // Makes sure the right functions happen at the right time
      attach_events: function( $modal ) {
         var self = this;

         // Pressing the `Cancel` button
         $modal.on('click', '.modal-cancel', function(event) {
            event.preventDefault();
            $modal.trigger('modalcancel');
         });

         // If the confirm button has been enabled
         if ( self.options.show_confirm ) {
            $modal.on('click', '.modal-confirm', function(event) {
               event.preventDefault();
               $modal.trigger('modalconfirm');
            });
         }

         // When the modal is confirmed
         $modal.on('modalconfirm', function() {
            try {
               if ( false !== self.options.on_confirm( $modal ) ) {
                  self.remove_modal( $modal );
               }
            }
            catch( error ) {
               console.log( error );
               alert(builderModalLocalize.close_error);
            }
         });

         // Close the modal
         $modal.on('modalcancel', function() {
            try {
               if ( false !== self.options.on_cancel( $modal ) ) {
                  self.remove_modal( $modal );
               }
            }
            catch( error ) {
               console.log( error );
               alert(builderModalLocalize.close_error);
            }
         });

         // Set up the tabs, if any are found
         var $tabs = $('.builder-modal-tab', $modal), $panes = $('.builder-modal-pane', $modal);
         if ( $tabs.length && $panes.length ) {
            $modal.addClass('no-padding');
            $tabs.removeClass('is-active').first().addClass('is-active');
            $panes.removeClass('is-active').first().addClass('is-active');
            $tabs.children('button').on('click', function() {
               var $this = $(this), id = $this.data('tab');
               $this.parent().addClass('is-active').siblings().removeClass('is-active');
               $panes.filter('[data-pane="'+id+'"]').addClass('is-active').siblings().removeClass('is-active');
               $modal.trigger('changetab');
               $modal.trigger('changetab'+id);
            });
         }
      },

      // Adds a modal with the specified content
      open_modal: function( modal_content ) {
         var $modal = this.create_modal( modal_content );
         var $container = $('#builder-admin-modals-absolute-container');
         var $tabs = $('.builder-modal-tab', $modal);

         // Set CSS based on number of other modals
         var $siblings = $container.children('.builder-admin-modal');
         var num_siblings = $siblings.length;
         var width = 800-(35*num_siblings);
         var height = window.innerHeight-(35*(num_siblings+1));

         $modal.css({
            height: height+'px',
            marginTop: -height/2+'px',
            maxWidth: width+'px',
            marginLeft: -width/2+'px',
         });

         // Apply the modal opening class
         $modal.addClass('modal-is-opening');

         // Set the height of the scrollable content
         $modal.children('.builder-modal-body').css('height', (height-55)+'px');

         // Check for errors
         try {

            // Finally, open the modal
            $container.append( $modal ).trigger('contentupdated');

            this.options.on_open( $modal );

            setTimeout( function() {
               $modal.removeClass('modal-is-opening');
            }, 5);

            // If there is at least 1 tab we need to trigger a click event
            // on the first one to ensure any events attached to this event
            // will fire and the pane will be displayed correctly
            if ( $tabs.length ) {
               setTimeout( function() {
                  $('button', $tabs.eq(0))[0].click();
               }, 250);
            }
         }
         catch( error ) {
            $modal.remove();
            $container.trigger('contentupdated');
            alert(builderModalLocalize.open_error);
         }

      },

      // Removes a modal using it`s jQuery object
      remove_modal: function( $modal ) {
         var self = this;
         setTimeout( function() {
            try {
               if ( false !== self.options.on_close( $modal ) ) {
                  $modal.trigger('modalbeforeremove');
                  $modal.remove();
                  $('#builder-admin-modals-absolute-container').trigger('contentupdated');
               }
            }
            catch( error ) {
               alert(builderModalLocalize.close_error);
            }
         }, 5);
      },

      // Appends the loading indicator to the absolute container
      append_loader: function() {
         $('#builder-admin-modals-absolute-container').trigger('appendloader');
      },

      // Removes the loading indicator
      remove_loader: function() {
         $('#builder-admin-modals-absolute-container').trigger('removeloader');
      }

   });

}(jQuery, _));