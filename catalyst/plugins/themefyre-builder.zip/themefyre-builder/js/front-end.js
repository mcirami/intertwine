// Ensure availability of the global themefyreBuilder object
window.themefyreBuilder = window.themefyreBuilder || {};

;(function($, _) {
   "use strict";

   // ======================================================
   //
   // General utility functions
   //
   // ======================================================

   // HTML5 Video backgrounds are disabled on nearly all modile devices & browsers
   themefyreBuilder.isMobile = function() {
      if ( 'undefined' === typeof navigator || 'undefined' === typeof navigator.userAgent ) {
         return false;
      }
      return navigator.userAgent.match(/(Android|iPod|iPhone|iPad|IEMobile|Opera Mini)/);
   };

   // Simple check to determine if we`re in RTL mode
   themefyreBuilder.isRtl = function() {
      return 'rt' === $('html').attr('dir');
   };

   // Convert provided value to bool format
   themefyreBuilder.getBool = function( input ) {
      return 'boolean' === typeof input ? input : 'true' === input;
   };

   // Custom setTimeout method which allows pause/resume functionality
   themefyreBuilder.setTimeout = function( callback, delay ) {
      var timerId, start, remaining = delay;

      this.pause = function() {
         window.clearTimeout(timerId);
         remaining -= new Date() - start;
      };

      this.resume = function() {
         start = new Date();
         window.clearTimeout(timerId);
         timerId = window.setTimeout(callback, remaining);
      };

      this.end = function() {
         window.clearTimeout(timerId);
      };

      this.resume();
   };

   // ======================================================
   //
   // Some mobile devices do not support fixed background images
   //
   // As a result all fixed background images are disabled on mobile devices
   // hopefully this can be removed in future versions of this plugin.
   //
   // ======================================================

   $(document).ready( function() {
      if ( themefyreBuilder.isMobile() ) {
         $('body').addClass('builder-disabled-fixed-backgrounds');
      }
   });

   // ======================================================
   //
   // Make sure the .JS class is applied to the body
   //
   // This line of script should be placed in the header file
   // of the theme immediately following the opening `body` tag.
   //
   // Example:
   //
   // <body <?php body_class(); ?>>
   // <script>document.body.className = document.body.className.replace('no-js','js');</script>
   //
   // ======================================================

   $(document).ready( function() {
      document.body.className = document.body.className.replace('no-js','js');
   });

   // ======================================================
   //
   // Initially set up the page
   //
   // Can be called after content is loaded dynamically via AJAX
   // to set up any newly added content.
   //
   // ======================================================

   // Invokes all functions for setting up the document
   themefyreBuilder.setupDocument = function() {
      themefyreBuilder.classifyFullWidthModules();
      themefyreBuilder.addShortcodes();
      themefyreBuilder.addSmoothScroll();
      themefyreBuilder.addMasonry();
      themefyreBuilder.addCarousels();
      themefyreBuilder.addSliders();
      themefyreBuilder.addHTML5VideoBackgrounds();
      themefyreBuilder.addFitVids();
      themefyreBuilder.addLightbox();
      themefyreBuilder.addAnimatedEntrances();
      themefyreBuilder.addParallaxScrolling();
   };

   // Called once upon page load
   $(document).ready( function() {
      themefyreBuilder.setupDocument();

      // Once all images in the page have loaded we call our initialization
      // function once again just to be sure all of our parallax scrolling
      // and animated entrance modules were set up correctly.
      $('body').imagesLoaded( themefyreBuilder.setupDocument );
   });

   // ======================================================
   //
   // Applies identification classes to each full width module
   //
   // ======================================================

   // Applies identification classes to each full width module
   // in order to classify them by their order and visibility
   themefyreBuilder.classifyFullWidthModules = function() {
      $('.builder-container').each( function() {
         var $modules = $('.builder-full-width-element', $(this) ).removeClass('builder-full-width-element-first builder-full-width-element-last').removeAttr('data-element-index').filter(':visible'), total = $modules.length;
         $modules.each( function( index ) {

            // Add 1 to the index for simpification
            index++;

            // General index identification
            $(this).attr('data-element-index', index);

            // Identify the first visible full width module
            if ( 1 === index ) {
               $(this).addClass('builder-full-width-element-first');
            }

            // Identify the last visible full width module
            if ( total === index ) {
               $(this).addClass('builder-full-width-element-last');
            }
         });
      });
   };

   // Needs to be called whenever the screen is resized to account for
   // variances in device visibility applied to full width modules
   $(document).ready( function() {
      $(window).resize( themefyreBuilder.classifyFullWidthModules );
   });

   // ======================================================
   //
   // Initially set up all shortcode plugins
   //
   // ======================================================

   // Instantiate all included jQuery shortcode plugins
   themefyreBuilder.addShortcodes = function() {
      $('.builder-toggle-group').themefyreBuilderToggleGroup();
      $('.builder-tab-group').themefyreBuilderTabGroup();
      $('.builder-promo-box').themefyreBuilderPromoBox();
      $('.builder-google-map').themefyreBuilderGoogleMap();
      $('.builder-full-width-slider').themefyreBuilderFullWidthSlider();
   };

   // ======================================================
   //
   // Smooth Scroll Links
   //
   // ======================================================


   themefyreBuilder.addSmoothScroll = function() {
      return $('.builder-container a[href*="#"]:not([href="#"]):not(.builder-disable-smooth-scroll)').each( function() {
         if ( location.pathname.replace(/^\//,'') !== this.pathname.replace(/^\//,'')|| location.hostname !== this.hostname) {
            return;
         }
         if ( ! $.data( this, 'smoothScroll' ) ) {
            $.data( this, 'smoothScroll', new themefyreBuilder.smoothScroll( this ) );
         }
      });
   };

   themefyreBuilder.smoothScroll = function( element ) {
      $(element).click( function( event ) {
         var $target = $(element.hash);
         if ( $target.length ) {
            $('html,body').animate({
               scrollTop: $target.offset().top-themefyreBuilder.scrollTopOffset+1,
            }, 1250, function() {
               window.location.hash = element.hash;
            });
            return false;
         }
      });
   };

   // ======================================================
   //
   // Masonry Galleries
   //
   // ======================================================

   themefyreBuilder.addMasonry = function() {
      return $('.builder-masonry').each( function() {
         if ( ! $.data( this, 'builderMasonry' ) ) {
            $.data( this, 'builderMasonry', new themefyreBuilder.builderMasonry( this ) );
         }
      });
   };

   themefyreBuilder.builderMasonry = function( element ) {
      $(element).imagesLoaded( function() {
         self.masonry = new Masonry( element, {
            isOriginLeft: ! themefyreBuilder.isRtl(),
            transitionDuration: 0,
         });
      });
   };

   // ======================================================
   //
   // Initially set up all Carousel elements
   //
   // ======================================================

   // Instantiate all HTML5 Video Backgrounds
   themefyreBuilder.addCarousels = function() {
      return $('.builder-carousel').each( function() {
         if ( ! $.data( this, 'builderCarousel' ) ) {
            $.data( this, 'builderCarousel', new themefyreBuilder.builderCarousel( this ) );
         }
      });
   };

   themefyreBuilder.builderCarousel = function( element ) {
      this.$element = $(element);
      this.element = element;
      this.init();
   };

   _.extend( themefyreBuilder.builderCarousel.prototype, {
      init: function() {
         var slidesToShow = this.$element.attr('data-carousel-columns') ? parseInt( this.$element.attr('data-carousel-columns') ) : 4,
             slidesToScroll = this.$element.attr('data-carousel-scroll-number') ? parseInt( this.$element.attr('data-carousel-scroll-number') ) : slidesToShow,
             interval = this.$element.attr('data-interval') ? parseInt( this.$element.attr('data-interval').replace(/[^0-9]/, '') ) : false,
             pauseOnHover = interval && 'true' === this.$element.attr('data-hoverpause'),
             pager = 'true' === this.$element.attr('data-carousel-pager');

         var args = {
            slidesToShow: slidesToShow,
            slidesToScroll: slidesToScroll,
            arrows: false,
            dots: pager,
            infinite: true,
            rtl: themefyreBuilder.isRtl(),
            adaptiveHeight: true,
         };

         // If auto play is enabled
         if ( interval ) {
            args.autoplay = true;
            args.autoplaySpeed = interval;
            args.pauseOnHover = pauseOnHover;
         }

         // Enable responsive mode
         switch ( slidesToShow ) {
            case 6: case 5:
               args.responsive = [
                  {
                     breakpoint: 992,
                     settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3,
                     }
                  },
                  {
                     breakpoint: 480,
                     settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                     }
                  },
               ];
               break;
            case 4: case 3:
               args.responsive = [
                  {
                     breakpoint: 992,
                     settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2,
                     }
                  },
                  {
                     breakpoint: 480,
                     settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                     }
                  },
               ];
               break;
            case 2:
               args.responsive = [
                  {
                     breakpoint: 480,
                     settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                     }
                  },
               ];
               break;
         }

         // Activate Slick jQuery plugin
         this.$element.slick( args );

         // Tell the CSS that the plugin has loaded
         this.$element.addClass('js-plugin-loaded');
      }
   });

   // ======================================================
   //
   // Initially set up all Slider elements
   //
   // ======================================================

   // Instantiate all HTML5 Video Backgrounds
   themefyreBuilder.addSliders = function() {
      return $('.builder-slider').each( function() {
         if ( ! $.data( this, 'builderSlider' ) ) {
            $.data( this, 'builderSlider', new themefyreBuilder.builderSlider( this ) );
         }
      });
   };

   themefyreBuilder.builderSlider = function( element ) {
      this.$element = $(element);
      this.element = element;
      this.init();
   };

   _.extend( themefyreBuilder.builderSlider.prototype, {
      init: function() {
         var interval = this.$element.attr('data-interval') ? parseInt( this.$element.attr('data-interval').replace(/[^0-9]/, '') ) : false,
             pauseOnHover = interval && 'true' === this.$element.attr('data-hoverpause'),
             transition = this.$element.attr('data-transition') ? this.$element.attr('data-transition') : 'slide',
             arrows = -1 !== _.indexOf( ['both', 'direction'], this.$element.attr('data-controls') ),
             dots = -1 !== _.indexOf( ['both', 'pager'], this.$element.attr('data-controls') );

         var args = {
            arrows: arrows,
            dots: dots,
            infinite: true,
            rtl: themefyreBuilder.isRtl(),
            adaptiveHeight: true,
         };

         // If auto play is enabled
         if ( interval ) {
            args.autoplay = true;
            args.autoplaySpeed = interval;
            args.pauseOnHover = pauseOnHover;
         }

         // Enable fade mode
         if ( 'fade' === transition ) {
            args.fade = true;
            args.cssEase = 'linear';
         }

         if ( true ) {
            args.prevArrow = '<button type="button" class="slick-prev"><span class="screen-reader-text">Previous</span><span class="css-arrow"></span></button>';
            args.nextArrow = '<button type="button" class="slick-next"><span class="screen-reader-text">Next</span><span class="css-arrow"></span></button>';
         }

         // Activate Slick jQuery plugin
         this.$element.slick( args );

         // Tell the CSS that the plugin has loaded
         this.$element.addClass('js-plugin-loaded');
      }
   });

   // ======================================================
   //
   // Initially set up all HTML5 Video Backgrounds
   //
   // ======================================================

   // Instantiate all HTML5 Video Backgrounds
   themefyreBuilder.addHTML5VideoBackgrounds = function() {

      // Make sure HTML5 video backgrounds are enabled for the current device
      if ( themefyreBuilder.isMobile() ) {
         $('body').addClass('builder-html5-video-backgrounds-disabled');
         $('.builder-html5-video-bg').remove();
         return;
      }

      // Set up each video background
      return $('.builder-html5-video-bg').each( function() {
         if ( ! $.data( this, 'HTML5VideoBackground' ) ) {
            $.data( this, 'HTML5VideoBackground', new themefyreBuilder.HTML5VideoBackground( this ) );
         }
      });
   };

   themefyreBuilder.HTML5VideoBackground = function( player ) {
      this.$player = $(player);
      this.player = player;
      this.$container = this.$player.parent();
      this.init();
   };

   _.extend( themefyreBuilder.HTML5VideoBackground.prototype, {
      init: function() {

         if ( this.player.readyState >= this.player.HAVE_FUTURE_DATA ) {
            this.playerLoaded();
         }
         else {
            this.$player.on( 'canplay', _.once( $.proxy(this.playerLoaded, this) ) );
         }
      },

      playerLoaded: function() {

         // Apply the ready class to thie video player
         this.$player.addClass('is-ready');

         // Initially set the size of the player
         this.setWidth();

         // Resize the player whenever the window is resized
         $(window).resize( $.proxy(this.setWidth, this) );

         this.player.play();
      },

      setWidth: function() {

         // Remove any styles to ensure the natural proportions are retained
         this.$player.removeAttr('style');

         // Set up some variables for determining the video size
         var boxWidth = this.$container.outerWidth(),
             boxHeight = this.$container.outerHeight(),
             playerWidth = this.$player.width(),
             playerHeight = this.$player.height();

         // Calculate new height and width
         var initW = playerWidth;
         var initH = playerHeight;
         var ratio = initH / initW;

         playerWidth = boxWidth;
         playerHeight = boxWidth * ratio;

         if ( playerHeight < boxHeight ) {
            playerHeight = boxHeight;
            playerWidth = playerHeight / ratio;
         }

         this.$player.css({
            width: playerWidth+'px',
            height: playerHeight+'px',
            marginLeft: -(playerWidth/2)+'px',
            marginTop: -(playerHeight/2)+'px',
         });
      },
   });

   // ======================================================
   //
   // Set Up embedded videos with FitVids
   //
   // ======================================================

   themefyreBuilder.addFitVids = function() {
      $('.builder-container').fitVids();
   };

   // ======================================================
   //
   // Set Up Lightboxes using Magnific Popup
   //
   // ======================================================

   themefyreBuilder.lightboxInstances = 0;

   // Instantiate all elements utilizing lightbox functionality
   themefyreBuilder.addLightbox = function() {
      $('.builder-lightbox-image, .builder-lightbox-iframe, .builder-lightbox-gallery, [data-builder-lightbox-role="image"], [data-builder-lightbox-role="iframe"], [data-builder-lightbox-role="gallery"]').each( function() {
         if ( $.data( this, 'lightbox' ) ) {
            return;
         }
         $.data( this, 'lightbox', true );

         themefyreBuilder.lightboxInstances++;

         var role;

         var $this = $(this);

         // Role provided via class
         if ( $this.hasClass('builder-lightbox-image') ) {
            role = 'image';
         }
         if ( $this.hasClass('builder-lightbox-iframe') ) {
            role = 'iframe';
         }
         if ( $this.hasClass('builder-lightbox-gallery') ) {
            role = 'gallery';
         }

         // Role provided via HTML data attribute
         if ( $this.data('builder-lightbox-role') ) {
            role = $this.data('builder-lightbox-role');
         }

         var args = {
            key: 'builder-lightbox-'+themefyreBuilder.lightboxInstances,
            midClick: true,
            closeBtnInside: true,
            fixedContentPos: false,
            removalDelay: 250,
            mainClass: 'mfp-zoom-in',
            callbacks: {
               open: function() {
                  $.magnificPopup.instance.next = function() {
                     var self = this;
                     self.wrap.removeClass('mfp-image-loaded');
                     setTimeout( function() { $.magnificPopup.proto.next.call( self ); }, 250 );
                  };
                  $.magnificPopup.instance.prev = function() {
                     var self = this;
                     self.wrap.removeClass('mfp-image-loaded');
                     setTimeout( function() { $.magnificPopup.proto.prev.call( self ); }, 250 );
                  };
               },
               imageLoadComplete: function() {
                  var self = this;
                  setTimeout(function() { self.wrap.addClass('mfp-image-loaded'); }, 5);
               },
            },
         };

         switch ( role ) {
            case 'image':
               $this.magnificPopup( _.extend( args, {
                  type: 'image',
                  closeOnContentClick: true,
                  image: {
                     titleSrc: 'data-builder-lightbox-caption',
                  },
               }));
               break;
            case 'iframe':
               $this.magnificPopup( _.extend( args, {
                  type: 'iframe',
               }));
               break;
            case 'gallery':
               $this.magnificPopup( _.extend( args, {
                  delegate: '[data-builder-lightbox-role="gallery-item"], .builder-lightbox-gallery-item',
                  gallery: {
                     enabled: true,
                     tCounter: '<span class="mfp-counter">%curr% / %total%</span>',
                  },
                  image: {
                     titleSrc: 'data-builder-lightbox-caption',
                  },
                  type: 'image',
               }));
               break;
         }
      });
   };

   // ======================================================
   //
   // Set Up Animated Entrances using Waypoints
   //
   // ======================================================

   $(document).on('animatedentrance', '[data-entrance]', function() {
      var $this = $(this), entrance = $this.attr('data-entrance'),
      delay = $this.attr('data-entrance-delay') ? parseInt( $this.attr('data-entrance-delay') ) : 0;
      if ( 'chained' === entrance ) {
         entrance = $this.closest('[data-entrance-trigger]').attr('data-entrance-trigger');
      }
      // if ( themefyreBuilder.isMobile() ) {
      //    delay = 0; // Disable delays on mobile devices
      // }
      setTimeout( function() {
         $this.imagesLoaded( function() {
            $this.addClass(entrance);
         });
      }, delay+150 );
   });

   // Instantiate all elements utilizing animated entrances
   themefyreBuilder.addAnimatedEntrances = function() {
      $('[data-entrance]').not('[data-entrance="chained"]').each( function() {
         if ( $.data( this, 'animatedentrance' ) ) {
            return;
         }
         $.data( this, 'animatedentrance', true );
         var $this = $(this);
         $this.waypoint( function() {
            $this.trigger('animatedentrance');
         }, { offset: '100%' });
      });

      $('[data-entrance-trigger]').each( function() {
         if ( $.data( this, 'animatedentrancetrigger' ) ) {
            return;
         }
         $.data( this, 'animatedentrancetrigger', true );
         var $this = $(this);
         $this.waypoint( function() {
            $('[data-entrance="chained"]', $this).trigger('animatedentrance');
         }, { offset: '100%' });
      });
   };

   // ======================================================
   //
   // Set Up Parallax Scrolling
   //
   // ======================================================

   // Refresh & update our parallax elements when page is scrolled/resized
   $(document).ready( function() {
      $(window).resize( themefyreBuilder.addParallaxScrolling );
      $(window).resize( themefyreBuilder.scrollParallaxElements );
      $(window).scroll( themefyreBuilder.scrollParallaxElements );
   });

   // Some variables specific to parallax scrolling that we will use later
   themefyreBuilder.parallaxElements = [];
   themefyreBuilder.lastScrollY = 0;
   themefyreBuilder.loadingPaintParallaxElements = false;

   // Instantiate all elements utilizing parallax scrolling
   //
   // Indexes each element that has parallax scrolling enabled
   themefyreBuilder.addParallaxScrolling = function() {
      themefyreBuilder.parallaxElements = [];

      // Do not continue if we`re on a `mobile` device
      if ( themefyreBuilder.isMobile() ) {
         return;
      }

      $('.builder-parallax-viewport [data-parallax]').each( function() {
         var $this = $(this), $viewport = $this.closest('.builder-parallax-viewport');

         var config = {
            $element: $this,
            height: $viewport.outerHeight(),
            offsetTop: $viewport.offset().top,
            offsetBottom: $viewport.outerHeight() + $viewport.offset().top,
            mode: $this.data('parallax'),
         };

         // Account for theme defined scrolltop offset
         if ( config.offsetTop > themefyreBuilder.scrollTopOffset ) {
            config.offsetTop -= themefyreBuilder.scrollTopOffset;
         }

         // Account for the height of the admin area when applicable
         if ( $('body').hasClass('admin-bar') && document.getElementById('wpadminbar') ) {
            config.offsetTop -= $('#wpadminbar').outerHeight();
         }

         themefyreBuilder.parallaxElements.push( config );

         // Repaint all parallax elements upon reset
         themefyreBuilder.paintParallaxElements();
      });
   };

   // Indexes each element that has parallax scrolling enabled
   themefyreBuilder.scrollParallaxElements = function() {
      if ( ! themefyreBuilder.loadingPaintParallaxElements ) {
         requestAnimationFrame( themefyreBuilder.paintParallaxElements );
         themefyreBuilder.lastScrollY = window.pageYOffset;
         themefyreBuilder.loadingPaintParallaxElements = true;
      }
   };

   // Used to reposition/restyle all parallax enable elements
   themefyreBuilder.paintParallaxElements = function() {
      _.each( themefyreBuilder.parallaxElements, function( element ) {
         if ( themefyreBuilder.lastScrollY > element.offsetTop && themefyreBuilder.lastScrollY < element.offsetBottom ) {


            var translate = (themefyreBuilder.lastScrollY-element.offsetTop)/3,
                fade = 1-(((themefyreBuilder.lastScrollY-element.offsetTop)/element.height)*2),
                scale = 1-(((themefyreBuilder.lastScrollY-element.offsetTop)/element.height)/3);

            switch ( element.mode ) {
               case 'translate':
                  element.$element.css('transform', 'translateY('+translate+'px)');
                  break;
               case 'fade':
                  element.$element.css('opacity', fade);
                  break;
               case 'scale':
                  element.$element.css('transform', 'scale('+scale+')');
                  break;
               case 'translate-fade':
                  element.$element.css({
                     transform: 'translateY('+translate+'px)',
                     opacity: fade,
                  });
                  break;
               case 'fade-scale':
                  element.$element.css({
                     transform: 'scale('+scale+')',
                     opacity: fade,
                  });
                  break;
               case 'translate-scale':
                  element.$element.css({
                     transform: 'translateY('+translate+'px) scale('+scale+')',
                  });
                  break;
               case 'translate-fade-scale':
                  element.$element.css({
                     transform: 'translateY('+translate+'px) scale('+scale+')',
                     opacity: fade,
                  });
                  break;
            }
         }
         else {
            switch ( element.mode ) {
               case 'translate':
               case 'scale':
               case 'translate-scale':
                  element.$element.css('transform', 'none');
                  break;
               case 'fade':
                  element.$element.css('opacity', 1);
                  break;
               case 'translate-fade':
               case 'fade-scale':
               case 'translate-fade-scale':
                  element.$element.css({
                     transform: 'none',
                     opacity: 1,
                  });
                  break;
            }
         }
      });
      themefyreBuilder.loadingPaintParallaxElements = false;
   };

   // ======================================================
   //
   // `Super Links` will extend their click event to the first child anchor found
   //
   // ======================================================

   $(document).on('click', '.builder-superlink', function(event) {

      // Make sure we`re not clicking on an actual link, or the child of one
      if ( 'a' === event.target.nodeName.toLowerCase() || $(event.target).parents('a').length ) {
         return;
      }

      // Make sure there is a link to `click`
      var $links = $('a', $(this));
      if ( ! $links.length ) {
         return;
      }

      // [0] gets the JavaScript object to make use of the native
      // click method, which simulates an authentic click event.
      $links.first()[0].click();
   });

   // ======================================================
   //
   // Toogle Group
   //
   // ======================================================

   $.fn.themefyreBuilderToggleGroup = function( options ) {
      return this.each( function() {
         if ( ! $.data( this, 'toggleGroup' ) ) {
            var defaults = {
               firstOpen: themefyreBuilder.getBool( this.getAttribute('data-first-open') ),
               allowMulti: themefyreBuilder.getBool( this.getAttribute('data-allow-multi') ),
            };
            var args = _.extend( defaults, options );
            $.data( this, 'toggleGroup', new themefyreBuilder.toggleGroup( this, args ) );
         }
      });
   };

   themefyreBuilder.toggleGroup = function( element, args ) {
      this.element = element;
      this.$element = $(element);
      this.config = args;
      this.init();
   };

   _.extend( themefyreBuilder.toggleGroup.prototype, {
      init: function() {
         this.$toggles = $('.builder-toggle', this.$element);

         // Attach all relevant events
         this.attachEvents();

         // Check if first toggle is open on load
         if ( this.config.firstOpen ) {
            this.openToggle( this.$toggles.first() );
         }
      },

      attachEvents: function() {
         var self = this;

         if ( $('.builder-toggle-group-filter-list', self.$element).length ) {
            $('.builder-toggle-group-filter-list', self.$element).on( 'click', '[data-filter]', function(event) {
               event.preventDefault();
               var $this = $(this), filter = $this.attr('data-filter');
               if ( ! $this.parent().hasClass('is-active') ) {
                  $this.parent().addClass('is-active').siblings().removeClass('is-active');
                  self.filterToggles( filter );
               }
            });
         }

         self.$element.on( 'click', '.builder-toggle-handle', function() {
            var $toggle = $(this).closest('.builder-toggle');

            // Make sure the toggle is active
            if ( $toggle.hasClass('is-disabled') ) {
               return;
            }

            // Determine what to do
            if ( $toggle.hasClass('is-open') ) {
               self.closeToggle( $toggle );
            }
            else {
               self.openToggle( $toggle );
            }
         });
      },

      openToggle: function( $toggle ) {
         $toggle.addClass('is-open');
         var $content = $toggle.children('.builder-toggle-content');
         $content.css('height', $content.children('div').outerHeight() );
         if ( ! this.config.allowMulti ) {
            this.closeToggle( $toggle.siblings() );
         }
      },

      closeToggle: function( $toggle ) {
         $toggle.removeClass('is-open').children('.builder-toggle-content').removeAttr('style');
      },

      filterToggles: function( filter ) {
         var self = this;

         // Close all toggles
         self.closeToggle( self.$toggles );

         // Filter the toggles
         setTimeout( function() {
            self.$toggles.each( function() {
               var $toggle = $(this), tags = $toggle.data('tags'), visible = '*' === filter;
               if ( ! visible && tags ) {
                  _.each( tags.split(','), function(tag) {
                     if ( filter === tag ) {
                        visible = true;
                     }
                  });
               }
               if ( visible ) {
                  $toggle.removeClass('is-disabled');
                  $('.builder-toggle-title a', $toggle).removeAttr('aria-disabled');
               }
               else {
                  $toggle.addClass('is-disabled');
                  $('.builder-toggle-title a', $toggle).attr('aria-disabled', '');
               }
            });
         }, 250 );
      },
   });

   // ======================================================
   //
   // Tab Group
   //
   // ======================================================

   $.fn.themefyreBuilderTabGroup = function() {
      return this.each( function() {
         if ( ! $.data( this, 'tabGroup' ) ) {
            $.data( this, 'tabGroup', new themefyreBuilder.tabGroup( this ) );
         }
      });
   };

   themefyreBuilder.tabGroup = function( element ) {
      this.element = element;
      this.$element = $(element);
      this.$tabs = $('.builder-tab-group-tab', this.$element);
      this.$panes = $('.builder-tab-group-pane', this.$element);
      this.init();
   };

   _.extend( themefyreBuilder.tabGroup.prototype, {
      init: function() {
         var self = this;

         this.$tabs.on( 'click', 'a', function(event) {
            event.preventDefault();
            var $tab = $(this).closest('.builder-tab-group-tab'), index = $tab.index();
            if ( ! $tab.hasClass('is-active') ) {
               self.changeTab( index );
            }
         });

         this.$panes.on( 'click', '.builder-tab-group-pane-title', function() {
            var $pane = $(this).closest('.builder-tab-group-pane'), index = $pane.index();
            if ( ! $pane.hasClass('is-active') ) {
               self.changeTab( index );
            }
         });
      },
      changeTab: function( index ) {
         this.$tabs.removeClass('is-active').eq(index).addClass('is-active');
         this.$panes.removeClass('is-active').eq(index).addClass('is-active');
      },
   });

   // ======================================================
   //
   // Promo Boxes
   //
   // ======================================================

   $.fn.themefyreBuilderPromoBox = function() {
      return this.each( function() {
         if ( ! $.data( this, 'promoBox' ) ) {
            $.data( this, 'promoBox', new themefyreBuilder.promoBox( this ) );
         }
      });
   };

   themefyreBuilder.promoBox = function( element ) {
      this.element = element;
      this.$element = $(element);
      this.$content = $( '.builder-promo-box-content', $(element) );
      this.init();
   };

   _.extend( themefyreBuilder.promoBox.prototype, {
      init: function() {

         // When the content changes size we need to recenter it
         this.$content.resize( $.proxy( this.center, this ) );
         this.center();

         // When the promo box changes size we need to scale the content
         this.$element.resize( $.proxy( this.scale, this ) );
         this.scale();

         // Set the content opacity to 1
         this.$content.css('opacity', '1');
      },
      center: function() {
         this.$content.css({
            marginLeft: -(this.$content.outerWidth()/2),
            marginTop: -(this.$content.outerHeight()/2),
         });
      },
      scale: function() {
         var currentWidth = this.$element.outerWidth(),
             contentWidth = this.$content.outerWidth();

         // Scaler has enough room, we`re good
         if ( currentWidth >= contentWidth ) {
            this.$content.css('transform', 'none');
         }
         else {
            this.$content.css('transform', 'scale('+( currentWidth / contentWidth )+')');
         }
      },
   });

   // ======================================================
   //
   // Google Maps Integration
   //
   // ======================================================

   $.fn.themefyreBuilderGoogleMap = function() {
      return this.each( function() {
         if ( ! $.data( this, 'googleMap' ) ) {
            $.data( this, 'googleMap', new themefyreBuilder.googleMap( this ) );
         }
      });
   };

   themefyreBuilder.googleMap = function( element ) {
      this.element = element;
      this.$element = $(element);
      this.init();
   };

   _.extend( themefyreBuilder.googleMap.prototype, {
      init: function() {
         var self = this;

         // Stor the Google API Geocoder
         this.geocoder = new google.maps.Geocoder();

         // Store all of the map marker placeholders
         this.$markers = $('.builder-google-map-marker', this.$element);
         this.markerCount = this.$markers.length;

         // Will hold the configuration for each marker
         this.mapID = this.$element.attr('id');
         this.$mapViewport = $('#'+this.mapID+'-viewport');

         // Will hold the configuration for each marker
         this.markersConfig = [];

         // Will contain the markers and their informational windows
         this.markers = [];
         this.markerWindows = [];

         // Prepare the provided markers for the map
         this.prepareMarkers();
      },

      prepareMarkers: function() {

         // Used to check when we`ve iterated through each marker
         var self = this, numMarkers = this.markerCount, $marker = [];

         // Iterate through each marker and get the lat/lng coordinates
         // then add the marker to the map
         this.$markers.each( function( index ) {
            $marker.push( $(this) );

            // Convert the address to usable coordinates, if possible
            self.geocoder.geocode( {'address': $marker[index].attr('data-address')}, function(results, status) {

               // As long as the address is valid, we add the marker to our configuration
               if ( status === google.maps.GeocoderStatus.OK ) {
                  self.markersConfig.push({
                     content: $marker[index].html(),
                     maxWidth: $marker[index].attr('data-max-width'),
                     visibility: $marker[index].attr('data-visibility'),
                     coordinates: [results[0].geometry.location.lat(), results[0].geometry.location.lng()]
                  });
               }

               // Workaround to wait for all addresses to be converted
               if ( ! --numMarkers && self.markersConfig.length ) {
                  self.initMap();
               }
            });
         });
      },

      initMap: function() {
         var self = this, map, styledMap, options, styleOptions;

         // Basic options
         options = {
            scrollwheel: false,
            disableDefaultUI: true,
            center: this.getCenter(),
            zoom: parseInt( this.$mapViewport.attr('data-zoom-level') ),
            draggable: 'true' === this.$mapViewport.attr('data-draggable'),
            zoomControl: 'true' === this.$mapViewport.attr('data-zoom-control'),
         };

         // Create the map with custom styles
         if ( this.$mapViewport.attr('data-hue') && this.$mapViewport.attr('data-water-color') ) {
            styleOptions = [
               {
                  stylers: [
                     { hue: this.$mapViewport.attr('data-hue') },
                     { gamma: 0.5 },
                     { weight: 0.5 },
                  ]
               },
               {
                  featureType: 'water',
                  stylers: [
                     { color: this.$mapViewport.attr('data-water-color') }
                  ]
               }
            ];

            // Create the map with custom styles
            options.mapTypeId = this.mapID;
            map = new google.maps.Map( document.getElementById(this.mapID+'-viewport'), options );
            styledMap = new google.maps.StyledMapType( styleOptions, { name: this.mapID } );
            map.mapTypes.set( this.mapID, styledMap );
         }

         // Create the map with default styles
         else {
            map = new google.maps.Map( document.getElementById(this.mapID+'-viewport'), options );
         }

         // This is where we add all of the markers
         _.each( this.markersConfig, function(value, index) {

            // Initially create the marker
            self.markers[index] = new google.maps.Marker({
               position: new google.maps.LatLng(value.coordinates[0], value.coordinates[1]),
               map: map,
            });

            // Check if the marker window has been enabled
            if ( 'hidden' !== value.visibility && value.content ) {

               // Create the marker window
               self.markerWindows[index] = new google.maps.InfoWindow({
                  content: value.content,
                  maxWidth: value.maxWidth,
               });

               // Toggle marker window on marker click
               google.maps.event.addListener( self.markers[index], 'click', function() {
                  self.markerWindows[index].open( map, self.markers[index] );
               });

               // If marker is visible on map load
               if ( 'load' === value.visibility ) {
                  self.markerWindows[index].open( map, self.markers[index] );
               }
            }
         });
      },

      getCenter: function() {
         var centerLat, centerLng, allLats = [], allLngs = [];

         // Only 1 marker, use this for center
         if ( 1 === this.markersConfig.length ) {
            centerLat = this.markersConfig[0].coordinates[0];
            centerLng = this.markersConfig[0].coordinates[1];
         }

         // Multiple markers, calculate the center
         else {
            _.each( this.markersConfig, function(value) {
               allLats.push(value.coordinates[0]);
               allLngs.push(value.coordinates[1]);
            });
            centerLat = (Math.max.apply(null, allLats) + Math.min.apply(null, allLats)) /2;
            centerLng = (Math.max.apply(null, allLngs) + Math.min.apply(null, allLngs)) /2;
         }

         return new google.maps.LatLng(centerLat, centerLng);
      },

   });

   // ======================================================
   //
   // Full Width Sliders
   //
   // ======================================================

   $.fn.themefyreBuilderFullWidthSlider = function() {
      return this.each( function() {
         if ( ! $.data( this, 'slider' ) ) {
            $.data( this, 'slider', new themefyreBuilder.fullWidthSlider( this ) );
         }
      });
   };

   themefyreBuilder.fullWidthSlider = function( element ) {
      this.element = element;
      this.$element = $(element);
      this.init();
   };

   _.extend( themefyreBuilder.fullWidthSlider.prototype, {
      init: function() {

         // The interval between automatic slide transitions
         this.interval = this.$element.attr('data-interval') ? parseInt( this.$element.attr('data-interval').replace(/[^0-9]/, '') ) : false;
         this.hoverPause = ( this.interval ) && 'true' === this.$element.attr('data-hoverpause');
         this.mouseOver = false;

         // Which controls (if any) have been enabled
         this.directionControl = -1 !== _.indexOf( ['both', 'direction'], this.$element.attr('data-controls') );
         this.pagerControl = -1 !== _.indexOf( ['both', 'pager'], this.$element.attr('data-controls') );

         // Will store the timer when auto is enabled
         this.timer = null;

         // Will store the timer for displaying the laoder
         this.showLoaderTimer = null;

         // Will be true when slider is animating
         this.animating = false;

         // The slides
         this.$slides = $('.builder-slider-slide', this.$element);
         this.numSlides = this.$slides.length;

         // 0 based index
         this.activeIndex = 0;

         // Append the direction control HTML when enabled
         if ( this.directionControl ) {
            this.$element.append( this.getDirectionHTML() );
         }

         // Append the pager control HTML when enabled
         if ( this.pagerControl ) {
            var $pager = $(this.getPagerHTML());
            $pager.children().first().addClass('is-active');
            this.$element.append( $pager );
         }

         // If auto is enabled start the timer
         if ( this.interval ) {
            this.setTimer();
         }

         // Attach all user events
         this.attachEvents();

         // Append the loader to the slider element
         this.$element.append( this.getLoaderHTML() );

         // Sanitize the slides
         this.prepareSlides();

         // Tell the CSS that the slider is ready
         this.$element.addClass('js-plugin-loaded');
      },

      attachEvents: function() {
         var self = this;

         // Pause interval when slider is moused over
         if ( this.hoverPause ) {
            this.$element.on({
               mouseenter: $.proxy( this.mouseEnter, this ),
               mouseleave: $.proxy( this.mouseLeave, this ),
            });
         }

         // Next/Previous slide buttons
         $('.builder-slider-next-slide', this.$element).on( 'click', $.proxy( this.next, this ) );
         $('.builder-slider-prev-slide', this.$element).on( 'click', $.proxy( this.prev, this ) );

         // Pager buttons
         $('.builder-slider-pager-nav button', this.$element).on( 'click', function() {
            self.changeSlide( $(this).index() );
         });
      },

      prepareSlides: function() {
         var self = this, $firstSlide = this.$slides.eq(0);

         this.$slides.each( function() {
            var $slide = $(this);

            // Remove the HTML5 video background if it not supported
            if ( $slide.is('.has-video-bg') && themefyreBuilder.isMobile() ) {
               $slide.removeClass('has-video-bg');
               $('.builder-html5-video-bg', $slide).remove();
            }
         });

         // Reveal the first slide & play the HTML5 video background if one is present
         $firstSlide.addClass('is-active is-visible');
         if ( $firstSlide.is('.has-video-bg') ) {
            var firstSlidePlayer = $('.builder-html5-video-bg', $firstSlide)[0];
            if ( firstSlidePlayer.readyState >= firstSlidePlayer.HAVE_FUTURE_DATA ) {
               firstSlidePlayer.play();
            }
            else {
               self.showLoader();
               $(firstSlidePlayer).on( 'canplay', _.once( function() {
                  firstSlidePlayer.play();
                  self.hideLoader();
               }));
            }
         }

         // Reset parallax scrolling for all elements found in the slider
         this.refreshParallaxElements( $firstSlide );
      },

      setTimer: function() {
         var self = this;
         this.clearTimer();
         this.timer = setTimeout( function() {
            if ( ! self.mouseOver ) {
               self.next();
            }
         }, this.interval );
      },

      clearTimer: function() {
         clearTimeout( this.timer );
      },

      mouseEnter: function() {
         this.mouseOver = true;
         this.clearTimer();
      },

      mouseLeave: function() {
         this.mouseOver = false;
         if ( ! this.animating ) {
            this.setTimer();
         }
      },

      getLoaderHTML: function() {
         return '<div class="builder-slider-spinner"><div></div><div></div><div></div></div>';
      },

      showLoader: function() {
         this.$element.addClass('is-loading');
      },

      hideLoader: function() {
         this.$element.removeClass('is-loading');
      },

      getDirectionHTML: function() {
         var HTML = [
            '<button type="button" class="builder-slider-next-slide">',
            '<span class="screen-reader-text">'+builderFrontEndLocalize.slider_next_text+'</span>',
            '<span class="css-arrow"></span>',
            '</button>',
            '<button type="button" class="builder-slider-prev-slide">',
            '<span class="screen-reader-text">'+builderFrontEndLocalize.slider_prev_text+'</span>',
            '<span class="css-arrow"></span>',
            '</button>',
         ];
         return HTML.join('');
      },

      getPagerHTML: function() {
         var HTML = [ '<div class="builder-slider-pager-nav">', ], buttonText;
         for (var i=1;i<=this.numSlides;i++) {
            buttonText = builderFrontEndLocalize.slider_pager_button_text.replace('%s', i);
            HTML.push( '<button type="button"><span class="screen-reader-text">'+buttonText+'</span></button>' );
         }
         HTML.push('</div>');
         return HTML.join('');
      },

      updateControlsHTML: function() {
         if ( this.pagerControl ) {
            var $pager = $('.builder-slider-pager-nav', this.$element);
            $pager.children().removeClass('is-active').eq( this.activeIndex ).addClass('is-active');
         }
      },

      next: function() {
         this.changeSlide( (this.activeIndex+1) === this.numSlides ? 0 : this.activeIndex+1 );
      },

      prev: function() {
         this.changeSlide( this.activeIndex === 0 ? this.numSlides-1 : this.activeIndex-1 );
      },

      refreshParallaxElements: function( $currentSlide ) {
         $('[data-parallax]', this.$slides.not($currentSlide) ).each( function() {
            var $this = $(this), parallaxMode = $this.attr('data-parallax');
            $this.attr('data-parallax-placeholder', parallaxMode);
            $this.removeAttr('data-parallax');
         });
         $('[data-parallax-placeholder]', $currentSlide ).each( function() {
            var $this = $(this), parallaxMode = $this.attr('data-parallax-placeholder');
            $this.attr('data-parallax', parallaxMode);
            $this.removeAttr('data-parallax-placeholder');
         });
         themefyreBuilder.addParallaxScrolling();
      },

      changeSlide: function( index ) {
         if ( this.animating || index === this.activeIndex ) {
            return;
         }

         // If auto is enabled clear the timer
         if ( this.interval ) {
            this.clearTimer();
         }

         // Set the animating state to true
         this.animating = true;

         var self = this, $nextSlide = this.$slides.eq(index);

         // Activate the show loader timer
         this.showLoaderTimer = setTimeout( $.proxy(this.showLoader, this), 50 );

         // The upcoming slide has a video BG or a parallax video bg
         // This means we need to wait for it to load completely to change to it
         if ( $nextSlide.is('.has-video-bg') ) {
            var nextSlidePlayer = $('.builder-html5-video-bg', $nextSlide)[0];

            if ( nextSlidePlayer.readyState >= nextSlidePlayer.HAVE_FUTURE_DATA ) {
               this.doChangeSlide(index);
            }
            else {
               $(nextSlidePlayer).on( 'canplay', _.once( function() {
                  self.doChangeSlide(index);
               }));
            }
         }

         // The upcoming slide has an image BG or a parallax image bg
         // This means we need to wait for the BG image to load
         else if ( $nextSlide.is('.has-image-bg') )  {
            var $nextSlideBGElement = $nextSlide.is('.has-parallax-image-bg') ? $('.builder-parallax-bg', $nextSlide) : $nextSlide,
                nextSlideImageURL = $nextSlideBGElement.css('background-image').match(/\((.*?)\)/)[1].replace(/('|")/g,''),
                nextSlideImage = new Image();

            nextSlideImage.src = nextSlideImageURL;
            if (nextSlideImage.complete) {
               self.doChangeSlide(index);
            }
            else {
               nextSlideImage.onload = function() {
                  self.doChangeSlide(index);
               }
            }
         }

         // No Video or image background, ready to change slides now
         else {
            self.doChangeSlide(index);
         }

      },

      doChangeSlide: function( index ) {
         var self = this,
             $currentSlide = this.$slides.eq(this.activeIndex),
             $nextSlide = this.$slides.eq(index);

         // Reset parallax scrolling for all elements found in the slider
         self.refreshParallaxElements( $nextSlide );

         // Change the active index
         self.activeIndex = index;

         // Update the HTML for all controls
         self.updateControlsHTML();

         // Prevent the loader from being revealed if it hasn`t yet
         // This generally happens when the image is already loaded
         clearTimeout( this.showLoaderTimer );
         self.hideLoader();

         // If the current slide has a video background, pause it after a delay
         if ( $currentSlide.is('.has-video-bg') ) {
            setTimeout( function() {
               var currentSlidePlayer = $('.builder-html5-video-bg', $currentSlide)[0];
               currentSlidePlayer.pause();
            }, 500);
         }

         // If the next slide has a video background, restart & play it
         if ( $nextSlide.is('.has-video-bg') ) {
            var nextSlidePlayer = $('.builder-html5-video-bg', $nextSlide)[0];
            nextSlidePlayer.currentTime = 0;
            nextSlidePlayer.play();
         }

         // Set the new slide to active and apply the animating class to the new slide
         $currentSlide.removeClass('is-active').addClass('is-hiding');
         $nextSlide.addClass('is-active is-animated is-visible');

         setTimeout( function() {

            // Hide the formerly active slide
            $currentSlide.removeClass('is-visible is-hiding');

            // Remove the animation class
            $nextSlide.removeClass('is-animated');

            // If auto is enabled reset the timer
            if ( self.interval ) {
               self.setTimer();
            }

            // We`re now done with the transition
            self.animating = false;
         }, 500);
      },
   });

}(jQuery, _));

// ======================================================
//
// requestAnimationFrame polyfill
//
// ======================================================

// http://paulirish.com/2011/requestanimationframe-for-smart-animating/
// http://my.opera.com/emoller/blog/2011/12/20/requestanimationframe-for-smart-er-animating
//
// requestAnimationFrame polyfill by Erik Möller. fixes from Paul Irish and Tino Zijdel
//
// MIT license
;(function() {
   var lastTime = 0;
   var vendors = ['ms', 'moz', 'webkit', 'o'];
   for ( var x = 0; x < vendors.length && !window.requestAnimationFrame; ++x ) {
      window.requestAnimationFrame = window[vendors[x]+'RequestAnimationFrame'];
      window.cancelAnimationFrame = window[vendors[x]+'CancelAnimationFrame'] || window[vendors[x]+'CancelRequestAnimationFrame'];
   }
   if ( ! window.requestAnimationFrame ) {
      window.requestAnimationFrame = function(callback, element) {
         var currTime = new Date().getTime();
         var timeToCall = Math.max( 0, 16 - (currTime - lastTime) );
         var id = window.setTimeout( function() { callback(currTime + timeToCall ); }, timeToCall);
         lastTime = currTime + timeToCall;
         return id;
      };
   }
   if ( ! window.cancelAnimationFrame ) {
      window.cancelAnimationFrame = function( id ) {
         clearTimeout( id );
      };
   }
}());

// ======================================================
//
// 3rd Party jQuery Plugins
//
// ======================================================

/*
 * jQuery resize event - v1.1 - 3/14/2010
 * http://benalman.com/projects/jquery-resize-plugin/
 *
 * Copyright (c) 2010 "Cowboy" Ben Alman
 * Dual licensed under the MIT and GPL licenses.
 * http://benalman.com/about/license/
 */
(function($,h,c){var a=$([]),e=$.resize=$.extend($.resize,{}),i,k="setTimeout",j="resize",d=j+"-special-event",b="delay",f="throttleWindow";e[b]=250;e[f]=true;$.event.special[j]={setup:function(){if(!e[f]&&this[k]){return false}var l=$(this);a=a.add(l);$.data(this,d,{w:l.width(),h:l.height()});if(a.length===1){g()}},teardown:function(){if(!e[f]&&this[k]){return false}var l=$(this);a=a.not(l);l.removeData(d);if(!a.length){clearTimeout(i)}},add:function(l){if(!e[f]&&this[k]){return false}var n;function m(s,o,p){var q=$(this),r=$.data(this,d);r.w=o!==c?o:q.width();r.h=p!==c?p:q.height();n.apply(this,arguments)}if($.isFunction(l)){n=l;return m}else{n=l.handler;l.handler=m}}};function g(){i=h[k](function(){a.each(function(){var n=$(this),m=n.width(),l=n.height(),o=$.data(this,d);if(m!==o.w||l!==o.h){n.trigger(j,[o.w=m,o.h=l])}});g()},e[b])}})(jQuery,this);

// Magnific Popup v1.0.0 by Dmitry Semenov
// http://bit.ly/magnific-popup#build=inline+image+ajax+iframe+gallery+retina+imagezoom+fastclick
(function(a){typeof define=="function"&&define.amd?define(["jquery"],a):typeof exports=="object"?a(require("jquery")):a(window.jQuery||window.Zepto)})(function(a){var b="Close",c="BeforeClose",d="AfterClose",e="BeforeAppend",f="MarkupParse",g="Open",h="Change",i="mfp",j="."+i,k="mfp-ready",l="mfp-removing",m="mfp-prevent-close",n,o=function(){},p=!!window.jQuery,q,r=a(window),s,t,u,v,w=function(a,b){n.ev.on(i+a+j,b)},x=function(b,c,d,e){var f=document.createElement("div");return f.className="mfp-"+b,d&&(f.innerHTML=d),e?c&&c.appendChild(f):(f=a(f),c&&f.appendTo(c)),f},y=function(b,c){n.ev.triggerHandler(i+b,c),n.st.callbacks&&(b=b.charAt(0).toLowerCase()+b.slice(1),n.st.callbacks[b]&&n.st.callbacks[b].apply(n,a.isArray(c)?c:[c]))},z=function(b){if(b!==v||!n.currTemplate.closeBtn)n.currTemplate.closeBtn=a(n.st.closeMarkup.replace("%title%",n.st.tClose)),v=b;return n.currTemplate.closeBtn},A=function(){a.magnificPopup.instance||(n=new o,n.init(),a.magnificPopup.instance=n)},B=function(){var a=document.createElement("p").style,b=["ms","O","Moz","Webkit"];if(a.transition!==undefined)return!0;while(b.length)if(b.pop()+"Transition"in a)return!0;return!1};o.prototype={constructor:o,init:function(){var b=navigator.appVersion;n.isIE7=b.indexOf("MSIE 7.")!==-1,n.isIE8=b.indexOf("MSIE 8.")!==-1,n.isLowIE=n.isIE7||n.isIE8,n.isAndroid=/android/gi.test(b),n.isIOS=/iphone|ipad|ipod/gi.test(b),n.supportsTransition=B(),n.probablyMobile=n.isAndroid||n.isIOS||/(Opera Mini)|Kindle|webOS|BlackBerry|(Opera Mobi)|(Windows Phone)|IEMobile/i.test(navigator.userAgent),s=a(document),n.popupsCache={}},open:function(b){var c;if(b.isObj===!1){n.items=b.items.toArray(),n.index=0;var d=b.items,e;for(c=0;c<d.length;c++){e=d[c],e.parsed&&(e=e.el[0]);if(e===b.el[0]){n.index=c;break}}}else n.items=a.isArray(b.items)?b.items:[b.items],n.index=b.index||0;if(n.isOpen){n.updateItemHTML();return}n.types=[],u="",b.mainEl&&b.mainEl.length?n.ev=b.mainEl.eq(0):n.ev=s,b.key?(n.popupsCache[b.key]||(n.popupsCache[b.key]={}),n.currTemplate=n.popupsCache[b.key]):n.currTemplate={},n.st=a.extend(!0,{},a.magnificPopup.defaults,b),n.fixedContentPos=n.st.fixedContentPos==="auto"?!n.probablyMobile:n.st.fixedContentPos,n.st.modal&&(n.st.closeOnContentClick=!1,n.st.closeOnBgClick=!1,n.st.showCloseBtn=!1,n.st.enableEscapeKey=!1),n.bgOverlay||(n.bgOverlay=x("bg").on("click"+j,function(){n.close()}),n.wrap=x("wrap").attr("tabindex",-1).on("click"+j,function(a){n._checkIfClose(a.target)&&n.close()}),n.container=x("container",n.wrap)),n.contentContainer=x("content"),n.st.preloader&&(n.preloader=x("preloader",n.container,n.st.tLoading));var h=a.magnificPopup.modules;for(c=0;c<h.length;c++){var i=h[c];i=i.charAt(0).toUpperCase()+i.slice(1),n["init"+i].call(n)}y("BeforeOpen"),n.st.showCloseBtn&&(n.st.closeBtnInside?(w(f,function(a,b,c,d){c.close_replaceWith=z(d.type)}),u+=" mfp-close-btn-in"):n.wrap.append(z())),n.st.alignTop&&(u+=" mfp-align-top"),n.fixedContentPos?n.wrap.css({overflow:n.st.overflowY,overflowX:"hidden",overflowY:n.st.overflowY}):n.wrap.css({top:r.scrollTop(),position:"absolute"}),(n.st.fixedBgPos===!1||n.st.fixedBgPos==="auto"&&!n.fixedContentPos)&&n.bgOverlay.css({height:s.height(),position:"absolute"}),n.st.enableEscapeKey&&s.on("keyup"+j,function(a){a.keyCode===27&&n.close()}),r.on("resize"+j,function(){n.updateSize()}),n.st.closeOnContentClick||(u+=" mfp-auto-cursor"),u&&n.wrap.addClass(u);var l=n.wH=r.height(),m={};if(n.fixedContentPos&&n._hasScrollBar(l)){var o=n._getScrollbarSize();o&&(m.marginRight=o)}n.fixedContentPos&&(n.isIE7?a("body, html").css("overflow","hidden"):m.overflow="hidden");var p=n.st.mainClass;return n.isIE7&&(p+=" mfp-ie7"),p&&n._addClassToMFP(p),n.updateItemHTML(),y("BuildControls"),a("html").css(m),n.bgOverlay.add(n.wrap).prependTo(n.st.prependTo||a(document.body)),n._lastFocusedEl=document.activeElement,setTimeout(function(){n.content?(n._addClassToMFP(k),n._setFocus()):n.bgOverlay.addClass(k),s.on("focusin"+j,n._onFocusIn)},16),n.isOpen=!0,n.updateSize(l),y(g),b},close:function(){if(!n.isOpen)return;y(c),n.isOpen=!1,n.st.removalDelay&&!n.isLowIE&&n.supportsTransition?(n._addClassToMFP(l),setTimeout(function(){n._close()},n.st.removalDelay)):n._close()},_close:function(){y(b);var c=l+" "+k+" ";n.bgOverlay.detach(),n.wrap.detach(),n.container.empty(),n.st.mainClass&&(c+=n.st.mainClass+" "),n._removeClassFromMFP(c);if(n.fixedContentPos){var e={marginRight:""};n.isIE7?a("body, html").css("overflow",""):e.overflow="",a("html").css(e)}s.off("keyup"+j+" focusin"+j),n.ev.off(j),n.wrap.attr("class","mfp-wrap").removeAttr("style"),n.bgOverlay.attr("class","mfp-bg"),n.container.attr("class","mfp-container"),n.st.showCloseBtn&&(!n.st.closeBtnInside||n.currTemplate[n.currItem.type]===!0)&&n.currTemplate.closeBtn&&n.currTemplate.closeBtn.detach(),n._lastFocusedEl&&a(n._lastFocusedEl).focus(),n.currItem=null,n.content=null,n.currTemplate=null,n.prevHeight=0,y(d)},updateSize:function(a){if(n.isIOS){var b=document.documentElement.clientWidth/window.innerWidth,c=window.innerHeight*b;n.wrap.css("height",c),n.wH=c}else n.wH=a||r.height();n.fixedContentPos||n.wrap.css("height",n.wH),y("Resize")},updateItemHTML:function(){var b=n.items[n.index];n.contentContainer.detach(),n.content&&n.content.detach(),b.parsed||(b=n.parseEl(n.index));var c=b.type;y("BeforeChange",[n.currItem?n.currItem.type:"",c]),n.currItem=b;if(!n.currTemplate[c]){var d=n.st[c]?n.st[c].markup:!1;y("FirstMarkupParse",d),d?n.currTemplate[c]=a(d):n.currTemplate[c]=!0}t&&t!==b.type&&n.container.removeClass("mfp-"+t+"-holder");var e=n["get"+c.charAt(0).toUpperCase()+c.slice(1)](b,n.currTemplate[c]);n.appendContent(e,c),b.preloaded=!0,y(h,b),t=b.type,n.container.prepend(n.contentContainer),y("AfterChange")},appendContent:function(a,b){n.content=a,a?n.st.showCloseBtn&&n.st.closeBtnInside&&n.currTemplate[b]===!0?n.content.find(".mfp-close").length||n.content.append(z()):n.content=a:n.content="",y(e),n.container.addClass("mfp-"+b+"-holder"),n.contentContainer.append(n.content)},parseEl:function(b){var c=n.items[b],d;c.tagName?c={el:a(c)}:(d=c.type,c={data:c,src:c.src});if(c.el){var e=n.types;for(var f=0;f<e.length;f++)if(c.el.hasClass("mfp-"+e[f])){d=e[f];break}c.src=c.el.attr("data-mfp-src"),c.src||(c.src=c.el.attr("href"))}return c.type=d||n.st.type||"inline",c.index=b,c.parsed=!0,n.items[b]=c,y("ElementParse",c),n.items[b]},addGroup:function(a,b){var c=function(c){c.mfpEl=this,n._openClick(c,a,b)};b||(b={});var d="click.magnificPopup";b.mainEl=a,b.items?(b.isObj=!0,a.off(d).on(d,c)):(b.isObj=!1,b.delegate?a.off(d).on(d,b.delegate,c):(b.items=a,a.off(d).on(d,c)))},_openClick:function(b,c,d){var e=d.midClick!==undefined?d.midClick:a.magnificPopup.defaults.midClick;if(!e&&(b.which===2||b.ctrlKey||b.metaKey))return;var f=d.disableOn!==undefined?d.disableOn:a.magnificPopup.defaults.disableOn;if(f)if(a.isFunction(f)){if(!f.call(n))return!0}else if(r.width()<f)return!0;b.type&&(b.preventDefault(),n.isOpen&&b.stopPropagation()),d.el=a(b.mfpEl),d.delegate&&(d.items=c.find(d.delegate)),n.open(d)},updateStatus:function(a,b){if(n.preloader){q!==a&&n.container.removeClass("mfp-s-"+q),!b&&a==="loading"&&(b=n.st.tLoading);var c={status:a,text:b};y("UpdateStatus",c),a=c.status,b=c.text,n.preloader.html(b),n.preloader.find("a").on("click",function(a){a.stopImmediatePropagation()}),n.container.addClass("mfp-s-"+a),q=a}},_checkIfClose:function(b){if(a(b).hasClass(m))return;var c=n.st.closeOnContentClick,d=n.st.closeOnBgClick;if(c&&d)return!0;if(!n.content||a(b).hasClass("mfp-close")||n.preloader&&b===n.preloader[0])return!0;if(b!==n.content[0]&&!a.contains(n.content[0],b)){if(d&&a.contains(document,b))return!0}else if(c)return!0;return!1},_addClassToMFP:function(a){n.bgOverlay.addClass(a),n.wrap.addClass(a)},_removeClassFromMFP:function(a){this.bgOverlay.removeClass(a),n.wrap.removeClass(a)},_hasScrollBar:function(a){return(n.isIE7?s.height():document.body.scrollHeight)>(a||r.height())},_setFocus:function(){(n.st.focus?n.content.find(n.st.focus).eq(0):n.wrap).focus()},_onFocusIn:function(b){if(b.target!==n.wrap[0]&&!a.contains(n.wrap[0],b.target))return n._setFocus(),!1},_parseMarkup:function(b,c,d){var e;d.data&&(c=a.extend(d.data,c)),y(f,[b,c,d]),a.each(c,function(a,c){if(c===undefined||c===!1)return!0;e=a.split("_");if(e.length>1){var d=b.find(j+"-"+e[0]);if(d.length>0){var f=e[1];f==="replaceWith"?d[0]!==c[0]&&d.replaceWith(c):f==="img"?d.is("img")?d.attr("src",c):d.replaceWith('<img src="'+c+'" class="'+d.attr("class")+'" />'):d.attr(e[1],c)}}else b.find(j+"-"+a).html(c)})},_getScrollbarSize:function(){if(n.scrollbarSize===undefined){var a=document.createElement("div");a.style.cssText="width: 99px; height: 99px; overflow: scroll; position: absolute; top: -9999px;",document.body.appendChild(a),n.scrollbarSize=a.offsetWidth-a.clientWidth,document.body.removeChild(a)}return n.scrollbarSize}},a.magnificPopup={instance:null,proto:o.prototype,modules:[],open:function(b,c){return A(),b?b=a.extend(!0,{},b):b={},b.isObj=!0,b.index=c||0,this.instance.open(b)},close:function(){return a.magnificPopup.instance&&a.magnificPopup.instance.close()},registerModule:function(b,c){c.options&&(a.magnificPopup.defaults[b]=c.options),a.extend(this.proto,c.proto),this.modules.push(b)},defaults:{disableOn:0,key:null,midClick:!1,mainClass:"",preloader:!0,focus:"",closeOnContentClick:!1,closeOnBgClick:!0,closeBtnInside:!0,showCloseBtn:!0,enableEscapeKey:!0,modal:!1,alignTop:!1,removalDelay:0,prependTo:null,fixedContentPos:"auto",fixedBgPos:"auto",overflowY:"auto",closeMarkup:'<button title="%title%" type="button" class="mfp-close">&times;</button>',tClose:"Close (Esc)",tLoading:"Loading..."}},a.fn.magnificPopup=function(b){A();var c=a(this);if(typeof b=="string")if(b==="open"){var d,e=p?c.data("magnificPopup"):c[0].magnificPopup,f=parseInt(arguments[1],10)||0;e.items?d=e.items[f]:(d=c,e.delegate&&(d=d.find(e.delegate)),d=d.eq(f)),n._openClick({mfpEl:d},c,e)}else n.isOpen&&n[b].apply(n,Array.prototype.slice.call(arguments,1));else b=a.extend(!0,{},b),p?c.data("magnificPopup",b):c[0].magnificPopup=b,n.addGroup(c,b);return c};var C="inline",D,E,F,G=function(){F&&(E.after(F.addClass(D)).detach(),F=null)};a.magnificPopup.registerModule(C,{options:{hiddenClass:"hide",markup:"",tNotFound:"Content not found"},proto:{initInline:function(){n.types.push(C),w(b+"."+C,function(){G()})},getInline:function(b,c){G();if(b.src){var d=n.st.inline,e=a(b.src);if(e.length){var f=e[0].parentNode;f&&f.tagName&&(E||(D=d.hiddenClass,E=x(D),D="mfp-"+D),F=e.after(E).detach().removeClass(D)),n.updateStatus("ready")}else n.updateStatus("error",d.tNotFound),e=a("<div>");return b.inlineElement=e,e}return n.updateStatus("ready"),n._parseMarkup(c,{},b),c}}});var H="ajax",I,J=function(){I&&a(document.body).removeClass(I)},K=function(){J(),n.req&&n.req.abort()};a.magnificPopup.registerModule(H,{options:{settings:null,cursor:"mfp-ajax-cur",tError:'<a href="%url%">The content</a> could not be loaded.'},proto:{initAjax:function(){n.types.push(H),I=n.st.ajax.cursor,w(b+"."+H,K),w("BeforeChange."+H,K)},getAjax:function(b){I&&a(document.body).addClass(I),n.updateStatus("loading");var c=a.extend({url:b.src,success:function(c,d,e){var f={data:c,xhr:e};y("ParseAjax",f),n.appendContent(a(f.data),H),b.finished=!0,J(),n._setFocus(),setTimeout(function(){n.wrap.addClass(k)},16),n.updateStatus("ready"),y("AjaxContentAdded")},error:function(){J(),b.finished=b.loadError=!0,n.updateStatus("error",n.st.ajax.tError.replace("%url%",b.src))}},n.st.ajax.settings);return n.req=a.ajax(c),""}}});var L,M=function(b){if(b.data&&b.data.title!==undefined)return b.data.title;var c=n.st.image.titleSrc;if(c){if(a.isFunction(c))return c.call(n,b);if(b.el)return b.el.attr(c)||""}return""};a.magnificPopup.registerModule("image",{options:{markup:'<div class="mfp-figure"><div class="mfp-close"></div><figure><div class="mfp-img"></div><figcaption><div class="mfp-bottom-bar"><div class="mfp-title"></div><div class="mfp-counter"></div></div></figcaption></figure></div>',cursor:"mfp-zoom-out-cur",titleSrc:"title",verticalFit:!0,tError:'<a href="%url%">The image</a> could not be loaded.'},proto:{initImage:function(){var c=n.st.image,d=".image";n.types.push("image"),w(g+d,function(){n.currItem.type==="image"&&c.cursor&&a(document.body).addClass(c.cursor)}),w(b+d,function(){c.cursor&&a(document.body).removeClass(c.cursor),r.off("resize"+j)}),w("Resize"+d,n.resizeImage),n.isLowIE&&w("AfterChange",n.resizeImage)},resizeImage:function(){var a=n.currItem;if(!a||!a.img)return;if(n.st.image.verticalFit){var b=0;n.isLowIE&&(b=parseInt(a.img.css("padding-top"),10)+parseInt(a.img.css("padding-bottom"),10)),a.img.css("max-height",n.wH-b)}},_onImageHasSize:function(a){a.img&&(a.hasSize=!0,L&&clearInterval(L),a.isCheckingImgSize=!1,y("ImageHasSize",a),a.imgHidden&&(n.content&&n.content.removeClass("mfp-loading"),a.imgHidden=!1))},findImageSize:function(a){var b=0,c=a.img[0],d=function(e){L&&clearInterval(L),L=setInterval(function(){if(c.naturalWidth>0){n._onImageHasSize(a);return}b>200&&clearInterval(L),b++,b===3?d(10):b===40?d(50):b===100&&d(500)},e)};d(1)},getImage:function(b,c){var d=0,e=function(){b&&(b.img[0].complete?(b.img.off(".mfploader"),b===n.currItem&&(n._onImageHasSize(b),n.updateStatus("ready")),b.hasSize=!0,b.loaded=!0,y("ImageLoadComplete")):(d++,d<200?setTimeout(e,100):f()))},f=function(){b&&(b.img.off(".mfploader"),b===n.currItem&&(n._onImageHasSize(b),n.updateStatus("error",g.tError.replace("%url%",b.src))),b.hasSize=!0,b.loaded=!0,b.loadError=!0)},g=n.st.image,h=c.find(".mfp-img");if(h.length){var i=document.createElement("img");i.className="mfp-img",b.el&&b.el.find("img").length&&(i.alt=b.el.find("img").attr("alt")),b.img=a(i).on("load.mfploader",e).on("error.mfploader",f),i.src=b.src,h.is("img")&&(b.img=b.img.clone()),i=b.img[0],i.naturalWidth>0?b.hasSize=!0:i.width||(b.hasSize=!1)}return n._parseMarkup(c,{title:M(b),img_replaceWith:b.img},b),n.resizeImage(),b.hasSize?(L&&clearInterval(L),b.loadError?(c.addClass("mfp-loading"),n.updateStatus("error",g.tError.replace("%url%",b.src))):(c.removeClass("mfp-loading"),n.updateStatus("ready")),c):(n.updateStatus("loading"),b.loading=!0,b.hasSize||(b.imgHidden=!0,c.addClass("mfp-loading"),n.findImageSize(b)),c)}}});var N,O=function(){return N===undefined&&(N=document.createElement("p").style.MozTransform!==undefined),N};a.magnificPopup.registerModule("zoom",{options:{enabled:!1,easing:"ease-in-out",duration:300,opener:function(a){return a.is("img")?a:a.find("img")}},proto:{initZoom:function(){var a=n.st.zoom,d=".zoom",e;if(!a.enabled||!n.supportsTransition)return;var f=a.duration,g=function(b){var c=b.clone().removeAttr("style").removeAttr("class").addClass("mfp-animated-image"),d="all "+a.duration/1e3+"s "+a.easing,e={position:"fixed",zIndex:9999,left:0,top:0,"-webkit-backface-visibility":"hidden"},f="transition";return e["-webkit-"+f]=e["-moz-"+f]=e["-o-"+f]=e[f]=d,c.css(e),c},h=function(){n.content.css("visibility","visible")},i,j;w("BuildControls"+d,function(){if(n._allowZoom()){clearTimeout(i),n.content.css("visibility","hidden"),e=n._getItemToZoom();if(!e){h();return}j=g(e),j.css(n._getOffset()),n.wrap.append(j),i=setTimeout(function(){j.css(n._getOffset(!0)),i=setTimeout(function(){h(),setTimeout(function(){j.remove(),e=j=null,y("ZoomAnimationEnded")},16)},f)},16)}}),w(c+d,function(){if(n._allowZoom()){clearTimeout(i),n.st.removalDelay=f;if(!e){e=n._getItemToZoom();if(!e)return;j=g(e)}j.css(n._getOffset(!0)),n.wrap.append(j),n.content.css("visibility","hidden"),setTimeout(function(){j.css(n._getOffset())},16)}}),w(b+d,function(){n._allowZoom()&&(h(),j&&j.remove(),e=null)})},_allowZoom:function(){return n.currItem.type==="image"},_getItemToZoom:function(){return n.currItem.hasSize?n.currItem.img:!1},_getOffset:function(b){var c;b?c=n.currItem.img:c=n.st.zoom.opener(n.currItem.el||n.currItem);var d=c.offset(),e=parseInt(c.css("padding-top"),10),f=parseInt(c.css("padding-bottom"),10);d.top-=a(window).scrollTop()-e;var g={width:c.width(),height:(p?c.innerHeight():c[0].offsetHeight)-f-e};return O()?g["-moz-transform"]=g.transform="translate("+d.left+"px,"+d.top+"px)":(g.left=d.left,g.top=d.top),g}}});var P="iframe",Q="//about:blank",R=function(a){if(n.currTemplate[P]){var b=n.currTemplate[P].find("iframe");b.length&&(a||(b[0].src=Q),n.isIE8&&b.css("display",a?"block":"none"))}};a.magnificPopup.registerModule(P,{options:{markup:'<div class="mfp-iframe-scaler"><div class="mfp-close"></div><iframe class="mfp-iframe" src="//about:blank" frameborder="0" allowfullscreen></iframe></div>',srcAction:"iframe_src",patterns:{youtube:{index:"youtube.com",id:"v=",src:"//www.youtube.com/embed/%id%?autoplay=1"},vimeo:{index:"vimeo.com/",id:"/",src:"//player.vimeo.com/video/%id%?autoplay=1"},gmaps:{index:"//maps.google.",src:"%id%&output=embed"}}},proto:{initIframe:function(){n.types.push(P),w("BeforeChange",function(a,b,c){b!==c&&(b===P?R():c===P&&R(!0))}),w(b+"."+P,function(){R()})},getIframe:function(b,c){var d=b.src,e=n.st.iframe;a.each(e.patterns,function(){if(d.indexOf(this.index)>-1)return this.id&&(typeof this.id=="string"?d=d.substr(d.lastIndexOf(this.id)+this.id.length,d.length):d=this.id.call(this,d)),d=this.src.replace("%id%",d),!1});var f={};return e.srcAction&&(f[e.srcAction]=d),n._parseMarkup(c,f,b),n.updateStatus("ready"),c}}});var S=function(a){var b=n.items.length;return a>b-1?a-b:a<0?b+a:a},T=function(a,b,c){return a.replace(/%curr%/gi,b+1).replace(/%total%/gi,c)};a.magnificPopup.registerModule("gallery",{options:{enabled:!1,arrowMarkup:'<button title="%title%" type="button" class="mfp-arrow mfp-arrow-%dir%"></button>',preload:[0,2],navigateByImgClick:!0,arrows:!0,tPrev:"Previous (Left arrow key)",tNext:"Next (Right arrow key)",tCounter:"%curr% of %total%"},proto:{initGallery:function(){var c=n.st.gallery,d=".mfp-gallery",e=Boolean(a.fn.mfpFastClick);n.direction=!0;if(!c||!c.enabled)return!1;u+=" mfp-gallery",w(g+d,function(){c.navigateByImgClick&&n.wrap.on("click"+d,".mfp-img",function(){if(n.items.length>1)return n.next(),!1}),s.on("keydown"+d,function(a){a.keyCode===37?n.prev():a.keyCode===39&&n.next()})}),w("UpdateStatus"+d,function(a,b){b.text&&(b.text=T(b.text,n.currItem.index,n.items.length))}),w(f+d,function(a,b,d,e){var f=n.items.length;d.counter=f>1?T(c.tCounter,e.index,f):""}),w("BuildControls"+d,function(){if(n.items.length>1&&c.arrows&&!n.arrowLeft){var b=c.arrowMarkup,d=n.arrowLeft=a(b.replace(/%title%/gi,c.tPrev).replace(/%dir%/gi,"left")).addClass(m),f=n.arrowRight=a(b.replace(/%title%/gi,c.tNext).replace(/%dir%/gi,"right")).addClass(m),g=e?"mfpFastClick":"click";d[g](function(){n.prev()}),f[g](function(){n.next()}),n.isIE7&&(x("b",d[0],!1,!0),x("a",d[0],!1,!0),x("b",f[0],!1,!0),x("a",f[0],!1,!0)),n.container.append(d.add(f))}}),w(h+d,function(){n._preloadTimeout&&clearTimeout(n._preloadTimeout),n._preloadTimeout=setTimeout(function(){n.preloadNearbyImages(),n._preloadTimeout=null},16)}),w(b+d,function(){s.off(d),n.wrap.off("click"+d),n.arrowLeft&&e&&n.arrowLeft.add(n.arrowRight).destroyMfpFastClick(),n.arrowRight=n.arrowLeft=null})},next:function(){n.direction=!0,n.index=S(n.index+1),n.updateItemHTML()},prev:function(){n.direction=!1,n.index=S(n.index-1),n.updateItemHTML()},goTo:function(a){n.direction=a>=n.index,n.index=a,n.updateItemHTML()},preloadNearbyImages:function(){var a=n.st.gallery.preload,b=Math.min(a[0],n.items.length),c=Math.min(a[1],n.items.length),d;for(d=1;d<=(n.direction?c:b);d++)n._preloadItem(n.index+d);for(d=1;d<=(n.direction?b:c);d++)n._preloadItem(n.index-d)},_preloadItem:function(b){b=S(b);if(n.items[b].preloaded)return;var c=n.items[b];c.parsed||(c=n.parseEl(b)),y("LazyLoad",c),c.type==="image"&&(c.img=a('<img class="mfp-img" />').on("load.mfploader",function(){c.hasSize=!0}).on("error.mfploader",function(){c.hasSize=!0,c.loadError=!0,y("LazyLoadError",c)}).attr("src",c.src)),c.preloaded=!0}}});var U="retina";a.magnificPopup.registerModule(U,{options:{replaceSrc:function(a){return a.src.replace(/\.\w+$/,function(a){return"@2x"+a})},ratio:1},proto:{initRetina:function(){if(window.devicePixelRatio>1){var a=n.st.retina,b=a.ratio;b=isNaN(b)?b():b,b>1&&(w("ImageHasSize."+U,function(a,c){c.img.css({"max-width":c.img[0].naturalWidth/b,width:"100%"})}),w("ElementParse."+U,function(c,d){d.src=a.replaceSrc(d,b)}))}}}}),function(){var b=1e3,c="ontouchstart"in window,d=function(){r.off("touchmove"+f+" touchend"+f)},e="mfpFastClick",f="."+e;a.fn.mfpFastClick=function(e){return a(this).each(function(){var g=a(this),h;if(c){var i,j,k,l,m,n;g.on("touchstart"+f,function(a){l=!1,n=1,m=a.originalEvent?a.originalEvent.touches[0]:a.touches[0],j=m.clientX,k=m.clientY,r.on("touchmove"+f,function(a){m=a.originalEvent?a.originalEvent.touches:a.touches,n=m.length,m=m[0];if(Math.abs(m.clientX-j)>10||Math.abs(m.clientY-k)>10)l=!0,d()}).on("touchend"+f,function(a){d();if(l||n>1)return;h=!0,a.preventDefault(),clearTimeout(i),i=setTimeout(function(){h=!1},b),e()})})}g.on("click"+f,function(){h||e()})})},a.fn.destroyMfpFastClick=function(){a(this).off("touchstart"+f+" click"+f),c&&r.off("touchmove"+f+" touchend"+f)}}(),A()})

/*!
Waypoints - 4.0.0
Copyright © 2011-2015 Caleb Troughton
Licensed under the MIT license.
https://github.com/imakewebthings/waypoints/blog/master/licenses.txt
*/
!function(){"use strict";function t(o){if(!o)throw new Error("No options passed to Waypoint constructor");if(!o.element)throw new Error("No element option passed to Waypoint constructor");if(!o.handler)throw new Error("No handler option passed to Waypoint constructor");this.key="waypoint-"+e,this.options=t.Adapter.extend({},t.defaults,o),this.element=this.options.element,this.adapter=new t.Adapter(this.element),this.callback=o.handler,this.axis=this.options.horizontal?"horizontal":"vertical",this.enabled=this.options.enabled,this.triggerPoint=null,this.group=t.Group.findOrCreate({name:this.options.group,axis:this.axis}),this.context=t.Context.findOrCreateByElement(this.options.context),t.offsetAliases[this.options.offset]&&(this.options.offset=t.offsetAliases[this.options.offset]),this.group.add(this),this.context.add(this),i[this.key]=this,e+=1}var e=0,i={};t.prototype.queueTrigger=function(t){this.group.queueTrigger(this,t)},t.prototype.trigger=function(t){this.enabled&&this.callback&&this.callback.apply(this,t)},t.prototype.destroy=function(){this.context.remove(this),this.group.remove(this),delete i[this.key]},t.prototype.disable=function(){return this.enabled=!1,this},t.prototype.enable=function(){return this.context.refresh(),this.enabled=!0,this},t.prototype.next=function(){return this.group.next(this)},t.prototype.previous=function(){return this.group.previous(this)},t.invokeAll=function(t){var e=[];for(var o in i)e.push(i[o]);for(var n=0,r=e.length;r>n;n++)e[n][t]()},t.destroyAll=function(){t.invokeAll("destroy")},t.disableAll=function(){t.invokeAll("disable")},t.enableAll=function(){t.invokeAll("enable")},t.refreshAll=function(){t.Context.refreshAll()},t.viewportHeight=function(){return window.innerHeight||document.documentElement.clientHeight},t.viewportWidth=function(){return document.documentElement.clientWidth},t.adapters=[],t.defaults={context:window,continuous:!0,enabled:!0,group:"default",horizontal:!1,offset:0},t.offsetAliases={"bottom-in-view":function(){return this.context.innerHeight()-this.adapter.outerHeight()},"right-in-view":function(){return this.context.innerWidth()-this.adapter.outerWidth()}},window.Waypoint=t}(),function(){"use strict";function t(t){window.setTimeout(t,1e3/60)}function e(t){this.element=t,this.Adapter=n.Adapter,this.adapter=new this.Adapter(t),this.key="waypoint-context-"+i,this.didScroll=!1,this.didResize=!1,this.oldScroll={x:this.adapter.scrollLeft(),y:this.adapter.scrollTop()},this.waypoints={vertical:{},horizontal:{}},t.waypointContextKey=this.key,o[t.waypointContextKey]=this,i+=1,this.createThrottledScrollHandler(),this.createThrottledResizeHandler()}var i=0,o={},n=window.Waypoint,r=window.onload;e.prototype.add=function(t){var e=t.options.horizontal?"horizontal":"vertical";this.waypoints[e][t.key]=t,this.refresh()},e.prototype.checkEmpty=function(){var t=this.Adapter.isEmptyObject(this.waypoints.horizontal),e=this.Adapter.isEmptyObject(this.waypoints.vertical);t&&e&&(this.adapter.off(".waypoints"),delete o[this.key])},e.prototype.createThrottledResizeHandler=function(){function t(){e.handleResize(),e.didResize=!1}var e=this;this.adapter.on("resize.waypoints",function(){e.didResize||(e.didResize=!0,n.requestAnimationFrame(t))})},e.prototype.createThrottledScrollHandler=function(){function t(){e.handleScroll(),e.didScroll=!1}var e=this;this.adapter.on("scroll.waypoints",function(){(!e.didScroll||n.isTouch)&&(e.didScroll=!0,n.requestAnimationFrame(t))})},e.prototype.handleResize=function(){n.Context.refreshAll()},e.prototype.handleScroll=function(){var t={},e={horizontal:{newScroll:this.adapter.scrollLeft(),oldScroll:this.oldScroll.x,forward:"right",backward:"left"},vertical:{newScroll:this.adapter.scrollTop(),oldScroll:this.oldScroll.y,forward:"down",backward:"up"}};for(var i in e){var o=e[i],n=o.newScroll>o.oldScroll,r=n?o.forward:o.backward;for(var s in this.waypoints[i]){var a=this.waypoints[i][s],l=o.oldScroll<a.triggerPoint,h=o.newScroll>=a.triggerPoint,p=l&&h,u=!l&&!h;(p||u)&&(a.queueTrigger(r),t[a.group.id]=a.group)}}for(var c in t)t[c].flushTriggers();this.oldScroll={x:e.horizontal.newScroll,y:e.vertical.newScroll}},e.prototype.innerHeight=function(){return this.element==this.element.window?n.viewportHeight():this.adapter.innerHeight()},e.prototype.remove=function(t){delete this.waypoints[t.axis][t.key],this.checkEmpty()},e.prototype.innerWidth=function(){return this.element==this.element.window?n.viewportWidth():this.adapter.innerWidth()},e.prototype.destroy=function(){var t=[];for(var e in this.waypoints)for(var i in this.waypoints[e])t.push(this.waypoints[e][i]);for(var o=0,n=t.length;n>o;o++)t[o].destroy()},e.prototype.refresh=function(){var t,e=this.element==this.element.window,i=e?void 0:this.adapter.offset(),o={};this.handleScroll(),t={horizontal:{contextOffset:e?0:i.left,contextScroll:e?0:this.oldScroll.x,contextDimension:this.innerWidth(),oldScroll:this.oldScroll.x,forward:"right",backward:"left",offsetProp:"left"},vertical:{contextOffset:e?0:i.top,contextScroll:e?0:this.oldScroll.y,contextDimension:this.innerHeight(),oldScroll:this.oldScroll.y,forward:"down",backward:"up",offsetProp:"top"}};for(var r in t){var s=t[r];for(var a in this.waypoints[r]){var l,h,p,u,c,d=this.waypoints[r][a],f=d.options.offset,w=d.triggerPoint,y=0,g=null==w;d.element!==d.element.window&&(y=d.adapter.offset()[s.offsetProp]),"function"==typeof f?f=f.apply(d):"string"==typeof f&&(f=parseFloat(f),d.options.offset.indexOf("%")>-1&&(f=Math.ceil(s.contextDimension*f/100))),l=s.contextScroll-s.contextOffset,d.triggerPoint=y+l-f,h=w<s.oldScroll,p=d.triggerPoint>=s.oldScroll,u=h&&p,c=!h&&!p,!g&&u?(d.queueTrigger(s.backward),o[d.group.id]=d.group):!g&&c?(d.queueTrigger(s.forward),o[d.group.id]=d.group):g&&s.oldScroll>=d.triggerPoint&&(d.queueTrigger(s.forward),o[d.group.id]=d.group)}}return n.requestAnimationFrame(function(){for(var t in o)o[t].flushTriggers()}),this},e.findOrCreateByElement=function(t){return e.findByElement(t)||new e(t)},e.refreshAll=function(){for(var t in o)o[t].refresh()},e.findByElement=function(t){return o[t.waypointContextKey]},window.onload=function(){r&&r(),e.refreshAll()},n.requestAnimationFrame=function(e){var i=window.requestAnimationFrame||window.mozRequestAnimationFrame||window.webkitRequestAnimationFrame||t;i.call(window,e)},n.Context=e}(),function(){"use strict";function t(t,e){return t.triggerPoint-e.triggerPoint}function e(t,e){return e.triggerPoint-t.triggerPoint}function i(t){this.name=t.name,this.axis=t.axis,this.id=this.name+"-"+this.axis,this.waypoints=[],this.clearTriggerQueues(),o[this.axis][this.name]=this}var o={vertical:{},horizontal:{}},n=window.Waypoint;i.prototype.add=function(t){this.waypoints.push(t)},i.prototype.clearTriggerQueues=function(){this.triggerQueues={up:[],down:[],left:[],right:[]}},i.prototype.flushTriggers=function(){for(var i in this.triggerQueues){var o=this.triggerQueues[i],n="up"===i||"left"===i;o.sort(n?e:t);for(var r=0,s=o.length;s>r;r+=1){var a=o[r];(a.options.continuous||r===o.length-1)&&a.trigger([i])}}this.clearTriggerQueues()},i.prototype.next=function(e){this.waypoints.sort(t);var i=n.Adapter.inArray(e,this.waypoints),o=i===this.waypoints.length-1;return o?null:this.waypoints[i+1]},i.prototype.previous=function(e){this.waypoints.sort(t);var i=n.Adapter.inArray(e,this.waypoints);return i?this.waypoints[i-1]:null},i.prototype.queueTrigger=function(t,e){this.triggerQueues[e].push(t)},i.prototype.remove=function(t){var e=n.Adapter.inArray(t,this.waypoints);e>-1&&this.waypoints.splice(e,1)},i.prototype.first=function(){return this.waypoints[0]},i.prototype.last=function(){return this.waypoints[this.waypoints.length-1]},i.findOrCreate=function(t){return o[t.axis][t.name]||new i(t)},n.Group=i}(),function(){"use strict";function t(t){this.$element=e(t)}var e=window.jQuery,i=window.Waypoint;e.each(["innerHeight","innerWidth","off","offset","on","outerHeight","outerWidth","scrollLeft","scrollTop"],function(e,i){t.prototype[i]=function(){var t=Array.prototype.slice.call(arguments);return this.$element[i].apply(this.$element,t)}}),e.each(["extend","inArray","isEmptyObject"],function(i,o){t[o]=e[o]}),i.adapters.push({name:"jquery",Adapter:t}),i.Adapter=t}(),function(){"use strict";function t(t){return function(){var i=[],o=arguments[0];return t.isFunction(arguments[0])&&(o=t.extend({},arguments[1]),o.handler=arguments[0]),this.each(function(){var n=t.extend({},o,{element:this});"string"==typeof n.context&&(n.context=t(this).closest(n.context)[0]),i.push(new e(n))}),i}}var e=window.Waypoint;window.jQuery&&(window.jQuery.fn.waypoint=t(window.jQuery)),window.Zepto&&(window.Zepto.fn.waypoint=t(window.Zepto))}();

/*
     _ _      _       _
 ___| (_) ___| | __  (_)___
/ __| | |/ __| |/ /  | / __|
\__ \ | | (__|   < _ | \__ \
|___/_|_|\___|_|\_(_)/ |___/
                   |__/

 Version: 1.5.9
  Author: Ken Wheeler
 Website: http://kenwheeler.github.io
    Docs: http://kenwheeler.github.io/slick
    Repo: http://github.com/kenwheeler/slick
  Issues: http://github.com/kenwheeler/slick/issues

 */
!function(a){"use strict";"function"==typeof define&&define.amd?define(["jquery"],a):"undefined"!=typeof exports?module.exports=a(require("jquery")):a(jQuery)}(function(a){"use strict";var b=window.Slick||{};b=function(){function c(c,d){var f,e=this;e.defaults={accessibility:!0,adaptiveHeight:!1,appendArrows:a(c),appendDots:a(c),arrows:!0,asNavFor:null,prevArrow:'<button type="button" data-role="none" class="slick-prev" aria-label="Previous" tabindex="0" role="button">Previous</button>',nextArrow:'<button type="button" data-role="none" class="slick-next" aria-label="Next" tabindex="0" role="button">Next</button>',autoplay:!1,autoplaySpeed:3e3,centerMode:!1,centerPadding:"50px",cssEase:"ease",customPaging:function(a,b){return'<button type="button" data-role="none" role="button" aria-required="false" tabindex="0">'+(b+1)+"</button>"},dots:!1,dotsClass:"slick-dots",draggable:!0,easing:"linear",edgeFriction:.35,fade:!1,focusOnSelect:!1,infinite:!0,initialSlide:0,lazyLoad:"ondemand",mobileFirst:!1,pauseOnHover:!0,pauseOnDotsHover:!1,respondTo:"window",responsive:null,rows:1,rtl:!1,slide:"",slidesPerRow:1,slidesToShow:1,slidesToScroll:1,speed:500,swipe:!0,swipeToSlide:!1,touchMove:!0,touchThreshold:5,useCSS:!0,useTransform:!1,variableWidth:!1,vertical:!1,verticalSwiping:!1,waitForAnimate:!0,zIndex:1e3},e.initials={animating:!1,dragging:!1,autoPlayTimer:null,currentDirection:0,currentLeft:null,currentSlide:0,direction:1,$dots:null,listWidth:null,listHeight:null,loadIndex:0,$nextArrow:null,$prevArrow:null,slideCount:null,slideWidth:null,$slideTrack:null,$slides:null,sliding:!1,slideOffset:0,swipeLeft:null,$list:null,touchObject:{},transformsEnabled:!1,unslicked:!1},a.extend(e,e.initials),e.activeBreakpoint=null,e.animType=null,e.animProp=null,e.breakpoints=[],e.breakpointSettings=[],e.cssTransitions=!1,e.hidden="hidden",e.paused=!1,e.positionProp=null,e.respondTo=null,e.rowCount=1,e.shouldClick=!0,e.$slider=a(c),e.$slidesCache=null,e.transformType=null,e.transitionType=null,e.visibilityChange="visibilitychange",e.windowWidth=0,e.windowTimer=null,f=a(c).data("slick")||{},e.options=a.extend({},e.defaults,f,d),e.currentSlide=e.options.initialSlide,e.originalSettings=e.options,"undefined"!=typeof document.mozHidden?(e.hidden="mozHidden",e.visibilityChange="mozvisibilitychange"):"undefined"!=typeof document.webkitHidden&&(e.hidden="webkitHidden",e.visibilityChange="webkitvisibilitychange"),e.autoPlay=a.proxy(e.autoPlay,e),e.autoPlayClear=a.proxy(e.autoPlayClear,e),e.changeSlide=a.proxy(e.changeSlide,e),e.clickHandler=a.proxy(e.clickHandler,e),e.selectHandler=a.proxy(e.selectHandler,e),e.setPosition=a.proxy(e.setPosition,e),e.swipeHandler=a.proxy(e.swipeHandler,e),e.dragHandler=a.proxy(e.dragHandler,e),e.keyHandler=a.proxy(e.keyHandler,e),e.autoPlayIterator=a.proxy(e.autoPlayIterator,e),e.instanceUid=b++,e.htmlExpr=/^(?:\s*(<[\w\W]+>)[^>]*)$/,e.registerBreakpoints(),e.init(!0),e.checkResponsive(!0)}var b=0;return c}(),b.prototype.addSlide=b.prototype.slickAdd=function(b,c,d){var e=this;if("boolean"==typeof c)d=c,c=null;else if(0>c||c>=e.slideCount)return!1;e.unload(),"number"==typeof c?0===c&&0===e.$slides.length?a(b).appendTo(e.$slideTrack):d?a(b).insertBefore(e.$slides.eq(c)):a(b).insertAfter(e.$slides.eq(c)):d===!0?a(b).prependTo(e.$slideTrack):a(b).appendTo(e.$slideTrack),e.$slides=e.$slideTrack.children(this.options.slide),e.$slideTrack.children(this.options.slide).detach(),e.$slideTrack.append(e.$slides),e.$slides.each(function(b,c){a(c).attr("data-slick-index",b)}),e.$slidesCache=e.$slides,e.reinit()},b.prototype.animateHeight=function(){var a=this;if(1===a.options.slidesToShow&&a.options.adaptiveHeight===!0&&a.options.vertical===!1){var b=a.$slides.eq(a.currentSlide).outerHeight(!0);a.$list.animate({height:b},a.options.speed)}},b.prototype.animateSlide=function(b,c){var d={},e=this;e.animateHeight(),e.options.rtl===!0&&e.options.vertical===!1&&(b=-b),e.transformsEnabled===!1?e.options.vertical===!1?e.$slideTrack.animate({left:b},e.options.speed,e.options.easing,c):e.$slideTrack.animate({top:b},e.options.speed,e.options.easing,c):e.cssTransitions===!1?(e.options.rtl===!0&&(e.currentLeft=-e.currentLeft),a({animStart:e.currentLeft}).animate({animStart:b},{duration:e.options.speed,easing:e.options.easing,step:function(a){a=Math.ceil(a),e.options.vertical===!1?(d[e.animType]="translate("+a+"px, 0px)",e.$slideTrack.css(d)):(d[e.animType]="translate(0px,"+a+"px)",e.$slideTrack.css(d))},complete:function(){c&&c.call()}})):(e.applyTransition(),b=Math.ceil(b),e.options.vertical===!1?d[e.animType]="translate3d("+b+"px, 0px, 0px)":d[e.animType]="translate3d(0px,"+b+"px, 0px)",e.$slideTrack.css(d),c&&setTimeout(function(){e.disableTransition(),c.call()},e.options.speed))},b.prototype.asNavFor=function(b){var c=this,d=c.options.asNavFor;d&&null!==d&&(d=a(d).not(c.$slider)),null!==d&&"object"==typeof d&&d.each(function(){var c=a(this).slick("getSlick");c.unslicked||c.slideHandler(b,!0)})},b.prototype.applyTransition=function(a){var b=this,c={};b.options.fade===!1?c[b.transitionType]=b.transformType+" "+b.options.speed+"ms "+b.options.cssEase:c[b.transitionType]="opacity "+b.options.speed+"ms "+b.options.cssEase,b.options.fade===!1?b.$slideTrack.css(c):b.$slides.eq(a).css(c)},b.prototype.autoPlay=function(){var a=this;a.autoPlayTimer&&clearInterval(a.autoPlayTimer),a.slideCount>a.options.slidesToShow&&a.paused!==!0&&(a.autoPlayTimer=setInterval(a.autoPlayIterator,a.options.autoplaySpeed))},b.prototype.autoPlayClear=function(){var a=this;a.autoPlayTimer&&clearInterval(a.autoPlayTimer)},b.prototype.autoPlayIterator=function(){var a=this;a.options.infinite===!1?1===a.direction?(a.currentSlide+1===a.slideCount-1&&(a.direction=0),a.slideHandler(a.currentSlide+a.options.slidesToScroll)):(a.currentSlide-1===0&&(a.direction=1),a.slideHandler(a.currentSlide-a.options.slidesToScroll)):a.slideHandler(a.currentSlide+a.options.slidesToScroll)},b.prototype.buildArrows=function(){var b=this;b.options.arrows===!0&&(b.$prevArrow=a(b.options.prevArrow).addClass("slick-arrow"),b.$nextArrow=a(b.options.nextArrow).addClass("slick-arrow"),b.slideCount>b.options.slidesToShow?(b.$prevArrow.removeClass("slick-hidden").removeAttr("aria-hidden tabindex"),b.$nextArrow.removeClass("slick-hidden").removeAttr("aria-hidden tabindex"),b.htmlExpr.test(b.options.prevArrow)&&b.$prevArrow.prependTo(b.options.appendArrows),b.htmlExpr.test(b.options.nextArrow)&&b.$nextArrow.appendTo(b.options.appendArrows),b.options.infinite!==!0&&b.$prevArrow.addClass("slick-disabled").attr("aria-disabled","true")):b.$prevArrow.add(b.$nextArrow).addClass("slick-hidden").attr({"aria-disabled":"true",tabindex:"-1"}))},b.prototype.buildDots=function(){var c,d,b=this;if(b.options.dots===!0&&b.slideCount>b.options.slidesToShow){for(d='<ul class="'+b.options.dotsClass+'">',c=0;c<=b.getDotCount();c+=1)d+="<li>"+b.options.customPaging.call(this,b,c)+"</li>";d+="</ul>",b.$dots=a(d).appendTo(b.options.appendDots),b.$dots.find("li").first().addClass("slick-active").attr("aria-hidden","false")}},b.prototype.buildOut=function(){var b=this;b.$slides=b.$slider.children(b.options.slide+":not(.slick-cloned)").addClass("slick-slide"),b.slideCount=b.$slides.length,b.$slides.each(function(b,c){a(c).attr("data-slick-index",b).data("originalStyling",a(c).attr("style")||"")}),b.$slider.addClass("slick-slider"),b.$slideTrack=0===b.slideCount?a('<div class="slick-track"/>').appendTo(b.$slider):b.$slides.wrapAll('<div class="slick-track"/>').parent(),b.$list=b.$slideTrack.wrap('<div aria-live="polite" class="slick-list"/>').parent(),b.$slideTrack.css("opacity",0),(b.options.centerMode===!0||b.options.swipeToSlide===!0)&&(b.options.slidesToScroll=1),a("img[data-lazy]",b.$slider).not("[src]").addClass("slick-loading"),b.setupInfinite(),b.buildArrows(),b.buildDots(),b.updateDots(),b.setSlideClasses("number"==typeof b.currentSlide?b.currentSlide:0),b.options.draggable===!0&&b.$list.addClass("draggable")},b.prototype.buildRows=function(){var b,c,d,e,f,g,h,a=this;if(e=document.createDocumentFragment(),g=a.$slider.children(),a.options.rows>1){for(h=a.options.slidesPerRow*a.options.rows,f=Math.ceil(g.length/h),b=0;f>b;b++){var i=document.createElement("div");for(c=0;c<a.options.rows;c++){var j=document.createElement("div");for(d=0;d<a.options.slidesPerRow;d++){var k=b*h+(c*a.options.slidesPerRow+d);g.get(k)&&j.appendChild(g.get(k))}i.appendChild(j)}e.appendChild(i)}a.$slider.html(e),a.$slider.children().children().children().css({width:100/a.options.slidesPerRow+"%",display:"inline-block"})}},b.prototype.checkResponsive=function(b,c){var e,f,g,d=this,h=!1,i=d.$slider.width(),j=window.innerWidth||a(window).width();if("window"===d.respondTo?g=j:"slider"===d.respondTo?g=i:"min"===d.respondTo&&(g=Math.min(j,i)),d.options.responsive&&d.options.responsive.length&&null!==d.options.responsive){f=null;for(e in d.breakpoints)d.breakpoints.hasOwnProperty(e)&&(d.originalSettings.mobileFirst===!1?g<d.breakpoints[e]&&(f=d.breakpoints[e]):g>d.breakpoints[e]&&(f=d.breakpoints[e]));null!==f?null!==d.activeBreakpoint?(f!==d.activeBreakpoint||c)&&(d.activeBreakpoint=f,"unslick"===d.breakpointSettings[f]?d.unslick(f):(d.options=a.extend({},d.originalSettings,d.breakpointSettings[f]),b===!0&&(d.currentSlide=d.options.initialSlide),d.refresh(b)),h=f):(d.activeBreakpoint=f,"unslick"===d.breakpointSettings[f]?d.unslick(f):(d.options=a.extend({},d.originalSettings,d.breakpointSettings[f]),b===!0&&(d.currentSlide=d.options.initialSlide),d.refresh(b)),h=f):null!==d.activeBreakpoint&&(d.activeBreakpoint=null,d.options=d.originalSettings,b===!0&&(d.currentSlide=d.options.initialSlide),d.refresh(b),h=f),b||h===!1||d.$slider.trigger("breakpoint",[d,h])}},b.prototype.changeSlide=function(b,c){var f,g,h,d=this,e=a(b.target);switch(e.is("a")&&b.preventDefault(),e.is("li")||(e=e.closest("li")),h=d.slideCount%d.options.slidesToScroll!==0,f=h?0:(d.slideCount-d.currentSlide)%d.options.slidesToScroll,b.data.message){case"previous":g=0===f?d.options.slidesToScroll:d.options.slidesToShow-f,d.slideCount>d.options.slidesToShow&&d.slideHandler(d.currentSlide-g,!1,c);break;case"next":g=0===f?d.options.slidesToScroll:f,d.slideCount>d.options.slidesToShow&&d.slideHandler(d.currentSlide+g,!1,c);break;case"index":var i=0===b.data.index?0:b.data.index||e.index()*d.options.slidesToScroll;d.slideHandler(d.checkNavigable(i),!1,c),e.children().trigger("focus");break;default:return}},b.prototype.checkNavigable=function(a){var c,d,b=this;if(c=b.getNavigableIndexes(),d=0,a>c[c.length-1])a=c[c.length-1];else for(var e in c){if(a<c[e]){a=d;break}d=c[e]}return a},b.prototype.cleanUpEvents=function(){var b=this;b.options.dots&&null!==b.$dots&&(a("li",b.$dots).off("click.slick",b.changeSlide),b.options.pauseOnDotsHover===!0&&b.options.autoplay===!0&&a("li",b.$dots).off("mouseenter.slick",a.proxy(b.setPaused,b,!0)).off("mouseleave.slick",a.proxy(b.setPaused,b,!1))),b.options.arrows===!0&&b.slideCount>b.options.slidesToShow&&(b.$prevArrow&&b.$prevArrow.off("click.slick",b.changeSlide),b.$nextArrow&&b.$nextArrow.off("click.slick",b.changeSlide)),b.$list.off("touchstart.slick mousedown.slick",b.swipeHandler),b.$list.off("touchmove.slick mousemove.slick",b.swipeHandler),b.$list.off("touchend.slick mouseup.slick",b.swipeHandler),b.$list.off("touchcancel.slick mouseleave.slick",b.swipeHandler),b.$list.off("click.slick",b.clickHandler),a(document).off(b.visibilityChange,b.visibility),b.$list.off("mouseenter.slick",a.proxy(b.setPaused,b,!0)),b.$list.off("mouseleave.slick",a.proxy(b.setPaused,b,!1)),b.options.accessibility===!0&&b.$list.off("keydown.slick",b.keyHandler),b.options.focusOnSelect===!0&&a(b.$slideTrack).children().off("click.slick",b.selectHandler),a(window).off("orientationchange.slick.slick-"+b.instanceUid,b.orientationChange),a(window).off("resize.slick.slick-"+b.instanceUid,b.resize),a("[draggable!=true]",b.$slideTrack).off("dragstart",b.preventDefault),a(window).off("load.slick.slick-"+b.instanceUid,b.setPosition),a(document).off("ready.slick.slick-"+b.instanceUid,b.setPosition)},b.prototype.cleanUpRows=function(){var b,a=this;a.options.rows>1&&(b=a.$slides.children().children(),b.removeAttr("style"),a.$slider.html(b))},b.prototype.clickHandler=function(a){var b=this;b.shouldClick===!1&&(a.stopImmediatePropagation(),a.stopPropagation(),a.preventDefault())},b.prototype.destroy=function(b){var c=this;c.autoPlayClear(),c.touchObject={},c.cleanUpEvents(),a(".slick-cloned",c.$slider).detach(),c.$dots&&c.$dots.remove(),c.$prevArrow&&c.$prevArrow.length&&(c.$prevArrow.removeClass("slick-disabled slick-arrow slick-hidden").removeAttr("aria-hidden aria-disabled tabindex").css("display",""),c.htmlExpr.test(c.options.prevArrow)&&c.$prevArrow.remove()),c.$nextArrow&&c.$nextArrow.length&&(c.$nextArrow.removeClass("slick-disabled slick-arrow slick-hidden").removeAttr("aria-hidden aria-disabled tabindex").css("display",""),c.htmlExpr.test(c.options.nextArrow)&&c.$nextArrow.remove()),c.$slides&&(c.$slides.removeClass("slick-slide slick-active slick-center slick-visible slick-current").removeAttr("aria-hidden").removeAttr("data-slick-index").each(function(){a(this).attr("style",a(this).data("originalStyling"))}),c.$slideTrack.children(this.options.slide).detach(),c.$slideTrack.detach(),c.$list.detach(),c.$slider.append(c.$slides)),c.cleanUpRows(),c.$slider.removeClass("slick-slider"),c.$slider.removeClass("slick-initialized"),c.unslicked=!0,b||c.$slider.trigger("destroy",[c])},b.prototype.disableTransition=function(a){var b=this,c={};c[b.transitionType]="",b.options.fade===!1?b.$slideTrack.css(c):b.$slides.eq(a).css(c)},b.prototype.fadeSlide=function(a,b){var c=this;c.cssTransitions===!1?(c.$slides.eq(a).css({zIndex:c.options.zIndex}),c.$slides.eq(a).animate({opacity:1},c.options.speed,c.options.easing,b)):(c.applyTransition(a),c.$slides.eq(a).css({opacity:1,zIndex:c.options.zIndex}),b&&setTimeout(function(){c.disableTransition(a),b.call()},c.options.speed))},b.prototype.fadeSlideOut=function(a){var b=this;b.cssTransitions===!1?b.$slides.eq(a).animate({opacity:0,zIndex:b.options.zIndex-2},b.options.speed,b.options.easing):(b.applyTransition(a),b.$slides.eq(a).css({opacity:0,zIndex:b.options.zIndex-2}))},b.prototype.filterSlides=b.prototype.slickFilter=function(a){var b=this;null!==a&&(b.$slidesCache=b.$slides,b.unload(),b.$slideTrack.children(this.options.slide).detach(),b.$slidesCache.filter(a).appendTo(b.$slideTrack),b.reinit())},b.prototype.getCurrent=b.prototype.slickCurrentSlide=function(){var a=this;return a.currentSlide},b.prototype.getDotCount=function(){var a=this,b=0,c=0,d=0;if(a.options.infinite===!0)for(;b<a.slideCount;)++d,b=c+a.options.slidesToScroll,c+=a.options.slidesToScroll<=a.options.slidesToShow?a.options.slidesToScroll:a.options.slidesToShow;else if(a.options.centerMode===!0)d=a.slideCount;else for(;b<a.slideCount;)++d,b=c+a.options.slidesToScroll,c+=a.options.slidesToScroll<=a.options.slidesToShow?a.options.slidesToScroll:a.options.slidesToShow;return d-1},b.prototype.getLeft=function(a){var c,d,f,b=this,e=0;return b.slideOffset=0,d=b.$slides.first().outerHeight(!0),b.options.infinite===!0?(b.slideCount>b.options.slidesToShow&&(b.slideOffset=b.slideWidth*b.options.slidesToShow*-1,e=d*b.options.slidesToShow*-1),b.slideCount%b.options.slidesToScroll!==0&&a+b.options.slidesToScroll>b.slideCount&&b.slideCount>b.options.slidesToShow&&(a>b.slideCount?(b.slideOffset=(b.options.slidesToShow-(a-b.slideCount))*b.slideWidth*-1,e=(b.options.slidesToShow-(a-b.slideCount))*d*-1):(b.slideOffset=b.slideCount%b.options.slidesToScroll*b.slideWidth*-1,e=b.slideCount%b.options.slidesToScroll*d*-1))):a+b.options.slidesToShow>b.slideCount&&(b.slideOffset=(a+b.options.slidesToShow-b.slideCount)*b.slideWidth,e=(a+b.options.slidesToShow-b.slideCount)*d),b.slideCount<=b.options.slidesToShow&&(b.slideOffset=0,e=0),b.options.centerMode===!0&&b.options.infinite===!0?b.slideOffset+=b.slideWidth*Math.floor(b.options.slidesToShow/2)-b.slideWidth:b.options.centerMode===!0&&(b.slideOffset=0,b.slideOffset+=b.slideWidth*Math.floor(b.options.slidesToShow/2)),c=b.options.vertical===!1?a*b.slideWidth*-1+b.slideOffset:a*d*-1+e,b.options.variableWidth===!0&&(f=b.slideCount<=b.options.slidesToShow||b.options.infinite===!1?b.$slideTrack.children(".slick-slide").eq(a):b.$slideTrack.children(".slick-slide").eq(a+b.options.slidesToShow),c=b.options.rtl===!0?f[0]?-1*(b.$slideTrack.width()-f[0].offsetLeft-f.width()):0:f[0]?-1*f[0].offsetLeft:0,b.options.centerMode===!0&&(f=b.slideCount<=b.options.slidesToShow||b.options.infinite===!1?b.$slideTrack.children(".slick-slide").eq(a):b.$slideTrack.children(".slick-slide").eq(a+b.options.slidesToShow+1),c=b.options.rtl===!0?f[0]?-1*(b.$slideTrack.width()-f[0].offsetLeft-f.width()):0:f[0]?-1*f[0].offsetLeft:0,c+=(b.$list.width()-f.outerWidth())/2)),c},b.prototype.getOption=b.prototype.slickGetOption=function(a){var b=this;return b.options[a]},b.prototype.getNavigableIndexes=function(){var e,a=this,b=0,c=0,d=[];for(a.options.infinite===!1?e=a.slideCount:(b=-1*a.options.slidesToScroll,c=-1*a.options.slidesToScroll,e=2*a.slideCount);e>b;)d.push(b),b=c+a.options.slidesToScroll,c+=a.options.slidesToScroll<=a.options.slidesToShow?a.options.slidesToScroll:a.options.slidesToShow;return d},b.prototype.getSlick=function(){return this},b.prototype.getSlideCount=function(){var c,d,e,b=this;return e=b.options.centerMode===!0?b.slideWidth*Math.floor(b.options.slidesToShow/2):0,b.options.swipeToSlide===!0?(b.$slideTrack.find(".slick-slide").each(function(c,f){return f.offsetLeft-e+a(f).outerWidth()/2>-1*b.swipeLeft?(d=f,!1):void 0}),c=Math.abs(a(d).attr("data-slick-index")-b.currentSlide)||1):b.options.slidesToScroll},b.prototype.goTo=b.prototype.slickGoTo=function(a,b){var c=this;c.changeSlide({data:{message:"index",index:parseInt(a)}},b)},b.prototype.init=function(b){var c=this;a(c.$slider).hasClass("slick-initialized")||(a(c.$slider).addClass("slick-initialized"),c.buildRows(),c.buildOut(),c.setProps(),c.startLoad(),c.loadSlider(),c.initializeEvents(),c.updateArrows(),c.updateDots()),b&&c.$slider.trigger("init",[c]),c.options.accessibility===!0&&c.initADA()},b.prototype.initArrowEvents=function(){var a=this;a.options.arrows===!0&&a.slideCount>a.options.slidesToShow&&(a.$prevArrow.on("click.slick",{message:"previous"},a.changeSlide),a.$nextArrow.on("click.slick",{message:"next"},a.changeSlide))},b.prototype.initDotEvents=function(){var b=this;b.options.dots===!0&&b.slideCount>b.options.slidesToShow&&a("li",b.$dots).on("click.slick",{message:"index"},b.changeSlide),b.options.dots===!0&&b.options.pauseOnDotsHover===!0&&b.options.autoplay===!0&&a("li",b.$dots).on("mouseenter.slick",a.proxy(b.setPaused,b,!0)).on("mouseleave.slick",a.proxy(b.setPaused,b,!1))},b.prototype.initializeEvents=function(){var b=this;b.initArrowEvents(),b.initDotEvents(),b.$list.on("touchstart.slick mousedown.slick",{action:"start"},b.swipeHandler),b.$list.on("touchmove.slick mousemove.slick",{action:"move"},b.swipeHandler),b.$list.on("touchend.slick mouseup.slick",{action:"end"},b.swipeHandler),b.$list.on("touchcancel.slick mouseleave.slick",{action:"end"},b.swipeHandler),b.$list.on("click.slick",b.clickHandler),a(document).on(b.visibilityChange,a.proxy(b.visibility,b)),b.$list.on("mouseenter.slick",a.proxy(b.setPaused,b,!0)),b.$list.on("mouseleave.slick",a.proxy(b.setPaused,b,!1)),b.options.accessibility===!0&&b.$list.on("keydown.slick",b.keyHandler),b.options.focusOnSelect===!0&&a(b.$slideTrack).children().on("click.slick",b.selectHandler),a(window).on("orientationchange.slick.slick-"+b.instanceUid,a.proxy(b.orientationChange,b)),a(window).on("resize.slick.slick-"+b.instanceUid,a.proxy(b.resize,b)),a("[draggable!=true]",b.$slideTrack).on("dragstart",b.preventDefault),a(window).on("load.slick.slick-"+b.instanceUid,b.setPosition),a(document).on("ready.slick.slick-"+b.instanceUid,b.setPosition)},b.prototype.initUI=function(){var a=this;a.options.arrows===!0&&a.slideCount>a.options.slidesToShow&&(a.$prevArrow.show(),a.$nextArrow.show()),a.options.dots===!0&&a.slideCount>a.options.slidesToShow&&a.$dots.show(),a.options.autoplay===!0&&a.autoPlay()},b.prototype.keyHandler=function(a){var b=this;a.target.tagName.match("TEXTAREA|INPUT|SELECT")||(37===a.keyCode&&b.options.accessibility===!0?b.changeSlide({data:{message:"previous"}}):39===a.keyCode&&b.options.accessibility===!0&&b.changeSlide({data:{message:"next"}}))},b.prototype.lazyLoad=function(){function g(b){a("img[data-lazy]",b).each(function(){var b=a(this),c=a(this).attr("data-lazy"),d=document.createElement("img");d.onload=function(){b.animate({opacity:0},100,function(){b.attr("src",c).animate({opacity:1},200,function(){b.removeAttr("data-lazy").removeClass("slick-loading")})})},d.src=c})}var c,d,e,f,b=this;b.options.centerMode===!0?b.options.infinite===!0?(e=b.currentSlide+(b.options.slidesToShow/2+1),f=e+b.options.slidesToShow+2):(e=Math.max(0,b.currentSlide-(b.options.slidesToShow/2+1)),f=2+(b.options.slidesToShow/2+1)+b.currentSlide):(e=b.options.infinite?b.options.slidesToShow+b.currentSlide:b.currentSlide,f=e+b.options.slidesToShow,b.options.fade===!0&&(e>0&&e--,f<=b.slideCount&&f++)),c=b.$slider.find(".slick-slide").slice(e,f),g(c),b.slideCount<=b.options.slidesToShow?(d=b.$slider.find(".slick-slide"),g(d)):b.currentSlide>=b.slideCount-b.options.slidesToShow?(d=b.$slider.find(".slick-cloned").slice(0,b.options.slidesToShow),g(d)):0===b.currentSlide&&(d=b.$slider.find(".slick-cloned").slice(-1*b.options.slidesToShow),g(d))},b.prototype.loadSlider=function(){var a=this;a.setPosition(),a.$slideTrack.css({opacity:1}),a.$slider.removeClass("slick-loading"),a.initUI(),"progressive"===a.options.lazyLoad&&a.progressiveLazyLoad()},b.prototype.next=b.prototype.slickNext=function(){var a=this;a.changeSlide({data:{message:"next"}})},b.prototype.orientationChange=function(){var a=this;a.checkResponsive(),a.setPosition()},b.prototype.pause=b.prototype.slickPause=function(){var a=this;a.autoPlayClear(),a.paused=!0},b.prototype.play=b.prototype.slickPlay=function(){var a=this;a.paused=!1,a.autoPlay()},b.prototype.postSlide=function(a){var b=this;b.$slider.trigger("afterChange",[b,a]),b.animating=!1,b.setPosition(),b.swipeLeft=null,b.options.autoplay===!0&&b.paused===!1&&b.autoPlay(),b.options.accessibility===!0&&b.initADA()},b.prototype.prev=b.prototype.slickPrev=function(){var a=this;a.changeSlide({data:{message:"previous"}})},b.prototype.preventDefault=function(a){a.preventDefault()},b.prototype.progressiveLazyLoad=function(){var c,d,b=this;c=a("img[data-lazy]",b.$slider).length,c>0&&(d=a("img[data-lazy]",b.$slider).first(),d.attr("src",null),d.attr("src",d.attr("data-lazy")).removeClass("slick-loading").load(function(){d.removeAttr("data-lazy"),b.progressiveLazyLoad(),b.options.adaptiveHeight===!0&&b.setPosition()}).error(function(){d.removeAttr("data-lazy"),b.progressiveLazyLoad()}))},b.prototype.refresh=function(b){var d,e,c=this;e=c.slideCount-c.options.slidesToShow,c.options.infinite||(c.slideCount<=c.options.slidesToShow?c.currentSlide=0:c.currentSlide>e&&(c.currentSlide=e)),d=c.currentSlide,c.destroy(!0),a.extend(c,c.initials,{currentSlide:d}),c.init(),b||c.changeSlide({data:{message:"index",index:d}},!1)},b.prototype.registerBreakpoints=function(){var c,d,e,b=this,f=b.options.responsive||null;if("array"===a.type(f)&&f.length){b.respondTo=b.options.respondTo||"window";for(c in f)if(e=b.breakpoints.length-1,d=f[c].breakpoint,f.hasOwnProperty(c)){for(;e>=0;)b.breakpoints[e]&&b.breakpoints[e]===d&&b.breakpoints.splice(e,1),e--;b.breakpoints.push(d),b.breakpointSettings[d]=f[c].settings}b.breakpoints.sort(function(a,c){return b.options.mobileFirst?a-c:c-a})}},b.prototype.reinit=function(){var b=this;b.$slides=b.$slideTrack.children(b.options.slide).addClass("slick-slide"),b.slideCount=b.$slides.length,b.currentSlide>=b.slideCount&&0!==b.currentSlide&&(b.currentSlide=b.currentSlide-b.options.slidesToScroll),b.slideCount<=b.options.slidesToShow&&(b.currentSlide=0),b.registerBreakpoints(),b.setProps(),b.setupInfinite(),b.buildArrows(),b.updateArrows(),b.initArrowEvents(),b.buildDots(),b.updateDots(),b.initDotEvents(),b.checkResponsive(!1,!0),b.options.focusOnSelect===!0&&a(b.$slideTrack).children().on("click.slick",b.selectHandler),b.setSlideClasses(0),b.setPosition(),b.$slider.trigger("reInit",[b]),b.options.autoplay===!0&&b.focusHandler()},b.prototype.resize=function(){var b=this;a(window).width()!==b.windowWidth&&(clearTimeout(b.windowDelay),b.windowDelay=window.setTimeout(function(){b.windowWidth=a(window).width(),b.checkResponsive(),b.unslicked||b.setPosition()},50))},b.prototype.removeSlide=b.prototype.slickRemove=function(a,b,c){var d=this;return"boolean"==typeof a?(b=a,a=b===!0?0:d.slideCount-1):a=b===!0?--a:a,d.slideCount<1||0>a||a>d.slideCount-1?!1:(d.unload(),c===!0?d.$slideTrack.children().remove():d.$slideTrack.children(this.options.slide).eq(a).remove(),d.$slides=d.$slideTrack.children(this.options.slide),d.$slideTrack.children(this.options.slide).detach(),d.$slideTrack.append(d.$slides),d.$slidesCache=d.$slides,void d.reinit())},b.prototype.setCSS=function(a){var d,e,b=this,c={};b.options.rtl===!0&&(a=-a),d="left"==b.positionProp?Math.ceil(a)+"px":"0px",e="top"==b.positionProp?Math.ceil(a)+"px":"0px",c[b.positionProp]=a,b.transformsEnabled===!1?b.$slideTrack.css(c):(c={},b.cssTransitions===!1?(c[b.animType]="translate("+d+", "+e+")",b.$slideTrack.css(c)):(c[b.animType]="translate3d("+d+", "+e+", 0px)",b.$slideTrack.css(c)))},b.prototype.setDimensions=function(){var a=this;a.options.vertical===!1?a.options.centerMode===!0&&a.$list.css({padding:"0px "+a.options.centerPadding}):(a.$list.height(a.$slides.first().outerHeight(!0)*a.options.slidesToShow),a.options.centerMode===!0&&a.$list.css({padding:a.options.centerPadding+" 0px"})),a.listWidth=a.$list.width(),a.listHeight=a.$list.height(),a.options.vertical===!1&&a.options.variableWidth===!1?(a.slideWidth=Math.ceil(a.listWidth/a.options.slidesToShow),a.$slideTrack.width(Math.ceil(a.slideWidth*a.$slideTrack.children(".slick-slide").length))):a.options.variableWidth===!0?a.$slideTrack.width(5e3*a.slideCount):(a.slideWidth=Math.ceil(a.listWidth),a.$slideTrack.height(Math.ceil(a.$slides.first().outerHeight(!0)*a.$slideTrack.children(".slick-slide").length)));var b=a.$slides.first().outerWidth(!0)-a.$slides.first().width();a.options.variableWidth===!1&&a.$slideTrack.children(".slick-slide").width(a.slideWidth-b)},b.prototype.setFade=function(){var c,b=this;b.$slides.each(function(d,e){c=b.slideWidth*d*-1,b.options.rtl===!0?a(e).css({position:"relative",right:c,top:0,zIndex:b.options.zIndex-2,opacity:0}):a(e).css({position:"relative",left:c,top:0,zIndex:b.options.zIndex-2,opacity:0})}),b.$slides.eq(b.currentSlide).css({zIndex:b.options.zIndex-1,opacity:1})},b.prototype.setHeight=function(){var a=this;if(1===a.options.slidesToShow&&a.options.adaptiveHeight===!0&&a.options.vertical===!1){var b=a.$slides.eq(a.currentSlide).outerHeight(!0);a.$list.css("height",b)}},b.prototype.setOption=b.prototype.slickSetOption=function(b,c,d){var f,g,e=this;if("responsive"===b&&"array"===a.type(c))for(g in c)if("array"!==a.type(e.options.responsive))e.options.responsive=[c[g]];else{for(f=e.options.responsive.length-1;f>=0;)e.options.responsive[f].breakpoint===c[g].breakpoint&&e.options.responsive.splice(f,1),f--;e.options.responsive.push(c[g])}else e.options[b]=c;d===!0&&(e.unload(),e.reinit())},b.prototype.setPosition=function(){var a=this;a.setDimensions(),a.setHeight(),a.options.fade===!1?a.setCSS(a.getLeft(a.currentSlide)):a.setFade(),a.$slider.trigger("setPosition",[a])},b.prototype.setProps=function(){var a=this,b=document.body.style;a.positionProp=a.options.vertical===!0?"top":"left","top"===a.positionProp?a.$slider.addClass("slick-vertical"):a.$slider.removeClass("slick-vertical"),(void 0!==b.WebkitTransition||void 0!==b.MozTransition||void 0!==b.msTransition)&&a.options.useCSS===!0&&(a.cssTransitions=!0),a.options.fade&&("number"==typeof a.options.zIndex?a.options.zIndex<3&&(a.options.zIndex=3):a.options.zIndex=a.defaults.zIndex),void 0!==b.OTransform&&(a.animType="OTransform",a.transformType="-o-transform",a.transitionType="OTransition",void 0===b.perspectiveProperty&&void 0===b.webkitPerspective&&(a.animType=!1)),void 0!==b.MozTransform&&(a.animType="MozTransform",a.transformType="-moz-transform",a.transitionType="MozTransition",void 0===b.perspectiveProperty&&void 0===b.MozPerspective&&(a.animType=!1)),void 0!==b.webkitTransform&&(a.animType="webkitTransform",a.transformType="-webkit-transform",a.transitionType="webkitTransition",void 0===b.perspectiveProperty&&void 0===b.webkitPerspective&&(a.animType=!1)),void 0!==b.msTransform&&(a.animType="msTransform",a.transformType="-ms-transform",a.transitionType="msTransition",void 0===b.msTransform&&(a.animType=!1)),void 0!==b.transform&&a.animType!==!1&&(a.animType="transform",a.transformType="transform",a.transitionType="transition"),a.transformsEnabled=a.options.useTransform&&null!==a.animType&&a.animType!==!1},b.prototype.setSlideClasses=function(a){var c,d,e,f,b=this;d=b.$slider.find(".slick-slide").removeClass("slick-active slick-center slick-current").attr("aria-hidden","true"),b.$slides.eq(a).addClass("slick-current"),b.options.centerMode===!0?(c=Math.floor(b.options.slidesToShow/2),b.options.infinite===!0&&(a>=c&&a<=b.slideCount-1-c?b.$slides.slice(a-c,a+c+1).addClass("slick-active").attr("aria-hidden","false"):(e=b.options.slidesToShow+a,d.slice(e-c+1,e+c+2).addClass("slick-active").attr("aria-hidden","false")),0===a?d.eq(d.length-1-b.options.slidesToShow).addClass("slick-center"):a===b.slideCount-1&&d.eq(b.options.slidesToShow).addClass("slick-center")),b.$slides.eq(a).addClass("slick-center")):a>=0&&a<=b.slideCount-b.options.slidesToShow?b.$slides.slice(a,a+b.options.slidesToShow).addClass("slick-active").attr("aria-hidden","false"):d.length<=b.options.slidesToShow?d.addClass("slick-active").attr("aria-hidden","false"):(f=b.slideCount%b.options.slidesToShow,e=b.options.infinite===!0?b.options.slidesToShow+a:a,b.options.slidesToShow==b.options.slidesToScroll&&b.slideCount-a<b.options.slidesToShow?d.slice(e-(b.options.slidesToShow-f),e+f).addClass("slick-active").attr("aria-hidden","false"):d.slice(e,e+b.options.slidesToShow).addClass("slick-active").attr("aria-hidden","false")),"ondemand"===b.options.lazyLoad&&b.lazyLoad()},b.prototype.setupInfinite=function(){var c,d,e,b=this;if(b.options.fade===!0&&(b.options.centerMode=!1),b.options.infinite===!0&&b.options.fade===!1&&(d=null,b.slideCount>b.options.slidesToShow)){for(e=b.options.centerMode===!0?b.options.slidesToShow+1:b.options.slidesToShow,c=b.slideCount;c>b.slideCount-e;c-=1)d=c-1,a(b.$slides[d]).clone(!0).attr("id","").attr("data-slick-index",d-b.slideCount).prependTo(b.$slideTrack).addClass("slick-cloned");for(c=0;e>c;c+=1)d=c,a(b.$slides[d]).clone(!0).attr("id","").attr("data-slick-index",d+b.slideCount).appendTo(b.$slideTrack).addClass("slick-cloned");b.$slideTrack.find(".slick-cloned").find("[id]").each(function(){a(this).attr("id","")})}},b.prototype.setPaused=function(a){var b=this;b.options.autoplay===!0&&b.options.pauseOnHover===!0&&(b.paused=a,a?b.autoPlayClear():b.autoPlay())},b.prototype.selectHandler=function(b){var c=this,d=a(b.target).is(".slick-slide")?a(b.target):a(b.target).parents(".slick-slide"),e=parseInt(d.attr("data-slick-index"));return e||(e=0),c.slideCount<=c.options.slidesToShow?(c.setSlideClasses(e),void c.asNavFor(e)):void c.slideHandler(e)},b.prototype.slideHandler=function(a,b,c){var d,e,f,g,h=null,i=this;return b=b||!1,i.animating===!0&&i.options.waitForAnimate===!0||i.options.fade===!0&&i.currentSlide===a||i.slideCount<=i.options.slidesToShow?void 0:(b===!1&&i.asNavFor(a),d=a,h=i.getLeft(d),g=i.getLeft(i.currentSlide),i.currentLeft=null===i.swipeLeft?g:i.swipeLeft,i.options.infinite===!1&&i.options.centerMode===!1&&(0>a||a>i.getDotCount()*i.options.slidesToScroll)?void(i.options.fade===!1&&(d=i.currentSlide,c!==!0?i.animateSlide(g,function(){i.postSlide(d);
}):i.postSlide(d))):i.options.infinite===!1&&i.options.centerMode===!0&&(0>a||a>i.slideCount-i.options.slidesToScroll)?void(i.options.fade===!1&&(d=i.currentSlide,c!==!0?i.animateSlide(g,function(){i.postSlide(d)}):i.postSlide(d))):(i.options.autoplay===!0&&clearInterval(i.autoPlayTimer),e=0>d?i.slideCount%i.options.slidesToScroll!==0?i.slideCount-i.slideCount%i.options.slidesToScroll:i.slideCount+d:d>=i.slideCount?i.slideCount%i.options.slidesToScroll!==0?0:d-i.slideCount:d,i.animating=!0,i.$slider.trigger("beforeChange",[i,i.currentSlide,e]),f=i.currentSlide,i.currentSlide=e,i.setSlideClasses(i.currentSlide),i.updateDots(),i.updateArrows(),i.options.fade===!0?(c!==!0?(i.fadeSlideOut(f),i.fadeSlide(e,function(){i.postSlide(e)})):i.postSlide(e),void i.animateHeight()):void(c!==!0?i.animateSlide(h,function(){i.postSlide(e)}):i.postSlide(e))))},b.prototype.startLoad=function(){var a=this;a.options.arrows===!0&&a.slideCount>a.options.slidesToShow&&(a.$prevArrow.hide(),a.$nextArrow.hide()),a.options.dots===!0&&a.slideCount>a.options.slidesToShow&&a.$dots.hide(),a.$slider.addClass("slick-loading")},b.prototype.swipeDirection=function(){var a,b,c,d,e=this;return a=e.touchObject.startX-e.touchObject.curX,b=e.touchObject.startY-e.touchObject.curY,c=Math.atan2(b,a),d=Math.round(180*c/Math.PI),0>d&&(d=360-Math.abs(d)),45>=d&&d>=0?e.options.rtl===!1?"left":"right":360>=d&&d>=315?e.options.rtl===!1?"left":"right":d>=135&&225>=d?e.options.rtl===!1?"right":"left":e.options.verticalSwiping===!0?d>=35&&135>=d?"left":"right":"vertical"},b.prototype.swipeEnd=function(a){var c,b=this;if(b.dragging=!1,b.shouldClick=b.touchObject.swipeLength>10?!1:!0,void 0===b.touchObject.curX)return!1;if(b.touchObject.edgeHit===!0&&b.$slider.trigger("edge",[b,b.swipeDirection()]),b.touchObject.swipeLength>=b.touchObject.minSwipe)switch(b.swipeDirection()){case"left":c=b.options.swipeToSlide?b.checkNavigable(b.currentSlide+b.getSlideCount()):b.currentSlide+b.getSlideCount(),b.slideHandler(c),b.currentDirection=0,b.touchObject={},b.$slider.trigger("swipe",[b,"left"]);break;case"right":c=b.options.swipeToSlide?b.checkNavigable(b.currentSlide-b.getSlideCount()):b.currentSlide-b.getSlideCount(),b.slideHandler(c),b.currentDirection=1,b.touchObject={},b.$slider.trigger("swipe",[b,"right"])}else b.touchObject.startX!==b.touchObject.curX&&(b.slideHandler(b.currentSlide),b.touchObject={})},b.prototype.swipeHandler=function(a){var b=this;if(!(b.options.swipe===!1||"ontouchend"in document&&b.options.swipe===!1||b.options.draggable===!1&&-1!==a.type.indexOf("mouse")))switch(b.touchObject.fingerCount=a.originalEvent&&void 0!==a.originalEvent.touches?a.originalEvent.touches.length:1,b.touchObject.minSwipe=b.listWidth/b.options.touchThreshold,b.options.verticalSwiping===!0&&(b.touchObject.minSwipe=b.listHeight/b.options.touchThreshold),a.data.action){case"start":b.swipeStart(a);break;case"move":b.swipeMove(a);break;case"end":b.swipeEnd(a)}},b.prototype.swipeMove=function(a){var d,e,f,g,h,b=this;return h=void 0!==a.originalEvent?a.originalEvent.touches:null,!b.dragging||h&&1!==h.length?!1:(d=b.getLeft(b.currentSlide),b.touchObject.curX=void 0!==h?h[0].pageX:a.clientX,b.touchObject.curY=void 0!==h?h[0].pageY:a.clientY,b.touchObject.swipeLength=Math.round(Math.sqrt(Math.pow(b.touchObject.curX-b.touchObject.startX,2))),b.options.verticalSwiping===!0&&(b.touchObject.swipeLength=Math.round(Math.sqrt(Math.pow(b.touchObject.curY-b.touchObject.startY,2)))),e=b.swipeDirection(),"vertical"!==e?(void 0!==a.originalEvent&&b.touchObject.swipeLength>4&&a.preventDefault(),g=(b.options.rtl===!1?1:-1)*(b.touchObject.curX>b.touchObject.startX?1:-1),b.options.verticalSwiping===!0&&(g=b.touchObject.curY>b.touchObject.startY?1:-1),f=b.touchObject.swipeLength,b.touchObject.edgeHit=!1,b.options.infinite===!1&&(0===b.currentSlide&&"right"===e||b.currentSlide>=b.getDotCount()&&"left"===e)&&(f=b.touchObject.swipeLength*b.options.edgeFriction,b.touchObject.edgeHit=!0),b.options.vertical===!1?b.swipeLeft=d+f*g:b.swipeLeft=d+f*(b.$list.height()/b.listWidth)*g,b.options.verticalSwiping===!0&&(b.swipeLeft=d+f*g),b.options.fade===!0||b.options.touchMove===!1?!1:b.animating===!0?(b.swipeLeft=null,!1):void b.setCSS(b.swipeLeft)):void 0)},b.prototype.swipeStart=function(a){var c,b=this;return 1!==b.touchObject.fingerCount||b.slideCount<=b.options.slidesToShow?(b.touchObject={},!1):(void 0!==a.originalEvent&&void 0!==a.originalEvent.touches&&(c=a.originalEvent.touches[0]),b.touchObject.startX=b.touchObject.curX=void 0!==c?c.pageX:a.clientX,b.touchObject.startY=b.touchObject.curY=void 0!==c?c.pageY:a.clientY,void(b.dragging=!0))},b.prototype.unfilterSlides=b.prototype.slickUnfilter=function(){var a=this;null!==a.$slidesCache&&(a.unload(),a.$slideTrack.children(this.options.slide).detach(),a.$slidesCache.appendTo(a.$slideTrack),a.reinit())},b.prototype.unload=function(){var b=this;a(".slick-cloned",b.$slider).remove(),b.$dots&&b.$dots.remove(),b.$prevArrow&&b.htmlExpr.test(b.options.prevArrow)&&b.$prevArrow.remove(),b.$nextArrow&&b.htmlExpr.test(b.options.nextArrow)&&b.$nextArrow.remove(),b.$slides.removeClass("slick-slide slick-active slick-visible slick-current").attr("aria-hidden","true").css("width","")},b.prototype.unslick=function(a){var b=this;b.$slider.trigger("unslick",[b,a]),b.destroy()},b.prototype.updateArrows=function(){var b,a=this;b=Math.floor(a.options.slidesToShow/2),a.options.arrows===!0&&a.slideCount>a.options.slidesToShow&&!a.options.infinite&&(a.$prevArrow.removeClass("slick-disabled").attr("aria-disabled","false"),a.$nextArrow.removeClass("slick-disabled").attr("aria-disabled","false"),0===a.currentSlide?(a.$prevArrow.addClass("slick-disabled").attr("aria-disabled","true"),a.$nextArrow.removeClass("slick-disabled").attr("aria-disabled","false")):a.currentSlide>=a.slideCount-a.options.slidesToShow&&a.options.centerMode===!1?(a.$nextArrow.addClass("slick-disabled").attr("aria-disabled","true"),a.$prevArrow.removeClass("slick-disabled").attr("aria-disabled","false")):a.currentSlide>=a.slideCount-1&&a.options.centerMode===!0&&(a.$nextArrow.addClass("slick-disabled").attr("aria-disabled","true"),a.$prevArrow.removeClass("slick-disabled").attr("aria-disabled","false")))},b.prototype.updateDots=function(){var a=this;null!==a.$dots&&(a.$dots.find("li").removeClass("slick-active").attr("aria-hidden","true"),a.$dots.find("li").eq(Math.floor(a.currentSlide/a.options.slidesToScroll)).addClass("slick-active").attr("aria-hidden","false"))},b.prototype.visibility=function(){var a=this;document[a.hidden]?(a.paused=!0,a.autoPlayClear()):a.options.autoplay===!0&&(a.paused=!1,a.autoPlay())},b.prototype.initADA=function(){var b=this;b.$slides.add(b.$slideTrack.find(".slick-cloned")).attr({"aria-hidden":"true",tabindex:"-1"}).find("a, input, button, select").attr({tabindex:"-1"}),b.$slideTrack.attr("role","listbox"),b.$slides.not(b.$slideTrack.find(".slick-cloned")).each(function(c){a(this).attr({role:"option","aria-describedby":"slick-slide"+b.instanceUid+c})}),null!==b.$dots&&b.$dots.attr("role","tablist").find("li").each(function(c){a(this).attr({role:"presentation","aria-selected":"false","aria-controls":"navigation"+b.instanceUid+c,id:"slick-slide"+b.instanceUid+c})}).first().attr("aria-selected","true").end().find("button").attr("role","button").end().closest("div").attr("role","toolbar"),b.activateADA()},b.prototype.activateADA=function(){var a=this;a.$slideTrack.find(".slick-active").attr({"aria-hidden":"false"}).find("a, input, button, select").attr({tabindex:"0"})},b.prototype.focusHandler=function(){var b=this;b.$slider.on("focus.slick blur.slick","*",function(c){c.stopImmediatePropagation();var d=a(this);setTimeout(function(){b.isPlay&&(d.is(":focus")?(b.autoPlayClear(),b.paused=!0):(b.paused=!1,b.autoPlay()))},0)})},a.fn.slick=function(){var f,g,a=this,c=arguments[0],d=Array.prototype.slice.call(arguments,1),e=a.length;for(f=0;e>f;f++)if("object"==typeof c||"undefined"==typeof c?a[f].slick=new b(a[f],c):g=a[f].slick[c].apply(a[f].slick,d),"undefined"!=typeof g)return g;return a}});

/*jshint browser:true */
/*!
* FitVids 1.1
*
* Copyright 2013, Chris Coyier - http://css-tricks.com + Dave Rupert - http://daverupert.com
* Credit to Thierry Koblentz - http://www.alistapart.com/articles/creating-intrinsic-ratios-for-video/
* Released under the WTFPL license - http://sam.zoy.org/wtfpl/
*
*/
;(function( $ ){

  'use strict';

  $.fn.fitVids = function( options ) {
    var settings = {
      customSelector: null,
      ignore: null
    };

    if(!document.getElementById('fit-vids-style')) {
      // appendStyles: https://github.com/toddmotto/fluidvids/blob/master/dist/fluidvids.js
      var head = document.head || document.getElementsByTagName('head')[0];
      var css = '.fluid-width-video-wrapper{width:100%;position:relative;padding:0;}.fluid-width-video-wrapper iframe,.fluid-width-video-wrapper object,.fluid-width-video-wrapper embed {position:absolute;top:0;left:0;width:100%;height:100%;}';
      var div = document.createElement("div");
      div.innerHTML = '<p>x</p><style id="fit-vids-style">' + css + '</style>';
      head.appendChild(div.childNodes[1]);
    }

    if ( options ) {
      $.extend( settings, options );
    }

    return this.each(function(){
      var selectors = [
        'iframe[src*="player.vimeo.com"]',
        'iframe[src*="youtube.com"]',
        'iframe[src*="youtube-nocookie.com"]',
        'iframe[src*="kickstarter.com"][src*="video.html"]',
        'object',
        'embed'
      ];

      if (settings.customSelector) {
        selectors.push(settings.customSelector);
      }

      var ignoreList = '.fitvidsignore';

      if(settings.ignore) {
        ignoreList = ignoreList + ', ' + settings.ignore;
      }

      var $allVideos = $(this).find(selectors.join(','));
      $allVideos = $allVideos.not('object object'); // SwfObj conflict patch
      $allVideos = $allVideos.not(ignoreList); // Disable FitVids on this video.

      $allVideos.each(function(count){
        var $this = $(this);
        if($this.parents(ignoreList).length > 0) {
          return; // Disable FitVids on this video.
        }
        if (this.tagName.toLowerCase() === 'embed' && $this.parent('object').length || $this.parent('.fluid-width-video-wrapper').length) { return; }
        if ((!$this.css('height') && !$this.css('width')) && (isNaN($this.attr('height')) || isNaN($this.attr('width'))))
        {
          $this.attr('height', 9);
          $this.attr('width', 16);
        }
        var height = ( this.tagName.toLowerCase() === 'object' || ($this.attr('height') && !isNaN(parseInt($this.attr('height'), 10))) ) ? parseInt($this.attr('height'), 10) : $this.height(),
            width = !isNaN(parseInt($this.attr('width'), 10)) ? parseInt($this.attr('width'), 10) : $this.width(),
            aspectRatio = height / width;
        if(!$this.attr('id')){
          var videoID = 'fitvid' + count;
          $this.attr('id', videoID);
        }
        $this.wrap('<div class="fluid-width-video-wrapper"></div>').parent('.fluid-width-video-wrapper').css('padding-top', (aspectRatio * 100)+'%');
        $this.removeAttr('height').removeAttr('width');
      });
    });
  };
// Works with either jQuery or Zepto
})( window.jQuery || window.Zepto );