// Ensure availability of the global themefyreBuilder object
window.themefyreBuilder = window.themefyreBuilder || {};

// A JavaScript equivalent of PHP’s strip_tags
// Thanks to: http://phpjs.org/functions/strip_tags/
themefyreBuilder.stripTags = function(input, allowed) {
   allowed = (((allowed || '') + '').toLowerCase().match(/<[a-z][a-z0-9]*>/g) || []).join('');
   var tags = /<\/?([a-z][a-z0-9]*)\b[^>]*>/gi,
       commentsAndPhpTags = /<!--[\s\S]*?-->|<\?(?:php)?[\s\S]*?\?>/gi;
   return input.replace(commentsAndPhpTags, '').replace(tags, function($0, $1) {
      return allowed.indexOf('<' + $1.toLowerCase() + '>') > -1 ? $0 : '';
   });
};

themefyreBuilder.encodeShortcodeAttr = function(input) {
   if ( 'string' !== typeof input || ! input.trim() ) {
      return input;
   }

   // Convert brackets to their HTML entity alternatives
   input = input.replace(/\[/g, 'BUILDER_LEFT_BRACKET');
   input = input.replace(/\]/g, 'BUILDER_RIGHT_BRACKET');

   // Convert quotes to their HTML entity alternatives
   input = input.replace(/"/g, 'BUILDER_DOUBLE_QUOTE');
   input = input.replace(/'/g, 'BUILDER_SINGLE_QUOTE');

   return input;
};

themefyreBuilder.decodeShortcodeAttr = function(input) {
   if ( 'string' !== typeof input || ! input.trim() ) {
      return input;
   }

   // Convert brackets to their HTML entity alternatives
   input = input.replace(/BUILDER_LEFT_BRACKET/g, '[');
   input = input.replace(/BUILDER_RIGHT_BRACKET/g, ']');

   // Convert quotes to their HTML entity alternatives
   input = input.replace(/BUILDER_DOUBLE_QUOTE/g, '"');
   input = input.replace(/BUILDER_SINGLE_QUOTE/g, "'");

   return input;
};

;(function($, _) {

   // Capture the close page event
   //
   // If the user tries to close the current tab without saving changes
   // we need to ask them if they really want to do this
   var themefyreBuilderBeforeUnload = function( event ) {
      var pageBuilder = $.data(document, 'themefyrePageBuilder');

      // If no changes have been made, do not continue
      if ( ! $('body').hasClass('page-builder-active') || ! pageBuilder.modified ) {
         return;
      }

      var confirmationMessage = builderLocalize.confirm_page_exit;
      (event || window.event).returnValue = confirmationMessage;
      return confirmationMessage;
   };

   $(window).on( 'beforeunload', themefyreBuilderBeforeUnload );

   $('#publish').on( 'click', function() {
      $(window).off( 'beforeunload', themefyreBuilderBeforeUnload );
   });

   $(document).ready( function() {

      // Store the page builder instance in the document data
      //
      // This way any methods of the page builder can be safely accessed
      // by another script externally. Example:
      //
      // var pageBuilder = $.data(document, 'themefyrePageBuilder');
      $.data(document, 'themefyrePageBuilder', new themefyreBuilder.pageBuilder() );

      // Remove click events from the builder meta box handle
      //
      // Normally clicking the handle would toggle the meta
      // box containing the page builder.
      $('#page_builder_meta_box .hndle').off('click');

      // Append the Builder Tooltip Container to the body element
      $('body').append('<div id="builder-tooltip-container" style="display:none;"></div>');

      // Mousing over a builder module
      //
      // This will create a short and informative description of the
      // module being hovered over, including its name and a list of its
      // attributes
      var $tooltip = $('#builder-tooltip-container');
      $(document).on('mousemove', function(event) {

         // The nearest module element
         var $target = $(event.target);

         // Make sure there is a new target
         if ( $target.is( $tooltip.data('lasttarget') ) ) {
            return;
         }
         $tooltip.data('lasttarget', $target);

         // Determine if the target is a module
         var $module = $target.is('.builder-module') ? $target : $target.closest('.builder-module'), info = '', parent_device_visibility = [], error_class = '';

         // Store the page builder object in a variable
         var pageBuilder = $.data(document, 'themefyrePageBuilder');

         // First check to see if the module has any parents with classes/ID`s
         $module.parents('.builder-module').add( $module ).each( function() {
            var $module = $(this);

            // Create the attributes object, if possible
            var attributes_obj = $module.length && $module.attr('data-attributes') ? JSON.parse( $module.attr('data-attributes') ) : null,
                css_class = attributes_obj && 'undefined' !== typeof attributes_obj['class'] ? attributes_obj['class'].trim() : '',
                css_id = attributes_obj && 'undefined' !== typeof attributes_obj.id ? attributes_obj.id.trim() : '',
                inline_attributes = attributes_obj && 'undefined' !== typeof attributes_obj.inline_attributes ? themefyreBuilder.decodeShortcodeAttr( attributes_obj.inline_attributes.trim() ) : '',
                device_visibility = attributes_obj && 'undefined' !== typeof attributes_obj.device_visibility && 'none' !== attributes_obj.device_visibility ? attributes_obj.device_visibility : '';

            if ( ! css_id && ! css_class && ! inline_attributes && ! device_visibility ) {
               return;
            }

            // Add the module name
            info += '<span class="module-title">'+pageBuilder.builder_get_module_name($module)+'</span>';

            // Add the module attributes
            if ( css_id ) {
               info += '<span class="module-attribute">#'+css_id+'</span>';
            }
            if ( css_class ) {
               css_class = css_class.split(' ').join(' .');
               info += '<span class="module-attribute">.'+css_class+'</span>';
            }
            if ( inline_attributes ) {
               info += '<span class="module-attribute">'+inline_attributes+'</span>';
            }
            if ( device_visibility ) {
               error_class = '';

               if ( parent_device_visibility.length ) {
                  var error_map = {
                     mobile: ['tablet', 'desktop', 'tablet-desktop'],
                     tablet: ['mobile', 'desktop'],
                     desktop: ['mobile', 'tablet', 'mobile-tablet'],
                     mobile_tablet: ['desktop'],
                     tablet_desktop: ['mobile'],
                  };
                  _.each( parent_device_visibility, function( value ) {
                     if ( -1 !== _.indexOf(error_map[device_visibility.replace('-','_')], value) ) {
                        error_class = ' has-error';
                     }
                  });
               }

               device_visibility_label = device_visibility.split('-').join(' & ')+' only';
               device_visibility_label = device_visibility_label.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
               info += '<span class="module-attribute'+error_class+'">Device visibility: '+device_visibility_label+'</span>';

               // This way we can determine the parent modules device visibility
               parent_device_visibility.push(device_visibility);
            }
         });

         // If there is nothing to display, hide the tooltip
         if ( ! info ) {
            $tooltip.fadeOut( function() {
               $tooltip.html('');
            });
         }

         // Reveal the tooltip, update its content
         else {
            $tooltip.stop(true,true).show().html(info);
         }
      });

      // Keyboard functionality for fullscreen mode
      $(document).on('keydown', function(event) {

         // Do not do anything if a WordPress modal is open, or if fullscreen is not active, or full screen mode is not active, or the escape key was not pressed
         if ( $('body').hasClass('modal-open') || $('body').hasClass('builder-admin-modal-active') || ! $('body').hasClass('builder-fullscreen-active') || 27 !== event.keyCode ) {
            return;
         }

         document.getElementById('builder-toggle-fullscreen').click();
         event.stopImmediatePropagation();
         event.preventDefault();
      });
   });

   themefyreBuilder.pageBuilder = function() {

      // Will be switched to true if changes are made at any time
      // used in themefyreBuilder.builder_history_add_step()
      this.modified = false;

      // The state of the page builder upon page load
      this.original_state = $('#builder-state').val();

      // Will be true when instant breview is enabled
      this.instant_preview = false;
      this.instant_preview_timer = null;

      // The instant preview state will store information
      // about the last thing that happened with the instant
      // preview functionality.
      // Possible values: `complete`, `waiting`, `canceled`
      this.instant_preview_state = 'complete';

      // Initially set up the history
      this.builder_history_reset();

      // Attach all general events
      this.attach_events();

      // Set up shortcode attribute controls
      this.attach_shortcode_attribute_control_events();

      // Set up the page builder events
      this.attach_page_builder_events();

      // Initially set up the canvas
      this.builder_refresh_canvas();
   };

   _.extend( themefyreBuilder.pageBuilder.prototype, {

      // Makes sure the right functions get called at the right time.
      attach_events: function() {
         var self = this;

         // Inserting a shortcode directly into the tmce editor
         $('#builder-insert-shortcode').click( function() {
            self.launch_insert_tmce_shortcode();
         });

         // Switching between the page builder and default editor
         $('#builder-toggle').click( function() {
            self.builder_switch_active_editor();
         });
      },

      // Sets up the interface for editing shortcode attributes visually
      //
      // Certain shortcode attribute types require enhanced functionality
      // via jQuery, by attaching the events to the document object they
      // only need to be setup once and will work for all dynamically
      // loaded modal windows.
      attach_shortcode_attribute_control_events: function() {
         var $document = $(document), self = this;

         // Set up the controls for `comma_list` and `bar_list` controls
         //
         // When entering text into an input associated with either of these
         // attribute types and the correct delimiter is entered the current
         // value of the input will be added to the existing list of items.
         $document.on( 'change keyup focusout', '.attribute-setting[data-type="comma_list"] input, .attribute-setting[data-type="bar_list"] input', function(event) {
            var $this = $(this), val = $this.val();
            var delimiter = 'comma_list' === $this.closest('.attribute-setting').data('type') ? ',' : '|';

            // Check if last character was a delimiter, only after `keyup` event
            if ( 'keyup' === event.type ) {
               if ( val.slice(-1) !== delimiter ) {
                  return;
               }

               // Remove the delimiter
               val = val.slice(0, -1);
            }

            // Make sure there is still a value
            if ( /\S/.test(val) ) {
               _.each( val.split(delimiter), function(value) {
                  if ( /\S/.test(value) ) {
                     $this.next().append('<li><span class="remove-item dashicons dashicons-no-alt"></span> <strong>'+value+'</strong></li>');
                  }
               });
            }

            // Clear the field
            $this.val('');
         });


         // Set up the controls for `comma_list` and `bar_list` controls
         //
         // Allows existing items to be removed by pressing the `X` icon.
         $document.on( 'click', '.attribute-setting[data-type="comma_list"] .list-items .remove-item, .attribute-setting[data-type="bar_list"] .list-items .remove-item', function() {
            $(this).parent().remove();
         });

         // Display the appropriate font weight selector
         //
         // Whenever a new font is selected make sure only the appropriate
         // list of available weights is visible.
         $document.on( 'change', '.builder-font-selector', function() {
            var $select = $(this), val = $select.val();
            if ( 'default' === val ) {
               $select.siblings('.builder-weight-selector').hide();
            }
            else {
               $select.siblings('.builder-weight-selector').hide().filter('[data-font="'+val+'"]').show();
            }
         });

         // Updating the font preview when a new font/variant is selected
         $document.on( 'change', '.attribute-setting[data-type="font"] select', function() {
            var $wrap = $(this).closest('.attribute-setting[data-type="font"]'),
                $preview = $('.builder-font-selector-preview', $wrap),
                family_value = $('.builder-font-selector', $wrap).val(),
                variant_value;

            // If the font is set to `default` or is empty
            if ( ! family_value || 'default' === family_value ) {
               $preview.hide();
               return;
            }

            // Split the value into it`s relevant parts
            family_value = family_value.split(',');

            // Make sure we`re dealing with a custom font
            if ( 'theme' === family_value[0] ) {
               $preview.hide();
               return;
            }

            // Clear any former inline CSS
            $preview.removeAttr('style');

            // Grab the variant value
            variant_value = $('[data-font="'+family_value.join(',')+'"]', $wrap).val();

            // If the current font is italicized
            if ( -1 !== variant_value.indexOf('italic') ) {
               variant_value = variant_value.replace('italic','');
               $preview.css('font-style', 'italic');
            }

            // Reveal & update the preview to reflect the selected font
            $preview.show().css({
               fontFamily: "'"+family_value[1]+"'",
               fontWeight: variant_value,
            });
         });

         // Pressing the preview of an image control
         //
         // Automatically calls the function to select a new attachment
         $document.on('click', '.builder-preview-image', function() {
            self.select_attachment($(this).data('key'));
         });

         // Pressing the button to either select an image or remove it
         $document.on('click', '.builder-select-image', function(event) {
            event.preventDefault();
            var key = $(this).data('key');

            // First, check to see if an image has already been selected,
            // if one has been selected remove it, clear the preview, and
            // update the text of the button to reflect this change.
            if ( $('input[data-key="'+key+'"]').val() ) {
               $('input[data-key="'+key+'"]').val('');
               $('p[data-key="'+key+'"]').html('');
               $(this).html($(this).data('add-text'));
               return;
            }

            // We made it here, which means there was no image to remove,
            // this means we need to launch the modal to select one.
            self.select_attachment(key);
         });

         // Pressing the preview of a gallery control
         //
         // Automatically calls the function to manage the gallery
         $document.on('click', '.builder-preview-gallery', function() {
            self.manage_gallery($(this).data('key'));
         });

         // Pressing the button to either manage a gallery or remove it
         $document.on('click', '.builder-manage-gallery', function(event) {
            event.preventDefault();
            var key = $(this).data('key');

            // First, check to see if an image has already been selected,
            // if one has been selected remove it, clear the preview, and
            // update the text of the button to reflect this change.
            if ( $('input[data-key="'+key+'"]').val() ) {
               $('input[data-key="'+key+'"]').val('');
               $('ul[data-key="'+key+'"]').html('');
               $(this).html($(this).data('add-text'));
               return;
            }

            // We made it here, which means there was no image to remove,
            // this means we need to launch the modal to select one.
            self.manage_gallery(key);
         });

         // Pressing a `Select Video` button
         //
         // Automatically calls the function to select a video file from the library
         $document.on('click', '.builder-select-video', function(event) {
            event.preventDefault();
            var key = $(this).data('key');

            var args = {
               key: key,
               type: 'video',
               on_confirm: function(url) {
                  $('input[data-key="'+key+'"]').val(url);
               },
            };

            themefyreBuilder.selectFile( args );
         });

         // Pressing a `Select Audio` button
         //
         // Automatically calls the function to select a audio file from the library
         $document.on('click', '.builder-select-audio', function(event) {
            event.preventDefault();
            var key = $(this).data('key');

            var args = {
               key: key,
               type: 'audio',
               on_confirm: function(url) {
                  $('input[data-key="'+key+'"]').val(url);
               },
            };

            themefyreBuilder.selectFile( args );
         });
      },

      // Sets up the events for the page builder interface
      attach_page_builder_events: function() {
         var self = this;
         var $document = $(document);

         // The start screen is displayed whenever the canvas is empty
         //
         // From the start screen the user can either add their first module,
         // or select a module to import to quickly build pages.
         $('#builder-start-select-template').click( function() {
            $('#builder-templates').trigger('click');
         });
         $('#builder-start-select-module').click( function() {
            $('#builder-canvas').trigger('click');
         });

         // Pressing the `Preview Changes` button
         $('#builder-preview-post').click( function(event) {
            event.preventDefault();
            $('#post-preview')[0].click();
         });

         // Pressing the `Save Changes` button
         $('#builder-save-post').click( function(event) {
            event.preventDefault();
            $('#publish')[0].click();
         });

         // Capture form submission event
         //
         // Immediately before the form is submitted the value of
         // the page builder at it`s current state is stored in a hidden
         // textarea so the value will be updated in the database.
         $('#post').on('submit', function() {
            if ( 'active' === $('#builder-state').val() ) {
               $('#builder-faux-content-wrap').append( $('<textarea />', {name:"content", id:"builder-faux-content"}) );
               $('#builder-temporary-value, #builder-faux-content').text( self.builder_capture_page() );
            }
            else if ( document.getElementById('builder-faux-content') ) {
               $('#builder-faux-content').remove();
            }
         });

         // Exporting as executable shortcodes
         $('#builder-export').click( function() {
            self.builder_export();
         });

         // Going back one step in the history
         $('#builder-undo').click( function() {
            self.builder_history_undo();
         });

         // Going forward one step in the history
         $('#builder-redo').click( function() {
            self.builder_history_redo();
         });

         // Clearing the current canvas
         $('#builder-reset').click( function() {
            if ( $('#builder-canvas').html() || self.builder_get_custom_css() ) {
               self.builder_reset_canvas();
            }
         });

         // Toggling instant preview mode
         $('#builder-instant-preview').click( function() {
            var $this = $(this);
            $this.toggleClass('is-active');
            self.instant_preview = $this.hasClass('is-active');

            // Make sure the preview is open initially
            if ( $this.hasClass('is-active') ) {
               $('#post-preview')[0].click();
            }
         });

         // Importing a separate page
         $('#builder-templates').click( function() {
            self.builder_launch_template_manager();
         });

         // Editing custom CSS
         $('#builder-edit-css').click( function() {
            self.builder_edit_css();
         });

         // Toggling fullscreen mode
         $('#builder-toggle-fullscreen').click( function() {
            self.builder_toggle_fullscreen();
         });

         // Pressing the button to add a module
         $document.on('click', '.builder-add-module', function() {
            self.builder_add_module( $(this) );
         });

         // Pressing an empty dropzone
         $document.on('click', '.builder-module-dropzone.is-empty', function() {
            $(this).next().trigger('click');
         });

         // Pressing the button to edit a module
         $document.on('click', '.builder-module .module-edit', function() {
            $(this).closest('.builder-module').trigger('moduleedit');
         });

         // Pressing the module preview to edit a module
         $document.on('click', '.builder-module .module-preview', function() {
            $(this).closest('.builder-module').trigger('moduleedit');
         });

         // Pressing the button to duplicate a module
         $document.on('click', '.builder-module .module-duplicate', function() {
            $(this).closest('.builder-module').trigger('moduleduplicate');
         });

         // Pressing the button to delete a module
         $document.on('click', '.builder-module .module-remove', function() {
            $(this).closest('.builder-module').trigger('moduleremove');
         });

         // Pressing and holding the button to move a module
         var clickHoldTimeout = 0;
         $document.on( 'mousedown', '.builder-module[data-role="full-width"] > .module-controls .module-move-up, .builder-module[data-role="full-width"] > .module-controls .module-move-down', function() {
            var $this = $(this);
            clickHoldTimeout = setTimeout( function() {
               $this.trigger('clickhold');
            }, 300 );
         }).on('mouseup mouseleave', function() {
            clearTimeout(clickHoldTimeout);
         });

         // Pressing the button to move a module up
         $document.on('click clickhold', '.builder-module .module-move-up', function( event ) {
            switch ( event.type ) {
               case 'click': $(this).closest('.builder-module').trigger('modulemoveup'); break;
               case 'clickhold': $(this).closest('.builder-module').trigger('modulemovetotop'); break;
            }
         });

         // Pressing the button to move a module down
         $document.on('click clickhold', '.builder-module .module-move-down', function( event ) {
            switch ( event.type ) {
               case 'click': $(this).closest('.builder-module').trigger('modulemovedown'); break;
               case 'clickhold': $(this).closest('.builder-module').trigger('modulemovetobottom'); break;
            }
         });

         // Editing a builder module
         $document.on('moduleedit', '.builder-module', function(event) {
            event.stopPropagation();
            self.builder_edit_module( $(event.target) );
         });

         // Duplicating a builder module
         $document.on('moduleduplicate', '.builder-module', function(event) {
            event.stopPropagation();
            var $target = $(event.target).parent('.builder-module-container').length ? $(event.target).parent('.builder-module-container') : $(event.target);
            self.builder_duplicate_module( $target );
            self.builder_refresh_canvas();
         });

         // Deleting a builder module
         $document.on('moduleremove', '.builder-module', function(event) {
            event.stopPropagation();
            var $target = $(event.target).parent('.builder-module-container').length ? $(event.target).parent('.builder-module-container') : $(event.target);
            self.builder_remove_module( $target );
            self.builder_refresh_canvas();
         });

         // Moving a module up
         $document.on('modulemoveup', '.builder-module', function(event) {
            event.stopPropagation();
            var $target = $(event.target).parent('.builder-module-container').length ? $(event.target).parent('.builder-module-container') : $(event.target);
            self.builder_reposition_module( $target, 'up' );
            self.builder_refresh_canvas();
         });

         // Moving a module down
         $document.on('modulemovedown', '.builder-module', function(event) {
            event.stopPropagation();
            var $target = $(event.target).parent('.builder-module-container').length ? $(event.target).parent('.builder-module-container') : $(event.target);
            self.builder_reposition_module( $target, 'down' );
            self.builder_refresh_canvas();
         });

         // Moving a module to the top (only applicable to full width modules)
         $document.on('modulemovetotop', '.builder-module[data-role="full-width"]', function(event) {
            event.stopPropagation();
            var $target = $(event.target).parent('.builder-module-container').length ? $(event.target).parent('.builder-module-container') : $(event.target);
            self.builder_reposition_module( $target, 'top' );
            self.builder_refresh_canvas();
         });

         // Moving a module to the bottom (only applicable to full width modules)
         $document.on('modulemovetobottom', '.builder-module[data-role="full-width"]', function(event) {
            event.stopPropagation();
            var $target = $(event.target).parent('.builder-module-container').length ? $(event.target).parent('.builder-module-container') : $(event.target);
            self.builder_reposition_module( $target, 'bottom' );
            self.builder_refresh_canvas();
         });

         // Icon picker search functionality
         $document.on( 'keyup change', '.builder-search-icons', function(event) {
            var $input = $(this), search = $input.val();

            // If the enter key is pressed while the search bar is in focus, we select & edit the first available module
            if ( 'keyup' === event.type && 13 === event.keyCode ) {
               var $firstAvailable = $input.next('.builder-available-icons').children('.icon-font-group:not(:hidden)').eq(0).find('[data-name]:not(:hidden)').eq(0);
               if ( $firstAvailable.length ) {
                  $firstAvailable.trigger('click')
               }
            }

            // If there is no search term reveal all icons
            if ( ! search ) {
               $input.next('.builder-available-icons').find('.icon-font-group, [data-name]').show();
               return;
            }

            // If there is one only show the relevant ones
            $input.next('.builder-available-icons').children('.icon-font-group').each( function() {
               var $group = $(this), hidden = true;
               $group.find('[data-name]').each( function() {
                  var $icon = $(this), value = $icon.data('name');
                  if (  -1 === value.indexOf(search) ) {
                     $icon.hide();
                  }
                  else {
                     $icon.show();
                     hidden = false;
                  }
               });
               if ( hidden ) {
                  $group.hide();
               }
               else {
                  $group.show();
               }
            });
         });

         // Icon picker search functionality
         $document.on( 'keyup change', '.builder-search-modules', function( event ) {
            var $input = $(this), search = $input.val().toLowerCase();

            // If the enter key is pressed while the search bar is in focus, we select & edit the first available module
            if ( 'keyup' === event.type && 13 === event.keyCode ) {
               var $firstAvailable = $input.next('.available-content-shortcodes').children('.available-content-shortcodes-group:not(:hidden)').eq(0).find('li:not(:hidden)').eq(0).children('button');
               if ( $firstAvailable.length ) {
                  $firstAvailable.trigger('clickhold')
               }
            }

            // If there is no search term reveal all icons
            if ( ! search ) {
               $input.next('.available-content-shortcodes').find('.available-content-shortcodes-group, [data-name]').show();
               return;
            }

            // If there is one only show the relevant ones
            $input.next('.available-content-shortcodes').children('.available-content-shortcodes-group').each( function() {
               var $group = $(this), hidden = true;
               $group.find('[data-name]').each( function() {
                  var $module = $(this), tag = $module.data('name').toLowerCase();
                  if (  -1 === tag.indexOf(search) ) {
                     $module.hide();
                  }
                  else {
                     $module.show();
                     hidden = false;
                  }
               });
               if ( hidden ) {
                  $group.hide();
               }
               else {
                  $group.show();
               }
            });
         });
      },

      // Switches between the page builder and default editor.
      builder_switch_active_editor: function() {
         var self = this;
         var $toggle = $('#builder-toggle');
         var current_state = $('#builder-state').val();
         var new_state = 'active' === current_state ? 'inactive' : 'active';

         // When switching to the default editor after the page builder has been active
         //
         // Clear the content of the TinyMCE editor when deactivating the page builder
         // only if the page builder was active upon page load
         if ( 'inactive' === new_state && 'active' === this.original_state && this.builder_capture_page() ) {
            var r = confirm( builderLocalize.confirm_switch_inactive );
            if ( ! r ) {
               return;
            }

            // Clear any content found in the default editor
            themefyreBuilder.setWPEditorContent('content', '');
         }

         // When activating the page builder for the first time
         //
         // If there is currently content in the default editor we need to tell the user
         // that this content will be converted for use by the page builder.
         if ( 'active' === new_state && 'inactive' === this.original_state && themefyreBuilder.getWPEditorContent('content') ) {
            var r = confirm( builderLocalize.confirm_switch_active );
            if ( ! r ) {
               return;
            }

            // Captures any existing content as a shortcode to be placed into the page builder
            var existingContent = '[builder_section][builder_row][builder_text_block builder_module_label="'+builderLocalize.preexisting_page_content_label+'"]'+themefyreBuilder.getWPEditorContent('content')+'[/builder_text_block][/builder_row][/builder_section]';

            // Reveal the modal loader
            $('#builder-admin-modals-absolute-container').trigger('appendloader');

            var args = {
               callback: function(response) {
                  $('#builder-canvas').html(response);
                  self.builder_refresh_canvas();
               },
               complete: function() {
                  $('#builder-admin-modals-absolute-container').trigger('removeloader');
               },
            };

            this.builder_get_interface_from_string( existingContent, args );
         }

         // The page builder uses a faux textarea to update the page content, this removes it
         if ( document.getElementById('builder-faux-content') ) {
            $('#builder-faux-content').remove();
         }

         // Modify the page HTML
         $('body').removeClass('page-builder-'+current_state).addClass('page-builder-'+new_state);
         $toggle.html( $toggle.data(new_state+'-text') );

         // Update the builder state input value
         $('#builder-state').val(new_state).trigger('change');
      },

      // Removes all modules from the page builder
      builder_reset_canvas: function() {

         // First make sure we have modules to delete or some custom CSS to remove
         if ( ! $('#builder-canvas').html() && ! this.builder_get_custom_css() ) {
            alert( builderLocalize.empty_canvas_delete );
            return;
         }

         // Now check to make sure this was intentional
         var check = confirm(builderLocalize.confirm_canvas_reset);
         if ( ! check ) {
            return;
         }

         // We made it here, time to get to work
         $('#builder-canvas').html(''); // Delete all modules
         this.builder_set_custom_css(''); // Remove all custom CSS
         this.builder_refresh_canvas();
         this.builder_history_add_step( builderLocalize.history_message_reset );
      },

      // Updates the reset button HTML depending on if there are modules or not
      builder_update_reset_button: function() {
         if ( $('#builder-canvas').html() || this.builder_get_custom_css() ) {
            $('#builder-reset').removeClass('is-disabled');
         }
         else {
            $('#builder-reset').addClass('is-disabled');
         }
      },

      // Initiate the instant preview timer
      builder_start_instant_preview: function() {
         var self = this;

         // If instant preview is enabled, trigger a preview refresh
         if ( ! this.instant_preview ) {
            return;
         }

         this.instant_preview_state = 'waiting';
         clearTimeout( this.instant_preview_timer );
         self.builder_reveal_instant_preview_queued_notification();

         this.instant_preview_timer = setTimeout( function() {
            $('#post-preview')[0].click();
            self.instant_preview_state = 'complete';
            self.builder_reveal_instant_preview_updated_notification();
         }, 1500);
      },

      // Cancel the instant preview timer
      builder_cancel_instant_preview: function() {
         this.instant_preview_state = 'canceled';
         clearTimeout( this.instant_preview_timer );
         this.builder_conceal_instant_preview_queued_notification();
      },

      // Temporarily reveals a notification indicating
      // that the preview is being loaded
      builder_reveal_instant_preview_queued_notification: function() {
         $('#builder-preview-notification').addClass('is-active');
         setTimeout( function() {
            $('#builder-preview-notification').addClass('is-visible');
         }, 5);
      },

      // Hides the notification indicating
      // that the preview is being loaded
      builder_conceal_instant_preview_queued_notification: function() {
         $('#builder-preview-notification').removeClass('is-visible');
         setTimeout( function() {
            $('#builder-preview-notification').removeClass('is-active');
         }, 250 );
      },

      // Temporarily reveals a notification indicating
      // that the preview has been updated
      builder_reveal_instant_preview_updated_notification: function() {
         $('#builder-preview-updated-notification').addClass('is-visible');
         setTimeout( function() {
            $('#builder-preview-notification').removeClass('is-visible');
            setTimeout( function() {
               $('#builder-preview-notification').removeClass('is-active');
               $('#builder-preview-updated-notification').removeClass('is-visible');
            }, 250 );
         }, 1000 );
      },

      // Goes back one step in the history
      builder_history_undo: function() {

         // Make sure we can go backward
         if ( 1 === this.active_history_index ) {
            return;
         }

         // Trigger the beginning of the instant preview
         this.builder_start_instant_preview();

         this.active_history_index--;
         this.builder_history_assess_state();

         var canvas = this.history[this.active_history_index-1].canvas;
         $('#builder-canvas').html(canvas);
         this.builder_refresh_canvas();

         var css = this.history[this.active_history_index-1].css;
         this.builder_set_custom_css(css);
      },

      // Goes forward one step in the history
      builder_history_redo: function() {

         // Make sure we can go forward
         if ( this.active_history_index === this.history.length ) {
            return;
         }

         // Trigger the beginning of the instant preview
         this.builder_start_instant_preview();

         this.active_history_index++;
         this.builder_history_assess_state();

         var canvas = this.history[this.active_history_index-1].canvas;
         $('#builder-canvas').html(canvas);
         this.builder_refresh_canvas();

         var css = this.history[this.active_history_index-1].css;
         this.builder_set_custom_css(css);
      },

      // Adds a new state to the builder history
      //
      // The message can be anything that describes what happened during the history step
      builder_history_add_step: function( message ) {
         this.builder_start_instant_preview();

         // If the active state is a former state then we need to
         // replace the inactive states with the new one.
         if ( this.active_history_index < this.history.length ) {
            this.history.splice( this.active_history_index );
         }

         // Increase the active state index by 1
         this.active_history_index++;

         this.history.push({
            canvas: $('#builder-canvas').html(),
            message: message,
            css: this.builder_get_custom_css(),
         });

         this.builder_history_assess_state();

         // Change the `modified` state of the page builder to true
         this.modified = true;
      },

      builder_history_assess_state: function() {

         // No saved states
         if ( 1 === this.history.length ) {
            $('#builder-undo, #builder-redo').addClass('is-disabled');
            $('#builder-undo').attr('title', '');
            $('#builder-redo').attr('title', '');
         }

         // Can not go backward
         else if ( 1 === this.active_history_index ) {
            var redoTitle = 'undefined' !== typeof this.history[this.active_history_index].message ? builderLocalize.redo_with_replace.replace('%s', this.history[this.active_history_index].message) : builderLocalize.redo;
            $('#builder-undo').addClass('is-disabled').attr('title', '' );
            $('#builder-redo').removeClass('is-disabled').attr('title', redoTitle );
         }

         // Can not go forward
         else if ( this.active_history_index === this.history.length ) {
            var undoTitle = 'undefined' !== typeof this.history[this.active_history_index-1].message ? builderLocalize.undo_with_replace.replace('%s', this.history[this.active_history_index-1].message) : builderLocalize.undo;
            $('#builder-undo').removeClass('is-disabled').attr('title', undoTitle );
            $('#builder-redo').addClass('is-disabled').attr('title', '');
         }

         // Can go forward or backward
         else {
            var undoTitle = 'undefined' !== typeof this.history[this.active_history_index-1].message ? builderLocalize.undo_with_replace.replace('%s', this.history[this.active_history_index-1].message) : builderLocalize.undo;
            var redoTitle = 'undefined' !== typeof this.history[this.active_history_index].message ? builderLocalize.redo_with_replace.replace('%s', this.history[this.active_history_index].message) : builderLocalize.redo;
            $('#builder-undo').removeClass('is-disabled').attr('title', undoTitle );
            $('#builder-redo').removeClass('is-disabled').attr('title', redoTitle );
         }
      },

      // Resets the page builder history to 0
      builder_history_reset: function() {

         // Create the initial history object
         //
         // This object will store any changes to the page builder
         // in the form of an HTML string.
         this.history = [{
            canvas: $('#builder-canvas').html(),
            message: builderLocalize.history_message_page_load,
            css: this.builder_get_custom_css(),
         }];

         // Will store the key of the active history state
         this.active_history_index = 1;

         // Ensure that the undo/redo buttons accurately depict the history
         this.builder_history_assess_state();
      },

      // Opens the modal for importing a page
      builder_launch_template_manager: function() {
         var self = this;

         // Prevent the instant preview from firing until the drag has completed
         if ( 'waiting' === self.instant_preview_state ) {
            self.builder_cancel_instant_preview();
            self.instant_preview_state = 'waiting';
         }

         // Set up the modal
         var modal_args = {
            title: builderLocalize.templates_modal_title,
            content: $('#builder-tmpl-builder-template-manager').html(),
            on_open: function( $modal ) {
               self.builder_on_launch_template_manager( $modal );
            },
            on_close: function( $modal ) {

               // When the template management modal is closed we need to capture its content
               // so it will be the same if it is opened again
               $('#builder-tmpl-builder-template-manager').html( $('.builder-modal-content', $modal).html() );

               // If the instant preview was postponed, we need to resume it
               if ( 'waiting' === self.instant_preview_state ) {
                  self.builder_start_instant_preview();
               }
            },
         };

         // Launch the modal
         var modal = new themefyreBuilder.builderModal( modal_args );
      },

      // Opens the modal for importing a page
      builder_on_launch_template_manager: function( $modal ) {
         var self = this;

         // ALlow the enter key to be used to submit the name for a new template
         $('#builder-create-new-template-name').on('keyup', function(event) {
            if ( 13 === event.keyCode ) {
               $('#builder-create-new-template-submit').trigger('click');
            }
         });

         // Pressing the button to save current page as a template
         //
         // This will first check to see if the user has entered a valid name
         // for the new tempalte, then make sure the current page is not empty
         // if both of these conditions are met, a new post will be created
         // based on the current page.
         $('#builder-create-new-template-submit').click( function() {
            var $title_field = $('#builder-create-new-template-name'),
                title = $title_field.val().replace(/[^a-z\d\s]+/gi, '');

            // Immediately clear the template name field value
            $title_field.val('');

            // Make sure name is long enough (at least 3 characters)
            if ( 3 > title.length ) {
               alert(builderLocalize.short_template_name);
               return;
            }

            // Make sure there is something to save
            if ( ! self.builder_capture_page() ) {
               alert(builderLocalize.empty_canvas_save);
               return;
            }

            // We made it this far, which means it is time to save our new template
            //
            // First, we capture the value of the current page, then we use an AJAX
            // call to programatically create our new template using PHP with the
            // submitted content & title.
            var builderValue = self.builder_capture_page(),
                CSSValue = self.builder_get_custom_css();

            // Reveal the loader
            $('#builder-admin-modals-absolute-container').trigger('appendloader');

            // Make the AJAX call to create out new template
            $.ajax({
               type: 'POST',
               url: builderLocalize.ajax_url,
               data: {
                  action: 'builder_ajax_create_template',
                  post_title: title,
                  builder_value: builderValue,
                  css_value: CSSValue,
               },
               error: function() {
                  alert(builderLocalize.ajax_create_template_error);
               },
               complete: function() {
                  $('#builder-admin-modals-absolute-container').trigger('removeloader');
               },
               success: function( response ) {
                  switch ( response ) {

                     // User was logged out
                     case 0:
                        alert(builderLocalize.ajax_logged_out);
                        break;

                     // Nonce timeout
                     case 1:
                        alert(builderLocalize.ajax_nonce_error);
                        break;

                     // Post could not be created
                     case 'error':
                        alert(builderLocalize.ajax_create_template_error);
                        break;

                     // Post was succesfully created
                     default:
                        $('#builder-import-template').removeClass('no-items').append(response);
                        break;
                  }
               },
            });

         });

         // Pressing a button associated with a certain prebuilt template slug
         //
         // If the buttons contains a `.remove-item` element this element can be pressed
         // to trigger an AJAX call which will delte the post with the specified ID.
         //
         // Otherwasie, the button can be pressed to trigger an AJAX call which will
         // import the content of the post with the specified ID.
         $modal.on( 'click', '.builder-importer-available-items button[data-template-slug]', function(event) {
            var $this = $(this),
                slug = $(this).data('template-slug'),
                templateName = $('.item-name', $this).text();

            // Reveal the loader
            $('#builder-admin-modals-absolute-container').trigger('appendloader');

            // Begin retrieving the builder template
            $.ajax({
               type: 'POST',
               url: builderLocalize.ajax_url,
               data: {
                  action: 'builder_ajax_get_premade_template',
                  template_slug: slug,
               },
               error: function() {
                  $('#builder-admin-modals-absolute-container').trigger('removeloader');
               },
               success: function( response ) {

                  // User was logged out
                  if ( 0 === response ) {
                     alert(builderLocalize.ajax_logged_out);
                  }

                  // Nonce timeout
                  else if ( '-1' === response ) {
                     alert(builderLocalize.ajax_nonce_error);
                  }

                  var args = {
                     callback: function(response) {
                        $('#builder-canvas').append(response);
                        self.builder_refresh_canvas();
                        self.builder_history_add_step(  builderLocalize.history_message_import_premade_template.replace('%s', templateName) );
                        $modal.trigger('modalcancel');
                     },
                     complete: function() {
                        $('#builder-admin-modals-absolute-container').trigger('removeloader');
                     },
                  };

                  self.builder_get_interface_from_string( response, args );
               },
            });
         });

         // Pressing a button associated with a certain post ID
         //
         // If the buttons contains a `.remove-item` element this element can be pressed
         // to trigger an AJAX call which will delte the post with the specified ID.
         //
         // Otherwise, the button can be pressed to trigger an AJAX call which will
         // import the content of the post with the specified ID.
         $modal.on( 'click', '.builder-importer-available-items button[data-post-id]', function(event) {
            var $this = $(this), $target = $(event.target), post_id = $(this).data('post-id');

            // The button to delete the post was pressed
            if ( $target.is('.remove-item') || $target.parents('.remove-item').length ) {

               // make sure the user meant to hit the delete button
               var r = confirm(builderLocalize.confirm_delete_post);
               if ( ! r ) {
                  return;
               }

               // Reveal the loader
               $('#builder-admin-modals-absolute-container').trigger('appendloader');

               // Begin retrieving the builder template
               $.ajax({
                  type: 'POST',
                  url: builderLocalize.ajax_url,
                  data: {
                     action: 'builder_ajax_delete_post',
                     post_id: post_id,
                  },
                  error: function() {
                     alert(builderLocalize.ajax_delete_post_error);
                  },
                  complete: function() {
                     $('#builder-admin-modals-absolute-container').trigger('removeloader');
                  },
                  success: function( response ) {
                     switch ( response ) {

                        // User was logged out
                        case 0:
                           alert(builderLocalize.ajax_logged_out);
                           break;

                        // Nonce timeout
                        case 1:
                           alert(builderLocalize.ajax_nonce_error);
                           break;

                        // Post was succesfully deleted
                        case 'success':
                           $this.slideUp( function() {
                              $this.remove();

                              // Check if this was the last saved template
                              // If it was, notify the user that they have no saved templates
                              setTimeout( function() {
                                 if ( ! $('#builder-import-template button').length ) {
                                    $('#builder-import-template').addClass('no-items');
                                 }
                              }, 10 );
                           });
                           break;

                        // Post could not be deleted/located
                        default:
                           alert(builderLocalize.ajax_delete_post_error);
                           break;
                     }
                  },
               });
               return;
            }

            // Reveal the loader
            $('#builder-admin-modals-absolute-container').trigger('appendloader');

            var historyMessage, importCSSComment;
            if ( $this.is('.builder-saved-template') ) {
               historyMessage = builderLocalize.history_message_import_saved_template.replace( '%s', $('.item-name', $this).text().trim() );
               importCSSComment = builderLocalize.import_css_saved_template_comment.replace( '%s', $('.item-name', $this).text().trim() );
            }
            else {
               historyMessage = builderLocalize.history_message_import_page.replace( '%s', $this.text().trim() );
               importCSSComment = builderLocalize.import_css_comment.replace( '%s', $this.text().trim() );
            }

            // These variables will be populated with values from our AJAX requests
            var builderValue = '',
                CSSValue = '';

            // Begin retrieving the builder template
            $.when(
               $.ajax({
                  type: 'POST',
                  url: builderLocalize.ajax_url,
                  data: {
                     action: 'builder_ajax_get_post_builder_value',
                     post_id: post_id,
                  },
                  success: function( response ) {
                     // User was logged out
                     if ( 0 === response ) {
                        alert(builderLocalize.ajax_logged_out);
                     }
                     // Nonce timeout
                     else if ( '-1' === response ) {
                        alert(builderLocalize.ajax_nonce_error);
                     }
                     // Store the value for later
                     builderValue = response;
                  },
               }),
               $.ajax({
                  type: 'POST',
                  url: builderLocalize.ajax_url,
                  data: {
                     action: 'builder_ajax_get_post_builder_css',
                     post_id: post_id,
                  },
                  success: function( response ) {
                     // User was logged out
                     if ( 0 === response ) {
                        alert(builderLocalize.ajax_logged_out);
                     }
                     // Nonce timeout
                     else if ( '-1' === response ) {
                        alert(builderLocalize.ajax_nonce_error);
                     }
                     // Store the value for later
                     CSSValue = response;
                  },
               })
            ).then( function() {

               // If any custom CSS was supplied, we add that to the current page value
               if ( CSSValue ) {
                  self.builder_append_custom_css( CSSValue, importCSSComment );
               }

               // If we have any data to process
               if ( builderValue ) {
                  var args = {
                     callback: function(response) {
                        if ( ! response ) {
                           alert(builderLocalize.import_template_empty);
                           return;
                        }
                        $('#builder-canvas').append(response);
                        self.builder_refresh_canvas();
                        self.builder_history_add_step( historyMessage );
                        $modal.trigger('modalcancel');
                     },
                     complete: function() {
                        $('#builder-admin-modals-absolute-container').trigger('removeloader');
                        if ( CSSValue ) {
                           setTimeout( function() {
                              alert(builderLocalize.css_imported_alert);
                           }, 10);
                        }
                     },
                  };
                  self.builder_get_interface_from_string( builderValue, args );
               }

               // If not we`ll just remove the loader
               else {
                  $('#builder-admin-modals-absolute-container').trigger('removeloader');
               }
            });

         });
      },

      // Opens the CSS editor for the page
      builder_edit_css: function() {
         var self = this;

         // Set up the modal
         var modal_args = {
            show_confirm: true,
            title: builderLocalize.edit_builder_css_title,
            content: '<div class="builder-codeMirror-wrap"><textarea id="builder-css-editor"></textarea></div><p class="description">'+builderLocalize.edit_builder_css_desc+'</p>',
            on_open: function() {
               var textarea = document.getElementById('builder-css-editor');
               var editor = CodeMirror.fromTextArea( textarea, {
                  lineNumbers: true,
                  indentUnit: 3,
                  mode: 'css',
                  viewportMargin: Infinity,
               });

               // Set up the saved value
               editor.setValue( self.builder_get_custom_css() );

               // Store the editor instance for later
               $(textarea).data('CodeMirrorInstance', editor);
            },
            on_confirm: function() {
               var editor = $('#builder-css-editor').data('CodeMirrorInstance');
               self.builder_set_custom_css(editor.getValue());
               self.builder_history_add_step(builderLocalize.history_message_modify_css);
            },
         };

         // Launch the modal
         var modal = new themefyreBuilder.builderModal( modal_args );
      },

      // Toggles fullscreen mode
      builder_toggle_fullscreen: function() {
         $('html,body').scrollTop(0);
         $('body').toggleClass('builder-fullscreen-active');
         $('#builder-toggle-fullscreen').toggleClass('is-active');
      },

      // Called every time something happens with the page builder
      builder_refresh_canvas: function() {
         this.builder_apply_sorting();
         this.builder_sanitize_dropzones();
         this.builder_refresh_dropzones();
         this.builder_assess_modules();
         this.builder_update_reset_button();
      },

      // Clears all dropzones of any invalid content
      builder_sanitize_dropzones: function() {

         // Removes invalid content from all dropzones
         $('.builder-module-dropzone').each( function() {
            var $dropzone = $(this), dropzone_role = $dropzone.data('dropzone');

            if ( ! $dropzone.html() ) {
               return;
            }

            $dropzone.contents().filter( function() {

               // node is not an HTML element, always remove it
               if ( this.nodeType !== 1 ) {
                  return true;
               }

               // We made it here, which means we`re dealing with an HTML node
               // so we have to check to make sure it is a builder module first
               if ( ! $(this).is('.builder-module') ) {
                  return true;
               }

               // We made it here, which means we`re dealing with a builder module
               // so we have to check to make sure it is a valid module in the right spot
               var module_role = $(this).data('role');

               // If the roles don't match up, the module is invalid
               if ( ! module_role || module_role !== dropzone_role ) {
                  return true;
               }

               // Child level dropzones only accept 1 valid module
               if ( 'child' === dropzone_role && $(this).data('tag') !== $dropzone.data('child-tag') ) {
                  return true;
               }
            }).remove();
         });
      },

      // Determines which dropzones are empty
      builder_refresh_dropzones: function() {

         // Determines which dropzones are empty
         $('.builder-module-dropzone').each( function() {
            var $zone = $(this), empty = true;
            $(this).children().each( function() {
               if ( 'none' !== $(this).css('display') ) {
                  empty = false;
               }
            });
            if ( empty ) {
               $zone.addClass('is-empty');
            }
            else {
               $zone.removeClass('is-empty');
            }
         });
      },

      // Determines which modules need to have a button inserted
      // after which allows the user to add new modules.
      builder_assess_modules: function() {
         $('.builder-module[data-role="full-width"], .builder-module[data-role="row"]').each( function() {
            var $this = $(this), role = $this.data('role'),
                button_text = 'row' === role ? builderLocalize.add_new_row_module : builderLocalize.add_new_full_width_module,
                button_html = '<button type="button" class="builder-add-module" data-role="'+role+'" title="'+button_text+'">'+button_text+'</button>';

            if ( ! $this.next().is('.builder-add-module') ) {
               $this.after(button_html);
            }
         });
         $('.builder-add-module[data-role="full-width"], .builder-add-module[data-role="row"]').not('.dropzone-button').each( function() {
            if ( ! $(this).prev('.builder-module').length ) {
               $(this).remove();
            }
         });
      },

      // Applies sorting to content/child dropzones
      builder_apply_sorting: function() {
         var self = this;
         $('.builder-module-dropzone[data-dropzone="content"], .builder-module-dropzone[data-dropzone="child"]').each( function() {
            var $this = $(this);

            if ( $this.data('sortingEnabled') ) {
               return;
            }
            $this.data('sortingEnabled', true);

            var dropzone = $this.data('dropzone');
            var connectWith = 'content' === dropzone ? '.builder-module-dropzone[data-dropzone="content"]' : false;

            $this.sortable({
               connectWith: connectWith,
               placeholder: 'builder-module-placeholder',
               appendTo: document.body,
               helper: 'clone',

               // start = drag start
               start: function( event, ui ) {

                  // Prevent the instant preview from firing until the drag has completed
                  if ( 'waiting' === self.instant_preview_state ) {
                     self.builder_cancel_instant_preview();
                     self.instant_preview_state = 'waiting';
                  }

                  // Set the height of the placeholder (subtract 2 to compensate for border)
                  ui.placeholder.height( ui.item.height()-2 );

                  $('body').addClass('builder-is-dragging-module');
                  ui.item.data('start-index', ui.item.index() );
                  ui.item.data('start-dropzone', ui.item.parent() );
                  ui.helper.addClass('builder-dragging');
               },

               // stop = drag stop
               stop: function( event, ui) {
                  $('body').removeClass('builder-is-dragging-module');
                  var config = self.builder_get_module_config( ui.item );

                  if ( ui.item.data('start-index') !== ui.item.index() || ! ui.item.data('start-dropzone').is( ui.item.parent() ) ) {
                     self.builder_refresh_dropzones();
                     if ( 'child' !== config.role ) {
                        self.builder_history_add_step( builderLocalize.history_message_drag_module.replace('%s', self.builder_get_module_name(ui.item)) );
                     }
                  }

                  // If the instant preview was postponed, we need to resume it
                  else if ( 'waiting' === self.instant_preview_state ) {
                     self.builder_start_instant_preview();
                  }
               },

               // over = move over potential new position
               over: function() {
                  self.builder_refresh_dropzones();
               },
            });

         });
      },

      // Returns the combined value of all builder pieces found within the supplied content.
      builder_gather_pieces: function( $content ) {
         var out = '';
         $('.builder-piece', $content).each( function() {
            out += $(this).val();
         });
         return out;
      },

      // Grabs the value of the current page.
      builder_capture_page: function() {
         return this.builder_gather_pieces( $('#builder-canvas') );
      },

      // Grabs the value of the custom CSS for the current page
      builder_get_custom_css: function() {
         return $('#builder-css-value').val();
      },

      // Sets the value of the custom CSS for the current page
      builder_set_custom_css: function( CSS ) {
         $('#builder-css-value').text(CSS);
      },

      // Appends some CSS to the current value
      //
      // You can optionally provide a message will be used
      // as a comment that will be prepended to the custom CSS
      builder_append_custom_css: function( CSS, message ) {
         if ( 'undefined' === typeof message ) {
            message = '';
         }
         if ( message ) {
            message = "/* "+message+" */\n";
         }
         var existingCSS = this.builder_get_custom_css(),
             lineBreak = existingCSS ? "\n\n" : '';
         $('#builder-css-value').text(existingCSS+lineBreak+message+CSS);
      },

      // Uses AJAX to return builder modules HTML from a stirng.
      builder_get_interface_from_string: function( string, args ) {
         var defaults = {
            callback: function(response) {},
            complete: function() {},
         };
         args = _.extend(defaults, args);
         $.ajax({
            type: 'POST',
            url: builderLocalize.ajax_url,
            data: {
               action: 'builder_ajax_get_builder_modules',
               value: string,
            },
            error: function() {
               alert(builderLocalize.ajax_error);
            },
            success: function( response ) {

               // User was logged out
               if ( 0 === response ) {
                  alert(builderLocalize.ajax_logged_out);
               }

               // Nonce timeout
               else if ( '-1' === response ) {
                  alert(builderLocalize.ajax_nonce_error);
               }

               // We made it here, call the callback
               args.callback(response);
            },
            complete: function() {
               args.complete();
            },
         });
      },

      // Gets the configuration for a shortcode module.
      builder_get_module_config: function( $module ) {
         return {
            role: $module.attr('data-role'),
            content_type: $module.attr('data-content-type'),
            tag: $module.attr('data-tag'),
            label_attribute: $module.attr('data-label-attribute'),
         };
      },

      // Gets the configuration for a shortcode module.
      builder_get_module_name: function( $module ) {
         var config = this.builder_get_module_config( $module ),
             name = $module.attr('data-singular-name');

         // Content & child level modules
         if ( ( 'content' === config.role || 'child' === config.role || ( 'full-width' === config.role && 'builder_section' !== config.tag ) ) && $('.module-label', $module).length ) {
            name += ' - ' + $('.module-label', $module).text().trim();
         }

         return name.trim();
      },

      // highlights a module for a brief moment
      builder_highlight_module: function( $module ) {
         $module.addClass('is-highlighting');
         setTimeout( function() {
            $module.addClass('done-highlighting');
            setTimeout( function() {
               $module.removeClass('done-highlighting');
               setTimeout( function() {
                  $module.removeClass('is-highlighting');
               }, 250);
            }, 250);
         }, 10);
      },

      // Called when the `Add module` button is pressed
      builder_add_module: function( $button ) {
         var self = this;
         var role = $button.attr('data-role');

         if ( 'child' === role ) {
            var tag     = $button.data('tag');
            var $module = $($('#builder-tmpl-builder-module-'+tag).html());
            $button.prev().append( $module );
            this.builder_refresh_canvas();
            return;
         }

         // Prevent the instant preview from firing until a module is selected
         // or the modal has been closed
         if ( 'waiting' === this.instant_preview_state ) {
            this.builder_cancel_instant_preview();
            this.instant_preview_state = 'waiting';
         }

         var title = $button.attr('title');

         // Set up the modal
         var modal_args = {
            title: title,
            content: $('#builder-tmpl-available-'+role+'-shortcodes').html(),
            add_class: 'no-padding',
            on_open: function( $modal ) {
               self.builder_on_launch_add_module( $modal, $button );
            },
            on_cancel: function() {
               if ( 'waiting' === self.instant_preview_state ) {
                  self.builder_start_instant_preview();
               }
            },
         };

         // Launch the modal
         var modal = new themefyreBuilder.builderModal( modal_args );
      },

      // Attaches the events for adding a module to the page builder.
      builder_on_launch_add_module: function( $modal, $button ) {
         var self = this;

         // If the modal contains a search bar, focus it
         if ( $('.builder-search-modules', $modal).length ) {
            $('.builder-search-modules', $modal).focus();
         }

         var clickHoldTimeout = 0;
         $modal.on( 'mousedown', 'button[data-tag]', function() {
            var $this = $(this);
            clickHoldTimeout = setTimeout( function() {
               $this.trigger('clickhold');
            }, 150 );
         }).on('mouseup mouseleave', function() {
            clearTimeout(clickHoldTimeout);
         });

         // Pressing the button to add a shortcode
         $modal.on('click clickhold', 'button[data-tag]', function(event) {
            var tag     = $(this).data('tag');
            var $module = $($('#builder-tmpl-builder-module-'+tag).html());

            // Close the current modal
            $modal.trigger('modalconfirm');

            // Insert the new module at the correct location
            switch ( $button.attr('data-role') ) {
               case 'row':
               case 'full-width':
                  if ( $button.prev().is('[data-dropzone]') ) {
                     $button.prev().append( $module );
                  }
                  else {
                     $button.after( $module );
                  }
                  break;
               case 'content':
                  $button.prev().append( $module );
                  break;
            }

            // Refresh the canvas
            self.builder_refresh_canvas();

            // Add a new history state
            self.builder_history_add_step( builderLocalize.history_message_add_module.replace('%s', self.builder_get_module_name( $module )) );

            // Automatically edit the module
            if ( 'clickhold' === event.type ) {
               $module.trigger('moduleedit');
            }

            // If not, highlight it if it has siblings
            else if ( $module.siblings().length ) {
               self.builder_highlight_module( $module );
            }
         });
      },

      // Edits a module in the page builder.
      builder_edit_module: function( $module ) {
         var self = this,
             module_config = self.builder_get_module_config( $module );

         // Prevent the instant preview from firing until the modal has been closed
         if ( 'waiting' === this.instant_preview_state ) {
            this.builder_cancel_instant_preview();
            this.instant_preview_state = 'waiting';
         }

         // Set up the new modal
         var modal_args = {
            title: builderLocalize.edit_module_title.replace('%s', this.builder_get_module_name( $module ) ),
            on_open: function( $modal ) {
               self.on_open_edit_shortcode_modal( $modal );
               self.builder_apply_shortcode_settings( $modal, $module );
               self.trigger_attribute_change_events( $modal );
            },
            on_confirm: function( $modal ) {

               // Make sure the modal has finished loading before it is saved
               if ( $modal.find('.builder-modal-inline-loader').length ) {
                  return false;
               }
               self.builder_on_submit_edit_shortcode_modal( $modal, $module );
               self.builder_highlight_module( $module );
            },
            on_cancel: function( $modal ) {
               if ( 'child' !== module_config.role && 'waiting' === self.instant_preview_state ) {
                  self.builder_start_instant_preview();
               }
            },
         };

         // Open a new modal for the shortcode edit screen
         self.open_edit_shortcode_modal( module_config.tag, modal_args );
      },

      // Duplicates a module in the page builder.
      builder_duplicate_module: function( $module ) {
         var $clone = $module.clone();
         var config = this.builder_get_module_config( $module );
         $module.after($clone);
         if ( 'child' !== config.role ) {
            this.builder_history_add_step( builderLocalize.history_message_duplicate_module.replace('%s', this.builder_get_module_name( $module )) );
         }
         this.builder_highlight_module( $clone );
      },

      // Deletes a module in the page builder.
      builder_remove_module: function( $module ) {
         var config = this.builder_get_module_config( $module ),
             $closestModal = $module.closest('.builder-admin-modal');
         $module.remove();
         if ( 'child' !== config.role ) {
            this.builder_history_add_step( builderLocalize.history_message_delete_module.replace('%s', this.builder_get_module_name( $module )) );
         }

         // Update the reset button HTML
         this.builder_update_reset_button();
      },

      // Scrolls the designated module into view
      builder_scroll_to_module: function( $module, callback ) {
         var config = this.builder_get_module_config( $module ),
             fullScreenActive = $('body').hasClass('builder-fullscreen-active'),
             $scrollBox = fullScreenActive ? $('#page_builder_meta_box') : $('html,body'),
             scrollPosition = fullScreenActive ? $scrollBox.scrollTop() : window.pageYOffset,
             modulePosition = fullScreenActive ? $module.position().top : $module.offset().top,
             scrollPositionOffset = fullScreenActive ? 50 : 32,
             scrollTo = 0;

         if ( fullScreenActive ) {
            $module.parents('.builder-module').each( function() {
               modulePosition += $(this).position().top; // Add the top offset of any containing modules
            });
            modulePosition += 62; // Accounts for the spacing between the canvas and the scrollBox
         }

         // Check if the module is out of the screen at all
         var offScreenTop = modulePosition < scrollPosition+scrollPositionOffset,
             offScreenBottom = modulePosition+$module.outerHeight() > scrollPosition+window.innerHeight,
             moduleLargerThanViewport = $module.outerHeight() >= ((window.innerHeight-scrollPositionOffset)-20);

         // Calculate the exact location we need to scroll to
         if ( offScreenTop || moduleLargerThanViewport ) {
            scrollTo = modulePosition-scrollPositionOffset-20; // Account for any sticky admin bars
         }
         else if ( offScreenBottom ) {
            scrollTo = modulePosition - window.innerHeight + $module.outerHeight() + 40;
         }

         if ( offScreenTop || offScreenBottom ) {
            $scrollBox.animate({
               scrollTop: scrollTo,
            }, 500, function() {
               callback( $module );
            });
         }
         else {
            callback( $module );
         }
      },

      // Moves a module in a certain direction
      builder_reposition_module: function( $module, direction ) {
         var self = this, role = $module.attr('data-role');
         if ( 'full-width' !== role && 'row' !== role ) {
            return;
         }

         // First check to see if there are any modules that
         // immediately precede or follow the module being moved.
         switch ( direction ) {
            case 'up':
               if ( $module.prevAll('.builder-module').length ) {
                  $module.prevAll('.builder-module').first().before( $module );
                  this.builder_scroll_to_module( $module, function( $module ) {
                     self.builder_history_add_step( builderLocalize.history_message_move_module_up.replace('%s', self.builder_get_module_name( $module )) );
                     self.builder_highlight_module( $module );
                  });
                  return;
               }
               break;
            case 'down':
               if ( $module.nextAll('.builder-module').length ) {
                  $module.nextAll('.builder-module').first().after( $module );
                  this.builder_scroll_to_module( $module, function( $module ) {
                     self.builder_history_add_step( builderLocalize.history_message_move_module_down.replace('%s', self.builder_get_module_name( $module )) );
                     self.builder_highlight_module( $module );
                  });
                  return;
               }
               break;
            case 'top':
               if ( $module.prevAll('.builder-module').length ) {
                  $module.prevAll('.builder-module').last().before( $module );
                  this.builder_scroll_to_module( $module, function( $module ) {
                     self.builder_history_add_step( builderLocalize.history_message_move_module_to_top.replace('%s', self.builder_get_module_name( $module )) );
                     self.builder_highlight_module( $module );
                  });
                  return;
               }
               break;
            case 'bottom':
               if ( $module.nextAll('.builder-module').length ) {
                  $module.nextAll('.builder-module').last().after( $module );
                  this.builder_scroll_to_module( $module, function( $module ) {
                     self.builder_history_add_step( builderLocalize.history_message_move_module_to_bottom.replace('%s', self.builder_get_module_name( $module )) );
                     self.builder_highlight_module( $module );
                  });
                  return;
               }
               break;
         }

         // Do not continue if we`re dealing with a full-width module
         if ( 'full-width' === role ) {
            return;
         }

         // We made it here, which means we are dealing with a row
         // module that is at the top/bottom of its current section,
         // this means we need to find the nearest section either
         // before or after the parent one and place the row at either
         // the top or bottom of this section.
         var $parent_section = $module.closest('.builder-module[data-tag="builder_section"]');

         switch ( direction ) {
            case 'up':
               var $nearest_section = $parent_section.prevAll('[data-tag="builder_section"]');
               if ( $nearest_section.length ) {
                  $nearest_section.first().find('[data-dropzone="row"]').append($module);
                  this.builder_scroll_to_module( $module, function( $module ) {
                     self.builder_history_add_step( builderLocalize.history_message_move_module_up.replace('%s', self.builder_get_module_name( $module )) );
                     self.builder_highlight_module( $module );
                  });
               }
               break;
            case 'down':
               var $nearest_section = $parent_section.nextAll('[data-tag="builder_section"]');
               if ( $nearest_section.length ) {
                  $nearest_section.first().find('[data-dropzone="row"]').prepend($module);
                  this.builder_scroll_to_module( $module, function( $module ) {
                     self.builder_history_add_step( builderLocalize.history_message_move_module_down.replace('%s', self.builder_get_module_name( $module )) );
                     self.builder_highlight_module( $module );
                  });
               }
               break;
         }
      },

      // When an edit shortcode modal is opened apply the module config.
      //
      // Because the modals for editing each shortcode are stored in the form
      // of an HTML template in a script tag it is necessary to apply any saved
      // attributes manually via JavaScript whenever the modal for editing
      // a shortcode is opened.
      builder_apply_shortcode_settings: function( $modal, $module ) {
         var self = this;

         // Grab the content
         var content = '';
         if ( $module.children('.builder-piece[data-piece="content"]').length ) {
            content = $module.children('.builder-piece[data-piece="content"]').val();
         }

         // Insert any saved content
         var $content_editor_wrap = $modal.find('.shortcode-content-editor');
         if ( content && $content_editor_wrap.length ) {
            switch ( $content_editor_wrap.data('type') ) {

               // TinyMCE editor
               case 'editor':

                  // Insert the content when the editor is ready
                  themefyreBuilder.setWPEditorContent('shortcode_wp_editor_content', content);
                  break;

               // Standard textarea
               case 'textarea':
                  var editor = $('#shortcode_codeMirror_content').data('CodeMirrorInstance');
                  editor.setValue(content);
                  break;

               // Child element
               case 'child_element':
                  var $loader = $(self.get_modal_inner_loader_HTML());
                  $content_editor_wrap.hide().after( $loader );
                  var args = {
                     callback: function( response ) {
                        $content_editor_wrap.find('[data-dropzone]').html(response);
                     },
                     complete: function() {
                        $loader.remove();
                        $content_editor_wrap.show();
                        self.builder_refresh_canvas();
                     }
                  };
                  self.builder_get_interface_from_string( content, args );
                  break;

            }
         }

         // Create the attributes object
         var attributes = {};
         if ( $module.attr('data-attributes') ) {
            attributes = JSON.parse( $module.attr('data-attributes') );
         }

         // Apply any saved module attributes
         _.each( attributes, function(saved_value, attribute) {
            var $control_wrap = $modal.find('[data-attribute="'+attribute+'"]');
            if ( ! $control_wrap.length ) {
               return;
            }
            switch ( $control_wrap.data('type') ) {

               // Check/uncheck the checkbox
               case 'bool':
                  var value = 'true' === saved_value ? true : false;
                  $control_wrap.find('[name]').prop('checked', value);
                  break;

               // Populate the preview with an AJAX callback
               case 'image':
               case 'gallery':
                  var $button = $control_wrap.find('[data-remove-text]');
                  var action = 'image' === $control_wrap.data('type') ? 'get_image_preview' : 'get_gallery_preview';
                  $control_wrap.find('[class*="-preview"]').after( self.get_modal_inner_loader_HTML() );
                  $button.parent().hide();
                  $control_wrap.find('[name]').val(saved_value).trigger('change');
                  $button.text( $button.data('remove-text') );
                  $.ajax({
                     type: 'POST',
                     url: builderLocalize.ajax_url,
                     data: {
                        action: 'builder_ajax_'+action,
                        value: saved_value,
                     },
                     error: function() {
                        alert(builderLocalize.ajax_error);
                     },
                     success: function( response ) {

                        // User was logged out
                        if ( 0 === response ) {
                           alert(builderLocalize.ajax_logged_out);
                        }

                        // Nonce timeout
                        else if ( '-1' === response ) {
                           alert(builderLocalize.ajax_nonce_error);
                        }

                        // We made it here, insert the preview
                        $control_wrap.find('[class*="-preview"]').html(response);
                     },
                     complete: function() {
                        $control_wrap.find('[class*="-preview"]').next().remove();
                        $button.parent().show();
                     }
                  });
                  break;

               // Apply the correct values to the font selector
               case 'font':
                  if ( 'default' !== saved_value ) {
                     var split_value = saved_value.split(',');
                     var font_value = split_value[0]+','+split_value[1];
                     var weight_value = split_value[2];
                     $control_wrap.find('[name]').val(font_value);
                     $control_wrap.find('[data-font="'+font_value+'"]').val(weight_value);

                  }
                  else {
                     $control_wrap.find('[name]').val(saved_value);
                  }
                  break;

               // Simply apply the setting to any element with a `name` attribute by default
               default:
                  $control_wrap.find('[name]').val( themefyreBuilder.decodeShortcodeAttr( saved_value ) );
                  break;
            }
         });
      },

      // When the form for editing a shortcode module is submitted.
      //
      // This will update the textareas within the module which store the
      // actual shortcode, as well as the `args` attribute which stores the saved
      // attributes in the form of a JSON object.
      builder_on_submit_edit_shortcode_modal: function( $modal, $module ) {
         var self = this;
         var config = this.builder_get_module_config( $module );
         var submitted = this.get_edit_shortcode_modal_settings( $modal, 'builder' );

         // Content & child level modules can have optional module previews
         if ( 'content' === config.role || 'child' === config.role ) {
            // If there is a preview callback we use that to grab the content
            if ( 'undefined' !== typeof themefyreBuilder.modulePreviewCallbacks[config.tag] ) {

               // Format the attributes to be used by the module preview callback
               var formattedAttributes = {};
               submitted.attributes
               _.each( submitted.attributes, function( value, index ) {
                  formattedAttributes[index] = themefyreBuilder.decodeShortcodeAttr( value );
               });

               // Format the content to be used by the module preview callback
               var formattedContent = '';
               if ( 'none' !== config.content_type && submitted.content.trim() ) {
                  switch ( config.content_type ) {
                     case 'editor':
                        if ( submitted.content ) {
                           formattedContent = window.switchEditors.wpautop( submitted.content );
                        }
                        break;
                     // Resort to default which means the content element is another shortcode
                     // The content type value should contain the tag of the content module
                     default:
                        formattedContent = []; // Begin with an empty array
                        var returnObject, lastIndex = 0;
                        do {
                           returnObject = wp.shortcode.next( config.content_type, submitted.content, lastIndex );
                           if ( returnObject ) {
                              lastIndex = returnObject.index+1; // Add 1 to ensure we do not reiterate over the same shortcode
                              formattedContent.push( returnObject.shortcode ); // Add the shortcode object to our return value
                           }
                        } while ( returnObject );
                        _.each( formattedContent, function( shortcode, shortcodeIndex ) {
                           _.each( shortcode.attrs.named, function( attrValue, attrIndex ) {
                              formattedContent[shortcodeIndex].attrs.named[attrIndex] = themefyreBuilder.decodeShortcodeAttr( attrValue );
                           });
                        });
                        break;
                  }
               }

               var previewContent = themefyreBuilder.modulePreviewCallbacks[config.tag]( formattedAttributes, formattedContent, $modal, $module );
               if ( previewContent ) {
                  $('.module-preview', $module).html(previewContent);
                  $module.addClass('has-preview');
               }
               else {
                  $('.module-preview', $module).html('');
                  $module.removeClass('has-preview');
               }
            }
            // No callback so we just make sure the preview is hidden
            else {
               $('.module-preview', $module).html('');
               $module.removeClass('has-preview');
            }
         }

         // Update the module attributes object
         if ( submitted.attributes ) {
            $module.attr('data-attributes', JSON.stringify( submitted.attributes ) );
         }

         // When editing a row module we add a specific attribute indicating the bottom margin value
         if ( submitted.attributes && 'row' === config.role ) {
            if ( 'undefined' !== typeof submitted.attributes.bottom_margin && submitted.attributes.bottom_margin ) {
               $module.attr( 'data-bottom-margin', submitted.attributes.bottom_margin );
            }
            else {
               $module.removeAttr( 'data-bottom-margin' );
            }
         }

         // Update the module label
         if ( 'none' !== config.label_attribute ) {
            var label = 'undefined' !== typeof submitted.attributes[config.label_attribute] ? themefyreBuilder.decodeShortcodeAttr( themefyreBuilder.stripTags( submitted.attributes[config.label_attribute] ) ) : '',
                $moduleLabel = $('.module-title .module-label', $module);
            if ( label ) {
               if ( $moduleLabel.length ) {
                  $moduleLabel.text(label);
               }
               else {
                  $('.module-title', $module).append('<span class="module-label">'+label+'</span>');
               }
               $module.addClass('has-custom-label');
            }
            else if ( $moduleLabel.length ) {
               $moduleLabel.remove();
               $module.removeClass('has-custom-label');
            }
         }

         // Update the module content
         if ( $module.children('.builder-piece[date-piece="content"]').length ) {
            $module.children('.builder-piece[date-piece="content"]').html(submitted.content);
         }

         // Update the usable shortcode
         $module.children('.builder-piece').each( function() {
            $(this).text( self.get_shortcode_string( submitted, $(this).data('piece') ) );
         });

         // Add a new history state
         if ( 'child' !== config.role ) {
            this.builder_history_add_step( builderLocalize.history_message_edit_module.replace('%s', this.builder_get_module_name( $module )) );
         }
      },

      // Called when the `Add Shortcode` button is pressed
      //
      // Opens a modal containing all available shortcodes that can be
      // inserted directly into the TMCE editor.
      launch_insert_tmce_shortcode: function() {
         var self = this;

         // Set up the modal
         var modal_args = {
            title: builderLocalize.select_shortcode_title,
            content: $('#builder-tmpl-available-tmce-shortcodes').html(),
            on_open: function( $modal ) {
               self.on_launch_insert_tmce_shortcode( $modal );
            },
         };

         // Launch the modal
         var modal = new themefyreBuilder.builderModal( modal_args );
      },

      // Attaches the events for selecting a shortcode.
      on_launch_insert_tmce_shortcode: function( $modal ) {
         var self = this;

         // Pressing the button to add a shortcode
         $modal.on('click', 'button[data-tag]', function() {
            var tag   = $(this).data('tag');
            var title = $(this).data('add-title');

            // Close the current modal
            $modal.trigger('modalcancel');

            // Set up the new modal
            var modal_args = {
               title: title,
               add_class: 'no-padding insert-tmce-shortcode',
               on_open: function( $modal ) {
                  self.on_open_edit_shortcode_modal( $modal );
                  self.trigger_attribute_change_events( $modal );
               },
               on_confirm: function( $modal ) {
                  self.on_submit_insert_tmce_shortcode( $modal );
               },
            };

            // Open a new modal for the shortcode edit screen
            self.open_edit_shortcode_modal( tag, modal_args );
         });
      },

      // When the modal for inserting a shortcode into the TinyMCE editor is submitted.
      on_submit_insert_tmce_shortcode: function( $modal ) {
         var self = this;
         var visual_editor_active = $('#wp-content-wrap').hasClass('tmce-active');

         // Get the the raw settings from the modal
         var args = self.get_edit_shortcode_modal_settings( $modal, visual_editor_active ? 'tmce' : 'html' );

         // Prepare the content for WP editor
         if ( args.content ) {
            args.content = visual_editor_active ? window.switchEditors.wpautop( args.content ) : "\n"+args.content+"\n";
         }

         // Get the shortcode in string form
         var shortcode = self.get_shortcode_string( args, 'complete' );

         // Insert the shortcode
         wpActiveEditor = 'content';
         send_to_editor( shortcode );
      },

      // Used to open the edit modal for a specific shortcode.
      open_edit_shortcode_modal: function( tag, args ) {
         var default_args = {
            title: tag,
            show_confirm: true,
            add_class: 'no-padding',
            content: $('#builder-tmpl-edit-shortcode-'+tag).html(),
         };

         args = _.extend(default_args, args);

         // Open a new modal for the shortcode edit screen
         var $modal = new themefyreBuilder.builderModal( args );
      },

      // Called when a modal for editing a shortcode is opened.
      //
      // Sets up the behavior of the tabs and the attribute controls.
      on_open_edit_shortcode_modal: function( $modal ) {
         var self = this;

         // Initially set up certain attribute control types
         //
         // Certain shortcode attribute controls require additional
         // setup upon opening the modal to edit it.
         $modal.find('.attribute-setting[data-type]').each( function() {
            var $control_wrap = $(this), type = $control_wrap.data('type');
            switch ( type ) {

               // Sets up the icon picker control
               case 'icon':
                  if ( $('.builder-select-icon', $control_wrap).length ) {
                     $('input', $control_wrap).on('change', function() {
                        var value = $(this).val(), $button = $('.builder-select-icon', $control_wrap);
                        if ( value ) {
                           $('.builder-icon-preview', $control_wrap).html('<i class="'+value+'"></i>');
                           $button.text( $button.data('remove-text') );
                        }
                        else {
                           $('.builder-icon-preview', $control_wrap).html('');
                           $button.text( $button.data('select-text') );
                        }
                     });

                     $('.builder-icon-preview', $control_wrap).on('click', function() {
                        self.pick_icon( $control_wrap );
                     });

                     $('.builder-select-icon', $control_wrap).on('click', function(event) {
                        event.preventDefault();
                        var $input = $('input', $control_wrap);
                        if ( ! $input.val() ) {
                           self.pick_icon( $control_wrap );
                        }
                        else {
                           $input.val('').trigger('change');
                        }
                     });
                  }
                  break;

               // Apply sorting to list attribute items.
               case 'comma_list':
               case 'bar_list':
                  $control_wrap.find('.list-items').sortable();
                  break;


               // Activate color pickers
               case 'hex_code':
                  $control_wrap.find('.builder-color-picker').wpColorPicker();
                  break;

            }
         });

         // Make sure all color pickers are hidden before closing the modal
         if ( $('.builder-color-picker', $modal).length ) {
            $modal.on('modalbeforeremove', function() {
               $('.builder-color-picker', $modal).iris('hide');
            });
         }

         // Set up the WordPress TinyMCE editor
         if ( $modal.find('.shortcode-content-editor[data-type="editor"]').length ) {

            // Hide the editor after changing tabs/closing the modal
            $modal.on('changetab modalbeforeremove', function() {
               $('#builder-shortcode-content-tmce-editor').removeAttr('style');
            });

            // Clear the editor after closing the modal
            $modal.on('modalbeforeremove', function() {
               themefyreBuilder.setWPEditorContent('shortcode_wp_editor_content', '');
            });

            // When switching to the content tab we reposition the editor accordingly
            $modal.on('changetabcontent', function() {

               var $panes = $('.builder-modal-panes', $modal);

               $('#builder-shortcode-content-tmce-editor').css({
                  width: $panes.outerWidth()-50, // Subtract 50 to simulate padding
                  left: $panes.offset().left+25, // Add 25 to simulate padding
                  top: $panes.offset().top,
               });

               // Set the height of the editor
               $('#shortcode_wp_editor_content_ifr, #shortcode_wp_editor_content').css('height', '275px');
            });
         }

         // Set up the HTML editor when applicable
         if ( $modal.find('.shortcode-content-editor[data-type="textarea"]').length ) {
            var textarea = document.getElementById('shortcode_codeMirror_content');
            var editor = CodeMirror.fromTextArea( textarea, {
               lineNumbers: true,
               indentUnit: 3,
               mode: 'htmlmixed',
            });

            // Store the editor instance for later
            $(textarea).data('CodeMirrorInstance', editor);
         }

      },

      // Fills the provided picker with a list of available icons
      pick_icon: function( $control_wrap ) {
         var args = {
            title: builderLocalize.select_icon_title,
            content: $('#builder-tmpl-icon-selector').html(),
            add_class: 'builder-icon-picker no-padding',
            on_open: function( $modal ) {
               $('.builder-search-icons', $modal).focus();
               $modal.on('click', '[data-icon]', function(event) {
                  event.preventDefault();
                  var icon = $(this).data('icon');
                  $('input', $control_wrap).val(icon).trigger('change');
                  $modal.trigger('modalcancel');
               });
            }
         };

         // Open a new modal for the shortcode edit screen
         var modal = new themefyreBuilder.builderModal( args );
      },

      // Gets all of the settings from an edit shortcode modal.
      get_edit_shortcode_modal_settings: function( $modal, context ) {
         var self = this, args = { tag:'', attributes:{}, content:'' };

         // Will contain the content editor, if there is one
         var $content_editor_wrap = $modal.find('.shortcode-content-editor');

         // Grab the tag for the shortcode being edited
         args.tag = $modal.find('.edit-shortcode-form').data('tag');

         // Set up the attributes
         $modal.find('.attribute-setting[data-type]').each( function() {
            if ( $(this).hasClass('is-disabled') ) {
               return;
            }
            var $control_wrap = $(this);
            var type = $control_wrap.data('type');
            var attribute = $control_wrap.data('attribute');
            var value = '';

            // Grab the value
            switch ( type ) {

               case 'bool':
                  var $field = $control_wrap.find('[name]');
                  value = $field.prop('checked') ? 'true' : 'false';
                  break;

               case 'comma_list':
               case 'bar_list':
                  var delimiter = 'comma_list' === type ? ',' : '|';
                  $control_wrap.find('ul li strong').each( function() {
                     value += themefyreBuilder.encodeShortcodeAttr( themefyreBuilder.stripTags( $(this).text() ) )+delimiter;
                  });

                  // Remove the delimiter
                  if ( value ) {
                     value = value.slice(0, -1);
                  }
                  break;

               case 'font':
                  var $field = $control_wrap.find('[name]');
                  value = $field.val();
                  if ( 'default' !== value ) {
                     value += ','+$control_wrap.find('[data-font="'+value+'"]').val();
                  }
                  break;

               case 'html_string':
                  var $field = $control_wrap.find('[name]');
                  value = themefyreBuilder.stripTags( $field.val(), '<span><a><br><br/><abbr><acronym><b><strong><i><em><del><ins><sub><sup><mark>' );
                  value = themefyreBuilder.encodeShortcodeAttr( value );
                  break;

               default:
                  var $field = $control_wrap.find('[name]');
                  value = themefyreBuilder.stripTags( $field.val() );
                  value = themefyreBuilder.encodeShortcodeAttr( value );
                  break;

            }

            // Add value to the args object
            if ( value ) {
               args.attributes[attribute] = value;
            }
         });

         // Grab any content
         if ( $content_editor_wrap.length ) {
            switch ( $content_editor_wrap.data('type') ) {

               // TinyMCE editor
               case 'editor':
                  args.content = themefyreBuilder.getWPEditorContent('shortcode_wp_editor_content');
                  break;

               // Standard textarea
               case 'textarea':
                  var editor = $('#shortcode_codeMirror_content').data('CodeMirrorInstance');
                  args.content = editor.getValue();
                  break;

               // Child element
               case 'child_element':
                  if ( 'builder' === context ) {
                     args.content = self.builder_gather_pieces( $content_editor_wrap );
                  }
                  else {
                     var line_break = 'tmce' === context ? '\n\n' : '\n', num_opens = 0;
                     $content_editor_wrap.find('.builder-piece').each( function() {
                        var piece_type = $(this).data('piece');
                        if ( 'open' === piece_type ) {
                           num_opens++;
                           if ( 1 < num_opens ) {
                              args.content += line_break;
                           }
                        }
                        if ( 'content' === piece_type ) {
                           args.content += line_break;
                        }
                        args.content += $(this).val();
                        if ( 'content' === piece_type ) {
                           args.content += line_break;
                        }
                     });
                  }
                  break;

            }
         }

         return args;
      },

      // Used to select an attachment from the media library
      select_attachment: function( key ) {
         var args = {
            key: key,
            on_confirm: function( attachment ) {
               var img_id = typeof attachment.id !== 'undefined' ? attachment.id : null, img_src = '';
               if ( img_id ) {
                  if ( typeof attachment.sizes !== 'undefined'
                       && typeof attachment.sizes.medium !== 'undefined'
                       && typeof attachment.sizes.medium.url !== 'undefined' ) {
                     img_src = attachment.sizes.medium.url;
                  }
                  else if ( typeof attachment.url !== 'undefined' ) {
                     img_src = attachment.url;
                  }
               }
               if ( img_src ) {
                  $('input[data-key="'+key+'"]').val(img_id).trigger('change');
                  $('p[data-key="'+key+'"]').html('<img src="'+img_src+'" alt="" />');
                  $('a[data-key="'+key+'"]').html($('a[data-key="'+key+'"]').data('remove-text'));
               }
               else {
                  alert( builderLocalize.get_attachment_error );
               }
            },
         };

         themefyreBuilder.selectAttachment(args);
      },

      // Used to manage an image gallery control
      manage_gallery: function( key ) {
         var args = {
            value: $('input[data-key="'+key+'"]').val(),
            on_confirm: function( attachments ) {
               var $preview = $('ul[data-key="'+key+'"]').html(''), id_list = [], img_src;

               _.each( attachments, function( attachment ) {
                  img_src = '';
                  if ( typeof attachment.attributes !== 'undefined'
                       && typeof attachment.attributes.sizes !== 'undefined'
                       && typeof attachment.attributes.sizes.medium !== 'undefined'
                       && typeof attachment.attributes.sizes.medium.url !== 'undefined' ) {
                     img_src = attachment.attributes.sizes.medium.url;
                  }
                  else if ( typeof attachment.attributes !== 'undefined'
                       && typeof attachment.attributes.url !== 'undefined' ) {
                     img_src = attachment.attributes.url
                  }
                  if ( img_src ) {
                     id_list.push( attachment.id );
                     $preview.append('<li style="background-image:url('+img_src+');" alt="" />');
                  }
               });

               // Update the input value
               $('input[data-key="'+key+'"]').val( id_list.join(',') ).trigger('change');

               // Update the button text accordingly
               $('a[data-key="'+key+'"]').html($('a[data-key="'+key+'"]').data('remove-text'));
            },
         };

         themefyreBuilder.manageGallery(args);
      },

      // Turns a formatted object into a shortcode in string form
      //
      // Expected input:
      //
      // args = {
      //    tag: SHORTCODE_TAG
      //    attributes: {
      //       ATTR: VALUE,
      //       ATTR: VALUE,
      //    },
      //    content: SHORTCODE_CONTENT,
      // }
      get_shortcode_string: function( args, piece ) {
         args = _.extend({ tag:'', attributes:{}, content:'' }, args);

         // Return only the content
         if ( 'content' === piece ) {
            return args.content;
         }

         // Return only the closing tag
         if ( 'close' === piece ) {
            return '[/'+args.tag+']';
         }

         var out = '['+args.tag;

         // Add the attributes, if any
         _.each( args.attributes, function(value, key) {
            out += ' '+key+'="'+value+'"';
         });

         out += ']';

         // Return only the opening tag
         if ( 'open' === piece ) {
            return out;
         }

         if ( args.content ) {
            out += args.content+'[/'+args.tag+']';
         }

         return out;
      },

      // Exports the current page as a string of executable shortcodes
      builder_export: function() {
         var args = {
            title: builderLocalize.export_modal_title,
            content: '<textarea style="width:100%;height:400px;">'+this.builder_capture_page()+'</textarea>',
         };

         var exportModal = new themefyreBuilder.builderModal( args );
      },

      // Returns the HTML for the inline modal loader.
      get_modal_inner_loader_HTML: function() {
         return '<div class="builder-modal-inline-loader"><div></div><div></div><div></div></div>';
      },

      // Triggers any functions attached to the `change` event of each attribute control.
      trigger_attribute_change_events: function( $modal ) {
         $modal.find('.attribute-setting input, .attribute-setting select').trigger('change');
      },

   });

}(jQuery, _));