// Ensure availability of the global themefyreBuilder object
window.themefyreBuilder = window.themefyreBuilder || {};

// Saving this for a time when I may need it
//
// window.switchEditors.wpautop(content)

(function($, _) {
   "use strict";

   // ======================================================
   //
   // Conditional to check if the visual editor has been enabled
   //
   // ======================================================

   // Conditional to check if the visual editor has been enabled
   themefyreBuilder.WPEditorVisualEnabled = function( editor_id ) {
      return document.getElementById(editor_id+'-tmce');
   };

   // ======================================================
   //
   // Conditional to check if the visual editor is active
   //
   // ======================================================

   // Conditional to check if the visual editor is active
   themefyreBuilder.WPEditorVisualActive = function( editor_id ) {
      return themefyreBuilder.WPEditorVisualEnabled( editor_id ) && $('#wp-'+editor_id+'-wrap').hasClass('tmce-active');
   };

   // ======================================================
   //
   // Get the content of a TinyMCE editor by ID
   //
   // ======================================================

   // Get the content of a TinyMCE editor by ID
   themefyreBuilder.getWPEditorContent = function( editor_id ) {

      // First, make sure the editor exists
      if ( ! editor_id || ! document.getElementById(editor_id) ) {
         return '';
      }

      // Check to see if the visual editor is currently active
      var visualEditorActive = themefyreBuilder.WPEditorVisualActive( editor_id );

      // Switch to text editor to get content correctly, if visual is active
      if ( visualEditorActive ) {
         $('#'+editor_id+'-html')[0].click();
      }

      // Grab the content while in text mode
      var content = $('#'+editor_id).val();

      // Switch back to visual editor if it was active before
      //
      // This is for consistency, WordPress remembers which editor was last
      // active and will use that setting to load each editor thereafter.
      if ( visualEditorActive ) {
         $('#'+editor_id+'-tmce')[0].click();
      }

      return content;
   };

   // ======================================================
   //
   // Set the content of a TinyMCE editor by ID
   //
   // ======================================================

   // Set the content of a TinyMCE editor by ID
   themefyreBuilder.setWPEditorContent = function( editor_id, content ) {

      // First, make sure the editor exists
      if ( ! editor_id || ! document.getElementById(editor_id) ) {
         return '';
      }

      // Check to see if the visual editor is currently active
      var visualEditorActive = themefyreBuilder.WPEditorVisualActive( editor_id );

      // Switch to text editor to get content correctly, if visual is active
      if ( visualEditorActive ) {
         $('#'+editor_id+'-html')[0].click();
      }

      // Set the content while in text mode
      $('#'+editor_id).val( content );

      // Switch back to visual editor if it was active before
      //
      // This is for consistency, WordPress remembers which editor was last
      // active and will use that setting to load each editor thereafter.
      if ( visualEditorActive ) {
         $('#'+editor_id+'-tmce')[0].click();
      }
   };

}(jQuery, _));