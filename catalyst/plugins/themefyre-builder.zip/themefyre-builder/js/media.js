// Ensure availability of the global themefyreBuilder object
window.themefyreBuilder = window.themefyreBuilder || {};

(function($, _) {
   "use strict";

   // Will contain each instance of media frame
   themefyreBuilder.media_modal_frames = [];

   // ======================================================
   //
   // Select an image from the media library
   //
   // ======================================================

   // Select an image from the media library
   themefyreBuilder.selectAttachment = function( args ) {
      var defaults = {
         key: "",                                              // Key will be used to identify this frame
         add_class: "",                                        // Custom class to be added to the media frame
         title: builderMediaLocalize.attachment_frame_title,        // Media frame title
         button_text: builderMediaLocalize.attachment_frame_button, // Media frame button text
         on_confirm: function( attachment ) {},                // Function to be executed after the frame has been confirmed
      };
      args = _.extend(defaults, args);

      // make sure a key has been specified
      if ( ! args.key ) {
         return;
      }

      // Check if the frame has already been created
      //
      // If it has, simply reopen it and return. THis way the frame HTML can be reused.
      if ( 'undefined' !== typeof themefyreBuilder.media_modal_frames[args.key] ) {
         themefyreBuilder.media_modal_frames[args.key].open();
         return;
      }

      // Create the media frame initially.
      themefyreBuilder.media_modal_frames[args.key] = wp.media({
         title: args.title,
         button: { text: args.button_text, },
         library: { type: 'image' },
         multiple: false,
         className: 'media-frame builder-image-select-frame '+args.add_class,
      });

      // When an image is selected, run a callback.
      themefyreBuilder.media_modal_frames[args.key].on( 'select', function() {

         // Grab the selected attachment object from the frome and convert it to JSON
         var attachment = themefyreBuilder.media_modal_frames[args.key].state().get('selection').first().toJSON();

         // Callback to handle the image selection
         args.on_confirm( attachment );
      });

      // Finally, open the modal.
      themefyreBuilder.media_modal_frames[args.key].open();
   };

   // ======================================================
   //
   // Manage a WordPress image gallery
   //
   // ======================================================

   // Manage a WordPress image gallery
   themefyreBuilder.manageGallery = function( args ) {
      var defaults = {
         value: "",                              // Possible comma delimited list of attachment ID`s
         add_class: "",                          // Custom class to be added to the media frame
         on_confirm: function( attachments ) {}, // Function to be executed after the frame has been confirmed
      };
      args = _.extend(defaults, args);

      // Will contain the selected list of attachments
      var selection = false;

      // Check to see if a value has been provided
      //
      // If one has then we need to create a WP Media Selection
      // object and pass it to the frame when we open it.
      if ( args.value ) {
         var query_args = {
            orderby: "post__in",
            order: "ASC",
            type: "image",
            perPage: -1,
            post__in: args.value.split(','),
         };

         // Create attachments object
         var attachments = wp.media.query( query_args );

         // Update the current selection
         selection = new wp.media.model.Selection( attachments.models, {
            props: attachments.props.toJSON(),
            multiple: true
         });
      }

      // The state of the media window
      var state = selection ? 'gallery-edit' : 'gallery-library';

      // Create the media frame.
      var gallery_frame = wp.media({
         frame: 'post',
         state: state,
         library: { type: 'image' },
         selection: selection,
         className: 'media-frame builder-gallery-editor-frame '+args.add_class,
      });

      // When the gallery is done being edited, run a callback
      gallery_frame.on( 'select update insert', function(gallery_frame) {

         // Callback to handle the gallery selection
         args.on_confirm( gallery_frame.models );
      });

      // Finally open the frame
      gallery_frame.open();
   };

   // ======================================================
   //
   // Select a file from the media library
   //
   // ======================================================

   // Select a file from the media library
   themefyreBuilder.selectFile = function( args ) {
      var defaults = {
         key: "",                        // Key will be used to identify this frame
         type: "",                       // File type to pick from
         add_class: "",                  // Custom class to be added to the media frame
         on_confirm: function( url ) {}, // Function to be executed after the frame has been confirmed
      };
      args = _.extend(defaults, args);

      // make sure a key has been specified
      if ( ! args.key ) {
         return;
      }

      // Check if the frame has already been created
      //
      // If it has, simply reopen it and return. THis way the frame HTML can be reused.
      if ( 'undefined' !== typeof themefyreBuilder.media_modal_frames[args.key] ) {
         themefyreBuilder.media_modal_frames[args.key].open();
         return;
      }

      // Create the media frame.
      themefyreBuilder.media_modal_frames[args.key] = wp.media({
         title: builderMediaLocalize.file_frame_title,
         button: { text: builderMediaLocalize.file_frame_button_text },
         library: { type: args.type },
         multiple: false,
      });

      // When an image is selected, run a callback.
      themefyreBuilder.media_modal_frames[args.key].on( 'select', function() {

         // Grab the selected attachment URL
         var attachment = themefyreBuilder.media_modal_frames[args.key].state().get('selection').first().toJSON();

         // Callback to handle the image selection
         args.on_confirm( attachment.url );
      });
   };

}(jQuery, _));