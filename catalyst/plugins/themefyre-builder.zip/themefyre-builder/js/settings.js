(function($, _) {
   "use strict";

   $(document).ready( function() {

      // Initiate the CSS editor
      var textarea = document.getElementById('builder-global-css');
      var editor = CodeMirror.fromTextArea( textarea, {
         lineNumbers: true,
         indentUnit: 3,
         mode: 'css',
         // viewportMargin: Infinity, // Uncomment for infinite height editor
      });

      // Mark the fonts in the font selector that are already in use as `disbled`
      $('.saved-font .font-name').each( function() {
         $('option[value="'+$(this).text()+'"]').prop('disabled', true);
      });

      // Reveal the font selector select box
      if ( document.getElementById('font-list') ) {
         $('#font-list').chosen().val('').trigger('chosen:updated');

         // When a new font is selected
         $('#font-list').on( 'change', function() {
            var $fontList = $(this),
                fontName = $fontList.val(),
                $selectedFontOption = $('option[value="'+fontName+'"]'),
                variants = $selectedFontOption.attr('data-variants').split(','),
                subsets = $selectedFontOption.attr('data-subsets').split(',');

            // Return select to default value
            $fontList.val('').trigger('chosen:updated');

            // Font can only be configured 1 way
            if ( 1 === variants.length && 1 === subsets.length ) {
               addFont( fontName, variants, subsets );
               return;
            }

            // Open the modal for configuring the selected font
            var modal = new themefyreBuilder.builderModal({
               title: builderSettingsLocalize.add_font_title.replace('%s', fontName),
               show_confirm: true,
               content: $('#tmpl-builder-configure-font').html(),
               on_open: function( $modal ) {
                  var $subsetsList = $('#font-subsets'), $subsetOption,
                      subsetsCount = subsets.length, variantsCount = variants.length;

                  // Enable the available variants
                  _.each( variants, function( variant ) {
                     $('label[for="variant-'+variant+'"]').addClass('is-enabled');

                     // 400 should be enabled by default when possible
                     if ( '400' === variant ) {
                        $('#variant-'+variant).prop('checked', true);
                     }

                     // Automatically select first subset
                     // if none others have been selected
                     if ( ! --variantsCount && ! $('#font-variants input:checked').length ) {
                        $('#variant-'+variants[0]).prop('checked', true);
                     }
                  });

                  // If there is only 1 variant available, force it to be selected
                  if ( 1 === variants.length ) {
                     $('#variant-'+variants[0]).prop('disabled', true);
                  }

                  // Populate the subsets list
                  _.each( subsets, function( subset ) {
                     $subsetOption = $('<input type="checkbox" id="subset-'+subset+'" value="'+subset+'" /><label for="subset-'+subset+'">'+subset+'</label>');

                     if ( 'latin' === subset ) {
                        $('h2', $subsetsList).after( $subsetOption );
                     }
                     else {
                        $subsetsList.append( $subsetOption );
                     }

                     // Automatically select first subset
                     if ( ! --subsetsCount ) {
                        $('input', $subsetsList).first().prop('checked', true);

                        // Only one subset is available for selection
                        if ( 1 === subsets.length ) {
                           $('input', $subsetsList).first().prop('disabled', true);
                        }
                     }
                  });
               },
               on_confirm: function( $modal ) {
                  var enabledVariants = [], enabledSubsets = [];
                  $('#font-variants input:checked').each( function() {
                     enabledVariants.push($(this).val());
                  });
                  $('#font-subsets input:checked').each( function() {
                     enabledSubsets.push($(this).val());
                  });

                  // No variants were selected
                  if ( ! enabledVariants.length ) {
                     alert('You must select at least one font style.');
                     return false;
                  }

                  // No subsets were selected
                  if ( ! enabledSubsets.length ) {
                     alert('You must select at least one font character set.');
                     return false;
                  }

                  // Call the function to add the new font
                  addFont( fontName, enabledVariants, enabledSubsets );
               },
            });
         });

      }

      // Can be used to add new fonts to the list of enabled fonts
      var addFont = function( name, variants, subsets ) {
         var isItalic, variantDescription, variantClass;

         // Make sure the list is not marked as empty
         $('#saved-fonts').removeClass('is-empty');

         // Disabel the font that has just been added
         $('option[value="'+name+'"]').prop('disabled', true);
         $('#font-list').trigger('chosen:updated');

         // Load the newly selected font
         $('body').append('<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family='+name.split(' ').join('+')+':'+variants.join(',')+'">');

         // Grab the template
         var $template = $($('#tmpl-builder-fonts-option').html()),
             $name = $('.font-name', $template),
             $variants = $('.font-variants', $template),
             $subsets = $('.font-subsets', $template);

         // Insert the name
         $name.text(name);

         // Apply the font family to the name & variants list
         $name.css('font-family', "'"+name+"'");
         $variants.css('font-family', "'"+name+"'");

         // Add the hidden inputs for storing the values
         $('.font-actions-column', $template).append('<input type="hidden" name="builder_google_fonts['+name+'][variants]" value="'+variants.join(',')+'" />');
         $('.font-actions-column', $template).append('<input type="hidden" name="builder_google_fonts['+name+'][subsets]" value="'+subsets.join(',')+'" />');

         // Insert the variants
         _.each( variants, function( variant ) {
            isItalic = -1 !== variant.indexOf('italic');
            variantClass = 'variant-'+variant;
            variant = variant.replace('italic', '');

            switch ( variant ) {
               case '100': variantDescription = 'Thin 100'; break;
               case '200': variantDescription = 'Extra Light 200'; break;
               case '300': variantDescription = 'Light 300'; break;
               case '400': variantDescription = 'Normal 400'; break;
               case '500': variantDescription = 'Medium 500'; break;
               case '600': variantDescription = 'Semi Bold 600'; break;
               case '700': variantDescription = 'Bold 700'; break;
               case '800': variantDescription = 'Extra Bold 800'; break;
               case '900': variantDescription = 'Ultra Bold 900'; break;
            }

            if ( isItalic ) {
               variantDescription += ' italic';
            }

            $variants.append('<span class="'+variantClass+'">'+variantDescription+'</span>');
         });

         // Insert the subsets
         $subsets.text( subsets.join(', ') );

         // APpend/reveal the new font
         $('#saved-fonts tbody').append( $template );
      };

      // When the button to remove a font is pressed
      $('#saved-fonts').on('click', '.remove-font', function(event) {
         event.preventDefault();

         var $this = $(this).closest('.saved-font'), name = $('.font-name', $this).text();

         // Remove the item
         $this.remove();

         // Make sure the list is not marked as empty
         if ( ! $('#saved-fonts .saved-font').length ) {
            $('#saved-fonts').addClass('is-empty');
         }

         // Enable the font that has just been removed
         $('option[value="'+name+'"]').prop('disabled', false);
         $('#font-list').trigger('chosen:updated');
      });

      // Pressing the button to remove all fonts
      $('#remove-all-fonts').click( function(event) {
         event.preventDefault();
         var r = confirm( builderSettingsLocalize.confirm_remove_font_all );
         if ( ! r ) {
            return;
         }
         $('#saved-fonts tbody').html('');
         $('#saved-fonts').addClass('is-empty');
         $('#font-list option').prop('disabled', false)
         $('#font-list').trigger('chosen:updated');
      });

   });

}(jQuery, _));