<?php

/**
 * Plugin Name: Themefyre Page Builder
 * Description: Visual drag & drop page builder built to work with select premium Themefyre WordPress themes.
 * Version: 0.0.2
 * Author: Themefyre
 * Author URI: http://themefyre.com/
 *
 * Support for the page builder can be added using add_theme_support
 * with an associative array of arguements. See below.
 *
 * $args = array(
 *
 *    // Max width of content for the page builder
 *    // needs to be an integer in pixels
 *    'content_max_width' => 1000,
 *
 *    // Offset to be applied to various theme functionality,
 *    // mostly used for themes with `sticky` headers
 *    'scroll_top_offset' => 0,
 *
 *    // Default size for the content spacer module
 *    'content_spacer_size' => 22,
 *
 *    // Associative array of Google fonts that are loaded
 *    // by the theme. This allows the user to use this font
 *    // when using the page builder. The keys need to be
 *    // exact font names and the values should be comma
 *    // delimited lists of CSS-friendly(ish) font variants.
 *    'theme_google_fonts' => array(
 *       'Font Name' => 'Font Variants',
 *    ),
 *
 *    // Associative array of button style options include with
 *    // the theme. The key should be the CSS class that will be
 *    // applied when the option is selected, and the values should
 *    // be the displayed name of the style option.
 *    'theme_button_styles' => array(
 *       'custom-style' => 'Custom Style',
 *    ),
 *
 *    // Associative array of header style options include with
 *    // the theme. The key should be the CSS class that will be
 *    // applied when the option is selected, and the values should
 *    // be the displayed name of the style option.
 *    'theme_header_styles' => array(
 *       'custom-style' => 'Custom Style',
 *    ),
 *
 * );
 *
 * add_theme_support( 'themefyre-page-builder', $args );
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */

// No direct access
defined( 'ABSPATH' ) or exit;

// Enable developer mode
if ( ! defined('BUILDER_DEVELOPER_MODE') ) {
   define( 'BUILDER_DEVELOPER_MODE', false );
}

/**
 * Themefyre Page Builder Class
 *
 * Allows users to visually build their pages and generate shortcodes.
 *
 * @package WordPress
 * @subpackage Themefyre Page Builder
 * @author Themefyre
 * @since Themefyre Page Builder 0.0.0
 */
final class Themefyre_Builder {

   /**
    * Builder uses many variables, several of which can be filtered to
    * customize the way it operates. Most of these variables are stored in a
    * private array that gets updated with the help of PHP magic methods.
    *
    * This is a precautionary measure, to avoid potential errors produced by
    * unanticipated direct manipulation of Builder's run-time data.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access private
    * @var array
    */
   private $data = array();

   /**
    * Will contain each shortcode`s configuration & methods.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    * @var array
    */
   public $shortcodes = array();

   /**
    * Will contain all registered page teimplates for the page builder.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    * @var array
    */
   public $templates = array();

   /**
    * Main Themefyre_Builder Instance
    *
    * Insures that only one instance of Themefyre_Builder exists in memory at
    * any one time. Also prevents needing to define globals all over the place.
    *
    * @since Themefyre Page Builder 0.0.0
    * @return The one true Themefyre_Builder
    */
   public static function instance() {

      // Store the instance locally to avoid private static replication
      static $instance = null;

      // Only run these methods if they haven't been ran previously
      if ( null === $instance ) {
         $instance = new Themefyre_Builder;
         $instance->globals();
         $instance->includes();
         $instance->add_actions();
      }

      // Always return the instance
      return $instance;
   }

   /**
    * A dummy constructor to prevent Themefyre_Builder from being loaded more than once.
    *
    * @see Themefyre_Builder::instance()
    * @see builder();
    *
    * @since Themefyre Page Builder 0.0.0
    */
   private function __construct() { /* Do nothing here */ }

   /**
    * A dummy magic method to prevent Themefyre_Builder from being cloned
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __clone() {
      _doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'themefyre_builder' ), '0.0.0' );
   }

   /**
    * A dummy magic method to prevent Themefyre_Builder from being unserialized
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __wakeup() {
      _doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'themefyre_builder' ), '0.0.0' );
   }

   /**
    * Magic method for checking the existence of a certain custom field
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __isset( $key ) {
      return isset( $this->data[$key] );
   }

   /**
    * Magic method for getting Themefyre_Builder variables
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __get( $key ) {
      return isset( $this->data[$key] ) ? $this->data[$key] : null;
   }

   /**
    * Magic method for setting Themefyre_Builder variables
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __set( $key, $value ) {
      $this->data[$key] = $value;
   }

   /**
    * Magic method for unsetting Themefyre_Builder variables
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function __unset( $key ) {
      if ( isset( $this->data[$key] ) ) {
         unset( $this->data[$key] );
      }
   }

   /**
    * Include all required files.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access private
    */
   private function includes() {

      // Shortcode class
      require_once $this->includes_dir . 'class-builder-shortcode.php';

      // General Functions & Hooks
      require_once $this->includes_dir . 'functions.php';
      require_once $this->includes_dir . 'hooks.php';

      // Shortcodes
      require_once $this->includes_dir . 'shortcodes/audio.php';
      require_once $this->includes_dir . 'shortcodes/builder-content.php';
      require_once $this->includes_dir . 'shortcodes/button-group.php';
      require_once $this->includes_dir . 'shortcodes/call-to-action.php';
      require_once $this->includes_dir . 'shortcodes/contact-form.php';
      require_once $this->includes_dir . 'shortcodes/divider.php';
      require_once $this->includes_dir . 'shortcodes/featured-number.php';
      require_once $this->includes_dir . 'shortcodes/full-width-slider.php';
      require_once $this->includes_dir . 'shortcodes/gallery.php';
      require_once $this->includes_dir . 'shortcodes/header.php';
      require_once $this->includes_dir . 'shortcodes/html-block.php';
      require_once $this->includes_dir . 'shortcodes/icon-box.php';
      require_once $this->includes_dir . 'shortcodes/icon.php';
      require_once $this->includes_dir . 'shortcodes/image-group.php';
      require_once $this->includes_dir . 'shortcodes/image.php';
      require_once $this->includes_dir . 'shortcodes/instructions.php';
      require_once $this->includes_dir . 'shortcodes/map.php';
      require_once $this->includes_dir . 'shortcodes/notification.php';
      require_once $this->includes_dir . 'shortcodes/price-table.php';
      require_once $this->includes_dir . 'shortcodes/promo-box.php';
      require_once $this->includes_dir . 'shortcodes/recent-posts.php';
      require_once $this->includes_dir . 'shortcodes/row.php';
      require_once $this->includes_dir . 'shortcodes/section.php';
      require_once $this->includes_dir . 'shortcodes/spacer.php';
      require_once $this->includes_dir . 'shortcodes/statistics.php';
      require_once $this->includes_dir . 'shortcodes/tab-group.php';
      require_once $this->includes_dir . 'shortcodes/team-member.php';
      require_once $this->includes_dir . 'shortcodes/testimonial-group.php';
      require_once $this->includes_dir . 'shortcodes/text-block.php';
      require_once $this->includes_dir . 'shortcodes/timeline.php';
      require_once $this->includes_dir . 'shortcodes/toggle-group.php';
      require_once $this->includes_dir . 'shortcodes/video.php';

      // Page Builder Admin classes
      if ( is_admin() ) {
         require_once $this->includes_dir . 'class-builder-interface.php';
         require_once $this->includes_dir . 'class-builder-settings.php';
      }

      // LayerSlider integration
      if ( builder_is_plugin_active( 'LayerSlider/layerslider.php' ) ) {
         require_once $this->includes_dir . 'extensions/layerslider.php';
      }

      // Slider Revolution integration
      if ( builder_is_plugin_active( 'revslider/revslider.php' ) ) {
         require_once $this->includes_dir . 'extensions/revslider.php';
      }

      // Themefyre Portfolio integration
      if ( builder_is_plugin_active( 'themefyre-portfolio/themefyre-portfolio.php' ) ) {
         require_once $this->includes_dir . 'extensions/themefyre-portfolio.php';
      }

      // WooCommerce integration
      if ( builder_is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
         require_once $this->includes_dir . 'extensions/woocommerce.php';
      }
   }

   /**
    * Set some smart defaults to class variables. Allow some of them to be
    * filtered to allow for early overriding.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access private
    */
   private function globals() {

      // Version Number
      $this->version = '0.0.2';

      // Setup some base path and URL information
      $this->file       = __FILE__;
      $this->basename   = apply_filters( 'builder_plugin_basename', plugin_basename( $this->file ) );
      $this->plugin_dir = apply_filters( 'builder_plugin_dir_path', plugin_dir_path( $this->file ) );
      $this->plugin_url = apply_filters( 'builder_plugin_dir_url',  plugin_dir_url ( $this->file ) );

      // Includes
      $this->includes_dir = apply_filters( 'builder_includes_dir', trailingslashit( $this->plugin_dir . 'includes'  ) );
      $this->includes_url = apply_filters( 'builder_includes_url', trailingslashit( $this->plugin_url . 'includes'  ) );

      // Languages
      $this->lang_dir = apply_filters( 'builder_lang_dir', trailingslashit( $this->plugin_dir . 'lang' ) );

      // included icon fonts (thanks to Fontello)
      $this->included_icon_fonts = array( 'entypo', 'font-awesome', 'typicons', 'maki', 'linecons', 'meteocons' );

      // Valid Google Font Variants
      $this->google_font_variants = array(
         '100'       => 'Thin 100',
         '100italic' => 'Thin 100 italic',
         '200'       => 'Extra Light 200',
         '200italic' => 'Extra Light 200 italic',
         '300'       => 'Light 300',
         '300italic' => 'Light 300 italic',
         '400'       => 'Normal 400',
         '400italic' => 'Normal 400 italic',
         '500'       => 'Medium 500',
         '500italic' => 'Medium 500 italic',
         '600'       => 'Semi Bold 600',
         '600italic' => 'Semi Bold 600 italic',
         '700'       => 'Bold 700',
         '700italic' => 'Bold 700 italic',
         '800'       => 'Extra Bold 800',
         '800italic' => 'Extra Bold 800 italic',
         '900'       => 'Ultra Bold 900',
         '900italic' => 'Ultra Bold 900 italic',
      );;

      // Element Alignment Options
      $this->halign_options = array(
         'none'   => __( '(no horizontal alignment)', 'themefyre_builder' ),
         'left'   => __( 'Left aligned', 'themefyre_builder' ),
         'right'  => __( 'Right aligned', 'themefyre_builder' ),
         'center' => __( 'Centered', 'themefyre_builder' ),
      );

      // Element Alignment Options
      $this->valign_options = array(
         'none'   => __( '(no vertical alignment)', 'themefyre_builder' ),
         'top'    => __( 'Top', 'themefyre_builder' ),
         'middle' => __( 'Middle', 'themefyre_builder' ),
         'bottom' => __( 'Bottom', 'themefyre_builder' ),
      );

      // Element Alignment Options
      $this->device_visibility_options = array(
         'none'           => __( '(visible on all devices)', 'themefyre_builder' ),
         'mobile'         => __( 'Mobile Only', 'themefyre_builder' ),
         'tablet'         => __( 'Tablet Only', 'themefyre_builder' ),
         'desktop'        => __( 'Desktop Only', 'themefyre_builder' ),
         'mobile-tablet'  => __( 'Mobile & Tablet Only', 'themefyre_builder' ),
         'tablet-desktop' => __( 'Tablet & Desktop Only', 'themefyre_builder' ),
      );

      // CSS3 Animated Entrances
      $this->animated_entrance_options = array(
         'none' => __( '(no animated entrance)', 'themefyre_builder' ),
         __( 'Fading Entrances', 'themefyre_builder' ) => array(
            'builder-fade-in'       => __( 'Fade In', 'themefyre_builder' ),
            'builder-fade-in-down'  => __( 'Fade In Down', 'themefyre_builder' ),
            'builder-fade-in-up'    => __( 'Fade In Up', 'themefyre_builder' ),
            'builder-fade-in-left'  => __( 'Fade In Left', 'themefyre_builder' ),
            'builder-fade-in-right' => __( 'Fade In Right', 'themefyre_builder' ),
         ),
         __( 'Zooming Entrances', 'themefyre_builder' ) => array(
            'builder-zoom-in'  => __( 'Zoom In', 'themefyre_builder' ),
            'builder-zoom-out' => __( 'Zoom Out', 'themefyre_builder' ),
         ),
         __( 'Flipping Entrances', 'themefyre_builder' ) => array(
            'builder-flip-in-x' => __( 'Flip In X', 'themefyre_builder' ),
            'builder-flip-in-y' => __( 'Flip In Y', 'themefyre_builder' ),
         ),
      );
   }

   /**
    * Registers initial setup actions with WordPress
    *
    * @since Themefyre Page Builder 0.0.0
    * @access private
    */
   private function add_actions() {
      add_action( 'init', array( $this, 'init' ), 5 );
      add_action( 'plugins_loaded', array( $this, 'plugins_loaded' ), 5 );
      add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ), 5 );
      add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ), 5 );
   }

   /**
    * Various functionality that needs to be fired upon the init action
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function init() {
      add_image_size( 'builder-posts-carousel', 0, 350 );
   }

   /**
    * Loads the plugins text domain
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function plugins_loaded() {
      load_plugin_textdomain( 'themefyre_builder', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );
   }

   /**
    * Registers included CSS/JS assets with WordPress for front-end use
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function enqueue_scripts() {
      $builder = builder();

      // Google Maps API, only enqueued when a MAP shortcode module is used
      $http = is_ssl() ? 'https' : 'http';
      wp_register_script('builder-gmaps-api', $http.'://maps.google.com/maps/api/js?sensor=true', null, $builder->version, true );

      // Front end stylehseet
      wp_register_style( 'builder-front-end', $builder->plugin_url . 'css/front-end.css', false, $builder->version );

      // Front end RTL stylehseet
      wp_register_style( 'builder-rtl', $builder->plugin_url . 'css/rtl.css', false, $builder->version );

      // Front end JavaScript
      wp_register_script( 'builder-front-end', $builder->plugin_url . 'js/front-end.js', array( 'underscore', 'jquery', 'masonry' ), $builder->version );

      // Localize general admin media script
      wp_localize_script( 'builder-front-end', 'builderFrontEndLocalize', array(
         'slider_next_text' => __( 'Next slide', 'themefyre_builder' ),
         'slider_prev_text' => __( 'Previous slide', 'themefyre_builder' ),
         'slider_pager_button_text' => __( 'Go to slide %s', 'themefyre_builder' ),
      ) );
   }

   /**
    * Registers included CSS/JS assets with WordPress for admin use
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function admin_enqueue_scripts() {
      $builder = builder();

      // Codemirror stylesheet
      wp_register_style( 'builder-codemirror', $builder->plugin_url . 'css/codemirror.css', false, $builder->version );

      // Codemirror script
      wp_register_script( 'builder-codemirror', $builder->plugin_url . 'js/codemirror.min.js', null, $builder->version, true );

      // WP Editor Integration Script
      wp_register_script( 'builder-wp-editor', $builder->plugin_url.'js/wp-editor.js', array('jquery', 'underscore'), $builder->version, true );

      // General admin media script
      wp_register_script( 'builder-media', $builder->plugin_url.'js/media.js', array('jquery', 'underscore'), $builder->version, true );

      // Localize general admin media script
      wp_localize_script( 'builder-media', 'builderMediaLocalize', array(
         'attachment_frame_title'  => __( 'Select An Image', 'themefyre_builder' ),
         'attachment_frame_button' => __( 'Insert Image', 'themefyre_builder' ),
         'file_frame_title'        => __( 'Select An Image', 'themefyre_builder' ),
         'file_frame_button_text'  => __( 'Use this file', 'themefyre_builder' ),
      ) );

      // Admin modal stylesheet
      wp_register_style( 'builder-modal', $builder->plugin_url . 'css/modal.css', false, $builder->version );

      // Admin modal script
      wp_register_script( 'builder-modal', $builder->plugin_url . 'js/modal.js', array( 'jquery', 'underscore' ), $builder->version, true );

      // Localize admin modal script
      wp_localize_script( 'builder-modal', 'builderModalLocalize', array(
         'ajax_url'         => admin_url('admin-ajax.php'),
         'ajax_error'       => __( 'There was an error retrieving the content, please try again.', 'themefyre_builder' ),
         'ajax_logged_out'  => __( 'It seems your are no longer logged in. Please log in and try again.', 'themefyre_builder' ),
         'ajax_nonce_error' => __( 'Your session has timed out. Please reload the page and try again.', 'themefyre_builder' ),
         'open_error'       => __( 'An unkown error occured while attempting to open the modal. Please try again.', 'themefyre_builder' ),
         'close_error'      => __( 'An unkown error occured while attempting to close the modal. Please try again.', 'themefyre_builder' ),
      ));

      // Shortcode composer stylesheet
      wp_register_style( 'builder-interface', $builder->plugin_url . 'css/interface.css', false, $builder->version );

      // Page Builder script
      $dep = array( 'underscore', 'jquery', 'wp-color-picker', 'builder-modal', 'builder-codemirror', 'builder-wp-editor', 'builder-media' );
      wp_register_script( 'builder-interface', $builder->plugin_url . 'js/interface.js', $dep, $builder->version, true );

      // Localize page builder script
      wp_localize_script( 'builder-interface', 'builderLocalize', array(
         'ajax_url'                                => admin_url('admin-ajax.php'),
         'select_shortcode_title'                  => __( 'Select Shortcode', 'themefyre_builder' ),
         'select_icon_title'                       => __( 'Select Icon', 'themefyre_builder' ),
         'ajax_error'                              => __( 'There was an error retrieving the content, please try again.', 'themefyre_builder' ),
         'ajax_delete_post_error'                  => __( 'There was an error deleting the post, please try again.', 'themefyre_builder' ),
         'ajax_logged_out'                         => __( 'It seems your are no longer logged in. Please log in and try again.', 'themefyre_builder' ),
         'ajax_nonce_error'                        => __( 'Your session has timed out. Please reload the page and try again.', 'themefyre_builder' ),
         'edit_module_title'                       => __( 'Edit %s', 'themefyre_builder' ),
         'templates_modal_title'                   => __( 'Template Manager', 'themefyre_builder' ),
         'import_template_empty'                   => __( 'The page/post you are attempting to import does not have any valid content to load.', 'themefyre_builder' ),
         'edit_builder_css_title'                  => __( 'Custom CSS', 'themefyre_builder' ),
         'edit_builder_css_desc'                   => __( 'Custom CSS to be applied to this page/post only.', 'themefyre_builder' ),
         'add_new_row_module'                      => __( 'Add New Row Module', 'themefyre_builder' ),
         'add_new_full_width_module'               => __( 'Add New Full Width Module', 'themefyre_builder' ),
         'empty_canvas_delete'                     => __( 'There are currently no modules to delete.', 'themefyre_builder' ),
         'confirm_canvas_reset'                    => __( 'Are you sure you want to delete all modues and remove all custom CSS? This action can be undone.', 'themefyre_builder' ),
         'confirm_page_exit'                       => __( 'The changes you made will be lost if you navigate away from this page.', 'themefyre_builder' ),
         'confirm_delete_post'                     => __( 'Are you sure you wish to delete this template? This can not be undone.', 'themefyre_builder' ),
         'confirm_switch_inactive'                 => __( 'Are you sure you wish to return to the default editor? All page builder content for the current page/post will be lost upon saving changes.', 'themefyre_builder' ),
         'confirm_switch_active'                   => __( 'Are you sure you wish to switch to the page builder? Any preexisting content for the current page/post will be added to the page builder in a text module.', 'themefyre_builder' ),
         'preexisting_page_content_label'          => __( 'Preexisting Page Content', 'themefyre_builder' ),
         'short_template_name'                     => __( 'The name you have entered is too short. Please try again with a name that is at least 3 characters long.', 'themefyre_builder' ),
         'empty_canvas_save'                       => __( 'The current page is empty. Please try again when you have added at least one shortcode module.', 'themefyre_builder' ),
         'ajax_create_template_error'              => __( 'There was an error creating the template. Please try again later.', 'themefyre_builder' ),
         'get_attachment_error'                    => __( 'There was an error retrieving the selected image, please try again later.', 'themefyre_builder' ),
         'export_modal_title'                      => __( 'Export Page as Executable Shortcodes', 'themefyre_builder' ),
         'undo'                                    => __( 'Undo', 'themefyre_builder' ),
         'redo'                                    => __( 'Redo', 'themefyre_builder' ),
         'undo_with_replace'                       => __( 'Undo %s', 'themefyre_builder' ),
         'redo_with_replace'                       => __( 'Redo %s', 'themefyre_builder' ),
         'history_message_import_premade_template' => __( 'import premade template: %s', 'themefyre_builder' ),
         'history_message_import_saved_template'   => __( 'import saved template: %s', 'themefyre_builder' ),
         'history_message_import_page'             => __( 'import page/post: %s', 'themefyre_builder' ),
         'history_message_drag_module'             => __( 'drag module: %s', 'themefyre_builder' ),
         'history_message_add_module'              => __( 'add new module: %s', 'themefyre_builder' ),
         'history_message_duplicate_module'        => __( 'duplicate module: %s', 'themefyre_builder' ),
         'history_message_delete_module'           => __( 'delete module: %s', 'themefyre_builder' ),
         'history_message_move_module_up'          => __( 'move module up: %s', 'themefyre_builder' ),
         'history_message_move_module_down'        => __( 'move module down: %s', 'themefyre_builder' ),
         'history_message_move_module_to_top'      => __( 'move module to top: %s', 'themefyre_builder' ),
         'history_message_move_module_to_bottom'   => __( 'move module to bottom: %s', 'themefyre_builder' ),
         'history_message_edit_module'             => __( 'edit module: %s', 'themefyre_builder' ),
         'history_message_reset'                   => __( 'remove all modules', 'themefyre_builder' ),
         'history_message_modify_css'              => __( 'modify custom CSS', 'themefyre_builder' ),
         'history_message_page_load'               => __( 'page load', 'themefyre_builder' ),
         'import_css_comment'                      => __( 'CSS imported from page/post: %s', 'themefyre_builder' ),
         'import_css_saved_template_comment'       => __( 'CSS imported from saved template: %s', 'themefyre_builder' ),
         'css_imported_alert'                      => __( 'Custom CSS has been modified by the imported template.', 'themefyre_builder' ),
      ));
   }

}

/**
 * The main function responsible for returning the one true Themefyre_Builder Instance
 * to functions everywhere.
 *
 * Use this function like you would a global variable, except without needing
 * to declare the global.
 *
 * Example: <?php $builder = builder(); ?>
 *
 * @return The one true Themefyre_Builder Instance
 */
function builder() {
   return Themefyre_Builder::instance();
}

// And now here`s something we hope you'll really like!
builder();