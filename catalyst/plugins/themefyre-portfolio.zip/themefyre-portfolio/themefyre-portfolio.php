<?php

/**
 * Plugin Name: Themefyre Portfolio
 * Description: Minimal portfolio plugin built to work with select premium Themefyre WordPress themes.
 * Version: 0.0.0
 * Author: Themefyre
 * Author URI: http://themefyre.com
 *
 * Adding support for this plugin requires that the theme has
 * support for the included `project` post type. It is highly
 * recommended that the theme contains the following page templates:
 *
 * - archive-project.php
 * - single-project.php
 * - taxonomy-project_category.php
 *
 * It is also recommended that the `archive-project` template can
 * also handle project search results.
 *
 * @package WordPress
 * @subpackage Themefyre Portfolio
 * @author Themefyre
 * @since Themefyre Portfolio 0.0.0
 */

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Themefyre Portfolio Class
 *
 * Allows users to easily build a portfolio of their past projects.
 *
 * @package WordPress
 * @subpackage Themefyre Portfolio
 * @author Themefyre
 * @since Themefyre Portfolio 0.0.0
 */
final class Themefyre_Portfolio {

   /**
    * Themefyre Portfolio uses many variables, several of which can be filtered to
    * customize the way it operates. Most of these variables are stored in a
    * private array that gets updated with the help of PHP magic methods.
    *
    * This is a precautionary measure, to avoid potential errors produced by
    * unanticipated direct manipulation of Themefyre Portfolio's run-time data.
    *
    * @since Themefyre Portfolio 0.0.0
    * @access private
    * @var array
    */
   private $data = array();

   /**
    * Main Themefyre_Portfolio Instance
    *
    * Insures that only one instance of Themefyre_Portfolio exists in memory at
    * any one time. Also prevents needing to define globals all over the place.
    *
    * @since Themefyre Portfolio 0.0.0
    * @return The one true Themefyre_Portfolio
    */
   public static function instance() {

      // Store the instance locally to avoid private static replication
      static $instance = null;

      // Only run these methods if they haven't been ran previously
      if ( null === $instance ) {
         $instance = new Themefyre_Portfolio;
         $instance->globals();
         $instance->includes();
         $instance->add_actions();
      }

      // Always return the instance
      return $instance;
   }

   /**
    * A dummy constructor to prevent Themefyre_Portfolio from being loaded more than once.
    *
    * @see Themefyre_Portfolio::instance()
    * @see bbpress();
    *
    * @since Themefyre Portfolio 0.0.0
    */
   private function __construct() { /* Do nothing here */ }

   /**
    * A dummy magic method to prevent Themefyre_Portfolio from being cloned
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    */
   public function __clone() {
      _doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'themefyre_portfolio' ), '0.0.0' );
   }

   /**
    * A dummy magic method to prevent Themefyre_Portfolio from being unserialized
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    */
   public function __wakeup() {
      _doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'themefyre_portfolio' ), '0.0.0' );
   }

   /**
    * Magic method for checking the existence of a certain custom field
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    */
   public function __isset( $key ) {
      return isset( $this->data[$key] );
   }

   /**
    * Magic method for getting Themefyre_Portfolio variables
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    */
   public function __get( $key ) {
      return isset( $this->data[$key] ) ? $this->data[$key] : null;
   }

   /**
    * Magic method for setting Themefyre_Portfolio variables
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    */
   public function __set( $key, $value ) {
      $this->data[$key] = $value;
   }

   /**
    * Magic method for unsetting Themefyre_Portfolio variables
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    */
   public function __unset( $key ) {
      if ( isset( $this->data[$key] ) ) {
         unset( $this->data[$key] );
      }
   }

   /**
    * Include all required files.
    *
    * @since Themefyre Portfolio 0.0.0
    * @access private
    */
   private function includes() {
      require_once $this->includes_dir . 'class-portfolio-settings.php';
      require_once $this->includes_dir . 'functions.php';
      require_once $this->includes_dir . 'hooks.php';
      require_once $this->includes_dir . 'widgets.php';
   }

   /**
    * Set some smart defaults to class variables. Allow some of them to be
    * filtered to allow for early overriding.
    *
    * @since 0.0.0
    * @access private
    */
   private function globals() {

      // Version Number
      $this->version = '0.0.0';

      // Setup some base path and URL information
      $this->file       = __FILE__;
      $this->basename   = apply_filters( 'portfolio_plugin_basename', plugin_basename( $this->file ) );
      $this->plugin_dir = apply_filters( 'portfolio_plugin_dir_path', plugin_dir_path( $this->file ) );
      $this->plugin_url = apply_filters( 'portfolio_plugin_dir_url',  plugin_dir_url ( $this->file ) );

      // Includes
      $this->includes_dir = apply_filters( 'portfolio_includes_dir', trailingslashit( $this->plugin_dir . 'includes'  ) );
      $this->includes_url = apply_filters( 'portfolio_includes_url', trailingslashit( $this->plugin_url . 'includes'  ) );

      // Languages
      $this->lang_dir = apply_filters( 'portfolio_lang_dir', trailingslashit( $this->plugin_dir . 'lang' ) );
   }

   /**
    * Registers initial setup actions with WordPress
    *
    * @since Themefyre Portfolio 0.0.0
    * @access private
    */
   private function add_actions() {
      add_action( 'init', array( $this, 'register_post_type' ) );
      add_action( 'plugins_loaded', array( $this, 'plugins_loaded' ), 5 );
      add_action('pre_get_posts', array( $this, 'pre_get_posts' ) );
      add_action( 'template_redirect', array( $this, 'template_redirect' ) );
      add_action( 'template_include', array( $this, 'template_include' ) );
      add_filter( 'wp_title', array( $this, 'wp_title' ), 10, 3 );
      add_filter( 'project_post_type_args', array( $this, 'custom_post_type_args' ), 10 );
      add_filter( 'portfolio_category_taxonomy_args', array( $this, 'custom_taxonomy_args' ), 10 );

      // Called once upon plugin activation.
      register_activation_hook( __FILE__, array( $this, 'activate' ) );

      // Flush rewrite rules again upon theme deactivation.
      register_deactivation_hook( __FILE__, array( $this, 'deactivate' ) );
   }

   /**
    * Loads the plugins text domain
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    */
   public function plugins_loaded() {
      load_plugin_textdomain( 'themefyre_portfolio', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );
   }

   /**
    * Registers the `project` post type with WordPress
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    */
   public function register_post_type() {
      $labels = array(
         'name'               => __( 'Projects', 'themefyre_portfolio' ),
         'singular_name'      => __( 'Project', 'themefyre_portfolio' ),
         'all_items'          => __( 'All Projects', 'themefyre_portfolio' ),
         'add_new_item'       => __( 'Add New Project', 'themefyre_portfolio' ),
         'edit_item'          => __( 'Edit Project', 'themefyre_portfolio' ),
         'new_item'           => __( 'New Project', 'themefyre_portfolio' ),
         'view_item'          => __( 'View Project', 'themefyre_portfolio' ),
         'search_items'       => __( 'Search Projects', 'themefyre_portfolio' ),
         'not_found'          => __( 'No projects found', 'themefyre_portfolio' ),
         'not_found_in_trash' => __( 'No projects found in trash', 'themefyre_portfolio' ),
      );

      $args = array(
         'labels'      => $labels,
         'description' => __( 'This is where you can add new projects to your portfolio.', 'themefyre_portfolio' ),
         'public'      => true,
         'menu_icon'   => 'dashicons-portfolio',
         'supports'    => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'comments' ),
         'has_archive' => 'projects',
         'rewrite'     => array(
            'slug' => 'project',
         ),
      );

      register_post_type( 'project', apply_filters( 'project_post_type_args', $args ) );

      $labels = array(
         'name'          => _x( 'Project Categories', 'taxonomy general name', 'themefyre_portfolio' ),
         'singular_name' => _x( 'Project Category', 'taxonomy singular name', 'themefyre_portfolio' ),
         'menu_name'     => __( 'Categories', 'themefyre_portfolio' ),
      );

      $args = array(
         'labels'       => $labels,
         'hierarchical' => true,
         'show_admin_column' => true,
         'rewrite'      => array(
            'slug'       => 'projects',
            'with_front' => false
         ),
      );

      register_taxonomy( 'project_category', 'project', apply_filters( 'portfolio_category_taxonomy_args', $args ) );
   }

   /**
    * Allows the user to select any page to serve as their portfolio
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    *
    * @param array $args The existing args for the project post type
    * @return string
    */
   public function custom_post_type_args( $args ) {
      if ( get_option('portfolio_project_slug') ) {
         $args['rewrite']['slug'] = get_option('portfolio_project_slug');
      }
      if ( $portfolio_page_uri = get_portfolio_page_uri() ) {
         $args['has_archive'] = $portfolio_page_uri;
      }
      else if ( get_option('portfolio_slug') ) {
         $args['has_archive'] = get_option('portfolio_slug');
      }
      return $args;
   }

   /**
    * Allows the user to select any page to serve as their portfolio
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    *
    * @param array $args The existing args for the project category taxonomy
    * @return string
    */
   public function custom_taxonomy_args( $args ) {
      if ( $portfolio_page_uri = get_portfolio_page_uri() ) {
         $args['rewrite']['slug'] = $portfolio_page_uri;
      }
      else if ( get_option('portfolio_slug') ) {
         $args['rewrite']['slug'] = get_option('portfolio_slug');
      }
      return $args;
   }

   /**
    * Allows the user to change the number of projects per page
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    *
    * @param mixed $query Query object
    */
   public function pre_get_posts( $query ) {
      // We only want to affect the main query
      if ( ! $query->is_main_query() ) {
         return;
      }

      // We only want to affect portfolio project archives
      if ( ! $query->is_post_type_archive( 'project' ) && ! $query->is_tax( get_object_taxonomies( 'project' ) ) ) {
         return;
      }

      // Change number of posts per page
      if ( $per_page = get_option('portfolio_per_page') ) {
         $query->set( 'posts_per_page', $per_page );
      }

      // Makes sure this is not called again
      remove_action( 'pre_get_posts', array( $this, 'pre_get_posts' ) );
   }

   /**
    * Allows the portfolio page to be set as the front page.
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    *
    * @uses is_portfolio_show_on_front()
    * @uses get_portfolio_page_permalink()
    */
   public function template_redirect() {
      if ( is_portfolio_show_on_front() && is_front_page() ) {
         wp_safe_redirect( get_portfolio_page_permalink() );
      }
   }

   /**
    * Use the project archive template for project search results
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    *
    * @param string $template The template currently being used
    * @return string
    */
   public function template_include( $template ) {
      global $wp_query;
      if ( $wp_query->is_search && 'project' == get_query_var('post_type') && $archive_template = locate_template('archive-project.php') ) {
         $template = $archive_template;
      }
      return $template;
   }

   /**
    * Modify the output of `wp_title` for certain portfolio related pages.
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    *
    * @param string $title Current title value
    * @param string $sep Title parts separator
    * @param string $sep_location Location of the separator
    * @return string
    */
   public function wp_title( $title, $sep, $sep_location ) {
      if ( ! get_theme_support( 'title-tag' ) || ! is_portfolio() || is_project() || is_project_search() || ! ( $portfolio_id = get_portfolio_page_id() ) || ! ( $portfolio_page = get_post( $portfolio_id ) ) ) {
         return $title;
      }

      // Project category taxonomy page
      if ( is_project_category() && ( $term = get_queried_object() ) ) {
         $title = $term->name . " $sep " . get_the_title( $portfolio_page ) . " $sep " . get_bloginfo( 'name', 'display' );
      }

      // Project post type archive page
      else {
         $title = get_the_title( $portfolio_page ) . " $sep " . get_bloginfo( 'name', 'display' );
      }

      return $title;
   }

   /**
    * Called upon plugin activation
    *
    * This function`s intented purpose is to flush the rewrite rules
    * after the new pos type has been registered with WordPress.
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    */
   public function activate() {
      $this->register_post_type();
      flush_rewrite_rules();
   }

   /**
    * Called upon plugin deactivation
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    */
   public function deactivate() {
      flush_rewrite_rules();
   }

}

/**
 * The main function responsible for returning the one true Themefyre_Portfolio Instance
 * to functions everywhere.
 *
 * Use this function like you would a global variable, except without needing
 * to declare the global.
 *
 * Example: <?php $portfolio = portfolio(); ?>
 *
 * @return The one true Themefyre_Portfolio Instance
 */
function portfolio() {
   return Themefyre_Portfolio::instance();
}

// And now here`s something we hope you'll really like!
portfolio();