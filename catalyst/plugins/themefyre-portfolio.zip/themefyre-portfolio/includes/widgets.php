<?php

if ( ! function_exists('portfolio_widgets_init') ) :
/**
 * Registers all included widgets with WordPress
 *
 * @since Themefyre Portfolio 0.0.0
 */
function portfolio_widgets_init() {
   register_widget( 'Portfolio_Widget_Search' );
   register_widget( 'Portfolio_Widget_Project_Categories' );
   register_widget( 'Portfolio_Widget_Recent_Projects' );
}
add_action( 'widgets_init', 'portfolio_widgets_init' );
endif;

/**
 * Portfolio search widget
 *
 * @package WordPress
 * @subpackage Themefyre Portfolio
 * @author Themefyre
 * @since Themefyre Portfolio 0.0.0
 */
class Portfolio_Widget_Search extends WP_Widget {

   /**
    * Portfolio_Widget_Search class constructor.
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    */
   public function __construct() {
      $widget_ops = array(
         'classname'   => 'widget_portfolio_search',
         'description' => sprintf( __( 'A search form for your %s projects only.', 'themefyre_portfolio' ), 'Themefyre Portfolio' ),
      );
      parent::__construct( 'portfolio_search', __( 'Search Projects', 'themefyre_portfolio' ), $widget_ops );
   }

   /**
    * Front-end display of widget.
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    *
    * @see WP_Widget::widget()
    *
    * @param array $args Widget arguments.
    * @param array $instance Saved values from database.
    */
   public function widget( $args, $instance ) {
      $title = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

      echo $args['before_widget'];

      if ( $title ) {
         echo $args['before_title'] . $title . $args['after_title'];
      }

      project_search_form();

      echo $args['after_widget'];
   }

   /**
    * Back-end widget form.
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    *
    * @see WP_Widget::form()
    *
    * @param array $instance Previously saved values from database.
    */
   public function form( $instance ) {
      $instance = wp_parse_args( (array) $instance, array( 'title' => '') );
      $title = $instance['title'];
      ?>
         <p>
            <label for="<?php echo $this->get_field_id('title'); ?>">
               <?php _e('Title:', 'themefyre_portfolio'); ?>
               <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
            </label>
         </p>
      <?php
   }

   /**
    * Sanitize widget form values as they are saved.
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    *
    * @see WP_Widget::update()
    *
    * @param array $new_instance Values just sent to be saved.
    * @param array $old_instance Previously saved values from database.
    * @return array Updated safe values to be saved.
    */
   public function update( $new_instance, $old_instance ) {
      $instance = $old_instance;
      $instance['title'] = empty( $new_instance['title'] ) ? '' : strip_tags( $new_instance['title'] );
      return $instance;
   }
}

/**
 * Project Categories Widget
 *
 * @package WordPress
 * @subpackage Themefyre Portfolio
 * @author Themefyre
 * @since Themefyre Portfolio 0.0.0
 */
class Portfolio_Widget_Project_Categories extends WP_Widget {

   /**
    * Portfolio_Widget_Project_Categories class constructor.
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    */
   public function __construct() {
      $widget_ops = array(
         'classname'   => 'widget_project_categories',
         'description' => sprintf( __( 'A list of your %s project categories.', 'themefyre_portfolio' ), 'Themefyre Portfolio' ),
      );
      parent::__construct( 'portfolio_categories', __( 'Project Categories', 'themefyre_portfolio' ), $widget_ops );
   }

   /**
    * Front-end display of widget.
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    *
    * @see WP_Widget::widget()
    *
    * @param array $args Widget arguments.
    * @param array $instance Saved values from database.
    */
   public function widget( $args, $instance ) {
      $title = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

      echo $args['before_widget'];

      if ( $title ) {
         echo $args['before_title'] . $title . $args['after_title'];
      }

      $list_args = array(
         'taxonomy'     => 'project_category',
         'orderby'      => 'name',
         'show_count'   => ! empty( $instance['count'] ),
         'hierarchical' => ! empty( $instance['hierarchical'] ),
         'title_li'     => '',
      );

      echo '<ul>';
      wp_list_categories( apply_filters( 'widget_project_categories_args', $list_args ) );
      echo '</ul>';

      echo $args['after_widget'];
   }

   /**
    * Back-end widget form.
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    *
    * @see WP_Widget::form()
    *
    * @param array $instance Previously saved values from database.
    */
   public function form( $instance ) {
      $instance = wp_parse_args( (array) $instance, array( 'title' => '') );
      $title = esc_attr( $instance['title'] );
      $count = isset( $instance['count'] ) ? (bool) $instance['count'] : false;
      $hierarchical = isset( $instance['hierarchical'] ) ? (bool) $instance['hierarchical'] : false;
      ?>
         <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e( 'Title:', 'themefyre_portfolio' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
         </p>
         <p>
            <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id('count'); ?>" name="<?php echo $this->get_field_name('count'); ?>"<?php checked( $count ); ?> />
            <label for="<?php echo $this->get_field_id('count'); ?>"><?php _e( 'Show post counts', 'themefyre_portfolio' ); ?></label>
            <br />
            <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id('hierarchical'); ?>" name="<?php echo $this->get_field_name('hierarchical'); ?>"<?php checked( $hierarchical ); ?> />
            <label for="<?php echo $this->get_field_id('hierarchical'); ?>"><?php _e( 'Show hierarchy', 'themefyre_portfolio' ); ?></label>
         </p>
      <?php
   }

   /**
    * Sanitize widget form values as they are saved.
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    *
    * @see WP_Widget::update()
    *
    * @param array $new_instance Values just sent to be saved.
    * @param array $old_instance Previously saved values from database.
    * @return array Updated safe values to be saved.
    */
   public function update( $new_instance, $old_instance ) {
      $instance = $old_instance;
      $instance['title'] = strip_tags( $new_instance['title'] );
      $instance['count'] = ! empty( $new_instance['count'] );
      $instance['hierarchical'] = ! empty( $new_instance['hierarchical'] );
      return $instance;
   }
}

/**
 * Recent Projects Widget
 *
 * @package WordPress
 * @subpackage Themefyre Portfolio
 * @author Themefyre
 * @since Themefyre Portfolio 0.0.0
 */
class Portfolio_Widget_Recent_Projects extends WP_Widget {

   /**
    * Portfolio_Widget_Recent_Projects class constructor.
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    */
   public function __construct() {
      $widget_ops = array(
         'classname'   => 'widget_recent_entries widget_recent_projects',
         'description' => sprintf( __( 'Your site&#8217;s most recent Projects.', 'themefyre_portfolio' ), 'Themefyre Portfolio' ),
      );
      parent::__construct( 'portfolio_recent_posts', __( 'Recent Projects', 'themefyre_portfolio' ), $widget_ops );

      add_action( 'save_post', array( $this, 'flush_widget_cache' ) );
      add_action( 'deleted_post', array( $this, 'flush_widget_cache' ) );
      add_action( 'switch_theme', array( $this, 'flush_widget_cache' ) );
   }

   /**
    * Front-end display of widget.
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    *
    * @see WP_Widget::widget()
    *
    * @param array $args Widget arguments.
    * @param array $instance Saved values from database.
    */
   public function widget( $args, $instance ) {
      $cache = array();
      if ( ! $this->is_preview() ) {
         $cache = wp_cache_get( 'portfolio_widget_recent_projects', 'widget' );
      }

      if ( ! is_array( $cache ) ) {
         $cache = array();
      }

      if ( ! isset( $args['widget_id'] ) ) {
         $args['widget_id'] = $this->id;
      }

      if ( isset( $cache[ $args['widget_id'] ] ) ) {
         echo $cache[ $args['widget_id'] ];
         return;
      }

      ob_start();

      $title = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );


      $number = ! empty( $instance['number'] ) ? absint( $instance['number'] ) : 5;
      if ( ! $number ) {
         $number = 5;
      }
      $show_date = isset( $instance['show_date'] ) ? (bool) $instance['show_date'] : false;

      $query = new WP_Query( apply_filters( 'portfolio_widget_recent_projects_query_args', array(
         'posts_per_page'      => $number,
         'no_found_rows'       => true,
         'post_status'         => 'publish',
         'ignore_sticky_posts' => true,
         'post_type'           => 'project',
      ) ) );

      if ( $query->have_posts() ) :
         echo $args['before_widget'];

         if ( $title ) {
            echo $args['before_title'] . $title . $args['after_title'];
         }

         echo '<ul>';

         while ( $query->have_posts() ) : $query->the_post();
            ?>
               <li>
                  <a href="<?php the_permalink(); ?>"><?php get_the_title() ? the_title() : the_ID(); ?></a>
                  <?php if ( $show_date ) : ?>
                     <span class="post-date"><?php echo get_the_date(); ?></span>
                  <?php endif; ?>
               </li>
            <?php
         endwhile;

         echo '</ul>';

         echo $args['after_widget'];

         // Reset the global $the_post as this query will have stomped on it
         wp_reset_postdata();
      endif;

      if ( ! $this->is_preview() ) {
         $cache[ $args['widget_id'] ] = ob_get_flush();
         wp_cache_set( 'portfolio_widget_recent_projects', $cache, 'widget' );
      }

      else {
         ob_end_flush();
      }
   }

   /**
    * Back-end widget form.
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    *
    * @see WP_Widget::form()
    *
    * @param array $instance Previously saved values from database.
    */
   public function form( $instance ) {
      $title     = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
      $number    = isset( $instance['number'] ) && $instance['number'] ? absint( $instance['number'] ) : 5;
      $show_date = isset( $instance['show_date'] ) ? (bool) $instance['show_date'] : false;
      ?>
         <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'themefyre_portfolio' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" />
         </p>
         <p>
            <label for="<?php echo $this->get_field_id( 'number' ); ?>"><?php _e( 'Number of posts to show:', 'themefyre_portfolio' ); ?></label>
            <input id="<?php echo $this->get_field_id( 'number' ); ?>" name="<?php echo $this->get_field_name( 'number' ); ?>" type="text" value="<?php echo $number; ?>" size="3" />
         </p>
         <p>
            <input class="checkbox" type="checkbox" <?php checked( $show_date ); ?> id="<?php echo $this->get_field_id( 'show_date' ); ?>" name="<?php echo $this->get_field_name( 'show_date' ); ?>" />
            <label for="<?php echo $this->get_field_id( 'show_date' ); ?>"><?php _e( 'Display post date?', 'themefyre_portfolio' ); ?></label>
         </p>
      <?php
   }

   /**
    * Sanitize widget form values as they are saved.
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    *
    * @see WP_Widget::update()
    *
    * @param array $new_instance Values just sent to be saved.
    * @param array $old_instance Previously saved values from database.
    * @return array Updated safe values to be saved.
    */
   public function update( $new_instance, $old_instance ) {
      $instance = $old_instance;
      $instance['title'] = strip_tags( $new_instance['title'] );
      $instance['number'] = absint( $new_instance['number'] );
      $instance['show_date'] = isset( $new_instance['show_date'] ) ? (bool) $new_instance['show_date'] : false;
      $this->flush_widget_cache();
      return $instance;
   }

   /**
    * Flushes the cached variations of this widget
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    */
   public function flush_widget_cache() {
      wp_cache_delete( 'portfolio_widget_recent_projects', 'widget' );
   }
}