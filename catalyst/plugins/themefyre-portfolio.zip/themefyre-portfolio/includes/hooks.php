<?php

/**
 * Themefyre Portoflio Actions & Filters.
 *
 * @package WordPress
 * @subpackage Themefyre Portfolio
 * @author Themefyre
 * @since Themefyre Portfolio 0.0.0
 */

// No direct access
defined( 'ABSPATH' ) or exit;

// Global configuration
$portfolio = portfolio();

/**
 * Add custom links to the plugin action links in WP admin.
 */
add_filter( 'plugin_action_links_' . $portfolio->basename, 'portfolio_action_links' );