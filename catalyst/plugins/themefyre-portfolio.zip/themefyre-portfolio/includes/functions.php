<?php

/**
 * Themefyre Portfolio Functions.
 *
 * @package WordPress
 * @subpackage Themefyre Portfolio
 * @author Themefyre
 * @since Themefyre Portfolio 0.0.0
 */

// No direct access
defined( 'ABSPATH' ) or exit;

/**
 * Add custom links to the plugin action links in WP admin.
 *
 * @since Themefyre Portfolio 0.0.0
 *
 * @return array
 */
function portfolio_action_links( $links ) {
   $links[] = '<a href="'.get_admin_url(null, 'options-general.php?page=portfolio-settings').'">'.esc_attr__('Settings', 'themefyre_portfolio').'</a>';
   return $links;
}

if ( ! function_exists('get_portfolio_page_id') ) :
/**
 * Returns the ID of the page the portfolio was assigned to.
 *
 * @since Themefyre Portfolio 0.0.0
 *
 * @return string|int
 */
function get_portfolio_page_id() {
   return apply_filters( 'get_portfolio_page_id', get_option('portfolio_page_id') );
}
endif;

if ( ! function_exists('get_portfolio_page_uri') ) :
/**
 * Returns the URI of the page the portfolio was assigned to.
 *
 * @since Themefyre Portfolio 0.0.0
 *
 * @return string
 */
function get_portfolio_page_uri() {
   return apply_filters( 'get_portfolio_page_uri', get_page_uri( get_portfolio_page_id() ) );
}
endif;

if ( ! function_exists('get_portfolio_page_permalink') ) :
/**
 * Returns the permalink for the portfolio page.
 *
 * @since Themefyre Portfolio 0.0.0
 *
 * @return string
 */
function get_portfolio_page_permalink() {
   return apply_filters( 'get_portfolio_page_permalink', get_post_type_archive_link('project') );
}
endif;

if ( ! function_exists('portfolio_page_permalink') ) :
/**
 * Prints the permalink for the portfolio page.
 *
 * @since Themefyre Portfolio 0.0.0
 *
 * @uses get_portfolio_page_permalink()
 *
 * @return string
 */
function portfolio_page_permalink() {
   echo get_portfolio_page_permalink();
}
endif;

if ( ! function_exists('is_portfolio_show_on_front') ) :
/**
 * Conditional, returns true when the portfolio page is also set to the home page.
 *
 * @since Themefyre Portfolio 0.0.0
 *
 * @return bool
 */
function is_portfolio_show_on_front() {
   return apply_filters( 'is_portfolio_show_on_front', 'page' == get_option( 'show_on_front' ) && ( $page_on_front = get_option( 'page_on_front' ) ) && ( $portfolio_page = get_portfolio_page_id() ) && $page_on_front === $portfolio_page );
}
endif;

if ( ! function_exists('is_project') ) :
/**
 * Conditional, returns true when viewing a single project page.
 *
 * @since Themefyre Portfolio 0.0.0
 *
 * @return bool
 */
function is_project() {
   return apply_filters( 'is_project', is_singular() && 'project' === get_post_type() );
}
endif;

if ( ! function_exists('is_project_category') ) :
/**
 * Conditional, returns true when viewing a project category archive.
 *
 * @since Themefyre Portfolio 0.0.0
 *
 * @return bool
 */
function is_project_category() {
   return apply_filters( 'is_project_category', is_tax( 'project_category' ) );
}
endif;

if ( ! function_exists('is_project_search') ) :
/**
 * Conditional, returns true when viewing project search results
 *
 * @since Themefyre Portfolio 0.0.0
 *
 * @return bool
 */
function is_project_search() {
   return apply_filters( 'is_project_search', is_post_type_archive( 'project' ) && is_search() );
}
endif;

if ( ! function_exists('is_portfolio') ) :
/**
 * Conditional, returns true when viewing a portfolio related page.
 *
 * @since Themefyre Portfolio 0.0.0
 *
 * @return bool
 */
function is_portfolio() {
   return apply_filters( 'is_portfolio', is_post_type_archive( 'project' ) || is_project_category() || is_project() );
}
endif;

if ( ! function_exists('get_project_search_form') ) :
/**
 * Gets the search form for searching projects.
 *
 * @since Themefyre Portfolio 0.0.0
 *
 * @return string
 */
function get_project_search_form() {
   ob_start(); ?>
      <form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
         <label>
            <span class="screen-reader-text"><?php esc_attr_e( 'Search for:', 'themefyre_portfolio' ); ?></span>
            <input type="search" class="search-field" placeholder="<?php esc_attr_e( 'Search Projects&hellip;', 'themefyre_portfolio' ); ?>" value="<?php echo get_search_query(); ?>" name="s" title="<?php esc_attr_e( 'Search for:', 'themefyre_portfolio' ); ?>" />
         </label>
         <input type="submit" class="search-submit" value="<?php esc_attr_e( 'Search', 'themefyre_portfolio' ); ?>" />
         <input type="hidden" name="post_type" value="project" />
      </form>
   <?php
   return apply_filters( 'get_project_search_form', ob_get_clean() );
}
endif;

if ( ! function_exists('project_search_form') ) :
/**
 * Prints the search form for searching projects.
 *
 * @since Themefyre Portfolio 0.0.0
 *
 * @uses get_project_search_form()
 */
function project_search_form() {
   echo get_project_search_form();
}
endif;