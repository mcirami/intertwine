<?php

// No direct access
defined( 'ABSPATH' ) or exit;

// Immediately invoke this class
if ( is_admin() ) {
   new Portfolio_Settings();
}

/**
 * The settings page for our plugin.
 *
 * @package WordPress
 * @subpackage Themefyre Portfolio
 * @author Themefyre
 * @since Themefyre Portfolio 0.0.0
 */
final class Portfolio_Settings {

   /**
    * Builder_Settings class constructor.
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    */
   public function __construct() {
      add_option( 'portfolio_page_id' );
      add_option( 'portfolio_per_page' );
      add_option( 'portfolio_slug' );
      add_option( 'portfolio_project_slug' );

      add_action( 'admin_menu', array( $this, 'add_options_page' ) );
      add_action( 'admin_init', array( $this, 'add_settings_sections' ) );
      add_action( 'admin_init', array( $this, 'add_settings_fields' ) );
      add_action( 'admin_init', array( $this, 'register_settings' ) );
   }

   /**
    * Add options page
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    */
   public function add_options_page() {
      add_options_page(
         sprintf( __( '%s Settings', 'themefyre_portfolio' ), 'Themefyre Portfolio' ),
         __( 'Portfolio', 'themefyre_portfolio' ),
         'manage_options',
         'portfolio-settings',
         array( $this, 'page_callback' )
      );
   }

   /**
    * Add the appropriate settings sections
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    */
   public function add_settings_sections() {
      add_settings_section(
         'general',
         '', // No title for first section
         '', // No callback for displaying the description
         'portfolio-settings'
      );

      add_settings_section(
         'permalinks',
         __( 'Permalinks', 'themefyre_portfolio' ),
         array( $this, 'permalinks_section_callback' ),
         'portfolio-settings'
      );
   }

   /**
    * Callback for the google_fonts_manager options section.
    *
    * @since Themefyre Page Builder 0.0.0
    * @access public
    */
   public function permalinks_section_callback() {
      ?>
         <p><?php esc_html_e('Use the below controls to customize the permalink structure for your projects. Please note that these options are only applicable while pretty permalinks are enabled.', 'themefyre_portfolio'); ?></p>
      <?php
   }

   /**
    * Registers the page builder fields with WordPress.
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    */
   public function add_settings_fields() {
      add_settings_field(
         'portfolio_page_id',
         __( 'Portfolio Page', 'themefyre_portfolio' ),
         array( $this, 'portfolio_page_id_callback' ),
         'portfolio-settings',
         'general'
      );

      add_settings_field(
         'portfolio_per_page',
         __( 'Projects Per Page', 'themefyre_portfolio' ),
         array( $this, 'portfolio_per_page_callback' ),
         'portfolio-settings',
         'general'
      );

      add_settings_field(
         'portfolio_slug',
         __( 'Default Project Archives Slug', 'themefyre_portfolio' ),
         array( $this, 'portfolio_slug_callback' ),
         'portfolio-settings',
         'permalinks'
      );

      add_settings_field(
         'portfolio_project_slug',
         __( 'Single Project Slug Prefix', 'themefyre_portfolio' ),
         array( $this, 'portfolio_project_slug_callback' ),
         'portfolio-settings',
         'permalinks'
      );
   }

   /**
    * Registers the page builder settings with WordPress.
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    */
   public function register_settings() {
      register_setting( 'portfolio-settings', 'portfolio_page_id', array( $this, 'update_portfolio_page_id' ) );
      register_setting( 'portfolio-settings', 'portfolio_per_page', array( $this, 'update_portfolio_per_page' ) );
      register_setting( 'portfolio-settings', 'portfolio_slug', array( $this, 'update_portfolio_slug' ) );
      register_setting( 'portfolio-settings', 'portfolio_project_slug', array( $this, 'update_portfolio_project_slug' ) );
   }

   /**
    * Sanitize the portfolio page ID value
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    *
    * @param int $page_id The submitted value
    * @return int
    */
   public function update_portfolio_page_id( $page_id ) {
      if ( ! empty( $page_id ) ) {
         $page_id = absint( $page_id );
      }
      return $page_id;
   }

   /**
    * Sanitize the projects per page value
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    *
    * @param int $per_page The submitted value
    * @return int
    */
   public function update_portfolio_per_page( $per_page ) {
      if ( ! empty( $per_page ) ) {
         $per_page = absint( $per_page );
      }
      return $per_page;
   }

   /**
    * Sanitize the portfolio slug value
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    *
    * @param int $portfolio_slug The submitted value
    * @return int
    */
   public function update_portfolio_slug( $portfolio_slug ) {
      if ( ! empty( $portfolio_slug ) ) {
         $portfolio_slug = sanitize_title_with_dashes( $portfolio_slug );
      }
      return $portfolio_slug;
   }

   /**
    * Sanitize the portfolio project slug value
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    *
    * @param int $portfolio_project_slug The submitted value
    * @return int
    */
   public function update_portfolio_project_slug( $portfolio_project_slug ) {
      if ( ! empty( $portfolio_project_slug ) ) {
         $portfolio_project_slug = sanitize_title_with_dashes( $portfolio_project_slug );
      }
      return $portfolio_project_slug;
   }

   /**
    * Print the field for updating the Portfolio Page value
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    */
   public function portfolio_page_id_callback() {
      $args = array(
         'name' => 'portfolio_page_id',
         'show_option_none' => __( '(no page selected)', 'themefyre_portfolio' ),
         'selected' => get_option('portfolio_page_id'),
      );

      wp_dropdown_pages( $args );

      printf( '<p class="description">%s</p>', sprintf( wp_kses( __( 'Select which page should serve as your portfolio.<br /><strong>Your portfolio is currently located here: <a href="%1$s">%1$s</a></strong>', 'themefyre_portfolio' ), array('a'=>array('href'=>array()),'strong'=>array(),'br'=>array()) ), get_portfolio_page_permalink() ) );
   }

   /**
    * Print the field for updating the projects per page value
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    */
   public function portfolio_per_page_callback() {
      $actual_value = get_option('portfolio_per_page') ? get_option('portfolio_per_page') : get_option('posts_per_page');
      printf( '<input type="number" value="%1$s" name="portfolio_per_page" placeholder="%2$s" />', get_option('portfolio_per_page'), esc_attr__('(same as blog)', 'themefyre_portfolio' ) );
      printf( '<p class="description">%s</p>', sprintf( wp_kses( __( 'Maximum number of projects shown per page.<br /><strong>Current number of projects per page: %s</strong>', 'themefyre_portfolio' ), array('strong'=>array(),'br'=>array()) ), $actual_value ) );
   }

   /**
    * Print the field for updating the projects per page value
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    */
   public function portfolio_slug_callback() {
      printf( '<input type="text" value="%1$s" name="portfolio_slug" placeholder="%2$s" />', get_option('portfolio_slug'), 'projects' );
      printf( '<p class="description">%s</p>', esc_html__( 'Selecting a page to serve as your portfolio above will override this option using the selected page\'s slug.', 'themefyre_portfolio' ) );
   }

   /**
    * Print the field for updating the projects per page value
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
    */
   public function portfolio_project_slug_callback() {
      $actual_value = get_option('portfolio_project_slug') ? get_option('portfolio_project_slug') : 'project';
      printf( '<input type="text" value="%1$s" name="portfolio_project_slug" placeholder="%2$s" />', get_option('portfolio_project_slug'), 'project' );
      printf( '<p class="description">%s</p>', sprintf( wp_kses( __( 'Custom text to be prepended to the URL of single project pages.<br />This value <strong>must</strong> be different from the value of the default project archives slug above.<br /><strong>Currently project URL\'s will appear similar to the following:</strong> %1$s', 'themefyre_portfolio' ), array('strong'=>array(),'br'=>array())), trailingslashit(get_home_url()).'<strong>'.$actual_value.'</strong>/some-single-slug/' ) );
   }

   /**
   * Options page callback
    *
    * @since Themefyre Portfolio 0.0.0
    * @access public
   */
   public function page_callback() {
      flush_rewrite_rules(); ?>
         <div class="wrap">
            <h2><?php printf( esc_html__( '%s Settings', 'themefyre_portfolio' ), 'Themefyre Portfolio' ); ?></h2>
            <form method="post" action="options.php">
               <?php settings_fields( 'portfolio-settings' ); ?>
               <?php do_settings_sections( 'portfolio-settings' ); ?>
               <?php submit_button(); ?>
            </form>
         </div>
      <?php
   }
}